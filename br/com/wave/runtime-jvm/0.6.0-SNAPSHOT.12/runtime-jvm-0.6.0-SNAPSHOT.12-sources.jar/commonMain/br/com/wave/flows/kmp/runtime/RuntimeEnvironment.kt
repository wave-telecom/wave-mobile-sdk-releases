package br.com.wave.flows.kmp.runtime

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.datetime.Clock

interface RuntimeDispatchers {
    val io: CoroutineDispatcher
}

object DefaultRuntimeDispatchers : RuntimeDispatchers {
    override val io: CoroutineDispatcher = Dispatchers.Default
}

interface RuntimeClock {
    fun nowMillis(): Long
}

object SystemRuntimeClock : RuntimeClock {
    override fun nowMillis(): Long = Clock.System.now().toEpochMilliseconds()
}

interface RuntimeLogger {
    fun debug(message: String)
    fun info(message: String)
    fun warn(message: String)
    fun error(message: String, throwable: Throwable? = null)
}

object NoOpRuntimeLogger : RuntimeLogger {
    override fun debug(message: String) = Unit
    override fun info(message: String) = Unit
    override fun warn(message: String) = Unit
    override fun error(message: String, throwable: Throwable?) = Unit
}
