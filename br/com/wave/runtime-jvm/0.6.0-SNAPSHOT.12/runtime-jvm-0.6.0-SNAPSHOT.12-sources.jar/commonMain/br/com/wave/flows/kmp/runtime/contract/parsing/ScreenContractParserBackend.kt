package br.com.wave.flows.kmp.runtime.contract.parsing

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.contract.dto.ScreenContractDto
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.mapping.support.NoOpContractAnomalyReporter
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

internal interface ScreenContractParserBackend {
    fun parse(
        json: String,
        reporter: ContractAnomalyReporter = NoOpContractAnomalyReporter,
    ): ScreenContract

    fun parse(
        root: JsonObject,
        reporter: ContractAnomalyReporter = NoOpContractAnomalyReporter,
    ): ScreenContract
}

internal object DtoScreenContractParserBackend : ScreenContractParserBackend {
    private val contractJson = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    override fun parse(
        json: String,
        reporter: ContractAnomalyReporter,
    ): ScreenContract {
        val root = normalizeLegacyScreenContractRoot(contractJson.parseToJsonElement(json).jsonObject)
        val dto = contractJson.decodeFromJsonElement(ScreenContractDto.serializer(), root)
        return dto.toScreenContract(reporter, contractJson)
    }

    override fun parse(
        root: JsonObject,
        reporter: ContractAnomalyReporter,
    ): ScreenContract {
        val dto = contractJson.decodeFromJsonElement(
            ScreenContractDto.serializer(),
            normalizeLegacyScreenContractRoot(root),
        )
        return dto.toScreenContract(reporter, contractJson)
    }

    private fun normalizeLegacyScreenContractRoot(root: JsonObject): JsonObject {
        if ("blocks" in root || "root" in root) return root
        if ("type" !in root) return root

        return buildJsonObject {
            root["id"]?.let { put("id", it) }
            put("blocks", root)
        }
    }
}

internal object DefaultScreenContractParserBackend : ScreenContractParserBackend by DtoScreenContractParserBackend
