package br.com.wave.flows.kmp.runtime.api

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.runtime.contract.parseScreenContract
import br.com.wave.flows.kmp.runtime.DefaultRuntimeDispatchers
import br.com.wave.flows.kmp.runtime.NoOpRuntimeLogger
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeDispatchers
import br.com.wave.flows.kmp.runtime.RuntimeContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.RuntimeLogger
import br.com.wave.flows.kmp.runtime.SystemRuntimeClock
import br.com.wave.flows.kmp.runtime.warmup.WarmupCacheKey
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore
import kotlinx.coroutines.withContext

class BffScreenContractProvider(
    baseUrl: String,
    private val externalCode: String,
    private val diskCache: WarmupDiskCacheStore? = null,
    private val api: BffApi,
    private val dispatchers: RuntimeDispatchers = DefaultRuntimeDispatchers,
    private val clock: RuntimeClock = SystemRuntimeClock,
    private val logger: RuntimeLogger = NoOpRuntimeLogger,
) : ScreenContractProvider {
    private val normalizedBaseUrl = baseUrl.trimEnd('/')

    private fun resolveCacheKey(componentId: String, overrideExternalCode: String?): Pair<String, String> {
        return componentId to (overrideExternalCode ?: externalCode)
    }

    override suspend fun getScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract {
        val (resolvedComponentId, resolvedExternalCode) = resolveCacheKey(componentId, externalCode)

        BffScreenContractCache.get(
            baseUrl = normalizedBaseUrl,
            externalCode = resolvedExternalCode,
            componentId = resolvedComponentId,
            mode = "full",
        )?.let { return it }

        return withContext(dispatchers.io) {
            diskCache?.readFullContractFromDisk(resolvedComponentId, resolvedExternalCode)?.let { contract ->
                BffScreenContractCache.put(
                    baseUrl = normalizedBaseUrl,
                    externalCode = resolvedExternalCode,
                    componentId = resolvedComponentId,
                    contract = contract,
                    mode = "full",
                )
                logger.info("Disk cache hit for '$resolvedComponentId'")
                return@withContext contract
            }

            val startMs = clock.nowMillis()

            val response = fetchContractResponse(
                slug = resolvedComponentId,
                externalCode = resolvedExternalCode,
            )

            val elapsedMs = clock.nowMillis() - startMs

            check(response.isSuccessful) {
                "Unsuccessful response for componentId=$resolvedComponentId externalCode=$resolvedExternalCode (HTTP ${response.code})"
            }

            val json = response.body
                ?: error(
                    "Empty response for componentId=$resolvedComponentId externalCode=$resolvedExternalCode (HTTP ${response.code})",
                )

            logger.info("Fetched contract for '$resolvedComponentId' in ${elapsedMs}ms")

            val contract = parseScreenContract(
                json = json,
                reporter = RuntimeContractAnomalyReporter(logger),
            )
            BffScreenContractCache.put(
                baseUrl = normalizedBaseUrl,
                externalCode = resolvedExternalCode,
                componentId = resolvedComponentId,
                contract = contract,
                mode = "full",
            )
            contract
        }
    }

    private suspend fun fetchContractResponse(
        slug: String,
        externalCode: String,
    ): ApiResponse<String> {
        val flowResponse = api.getFlowContract(
            flowId = slug,
            externalCode = externalCode,
        )

        if (flowResponse.isSuccessful) {
            return flowResponse
        }

        if (!shouldFallbackToComponent(flowResponse.code)) {
            return flowResponse
        }

        return api.getComponentContract(
            componentId = slug,
            externalCode = externalCode,
        )
    }

    private fun shouldFallbackToComponent(httpCode: Int): Boolean {
        return httpCode == 404 || httpCode == 400
    }

    override suspend fun getCachedScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? {
        val (resolvedComponentId, resolvedExternalCode) = resolveCacheKey(componentId, externalCode)
        return withContext(dispatchers.io) {
            BffScreenContractCache.get(
                baseUrl = normalizedBaseUrl,
                externalCode = resolvedExternalCode,
                componentId = resolvedComponentId,
                mode = "full",
            ) ?: BffScreenContractCache.get(
                baseUrl = normalizedBaseUrl,
                externalCode = resolvedExternalCode,
                componentId = resolvedComponentId,
                mode = "skeleton",
            ) ?: diskCache?.readBestEffortContractFromDisk(resolvedComponentId, resolvedExternalCode)
        }
    }

    override fun peekCachedScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? {
        val (resolvedComponentId, resolvedExternalCode) = resolveCacheKey(componentId, externalCode)
        return BffScreenContractCache.get(
            baseUrl = normalizedBaseUrl,
            externalCode = resolvedExternalCode,
            componentId = resolvedComponentId,
            mode = "full",
        ) ?: BffScreenContractCache.get(
            baseUrl = normalizedBaseUrl,
            externalCode = resolvedExternalCode,
            componentId = resolvedComponentId,
            mode = "skeleton",
        )
    }

    private fun WarmupDiskCacheStore.readFullContractFromDisk(
        slug: String,
        resolvedExternalCode: String,
    ): ScreenContract? {
        val candidates = listOf(
            WarmupCacheKey(normalizedBaseUrl, resolvedExternalCode, "flow", slug, "full"),
            WarmupCacheKey(normalizedBaseUrl, resolvedExternalCode, "component", slug, "full"),
        )
        for (key in candidates) {
            val json = read(key) ?: continue
            return try {
                parseScreenContract(
                    json = json,
                    reporter = RuntimeContractAnomalyReporter(logger),
                )
            } catch (e: Exception) {
                logger.warn("Disk cache parse failed for '$slug': ${e.message}")
                null
            }
        }
        return null
    }

    private fun WarmupDiskCacheStore.readBestEffortContractFromDisk(
        slug: String,
        resolvedExternalCode: String,
    ): ScreenContract? {
        val candidates = listOf(
            WarmupCacheKey(normalizedBaseUrl, resolvedExternalCode, "flow", slug, "full"),
            WarmupCacheKey(normalizedBaseUrl, resolvedExternalCode, "component", slug, "full"),
            WarmupCacheKey(normalizedBaseUrl, resolvedExternalCode, "flow", slug, "skeleton"),
        )
        for (key in candidates) {
            val json = read(key) ?: continue
            return try {
                parseScreenContract(
                    json = json,
                    reporter = RuntimeContractAnomalyReporter(logger),
                )
            } catch (e: Exception) {
                logger.warn("Disk cache parse failed for '$slug': ${e.message}")
                null
            }
        }
        return null
    }

    fun clearCache() {
        BffScreenContractCache.clearSession(
            baseUrl = normalizedBaseUrl,
            externalCode = externalCode,
        )
    }
}
