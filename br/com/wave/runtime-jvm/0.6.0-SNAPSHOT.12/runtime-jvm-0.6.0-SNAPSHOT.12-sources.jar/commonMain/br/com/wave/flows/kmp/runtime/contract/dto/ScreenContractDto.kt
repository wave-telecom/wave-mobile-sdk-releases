package br.com.wave.flows.kmp.runtime.contract.dto

import br.com.wave.flows.kmp.runtime.contract.dto.block.BlockDto
import kotlinx.serialization.Serializable

@Serializable
internal data class ScreenContractDto(
    val id: String? = null,
    val type: String? = null,
    val name: String? = null,
    val blocks: BlockDto? = null,
    val root: BlockDto? = null,
    val meta: MetaDto? = null,
) {
    fun primaryRootBlockOrNull(): BlockDto? = blocks ?: root
}

@Serializable
internal data class MetaDto(
    val expiresIn: String? = null,
)
