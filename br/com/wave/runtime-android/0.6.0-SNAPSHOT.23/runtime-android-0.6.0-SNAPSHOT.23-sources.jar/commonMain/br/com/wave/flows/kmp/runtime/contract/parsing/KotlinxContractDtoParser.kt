package br.com.wave.flows.kmp.runtime.contract.parsing

import br.com.wave.flows.kmp.core.contract.BackConfig
import br.com.wave.flows.kmp.core.contract.BlockAction
import br.com.wave.flows.kmp.core.contract.BlockActionTarget
import br.com.wave.flows.kmp.core.contract.BlockActionType
import br.com.wave.flows.kmp.core.contract.BlockConfig
import br.com.wave.flows.kmp.core.contract.BlockStyle
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.contract.CardBlockConfig
import br.com.wave.flows.kmp.core.contract.CarouselBlockConfig
import br.com.wave.flows.kmp.core.contract.ChartBlockConfig
import br.com.wave.flows.kmp.core.contract.ContainerBlockConfig
import br.com.wave.flows.kmp.core.contract.ChartDataPoint
import br.com.wave.flows.kmp.core.contract.DelegatedHostActionConfig
import br.com.wave.flows.kmp.core.contract.DividerBlockConfig
import br.com.wave.flows.kmp.core.contract.ImageBlockConfig
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.NavigateConfig
import br.com.wave.flows.kmp.core.contract.OpenUrlConfig
import br.com.wave.flows.kmp.core.contract.AccordionBlockConfig
import br.com.wave.flows.kmp.core.contract.BottomSheetBlockConfig
import br.com.wave.flows.kmp.core.contract.RadioGroupBlockConfig
import br.com.wave.flows.kmp.core.contract.RefreshConfig
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ShowHideConfig
import br.com.wave.flows.kmp.core.contract.SkeletonBlockConfig
import br.com.wave.flows.kmp.core.contract.SpacerBlockConfig
import br.com.wave.flows.kmp.core.contract.TabOption
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextSegment
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.contract.ToolbarBlockConfig
import br.com.wave.flows.kmp.core.contract.UnknownBlockConfig
import br.com.wave.flows.kmp.core.contract.VerbatimHostCallbackJson
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.errors.UnsupportedActionTargetError
import br.com.wave.flows.kmp.core.errors.UnsupportedBlockTypeError
import br.com.wave.flows.kmp.runtime.contract.dto.ScreenContractDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.ActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.BackActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.DelegatedHostActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.HideActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.NavigateActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.OpenUrlActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.RefreshActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.ShowActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.UnknownActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.AccordionBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.AccordionBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BottomSheetBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BottomSheetBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ButtonBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ButtonBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CardBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CardBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CarouselBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CarouselBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ContainerBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ContainerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.DividerBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.DividerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ImageBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ImageBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ListBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ListBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.RadioGroupBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.RadioGroupBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SkeletonBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SkeletonBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SpacerBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SpacerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BaseStyleDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartDataPointDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.PositioningStyleDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SizedStyleDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabOptionDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TextBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.RichTextBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.RichTextBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TextBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ToolbarBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ToolbarBlockDto
import br.com.wave.flows.kmp.runtime.contract.parseActionTarget
import br.com.wave.flows.kmp.runtime.contract.parseBlockType
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.mapping.support.parseOrientationValue
import br.com.wave.flows.kmp.runtime.contract.mapping.support.normalizeLegacyIconUrl
import br.com.wave.flows.kmp.runtime.contract.tabsplans.TabsPlansHydrator

internal fun ScreenContractDto.toScreenContract(
    reporter: ContractAnomalyReporter,
    jsonParser: kotlinx.serialization.json.Json,
): ScreenContract {
    return ScreenContractDtoMapper(reporter).map(this)
}

internal class ScreenContractDtoMapper(
    private val reporter: ContractAnomalyReporter,
) {
    private val blockNodeMapper = BlockNodeDtoMapper(reporter)

    fun map(dto: ScreenContractDto): ScreenContract {
        val rootNode = resolveRootNode(dto)
            ?: error("Missing screen contract root block")

        return ScreenContract(
            id = dto.id ?: error("Missing screen contract id"),
            type = dto.type ?: "screen",
            root = blockNodeMapper.map(rootNode),
        )
    }

    private fun resolveRootNode(dto: ScreenContractDto): BlockDto? {
        if (dto.blocks != null && dto.root != null) {
            reporter.reportPrecedenceConflict(
                context = "screen.contract",
                preferredField = "blocks",
                ignoredField = "root",
            )
        }

        if (dto.blocks == null && dto.root != null) {
            reporter.reportFallbackApplied(
                field = "screen.contract.blocks",
                rawValue = dto.root.toString(),
                recovery = "used root fallback",
            )
        }

        return dto.primaryRootBlockOrNull()?.let { TabsPlansHydrator(reporter).hydrate(it) }
    }
}

internal class BlockNodeDtoMapper(
    private val reporter: ContractAnomalyReporter,
) {
    private val blockActionMapper = BlockActionDtoMapper(reporter)

    fun map(blockNode: BlockDto): BlockNode {
        val blockId = blockNode.id ?: error("Missing block id")
        val rawType = blockNode.type
        val mappedType = parseBlockTypeOrNull(rawType)
        val contractErrors = mutableListOf<RenderBlockError>()

        val blockType = if (mappedType == null) {
            reporter.reportUnknownEnumValue(
                field = "block.type",
                rawValue = rawType,
                recovery = "mapped block to unknown",
            )
            contractErrors += UnsupportedBlockTypeError(blockId, rawType)
            BlockType.UNKNOWN
        } else {
            mappedType
        }

        val actionResult = blockNode.action?.let { actionDto ->
            blockActionMapper.map(blockId, actionDto)
        }
        actionResult?.error?.let(contractErrors::add)

        val children = (blockNode.children ?: emptyList()).map(::map)
        val config = mapTypedConfig(blockType, blockNode, rawType)

        return BlockNode(
            id = blockId,
            type = blockType,
            config = enrichConfigFromLegacyVariants(
                blockNode = blockNode,
                blockType = blockType,
                config = config,
            ),
            children = children,
            action = actionResult?.action,
            contractErrors = contractErrors,
        )
    }

    private fun enrichConfigFromLegacyVariants(
        blockNode: BlockDto,
        blockType: BlockType,
        config: BlockConfig,
    ): BlockConfig {
        if (blockType != BlockType.RADIO_GROUP) return config
        val radioGroupConfig = config as? RadioGroupBlockConfig ?: return config

        val inferredActiveColor = radioGroupConfig.activeColorHex
            ?: findNestedSelectedVariantField(blockNode, "color")
        val inferredActiveBackground = radioGroupConfig.activeBackgroundColorHex
            ?: findNestedSelectedVariantField(blockNode, "backgroundColor")

        return radioGroupConfig.copy(
            activeColorHex = inferredActiveColor,
            activeBackgroundColorHex = inferredActiveBackground,
        )
    }

    private fun findNestedSelectedVariantField(
        node: BlockDto,
        fieldName: String,
    ): String? {
        selectedVariantField(node, fieldName)?.let { return it }

        node.children?.forEach { child ->
            val nested = findNestedSelectedVariantField(child, fieldName)
            if (!nested.isNullOrBlank()) return nested
        }
        return null
    }

    private fun selectedVariantField(
        node: BlockDto,
        fieldName: String,
    ): String? {
        val selected = when (node) {
            is CardBlockDto -> node.config?.variants?.selected?.toBlockVariantSelected()
            is ImageBlockDto -> node.config?.variants?.selected?.toBlockVariantSelected()
            is TextBlockDto -> node.config?.variants?.selected?.toBlockVariantSelected()
            is RadioGroupBlockDto -> node.config?.variants?.selected?.toBlockVariantSelected()
            else -> null
        }

        return when (fieldName) {
            "color" -> selected?.color
            "backgroundColor" -> selected?.backgroundColor
            else -> null
        }
    }

    private fun br.com.wave.flows.kmp.runtime.contract.dto.block.RadioGroupVariantDto.toBlockVariantSelected(): br.com.wave.flows.kmp.runtime.contract.dto.block.BlockVariantSelectedDto {
        return br.com.wave.flows.kmp.runtime.contract.dto.block.BlockVariantSelectedDto(
            color = color,
            backgroundColor = backgroundColor,
        )
    }

    private fun br.com.wave.flows.kmp.runtime.contract.dto.block.BlockVariantSelectedDto.toBlockVariantSelected(): br.com.wave.flows.kmp.runtime.contract.dto.block.BlockVariantSelectedDto {
        return this
    }

    private fun mapTypedConfig(
        blockType: BlockType,
        blockNode: BlockDto,
        rawType: String?,
    ): BlockConfig {
        return when (blockType) {
            BlockType.TEXT -> mapTextConfig((blockNode as? TextBlockDto)?.config)
            BlockType.RICH_TEXT -> mapRichTextConfig((blockNode as? RichTextBlockDto)?.config)
            BlockType.BUTTON -> mapButtonConfig((blockNode as? ButtonBlockDto)?.config)
            BlockType.CARD -> mapCardConfig((blockNode as? CardBlockDto)?.config)
            BlockType.CONTAINER -> mapContainerConfig((blockNode as? ContainerBlockDto)?.config)
            BlockType.LIST -> mapListConfig((blockNode as? ListBlockDto)?.config)
            BlockType.DIVIDER -> mapDividerConfig((blockNode as? DividerBlockDto)?.config)
            BlockType.SPACER -> mapSpacerConfig((blockNode as? SpacerBlockDto)?.config)
            BlockType.TOOLBAR -> mapToolbarConfig((blockNode as? ToolbarBlockDto)?.config)
            BlockType.IMAGE -> mapImageConfig((blockNode as? ImageBlockDto)?.config, rawType)
            BlockType.RADIO_GROUP -> mapRadioGroupConfig((blockNode as? RadioGroupBlockDto)?.config)
            BlockType.SKELETON -> mapSkeletonConfig((blockNode as? SkeletonBlockDto)?.config)
            BlockType.CAROUSEL -> mapCarouselConfig((blockNode as? CarouselBlockDto)?.config)
            BlockType.CHART -> mapChartConfig((blockNode as? ChartBlockDto)?.config)
            BlockType.TABS -> mapTabsConfig((blockNode as? TabsBlockDto)?.config)
            BlockType.BOTTOM_SHEET -> mapBottomSheetConfig((blockNode as? BottomSheetBlockDto)?.config)
            BlockType.ACCORDION -> mapAccordionConfig((blockNode as? AccordionBlockDto)?.config)
            BlockType.UNKNOWN -> UnknownBlockConfig(
                rawType = rawType,
                style = readStyle(null),
            )
        }
    }

    private fun mapTextConfig(config: TextBlockConfigDto?): TextBlockConfig {
        return TextBlockConfig(
            value = config?.value ?: "",
            style = readStyle(config),
            fontSizeSp = config?.fontSize,
            fontFamily = config?.fontFamily,
            fontWeight = config?.fontWeight,
            align = config?.align,
            strikethrough = config?.strikethrough == true,
        )
    }

    private fun mapRichTextConfig(config: RichTextBlockConfigDto?): RichTextBlockConfig {
        return RichTextBlockConfig(
            style = readStyle(config),
            segments = config?.segments.orEmpty().mapNotNull { segment ->
                val text = segment.text ?: return@mapNotNull null
                RichTextSegment(
                    text = text,
                    fontSizeSp = segment.fontSize,
                    fontFamily = segment.fontFamily,
                    fontWeight = segment.fontWeight,
                    fontStyle = segment.fontStyle,
                    color = segment.color,
                    strikethrough = segment.strikethrough == true,
                    underline = segment.underline == true,
                )
            },
            fontSizeSp = config?.fontSize,
            fontFamily = config?.fontFamily,
            fontWeight = config?.fontWeight,
            fontStyle = config?.fontStyle,
            color = config?.color,
            align = config?.align,
            strikethrough = config?.strikethrough == true,
            truncate = config?.truncate == true,
        )
    }

    private fun mapButtonConfig(config: ButtonBlockConfigDto?): ButtonBlockConfig {
        val style = readStyle(config)
        return ButtonBlockConfig(
            value = config?.value
                ?: config?.text
                ?: config?.ariaLabel
                ?: "",
            style = style.copy(
                colorHex = config?.textColor ?: style.colorHex,
            ),
            fontSizeSp = config?.fontSize,
            fontWeight = config?.fontWeight,
        )
    }

    private fun mapCardConfig(config: CardBlockConfigDto?): CardBlockConfig {
        return CardBlockConfig(
            style = readStyle(config),
            elevation = config?.elevation,
        )
    }

    private fun mapContainerConfig(config: ContainerBlockConfigDto?): ContainerBlockConfig {
        return ContainerBlockConfig(
            style = readStyle(config),
        )
    }

    private fun mapListConfig(config: ListBlockConfigDto?): ListBlockConfig {
        return ListBlockConfig(
            spacing = config?.spacing ?: 0,
            orientation = parseOrientationValue(config?.orientation),
            align = config?.align,
            verticalAlign = config?.verticalAlign,
            horizontalAlign = config?.horizontalAlign,
            expand = config?.expand == true,
            style = readStyle(config),
        )
    }

    private fun mapDividerConfig(config: DividerBlockConfigDto?): DividerBlockConfig {
        return DividerBlockConfig(
            orientation = parseOrientationValue(config?.orientation),
            style = readStyle(config),
        )
    }

    private fun mapImageConfig(config: ImageBlockConfigDto?, rawType: String?): ImageBlockConfig {
        val url = config?.url ?: ""
        return ImageBlockConfig(
            url = normalizeLegacyIconUrl(url, rawType) ?: url,
            altText = config?.altText,
            aspectRatio = config?.aspectRatio,
            width = config?.width,
            height = config?.height,
            style = readStyle(config),
        )
    }

    private fun mapRadioGroupConfig(config: RadioGroupBlockConfigDto?): RadioGroupBlockConfig {
        return RadioGroupBlockConfig(
            orientation = parseOrientationValue(config?.orientation),
            activeIndex = config?.activeIndex,
            activeColorHex = config?.activeColor,
            activeBackgroundColorHex = config?.activeBackgroundColor,
            spacing = config?.spacing ?: 0,
            style = readStyle(config),
        )
    }

    private fun mapSkeletonConfig(config: SkeletonBlockConfigDto?): SkeletonBlockConfig {
        return SkeletonBlockConfig(
            width = config?.width,
            height = config?.height,
            align = config?.align,
            style = readStyle(config, includeSize = false),
        )
    }

    private fun mapCarouselConfig(config: CarouselBlockConfigDto?): CarouselBlockConfig {
        return CarouselBlockConfig(
            itemWidth = config?.itemWidth ?: 0,
            showIndicators = config?.showIndicators == true,
            showButtons = config?.showButtons,
            spacing = config?.spacing ?: 0,
            style = readStyle(config),
        )
    }

    private fun mapChartConfig(config: ChartBlockConfigDto?): ChartBlockConfig {
        return ChartBlockConfig(
            type = config?.type ?: "bar",
            data = readChartData(config?.data),
            size = config?.size ?: 0,
            style = readStyle(config),
        )
    }

    private fun mapSpacerConfig(config: SpacerBlockConfigDto?): SpacerBlockConfig {
        return SpacerBlockConfig(style = readStyle(config))
    }

    private fun mapToolbarConfig(config: ToolbarBlockConfigDto?): ToolbarBlockConfig {
        return ToolbarBlockConfig(
            title = config?.title ?: "",
            align = config?.align,
            style = readStyle(config),
        )
    }

    private fun mapTabsConfig(config: TabsBlockConfigDto?): TabsBlockConfig {
        val selectedVariant = config?.variants?.selected
        return TabsBlockConfig(
            options = readTabOptions(config?.options),
            gap = config?.gap ?: 0,
            activeColorHex = config?.activeColor ?: selectedVariant?.color,
            activeBackgroundColorHex = config?.activeBackgroundColor ?: selectedVariant?.backgroundColor,
            inactiveColorHex = config?.inactiveColor ?: config?.color,
            inactiveBackgroundColorHex = config?.inactiveBackgroundColor ?: config?.backgroundColor,
            fontSizeSp = config?.fontSize,
            fontFamily = config?.fontFamily,
            fontWeight = config?.fontWeight,
            style = readStyle(config),
        )
    }

    private fun mapBottomSheetConfig(config: BottomSheetBlockConfigDto?): BottomSheetBlockConfig {
        return BottomSheetBlockConfig(style = readStyle(config))
    }

    private fun mapAccordionConfig(config: AccordionBlockConfigDto?): AccordionBlockConfig {
        return AccordionBlockConfig(
            title = config?.title,
            defaultOpen = config?.defaultOpen == true,
            iconColorHex = config?.iconColor,
            iconUrl = config?.iconUrl,
            iconWidth = config?.iconWidth,
            iconHeight = config?.iconHeight,
            wrapContent = config?.wrapContent,
            fullWidth = config?.fullWidth,
            fontSizeSp = config?.fontSize,
            fontFamily = config?.fontFamily,
            fontWeight = config?.fontWeight,
            fontStyle = config?.fontStyle,
            style = readStyle(config),
        )
    }

    private fun readChartData(data: List<ChartDataPointDto>?): List<ChartDataPoint> {
        return (data ?: emptyList()).mapIndexedNotNull { index, item ->
            val key = item.key
            val value = item.value
            val fill = item.fill
            if (key.isNullOrBlank() || value == null || fill.isNullOrBlank()) {
                reporter.reportCollectionItemDropped(
                    field = "block.config.data[$index]",
                    rawValue = item.toString(),
                    recovery = "dropped chart item missing key, value or fill",
                )
                null
            } else {
                ChartDataPoint(
                    key = key,
                    value = value,
                    fill = fill,
                )
            }
        }
    }

    private fun readTabOptions(options: List<TabOptionDto>?): List<TabOption> {
        return (options ?: emptyList()).mapIndexedNotNull { index, item ->
            val id = item.id
            val label = item.label
            val contentReferenceId = item.contentReferenceId
            if (id.isNullOrBlank() || contentReferenceId.isNullOrBlank()) {
                reporter.reportCollectionItemDropped(
                    field = "block.config.options[$index]",
                    rawValue = item.toString(),
                    recovery = "dropped tab option missing id or contentReferenceId",
                )
                null
            } else {
                TabOption(id = id, label = label ?: id, contentReferenceId = contentReferenceId)
            }
        }
    }

    private fun readStyle(config: BaseStyleDto?, includeSize: Boolean = true): BlockStyle {
        val sizedConfig = config as? SizedStyleDto
        val positionedConfig = config as? PositioningStyleDto
        return BlockStyle(
            width = if (includeSize) sizedConfig?.width else null,
            height = if (includeSize) sizedConfig?.height else null,
            position = positionedConfig?.position,
            top = positionedConfig?.top,
            right = positionedConfig?.right,
            bottom = positionedConfig?.bottom,
            left = positionedConfig?.left,
            zIndex = positionedConfig?.zIndex,
            margin = config?.margin,
            marginTop = config?.marginTop,
            marginBottom = config?.marginBottom,
            marginLeft = config?.marginLeft,
            marginRight = config?.marginRight,
            padding = config?.padding,
            paddingTop = config?.paddingTop,
            paddingBottom = config?.paddingBottom,
            paddingLeft = config?.paddingLeft,
            paddingRight = config?.paddingRight,
            borderRadius = config?.borderRadius,
            borderRadiusTop = config?.borderRadiusTop,
            borderRadiusBottom = config?.borderRadiusBottom,
            borderRadiusLeft = config?.borderRadiusLeft,
            borderRadiusRight = config?.borderRadiusRight,
            borderWidth = config?.borderWidth,
            borderColorHex = config?.borderColor,
            borderStyle = config?.borderStyle,
            backgroundColorHex = config?.backgroundColor,
            colorHex = config?.color,
            visibility = config?.visibility,
        )
    }
}

internal class BlockActionDtoMapper(
    private val reporter: ContractAnomalyReporter,
) {
    fun map(
        blockId: String,
        actionDto: ActionDto,
    ): BlockActionMappingResult {
        val target = parseActionTargetOrNull(actionDto.onAction)
        if (target == null) {
            reporter.reportUnknownEnumValue(
                field = "action.onAction",
                rawValue = actionDto.onAction,
                recovery = "ignored unsupported action target",
            )
            return BlockActionMappingResult(
                action = null,
                error = UnsupportedActionTargetError(blockId, actionDto.onAction),
            )
        }

        val parsedConfig = when (val action = actionDto) {
            is NavigateActionDto -> {
                val verbatim = action.config ?: VerbatimHostCallbackJson(JsonObject(emptyMap()))
                NavigateConfig(
                    destinationId = (verbatim.element["destinationId"] as? JsonPrimitive)
                        ?.contentOrNull
                        .orEmpty(),
                    verbatim = verbatim,
                )
            }

            is ShowActionDto -> ShowHideConfig(action.config?.referenceId ?: "")
            is HideActionDto -> ShowHideConfig(action.config?.referenceId ?: "")
            is BackActionDto -> BackConfig(action.config?.referenceId ?: "")
            is OpenUrlActionDto -> OpenUrlConfig(action.config?.externalDestinationUrl ?: "")
            is RefreshActionDto -> RefreshConfig
            is DelegatedHostActionDto -> DelegatedHostActionConfig(rawJson = actionDto.toString())
            is UnknownActionDto -> return BlockActionMappingResult(
                action = null,
                error = UnsupportedActionTargetError(blockId, action.onAction),
            )
        }

        return BlockActionMappingResult(
            action = BlockAction(
                type = BlockActionType.CLICK,
                onAction = target,
                config = parsedConfig,
            ),
        )
    }

}

internal data class BlockActionMappingResult(
    val action: BlockAction?,
    val error: RenderBlockError? = null,
)

private fun parseBlockTypeOrNull(value: String?): BlockType? {
    return runCatching { parseBlockType(value) }.getOrNull()
}

private fun parseActionTargetOrNull(value: String?): BlockActionTarget? {
    return runCatching { parseActionTarget(value) }.getOrNull()
}
