package br.com.wave.flows.kmp.runtime.contract.tabsplans

import br.com.wave.flows.kmp.runtime.contract.dto.block.AccordionBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BottomSheetBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ButtonBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CardBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CarouselBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ContainerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.DividerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ImageBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ListBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.RadioGroupBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SkeletonBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.SpacerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.RichTextBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TextBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ToolbarBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.UnknownBlockDto
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter

internal class TabsPlansHydrator(
    private val reporter: ContractAnomalyReporter,
    private val expanders: List<TabsPlansBlockExpander> = listOf(TabsPlansHydrationExpander()),
) {
    fun hydrate(block: BlockDto): BlockDto {
        if (!containsTabsPlans(block)) return block
        return hydrateBlock(block)
    }

    private fun hydrateBlock(block: BlockDto): BlockDto {
        return when (block) {
            is TabsPlansBlockDto -> expandBlock(block)
            else -> {
                val children = block.children ?: return block
                val hydratedChildren = children.map(::hydrateBlock)
                if (hydratedChildren == children) {
                    block
                } else {
                    block.withChildren(hydratedChildren)
                }
            }
        }
    }

    private fun containsTabsPlans(block: BlockDto): Boolean {
        return when (block) {
            is TabsPlansBlockDto -> true
            else -> block.children?.any(::containsTabsPlans) == true
        }
    }

    private fun expandBlock(block: TabsPlansBlockDto): BlockDto {
        val expander = expanders.firstOrNull { it.supports(block) }
            ?: error("No tabs-plans expander registered for block type=${block.type} id=${block.id}")
        return hydrateBlock(expander.expand(block, reporter))
    }
}

internal interface TabsPlansBlockExpander {
    fun supports(block: TabsPlansBlockDto): Boolean
    fun expand(block: TabsPlansBlockDto, reporter: ContractAnomalyReporter): BlockDto
}

private fun BlockDto.withChildren(newChildren: List<BlockDto>): BlockDto {
    return when (this) {
        is TextBlockDto -> copy(children = newChildren)
        is RichTextBlockDto -> copy(children = newChildren)
        is ButtonBlockDto -> copy(children = newChildren)
        is CardBlockDto -> copy(children = newChildren)
        is ContainerBlockDto -> copy(children = newChildren)
        is ListBlockDto -> copy(children = newChildren)
        is DividerBlockDto -> copy(children = newChildren)
        is ImageBlockDto -> copy(children = newChildren)
        is CarouselBlockDto -> copy(children = newChildren)
        is ChartBlockDto -> copy(children = newChildren)
        is RadioGroupBlockDto -> copy(children = newChildren)
        is SkeletonBlockDto -> copy(children = newChildren)
        is SpacerBlockDto -> copy(children = newChildren)
        is ToolbarBlockDto -> copy(children = newChildren)
        is TabsBlockDto -> copy(children = newChildren)
        is BottomSheetBlockDto -> copy(children = newChildren)
        is AccordionBlockDto -> copy(children = newChildren)
        is UnknownBlockDto -> copy(children = newChildren)
        is TabsPlansBlockDto -> copy(children = newChildren)
    }
}
