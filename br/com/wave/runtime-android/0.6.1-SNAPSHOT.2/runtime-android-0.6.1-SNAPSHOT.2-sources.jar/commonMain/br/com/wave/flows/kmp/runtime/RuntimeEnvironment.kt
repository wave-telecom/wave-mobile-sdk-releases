package br.com.wave.flows.kmp.runtime

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlin.time.Clock
import kotlin.time.TimeSource

interface RuntimeDispatchers {
    val io: CoroutineDispatcher
}

object DefaultRuntimeDispatchers : RuntimeDispatchers {
    override val io: CoroutineDispatcher = Dispatchers.Default
}

interface RuntimeClock {
    fun nowMillis(): Long
}

object SystemRuntimeClock : RuntimeClock {
    override fun nowMillis(): Long = Clock.System.now().toEpochMilliseconds()
}

/**
 * Monotonic clock for measuring elapsed durations (e.g. the refresh cooldown). Immune
 * to wall-clock jumps — NTP sync, manual time change, DST — that can shorten, extend, or
 * break a window measured with [SystemRuntimeClock]. The returned value is NOT an epoch;
 * only differences between readings are meaningful.
 */
object MonotonicRuntimeClock : RuntimeClock {
    private val origin = TimeSource.Monotonic.markNow()
    override fun nowMillis(): Long = origin.elapsedNow().inWholeMilliseconds
}

interface RuntimeLogger {
    fun debug(message: String)
    fun info(message: String)
    fun warn(message: String)
    fun error(message: String, throwable: Throwable? = null)
}

object NoOpRuntimeLogger : RuntimeLogger {
    override fun debug(message: String) = Unit
    override fun info(message: String) = Unit
    override fun warn(message: String) = Unit
    override fun error(message: String, throwable: Throwable?) = Unit
}
