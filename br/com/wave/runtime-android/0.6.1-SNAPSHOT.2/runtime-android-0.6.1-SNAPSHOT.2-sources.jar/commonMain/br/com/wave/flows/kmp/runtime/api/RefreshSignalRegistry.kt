package br.com.wave.flows.kmp.runtime.api

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

/**
 * Per-(flowId, externalCode) counter that [FlowWrapper.refresh] bumps
 * after cache invalidation. [RenderBlockRoute] observes the counter for
 * its mounted flow and folds it into produceState keys so a refresh
 * triggers a re-fetch without any host-side token.
 *
 * Keyed by `"$flowId|${externalCode.orEmpty()}"`. A bump on one key
 * never affects sibling flows or the navbar.
 *
 * Thread-safety: the backing [MutableStateFlow] holds an immutable map;
 * all writes go through [MutableStateFlow.update] which is lock-free and
 * safe from any thread.
 */
object RefreshSignalRegistry {
    private val state = MutableStateFlow<Map<String, Int>>(emptyMap())

    private fun key(flowId: String, externalCode: String?): String =
        "$flowId|${externalCode.orEmpty()}"

    /**
     * Returns a [Flow] of the current refresh counter for [flowId].
     * Intended for `collectAsState(initial = 0)` in [RenderBlockRoute].
     */
    fun counterFlow(flowId: String, externalCode: String?): Flow<Int> =
        state.map { it[key(flowId, externalCode)] ?: 0 }.distinctUntilChanged()

    /** Increments the counter for [flowId]. Safe to call from any thread. */
    fun bump(flowId: String, externalCode: String?) {
        val k = key(flowId, externalCode)
        state.update { current -> current + (k to ((current[k] ?: 0) + 1)) }
    }

    /** Clears all signals. Call on session start and in tests for isolation. */
    fun reset() {
        state.value = emptyMap()
    }
}
