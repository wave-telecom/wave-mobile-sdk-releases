package br.com.wave.flows.kmp.runtime

import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomaly
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter

class RuntimeContractAnomalyReporter(
    private val logger: RuntimeLogger = NoOpRuntimeLogger,
) : ContractAnomalyReporter {

    override fun report(anomaly: ContractAnomaly) {
        logger.warn(
            buildString {
                append("contract_anomaly")
                append(" type=").append(anomaly.type.name)
                append(" context=").append(anomaly.parserContext)
                anomaly.fieldPath?.let { append(" field=").append(it) }
                anomaly.recovery?.let { append(" recovery=").append(it) }
                anomaly.details?.let { append(" details=").append(it) }
            },
        )
    }
}
