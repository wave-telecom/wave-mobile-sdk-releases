package br.com.wave.flows.kmp.runtime

/**
 * Seam for opt-in verbose diagnostics for the contract fetch/parse pipeline.
 *
 * The verbose formatting (decoder messages, JSON paths, contract meta) lives
 * only in the `sdkBuildType=debug` source set of this module and is installed
 * via [br.com.wave.flows.kmp.runtime.ContractDiagnosticsBootstrap]. In a
 * published (release) build that source set is compiled out entirely: the
 * hook below stays null and the forwarders emit nothing, so verbose payload
 * detail can never reach an integrator regardless of the HOST app's own
 * debug/release build type.
 */
internal object RuntimeDiagnostics {
    internal var contractDiagnostics: ContractDiagnostics? = null
}

/**
 * Verbose contract diagnostics delegate. The only implementation lives in the
 * debug source set; release builds never have a concrete instance to install.
 */
internal interface ContractDiagnostics {
    fun logParseFailureDetail(logger: RuntimeLogger, context: String, error: Throwable)
    fun logPayloadMeta(logger: RuntimeLogger, context: String, rawJson: String)
    fun logSkeletonCacheRead(logger: RuntimeLogger, componentId: String, externalCode: String, baseUrl: String, hit: Boolean)
    fun logSkeletonCacheReadSkipped(logger: RuntimeLogger, providerType: String?)
    fun logWarmupCacheWrite(
        logger: RuntimeLogger,
        slug: String,
        entryType: String,
        mode: String,
        ttlMs: Long,
        externalCode: String,
        baseUrl: String,
    )
    fun logSessionBuildMarker(logger: RuntimeLogger, description: String)
}

/**
 * Detail line for a contract failure. No-op when no delegate is installed
 * (release builds, or diagnostics off).
 */
internal fun RuntimeLogger.debugContractDetail(context: String, error: Throwable) {
    RuntimeDiagnostics.contractDiagnostics?.logParseFailureDetail(this, context, error)
}

/**
 * `meta` descriptor (contract version + correlationId) of a fetched payload,
 * for correlating client-side failures with BFF deploys. Same seam as
 * [debugContractDetail].
 */
internal fun RuntimeLogger.debugContractMeta(context: String, rawJson: String) {
    RuntimeDiagnostics.contractDiagnostics?.logPayloadMeta(this, context, rawJson)
}

/**
 * Skeleton cache read outcome (hit/miss), keyed by the exact fields the reading
 * [br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider] used to build the lookup.
 * Same seam as [debugContractDetail].
 */
internal fun RuntimeLogger.debugSkeletonCacheRead(componentId: String, externalCode: String, baseUrl: String, hit: Boolean) {
    RuntimeDiagnostics.contractDiagnostics?.logSkeletonCacheRead(this, componentId, externalCode, baseUrl, hit)
}

/**
 * Skeleton cache read skipped because the runtime's contract provider is not a
 * [br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider]. Public (unlike the other
 * wrappers in this file) so the `flows-sdk` module's `RenderBlockWeb.kt` — the only caller,
 * across a module boundary — can reach the same gated seam instead of logging unconditionally.
 */
fun RuntimeLogger.debugSkeletonCacheReadSkipped(providerType: String?) {
    RuntimeDiagnostics.contractDiagnostics?.logSkeletonCacheReadSkipped(this, providerType)
}

/** Extended (key-field) form of the warmup cache-write log, same seam as [debugContractMeta]. */
internal fun RuntimeLogger.debugWarmupCacheWrite(
    slug: String,
    entryType: String,
    mode: String,
    ttlMs: Long,
    externalCode: String,
    baseUrl: String,
) {
    RuntimeDiagnostics.contractDiagnostics?.logWarmupCacheWrite(this, slug, entryType, mode, ttlMs, externalCode, baseUrl)
}

/**
 * Build-identity marker at session start ([br.com.wave.flows.kmp.FlowsSdkBuildInfo.DESCRIPTION]).
 * Public for the same cross-module reason as [debugSkeletonCacheReadSkipped] — the only caller,
 * `FlowWrapper.openSession()`, lives in `flows-sdk`.
 */
fun RuntimeLogger.debugSessionBuildMarker(description: String) {
    RuntimeDiagnostics.contractDiagnostics?.logSessionBuildMarker(this, description)
}
