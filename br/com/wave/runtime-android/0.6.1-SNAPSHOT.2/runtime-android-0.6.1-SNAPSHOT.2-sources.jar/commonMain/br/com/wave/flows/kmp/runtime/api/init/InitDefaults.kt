package br.com.wave.flows.kmp.runtime.api.init

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Role key under which the BFF nominates the component to show when a block cannot be rendered.
 * Protocol vocabulary owned by the BFF, not by this SDK — the component *id* is whatever that
 * entry's `slug` says, so a tenant can rename or replace the screen without a client release.
 */
const val INIT_DEFAULT_ROLE_ERROR = "offline-error"

/** The component the BFF nominates for a role — `slug` is the id to fetch, `type` its kind. */
data class InitDefaultEntry(val slug: String, val type: String)

/**
 * Process-wide store for the `default` map declared in `/api/init`. [InitResponseParser] has
 * parsed that map since it was written; this store is the first consumer, so a composable can
 * read a role's nominated component without depending on the init fetch's timing.
 */
object InitDefaults {

    private val _entries = MutableStateFlow<Map<String, InitDefaultEntry>>(emptyMap())
    val entries: StateFlow<Map<String, InitDefaultEntry>> = _entries.asStateFlow()

    fun entryFor(role: String): InitDefaultEntry? = _entries.value[role]

    internal fun publish(raw: Map<String, InitDefaultEntry>) {
        _entries.value = raw
    }
}
