package br.com.wave.flows.kmp.runtime.api.init

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject

internal object InitResponseParser {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    fun parse(json: String): InitResponseDto {
        val root = runCatching { this.json.parseToJsonElement(json) as? JsonObject }.getOrNull()
            ?: return InitResponseDto()

        return InitResponseDto(
            preloadable = root["preloadable"].toInitEntries(),
            cacheable = root["cacheable"].toInitEntries(),
            defaults = root["default"].toDefaultsMap(),
        )
    }

    private fun JsonElement?.toInitEntries(): List<InitEntryDto> {
        val array = this?.jsonArray ?: return emptyList()
        return array.mapNotNull { element ->
            val obj = element.jsonObject
            InitEntryDto(
                slug = obj["slug"].asStringOrEmpty(),
                type = obj["type"].asStringOrEmpty(),
            )
        }
    }

    private fun JsonElement?.toDefaultsMap(): Map<String, InitEntryDto> {
        val obj = this?.jsonObject ?: return emptyMap()
        return obj.mapValues { (_, value) ->
            val entry = value.jsonObject
            InitEntryDto(
                slug = entry["slug"].asStringOrEmpty(),
                type = entry["type"].asStringOrEmpty(),
            )
        }
    }

    private fun JsonElement?.asStringOrEmpty(): String {
        return (this as? JsonPrimitive)?.contentOrNull.orEmpty()
    }
}
