package br.com.wave.flows.kmp.runtime.api.init

internal data class InitResponseDto(
    val preloadable: List<InitEntryDto> = emptyList(),
    val cacheable: List<InitEntryDto> = emptyList(),
    val defaults: Map<String, InitEntryDto> = emptyMap(),
)
