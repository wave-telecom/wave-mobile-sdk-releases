package br.com.wave.flows.kmp.runtime

/**
 * Release counterpart of the debug `ContractDiagnosticsBootstrap` (same FQN,
 * other source set): the verbose delegate does not exist in this build, so
 * installing is a no-op and [RuntimeDiagnostics.contractDiagnostics] stays
 * null.
 */
object ContractDiagnosticsBootstrap {
    fun install() {}
}
