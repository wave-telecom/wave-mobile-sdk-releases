package br.com.wave.flows.kmp.runtime.api

import br.com.wave.flows.kmp.core.contract.BlockStateEffect
import br.com.wave.flows.kmp.core.contract.ScreenContract
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

internal object BffScreenContractCache {
    private data class CacheKey(
        val baseUrl: String,
        val externalCode: String,
        val componentId: String,
        val mode: String,
    )

    private val cache = MutableStateFlow<Map<CacheKey, ScreenContract>>(emptyMap())

    fun get(
        baseUrl: String,
        externalCode: String,
        componentId: String,
        mode: String = "full",
    ): ScreenContract? {
        return cache.value[CacheKey(normalizeBaseUrl(baseUrl), externalCode, componentId, mode)]
    }

    fun put(
        baseUrl: String,
        externalCode: String,
        componentId: String,
        contract: ScreenContract,
        mode: String = "full",
    ) {
        val key = CacheKey(normalizeBaseUrl(baseUrl), externalCode, componentId, mode)
        cache.update { current ->
            current + (key to contract)
        }
    }

    fun clearSession(
        baseUrl: String,
        externalCode: String,
    ) {
        val normalizedBaseUrl = normalizeBaseUrl(baseUrl)
        cache.update { current ->
            current.filterKeys { key ->
                key.baseUrl != normalizedBaseUrl || key.externalCode != externalCode
            }
        }
    }

    fun clearAll() {
        cache.value = emptyMap()
    }

    /**
     * Drops a single entry from the in-memory cache. Surgical refresh
     * helper: callers can invalidate a specific component for a specific
     * mode (e.g. only `full`) while leaving the rest of the cache —
     * including the same component's `skeleton` entry — intact.
     */
    fun remove(
        baseUrl: String,
        externalCode: String,
        componentId: String,
        mode: String,
    ) {
        val key = CacheKey(normalizeBaseUrl(baseUrl), externalCode, componentId, mode)
        cache.update { current -> current - key }
    }

    private fun normalizeBaseUrl(baseUrl: String): String {
        return baseUrl.trimEnd('/')
    }
}

object RenderBlockInteractionCache {
    private data class SelectionKey(
        val routeId: String,
        val blockId: String,
        val slot: String,
    )

    private data class ToggleKey(
        val routeId: String,
        val blockId: String,
        val slot: String,
    )

    private data class CounterKey(
        val routeId: String,
        val blockId: String,
        val slot: String,
    )

    private data class PropertyKey(
        val routeId: String,
        val blockId: String,
        val property: String,
    )

    private val selections = MutableStateFlow<Map<SelectionKey, String>>(emptyMap())
    private val toggles = MutableStateFlow<Map<ToggleKey, Boolean>>(emptyMap())
    private val counters = MutableStateFlow<Map<CounterKey, Int>>(emptyMap())
    private val visibilityByRoute = MutableStateFlow<Map<String, Map<String, Boolean>>>(emptyMap())
    private val properties = MutableStateFlow<Map<PropertyKey, Int>>(emptyMap())

    fun getSelection(
        routeId: String,
        blockId: String,
        slot: String = "selection",
    ): String? = selections.value[SelectionKey(routeId = routeId, blockId = blockId, slot = slot)]

    fun putSelection(
        routeId: String,
        blockId: String,
        value: String,
        slot: String = "selection",
    ) {
        val key = SelectionKey(routeId = routeId, blockId = blockId, slot = slot)
        selections.update { current -> current + (key to value) }
    }

    fun getToggle(
        routeId: String,
        blockId: String,
        slot: String = "toggle",
    ): Boolean? = toggles.value[ToggleKey(routeId = routeId, blockId = blockId, slot = slot)]

    fun putToggle(
        routeId: String,
        blockId: String,
        value: Boolean,
        slot: String = "toggle",
    ) {
        val key = ToggleKey(routeId = routeId, blockId = blockId, slot = slot)
        toggles.update { current -> current + (key to value) }
    }

    fun getCounter(
        routeId: String,
        blockId: String,
        slot: String = "counter",
    ): Int = counters.value[CounterKey(routeId = routeId, blockId = blockId, slot = slot)] ?: 0

    fun putCounter(
        routeId: String,
        blockId: String,
        value: Int,
        slot: String = "counter",
    ) {
        val key = CounterKey(routeId = routeId, blockId = blockId, slot = slot)
        counters.update { current -> current + (key to value) }
    }

    fun getVisibility(routeId: String): Map<String, Boolean>? = visibilityByRoute.value[routeId]

    fun putVisibility(
        routeId: String,
        visibility: Map<String, Boolean>,
    ) {
        visibilityByRoute.update { current -> current + (routeId to visibility) }
    }

    /**
     * Generic (routeId, blockId, property) -> Int channel backing the
     * `stateEffect` cross-block sync mechanism: any block can read/write any
     * named Int property on any other block without the channel knowing what
     * "tabs" or "carousel" mean. Writes are idempotent by construction — an
     * equal resulting map does not emit from [MutableStateFlow], so a
     * programmatic round-trip (tap -> peer scroll -> settle -> peer
     * write-back of the same index) terminates as a no-op instead of
     * ping-ponging.
     */
    fun getBlockPropertyOrNull(
        routeId: String,
        blockId: String,
        property: String,
    ): Int? = properties.value[PropertyKey(routeId = routeId, blockId = blockId, property = property)]

    fun putBlockProperty(
        routeId: String,
        blockId: String,
        property: String,
        value: Int,
    ) {
        val key = PropertyKey(routeId = routeId, blockId = blockId, property = property)
        properties.update { current -> current + (key to value) }
    }

    fun blockPropertyFlow(
        routeId: String,
        blockId: String,
        property: String,
    ): Flow<Int?> {
        val key = PropertyKey(routeId = routeId, blockId = blockId, property = property)
        return properties.map { it[key] }.distinctUntilChanged()
    }

    fun clearSelectionState(routeId: String) {
        selections.update { current -> current.filterKeys { it.routeId != routeId } }
        toggles.update { current -> current.filterKeys { it.routeId != routeId } }
        properties.update { current -> current.filterKeys { it.routeId != routeId } }
    }

    fun clearAll() {
        selections.value = emptyMap()
        toggles.value = emptyMap()
        counters.value = emptyMap()
        visibilityByRoute.value = emptyMap()
        properties.value = emptyMap()
    }
}

/**
 * Applies a declared `stateEffect`: writes [value] onto the peer block
 * ([BlockStateEffect.referenceId]) at [BlockStateEffect.property]. Kept
 * top-level (not a method on [RenderBlockInteractionCache]) so the channel
 * itself stays free of any `stateEffect`/model knowledge — this is the one
 * place that bridges the generic channel to the contract-model concept.
 */
fun applyStateEffect(
    routeId: String,
    effect: BlockStateEffect,
    value: Int,
) {
    RenderBlockInteractionCache.putBlockProperty(
        routeId = routeId,
        blockId = effect.referenceId,
        property = effect.property,
        value = value,
    )
}

fun clearBffScreenContractCache() {
    BffScreenContractCache.clearAll()
    RenderBlockInteractionCache.clearAll()
    br.com.wave.flows.kmp.runtime.api.sources.LiveBlockIndex.clearAll()
}
