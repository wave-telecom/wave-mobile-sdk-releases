package br.com.wave.flows.kmp.runtime.api

import io.ktor.client.HttpClient
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import io.ktor.http.encodeURLPathPart

internal class KtorBffApi(
    private val client: HttpClient,
    private val baseUrl: String,
) : BffApi {

    override suspend fun getInit(externalCode: String): ApiResponse<String> {
        return client.getResponse(
            url = "$baseUrl/api/init",
            externalCode = externalCode,
        )
    }

    override suspend fun getFlowContract(
        flowId: String,
        externalCode: String,
    ): ApiResponse<String> {
        return client.getResponse(
            url = "$baseUrl/api/components/flow/${flowId.encodeURLPathPart()}",
            externalCode = externalCode,
        )
    }

    override suspend fun getFlowContractSkeleton(
        flowId: String,
        externalCode: String,
        mode: String,
    ): ApiResponse<String> {
        return client.getResponse(
            url = "$baseUrl/api/components/flow/${flowId.encodeURLPathPart()}",
            externalCode = externalCode,
            mode = mode,
        )
    }

    override suspend fun getComponentContract(
        componentId: String,
        externalCode: String,
    ): ApiResponse<String> {
        return client.getResponse(
            url = "$baseUrl/api/components/${componentId.encodeURLPathPart()}",
            externalCode = externalCode,
        )
    }

    private suspend fun HttpClient.getResponse(
        url: String,
        externalCode: String,
        mode: String? = null,
    ): ApiResponse<String> {
        val response = get(url) {
            url {
                parameters.append("externalCode", externalCode)
                if (mode != null) {
                    parameters.append("mode", mode)
                }
            }
        }

        return ApiResponse(
            code = response.status.value,
            body = response.bodyAsText().takeIf { it.isNotBlank() },
        )
    }
}
