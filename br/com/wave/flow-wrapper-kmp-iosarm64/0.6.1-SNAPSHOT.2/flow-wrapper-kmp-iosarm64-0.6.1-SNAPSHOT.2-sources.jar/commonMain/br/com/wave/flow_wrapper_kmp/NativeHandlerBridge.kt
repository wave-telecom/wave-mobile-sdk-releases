package br.com.wave.flow_wrapper_kmp

/**
 * `NativeHandler` is the SDK's one and only JS-visible bridge object, registered on
 * both platforms (see `Platform.android.kt`/`Platform.ios.kt`). This file adds the
 * session credential to its protocol instead of standing up a second bridge object
 * for it — two objects doing the same kind of native↔page conversation is
 * duplication a previous commit introduced (`WaveAuthBridge`) and this one removes.
 *
 * `window.NativeHandler.fetchWaveToken()` returns the current wave token, or an
 * empty string when the session has none (before `start`, or after `logout`). The
 * value does not change while a WebView stays mounted — the web SDK is expected to
 * call it once during its own init and again before any authenticated request, since
 * a new WebView load (a new session, or a re-mount after logout) is the only way it
 * moves.
 *
 * No version field or schema marker is part of this contract. The consumer
 * negotiates by checking whether the method exists
 * (`typeof window.NativeHandler.fetchWaveToken === 'function'`) before calling it —
 * the idiomatic feature-detection path in JavaScript, and the only one that works
 * while older app versions (without this method) are still in users' hands.
 */
internal const val NATIVE_HANDLER_BRIDGE_NAME = "NativeHandler"

// The single source of truth for the method name: both platform install sites call
// nativeHandlerFetchWaveTokenRedefineScript below rather than duplicating the string,
// so there is exactly one place this can ever drift between Android and iOS.
internal const val NATIVE_HANDLER_METHOD_FETCH_WAVE_TOKEN = "fetchWaveToken"
internal const val NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP = "sendDataToApp"
internal const val NATIVE_HANDLER_METHOD_CALL_NATIVE = "callNative"

/**
 * The origin `NATIVE_HANDLER_BRIDGE_NAME`'s credential method must be scoped to when
 * a platform supports origin-restricted injection (see `Platform.android.kt`'s
 * `installNativeHandlerCredential`): the scheme and host (and port, if not the
 * scheme default) of [url], with no path — a foreign iframe the page embeds never
 * matches this and never sees the credential.
 *
 * Falls back to `"*"` (unrestricted) for a [url] with no readable scheme/host, which
 * only happens for a caller-constructed URL this SDK's own `EntryUrlProvider` would
 * never produce.
 */
internal fun nativeHandlerAllowedOriginFor(url: String): String {
    val schemeEnd = url.indexOf("://")
    if (schemeEnd < 0) return "*"
    val afterScheme = url.substring(schemeEnd + 3)
    val authorityEnd = afterScheme.indexOfFirst { it == '/' || it == '?' || it == '#' }
    val authority = if (authorityEnd >= 0) afterScheme.substring(0, authorityEnd) else afterScheme
    if (authority.isEmpty()) return "*"
    return url.substring(0, schemeEnd + 3) + authority
}

/**
 * Redefines `window.NativeHandler.fetchWaveToken` to return [token] (or an empty
 * string). Used to bake the initial value into a document-start script on both
 * platforms (see the platform-specific `rememberNativeHandlerWebViewFactory` actuals).
 */
internal fun nativeHandlerFetchWaveTokenRedefineScript(token: String?): String =
    "window.$NATIVE_HANDLER_BRIDGE_NAME=window.$NATIVE_HANDLER_BRIDGE_NAME||{};" +
        "window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_FETCH_WAVE_TOKEN=" +
        "function(){return ${token.orEmpty().toNativeHandlerJsLiteral()};};"

/**
 * `NATIVE_HANDLER_BRIDGE_NAME` is the *whole* bridge object on Android — the real
 * `@JavascriptInterface` binding backs `sendDataToApp`/`callNative` directly — but on
 * iOS the document-start script above only ever defined the credential method, so a
 * page that feature-detects by object existence (rather than per-method) finds an
 * object that looks like the Android bridge and calls into it, only to hit a
 * `TypeError` because nothing on iOS answers. This closes that gap for the one
 * transport iOS actually has: forwards `sendDataToApp`/`callNative` onto
 * `window.webkit.messageHandlers.$NATIVE_HANDLER_BRIDGE_NAME`, the same handler
 * `PageHeightObserver` already falls back to. **Android must never install this**:
 * its `sendDataToApp`/`callNative` are the real bindings, and this script would only
 * ever be a same-named JS shadow racing an injection order neither
 * `WebView.addJavascriptInterface` nor `WebViewCompat.addDocumentStartJavaScript`
 * documents — so it is composed at the iOS call sites only, never in the shared
 * script both platforms install.
 *
 * An unknown `callNative` method name returns silently here, while Android's real
 * binding logs `unsupported_native_handler_method` before returning (see
 * `Platform.android.kt`'s `@JavascriptInterface fun callNative`). That is a deliberate
 * asymmetry, not an oversight: this script runs inside the consumer's own page, so it
 * must never write to a console the consumer does not own — the diagnostic Android
 * gets (via Logcat, off the page) has no iOS equivalent that stays off-page.
 *
 * The payload `p` is a contract, not a type this script enforces: the production web
 * caller declares `sendDataToApp: (message: string) => void` and always passes the
 * result of `JSON.stringify`, so `p` is expected to already be a string by the time it
 * reaches here. The iOS native receiver additionally tolerates a non-string body by
 * JSON-serializing it itself (`Platform.ios.kt`'s `NativeHandlerScriptMessageHandler.
 * userContentController`), but that is a receiver-side safety net — this shim performs
 * no normalization of its own.
 */
internal fun nativeHandlerWebkitDocumentStartScript(token: String?): String =
    nativeHandlerFetchWaveTokenRedefineScript(token) + NATIVE_HANDLER_WEBKIT_TRANSPORT_JS

private val NATIVE_HANDLER_WEBKIT_TRANSPORT_JS: String =
    "if(typeof window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP!=='function'){" +
        "window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP=function(p){" +
            "try{" +
                "if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.$NATIVE_HANDLER_BRIDGE_NAME){" +
                    "window.webkit.messageHandlers.$NATIVE_HANDLER_BRIDGE_NAME.postMessage(p);" +
                "}" +
            "}catch(e){}" +
        "};" +
    "}" +
    "if(typeof window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_CALL_NATIVE!=='function'){" +
        "window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_CALL_NATIVE=function(m,p,c){" +
            "try{" +
                "if(m==='$NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP'){" +
                    "window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP(p);" +
                "}" +
            "}catch(e){}" +
        "};" +
    "}"

// Wave tokens are JWT-shaped (base64url segments, A-Za-z0-9-_.) so this never has
// real work to do — kept anyway because the value crosses into a raw script string.
private fun String.toNativeHandlerJsLiteral(): String = buildString {
    append('"')
    this@toNativeHandlerJsLiteral.forEach { char ->
        when (char) {
            '\\' -> append("\\\\")
            '"' -> append("\\\"")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            else -> append(char)
        }
    }
    append('"')
}
