package br.com.wave.flow_wrapper_kmp

/**
 * Which leaf renders a resolved `RenderBlock` contract: the default Compose
 * tree ([COMPOSE]) or the Android View tree ([VIEW] — Android-only; every
 * other platform stays on [COMPOSE] regardless of this setting). Mirrors
 * `br.com.wave.flows.kmp.RenderEngine` on the native SDK this wrapper forwards to.
 */
enum class RenderEngine { COMPOSE, VIEW }
