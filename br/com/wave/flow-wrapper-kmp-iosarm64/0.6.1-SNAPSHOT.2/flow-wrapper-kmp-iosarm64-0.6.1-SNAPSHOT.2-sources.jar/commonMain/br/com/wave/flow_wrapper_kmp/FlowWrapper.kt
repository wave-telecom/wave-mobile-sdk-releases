package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import br.com.wave.flow_wrapper_kmp.featureflags.ContractFeatureFlagProvider
import br.com.wave.flow_wrapper_kmp.featureflags.Feature
import br.com.wave.flow_wrapper_kmp.featureflags.FeatureFlags
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRouting
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRoutingPolicy
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRoutingSessionContext

private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"
private const val NAVBAR_FLOW_PATH = "/flows/navbar"
private const val NAVBAR_CURRENT_PAGE_QUERY_PARAM = "currentPage"
private const val NAVBAR_NEXT_COMPONENT_ID_FIELD = "nextComponentId"
private const val NAVBAR_COMPONENT_SCREEN_TOKEN = "-screen-"

// Cap on consecutive render-process-gone recoveries before falling back to the error page,
// so a page that keeps killing its renderer can't loop reload↔death indefinitely.
private const val MAX_WEBVIEW_RECOVERY_ATTEMPTS = 3

// A death loop only counts recoveries within this rolling window: a death arriving after the
// window closes starts a fresh episode. This keeps legitimate, well-spaced OS memory kills
// recoverable forever while still capping a rapid load↔die loop.
private val WEBVIEW_RECOVERY_EPISODE_WINDOW = kotlin.time.Duration.parse("60s")

internal data class RuntimeConfig(
    val externalCode: String,
    val flowWrapperConfig: FlowWrapperConfig,
) {
    /**
     * The journeys WebView host, from the session token's `env` claim.
     *
     * Computed rather than captured: the claim only becomes readable once the native
     * session has resolved the credential (which happens during `start`, AFTER this
     * config is published so `onReady` callbacks can already read `currentConfig()`).
     * Every consumer — the warm-up URL, the entry URL, the host's own reads — happens
     * after that point.
     */
    val environment: FlowWrapperEnvironment
        get() = resolveSessionEnvironment()
}

/**
 * The single whitelist both env checks answer to: [requireSupportedEnvironmentClaim] on
 * the token the host just handed over, and [resolveSessionEnvironment] on the session
 * already open. They must never drift — a value one accepts and the other rejects would
 * mean a session that starts and then cannot build a URL.
 */
private fun mapSessionEnvironment(rawClaim: String?): FlowWrapperEnvironment? =
    rawClaim?.trim()?.uppercase()?.let { value ->
        FlowWrapperEnvironment.entries.firstOrNull { it.name == value }
    }

private fun invalidEnvironmentClaimMessage(rawClaim: String?): String =
    "FlowWrapper.start received an invalid waveToken: its payload's env claim must be one of " +
        "${FlowWrapperEnvironment.entries.joinToString(", ") { it.name }} (was ${rawClaim ?: "absent"})."

/**
 * Maps the token's raw `env` claim onto [FlowWrapperEnvironment].
 *
 * An absent or unrecognized claim used to fall back to the build type (debug -> DEV,
 * release -> PRD). That let a release build handed a dev token silently load the
 * production WebView host with one debug log line — the claim now decides, or
 * [start] fails loudly with a message the integrator can act on.
 */
private fun resolveSessionEnvironment(): FlowWrapperEnvironment {
    val raw = br.com.wave.flows.kmp.waveTokenEnvironment()
    return requireNotNull(mapSessionEnvironment(raw)) { invalidEnvironmentClaimMessage(raw) }
}

/**
 * Rejects an `env` value this build cannot route to, reading the claim off [waveToken]
 * itself — the store holds nothing yet at the point [start] calls this.
 *
 * [resolveSessionEnvironment] cannot stand in for it: every consumer of it runs behind
 * the native bridge (whose `runCatching` swallows the failure) or behind the legacy
 * warm-up, which a contract that never declares that engine legitimately skips. The
 * session would then open on an environment the SDK has no host for and only break
 * later, at the first URL built.
 */
private fun requireSupportedEnvironmentClaim(waveToken: String) {
    val raw = br.com.wave.flows.kmp.waveTokenEnvironmentClaim(waveToken)
    requireNotNull(mapSessionEnvironment(raw)) { invalidEnvironmentClaimMessage(raw) }
}

/** Maps the wrapper's host theme mode to the native SDK's equivalent (1:1). */
internal fun FlowThemeMode.toNativeThemeMode(): br.com.wave.flows.kmp.FlowThemeMode =
    when (this) {
        FlowThemeMode.System -> br.com.wave.flows.kmp.FlowThemeMode.System
        FlowThemeMode.Light -> br.com.wave.flows.kmp.FlowThemeMode.Light
        FlowThemeMode.Dark -> br.com.wave.flows.kmp.FlowThemeMode.Dark
    }

object FlowWrapper {
    private var runtimeConfig: RuntimeConfig? = null
    private var warmupHandle: FlowWrapperWarmupHandle? = null
    private var warmupGeneration: Long = 0
    private var navbarCurrentPage: String? = null
    private val themeModeState = mutableStateOf(FlowThemeMode.System)
    private val webViewRefreshTicks = mutableStateMapOf<String, Int>()      // requested (observable: wakes a composed block)
    private val webViewAppliedRefreshTicks = mutableMapOf<String, Int>()    // applied (plain: consuming it must NOT recompose)
    private val webViewRecreateTicks = mutableStateMapOf<String, Int>()     // process-gone recovery (observable: forces WebView recreation)
    private val webViewRecoveryAttempts = mutableMapOf<String, Int>()       // bounded retry guard (plain: consuming it must NOT recompose)
    private val webViewRecoveryEpisodeMarks = mutableMapOf<String, kotlin.time.TimeMark>() // start of the current recovery episode, per component

    // Test seam: swapped for a fake TimeSource in tests to control episode-window elapsing.
    internal var webViewRecoveryTimeSource: kotlin.time.TimeSource = kotlin.time.TimeSource.Monotonic

    internal fun resetForTests() {
        warmupHandle?.cancel()
        warmupHandle = null
        runtimeConfig = null
        warmupGeneration = 0
        navbarCurrentPage = null
        themeModeState.value = FlowThemeMode.System
        webViewRefreshTicks.clear()
        webViewAppliedRefreshTicks.clear()
        webViewRecreateTicks.clear()
        webViewRecoveryAttempts.clear()
        webViewRecoveryEpisodeMarks.clear()
        webViewRecoveryTimeSource = kotlin.time.TimeSource.Monotonic
        flowWrapperWarmupLauncher = DefaultFlowWrapperWarmupLauncher
        nativeRenderBridgeDelegate = DefaultNativeRenderBridgeDelegate
        DefaultNativeRenderBridgeDelegate.reset()
        RenderRouting.resetForTests()
        FeatureFlags.resetForTests()
        br.com.wave.flows.kmp.FlowWrapper.resetThemeForTests()
        // Session credential is process-wide state like the theme: without this a test
        // that started a session leaks its token into the next one's URLs.
        br.com.wave.flows.kmp.FlowWrapper.clearWaveToken()
    }

    fun setThemeMode(mode: FlowThemeMode) {
        if (!FeatureFlags.isEnabled(Feature.DarkMode)) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "set_theme_mode_ignored requested=$mode reason=feature_flag_disabled feature=DarkMode",
            )
            return
        }
        // WebView path: drives the themeMode URL query param.
        themeModeState.value = mode
        // Native path: forward to the kmp SDK so natively-rendered blocks follow the same
        // mode (the wrapper renders some blocks natively; both engines must agree).
        br.com.wave.flows.kmp.FlowWrapper.setThemeMode(mode.toNativeThemeMode())
    }

    internal fun currentThemeMode(): FlowThemeMode = themeModeState.value

    /**
     * Real SDK opt-in (not a debug-only backdoor) selecting the leaf renderer
     * for every mounted `RenderBlock`; forwards straight to the native SDK's
     * process-wide [br.com.wave.flows.kmp.FlowWrapper.renderEngine].
     */
    fun setRenderEngine(engine: RenderEngine) {
        br.com.wave.flows.kmp.FlowWrapper.renderEngine = when (engine) {
            RenderEngine.COMPOSE -> br.com.wave.flows.kmp.RenderEngine.COMPOSE
            RenderEngine.VIEW -> br.com.wave.flows.kmp.RenderEngine.VIEW
        }
    }

    /**
     * Map the contract's theme token to the DarkMode feature flag + theme mode.
     * `"on"`/`"system"`/`"light"`/`"dark"` enable theming with the requested mode;
     * `"off"`/null/unknown DISABLE it and lock both engines to light — visual theming is
     * not validated yet, so a disabled contract must never render dark (even if the OS is
     * dark). Installing the provider here is what lets the backend drive theming.
     */
    internal fun applyContractTheme(themeToken: String?) {
        val normalized = themeToken?.trim()?.lowercase()
        val (darkModeEnabled, mode) = when (normalized) {
            "on", "system" -> true to FlowThemeMode.System
            "light" -> true to FlowThemeMode.Light
            "dark" -> true to FlowThemeMode.Dark
            else -> false to FlowThemeMode.Light // themes off: lock to light, never follow system
        }
        FeatureFlags.installProvider(ContractFeatureFlagProvider(darkMode = darkModeEnabled))
        themeModeState.value = mode
        // Native engine follows the same decision (off -> light). The WebView path forces
        // light too via resolveThemeQueryParam when the flag is off.
        br.com.wave.flows.kmp.FlowWrapper.setThemeMode(mode.toNativeThemeMode())
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "contract_theme_applied token=$normalized darkMode=$darkModeEnabled mode=$mode",
        )
    }

    // Any active force (scoped or global) owns the leaf engine while active — the leaf
    // is process-wide, see RenderRoutingPolicy's nativeLeafRequested note. Set
    // unconditionally otherwise: iOS's platform gate (platformSupportsViewEngine=false)
    // keeps Compose even when VIEW is requested — the arbitrated iOS fallback.
    private fun applyContractRenderEngine(nativeLeafRequested: Boolean) {
        if (RenderRouting.activeOverride() != null) return
        setRenderEngine(if (nativeLeafRequested) RenderEngine.VIEW else RenderEngine.COMPOSE)
    }

    /** Bundles the two contract-driven flags that must land together at init. */
    internal fun applyContractPolicy(policy: RenderRoutingPolicy) {
        applyContractTheme(policy.themeToken)
        applyContractRenderEngine(policy.nativeLeafRequested)
    }

    /**
     * [waveToken] is the credential the integrator's own backend issued — a JWT whose
     * payload carries the BFF `base_url`, the `env` selecting the journeys WebView
     * host, and the subscriber's `externalCode`. It is required and never persisted:
     * the SDK holds it in memory for the life of the process, so every session starts
     * from a token the host hands over. The subscriber identifier is read from the
     * token's `externalCode` claim — there is no separate parameter for it, so a host
     * cannot pass one subscriber's identifier alongside another's token.
     *
     * Throws [IllegalArgumentException] when [waveToken] is blank, is not a readable
     * JWT, carries no `base_url`, `env` or `externalCode`, or names an `env` this build
     * has no journeys host for. Every one of those is checked before any session state
     * moves, so a bad credential never retires the session already running.
     *
     * [onUnauthorized], when given, is subscribed for the life of this session — it
     * fires on a BFF 401 whether or not any `RenderBlock` is mounted at the time,
     * including during this very `start`'s own warm-up.
     */
    fun start(
        waveToken: String,
        config: FlowWrapperConfig = FlowWrapperConfig(),
        onReady: (() -> Unit)? = null,
        onUnauthorized: (() -> Unit)? = null,
    ) {
        val sanitizedToken = waveToken.trim()

        require(sanitizedToken.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank waveToken."
        }

        // Before any session teardown, and before the native bridge — whose runCatching
        // would swallow it — so a bad credential surfaces to the integrator as the
        // config error it is, and a bad re-init never tears down a working session.
        // This also guarantees a non-blank externalCode claim.
        br.com.wave.flows.kmp.FlowWrapper.validateWaveToken(sanitizedToken)

        // The claim's VALUE, not just its presence, and here for the same reason: it is
        // the last point at which nothing has moved yet.
        requireSupportedEnvironmentClaim(sanitizedToken)

        val externalCode = checkNotNull(br.com.wave.flows.kmp.waveTokenExternalCode(sanitizedToken)) {
            "FlowWrapper.start: validateWaveToken succeeded but the externalCode claim could not be read back."
        }

        val nextConfig =
            RuntimeConfig(
                externalCode = externalCode,
                flowWrapperConfig = config,
            )

        runtimeConfig = nextConfig
        navbarCurrentPage = null
        br.com.wave.flows.kmp.FlowWrapper.webModuleBaseUrlOverride = config.webModuleBaseUrlOverride

        // Resolve routing before warm-up: warm targets come from policy.nativeFlowIds().
        val policy =
            RenderRouting.resolve(
                RenderRoutingSessionContext(
                    externalCode = externalCode,
                ),
            )

        // The same contract carries the theme flag and leaf engine: apply both before
        // any rendering.
        applyContractPolicy(policy)

        warmupHandle?.cancel()
        if (warmupHandle != null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_warmup_cancelled reason=new_start",
            )
        }
        warmupHandle = null
        val generation = ++warmupGeneration
        var readyInvoked = false
        var webWarmupStarted = false
        var webWarmupFinished = false
        // This session's own handle, kept apart from [warmupHandle]: a newer start() or a
        // logout() replaces the published one, and a late completion from THIS session
        // must never cancel that newer WebView.
        var ownedWarmupHandle: FlowWrapperWarmupHandle? = null

        // Readiness is the native init's alone. The legacy warm-up below is best-effort:
        // neither its ready callback nor its timeout can hold start() open, so a slow or
        // dead throwaway WebView no longer delays the host's onReady.
        fun invokeReady() {
            if (readyInvoked || generation != warmupGeneration) return
            readyInvoked = true
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_ready nativeRenderReady=true",
            )
            onReady?.invoke()
        }

        fun finishWebWarmup(reason: String, callbackType: String? = null) {
            if (webWarmupFinished || generation != warmupGeneration) return
            webWarmupFinished = true
            val handle = ownedWarmupHandle
            ownedWarmupHandle = null
            if (handle != null) {
                if (warmupHandle === handle) warmupHandle = null
                handle.cancel()
            }
            when (reason) {
                "callback" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_ready callbackType=${callbackType ?: "UNKNOWN"}",
                )
                "timeout" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_timeout timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS",
                )
                "unavailable" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_unavailable",
                )
            }
        }

        // Decides and launches the legacy warm-up. It runs from the init's callback
        // instead of alongside start(), because only there is the /api/init policy
        // installed — and a newer start() or a logout() can land in between, hence the
        // generation guard. [webWarmupStarted] makes the whole decision one-shot: an
        // init that calls back twice must not spawn a second throwaway WebView, nor
        // strand the first one by overwriting the handle that owns it. Provisional: this
        // branch exists only while the legacy webview does, and goes away with it.
        fun launchWebWarmupIfDeclared() {
            if (webWarmupStarted || generation != warmupGeneration) return
            webWarmupStarted = true

            if (!RenderRouting.sessionUsesWebView()) {
                platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_skipped reason=no_webview_declared",
                )
                return
            }

            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_warmup_started timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS",
            )

            // The warm-up URL reads the wave token resolved by onSdkStart, which is the
            // other reason this only runs from its callback: computing the URL any
            // earlier would warm the WebView unauthenticated.
            val launchedHandle =
                flowWrapperWarmupLauncher.launch(
                    entryUrl = nextConfig.warmupUrl(),
                    waveToken = br.com.wave.flows.kmp.waveTokenForWebView(),
                    onCallbackPayload = { payload ->
                        val callbackMessage = parseNativeBridgeParams(payload) ?: return@launch
                        if (!isFlowWrapperWarmupReadyCallback(callbackMessage)) {
                            platformLogDebug(
                                FLOW_WRAPPER_LOG_TAG,
                                "sdk_init_warmup_ignored_callback callbackType=${callbackMessage.type}",
                            )
                            return@launch
                        }
                        finishWebWarmup(reason = "callback", callbackType = callbackMessage.type)
                    },
                    onTimeout = {
                        finishWebWarmup(reason = "timeout")
                    },
                    timeoutMs = FLOW_WRAPPER_WARMUP_TIMEOUT_MS,
                )

            if (launchedHandle == null) {
                finishWebWarmup(reason = "unavailable")
                return
            }

            // A launcher that reported ready (or timed out) synchronously already closed
            // this warm-up, and a logout() reentered from a callback already invalidated
            // it. Either way the handle arrives dead: publishing it now would leave a
            // WebView running with nothing owning it.
            if (webWarmupFinished || generation != warmupGeneration) {
                launchedHandle.cancel()
                return
            }

            ownedWarmupHandle = launchedHandle
            warmupHandle = launchedHandle
        }

        // Opens the native session, which is what resolves the wave token (explicit >
        // persisted) into the store, and only calls back once the /api/init policy is
        // installed (or the seed kept, on failure). The legacy warm-up is decided from
        // there: it costs a WebView spawn, so it is paid for only when the resolved
        // contract (or an active force) explicitly named the legacy engine.
        nativeRenderBridgeDelegate.onSdkStart(
            waveToken = waveToken,
            onReady = {
                // Warm-up first, readiness second: the WebView gets its head start while
                // the host is still being told the SDK is up. It is never awaited — the
                // launch returns as soon as the WebView is spawned.
                launchWebWarmupIfDeclared()
                invokeReady()
            },
            onUnauthorized = onUnauthorized,
        )
    }

    /**
     * Logs the subscriber out: the integrator's word for dropping their session and
     * every trace of it this SDK holds, in memory or on disk, so they never have to
     * know a session is a token plus caches. Cancels any in-flight warm-up, forgets
     * the navbar's current page, and clears the native session's wave token — which
     * also purges the warm-up disk cache and the in-memory contract/header caches
     * `br.com.wave.flows.kmp.FlowWrapper.clearWaveToken` owns.
     *
     * Also drops [runtimeConfig] itself, not just the credential: an earlier change
     * removed the DEV/PRD fallback, so reading the session's `base_url`/`environment`
     * off a cleared token now throws instead of falling back — a stale in-memory
     * config held past logout would hit exactly that the next time anything tried to
     * read it. With no config left, the SDK requires a fresh [start] before it renders
     * anything again.
     *
     * Neither write above is Compose state — [runtimeConfig] never was, and
     * [br.com.wave.flows.kmp.FlowWrapper.clearWaveToken]'s credential store no longer
     * is either — so calling `logout()` cannot itself wake a mounted `RenderBlock`/
     * WebView into recomposing and re-reading the config it just cleared. A block
     * left mounted past logout simply keeps showing the logged-out subscriber's last
     * frame; the host is expected to unmount it (or start a new session).
     */
    fun logout() {
        warmupHandle?.cancel()
        warmupHandle = null
        // Same instrument [start] uses to retire a session: an init still in flight when
        // the subscriber logs out belongs to a session that no longer exists, so its
        // callback must neither deliver a stale onReady nor warm a WebView for it.
        warmupGeneration += 1
        runtimeConfig = null
        navbarCurrentPage = null
        br.com.wave.flows.kmp.FlowWrapper.clearWaveToken()
    }

    /**
     * Forwards a host refresh callback to the native SDK so the cached contract is actually
     * invalidated. Safe in webview mode: the native [br.com.wave.flows.kmp.FlowWrapper.refresh]
     * no-ops when no contract provider is configured (no native RenderBlock mounted).
     *
     * Also arms a one-shot cache bypass for the WebView render path: the next reload of
     * [componentId] loads once with `refresh=true` in the URL, then reverts.
     */
    fun refresh(componentId: String, externalCode: String? = null) {
        br.com.wave.flows.kmp.FlowWrapper.refresh(componentId, externalCode)
        webViewRefreshTicks[componentId] = (webViewRefreshTicks[componentId] ?: 0) + 1
    }

    internal fun webViewRefreshTick(componentId: String): Int = webViewRefreshTicks[componentId] ?: 0

    internal fun webViewAppliedRefreshTick(componentId: String): Int =
        webViewAppliedRefreshTicks[componentId] ?: 0

    internal fun markWebViewRefreshApplied(componentId: String, tick: Int) {
        webViewAppliedRefreshTicks[componentId] = tick
    }

    /**
     * Recovers a WebView whose render process was killed (Android `onRenderProcessGone` with
     * `didCrash == false`, iOS `webViewWebContentProcessDidTerminate`) — the usual outcome of the
     * OS reclaiming memory while the app was backgrounded. Bumps a recreate tick that forces the
     * composed block to drop the defunct WebView and rebuild a fresh one, reloading the SAME URL
     * (no cache bypass, unlike [refresh]).
     *
     * Attempts are counted per rolling [WEBVIEW_RECOVERY_EPISODE_WINDOW]: a death arriving after
     * the window since the last recovery starts a fresh episode with the counter back at zero, so
     * well-spaced OS memory kills always recover. Only [MAX_WEBVIEW_RECOVERY_ATTEMPTS] recoveries
     * inside the same episode are allowed — a rapid load↔die loop cannot spin forever. Returns
     * `false` when the in-episode budget is spent, signalling the caller to fall back to the
     * static error page; a later death, once the window has elapsed, may recover again.
     */
    internal fun recreateWebView(componentId: String): Boolean {
        val episodeMark = webViewRecoveryEpisodeMarks[componentId]
        val episodeExpired = episodeMark == null || episodeMark.elapsedNow() >= WEBVIEW_RECOVERY_EPISODE_WINDOW
        val attempts = if (episodeExpired) 0 else webViewRecoveryAttempts[componentId] ?: 0
        if (attempts >= MAX_WEBVIEW_RECOVERY_ATTEMPTS) return false
        webViewRecoveryAttempts[componentId] = attempts + 1
        webViewRecoveryEpisodeMarks[componentId] = webViewRecoveryTimeSource.markNow()
        webViewRecreateTicks[componentId] = (webViewRecreateTicks[componentId] ?: 0) + 1
        return true
    }

    internal fun webViewRecreateTick(componentId: String): Int = webViewRecreateTicks[componentId] ?: 0

    private fun requireConfig(): RuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(waveToken) must be called before RenderBlock()."
        }
    }

    internal fun currentConfig(): RuntimeConfig = requireConfig()

    internal fun resolveEntryPathForRendering(entryPath: String): String {
        if (entryPath != NAVBAR_FLOW_PATH) return entryPath
        val currentPage = navbarCurrentPage ?: return entryPath
        if (entryPath.containsQueryParam(NAVBAR_CURRENT_PAGE_QUERY_PARAM)) return entryPath
        return entryPath.appendQueryParameter(NAVBAR_CURRENT_PAGE_QUERY_PARAM, currentPage)
    }

    internal fun updateRuntimeStateFromCallback(
        entryPath: String,
        callbackMessage: NativeCallbackMessage,
    ) {
        if (entryPath != NAVBAR_FLOW_PATH) return

        val currentPage = callbackMessage.resolveNavbarCurrentPage() ?: return

        if (navbarCurrentPage == currentPage) return
        navbarCurrentPage = currentPage
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "navbar_state_updated currentPage=$currentPage",
        )
    }
}

private fun String.containsQueryParam(paramName: String): Boolean {
    return contains("?$paramName=") || contains("&$paramName=")
}

private fun String.appendQueryParameter(
    paramName: String,
    paramValue: String,
): String {
    val separator = if ('?' in this) '&' else '?'
    return "$this$separator$paramName=$paramValue"
}

private fun NativeCallbackMessage.resolveNavbarCurrentPage(): String? {
    extractStringFieldFromJson(
        json = payload,
        fieldName = NAVBAR_CURRENT_PAGE_QUERY_PARAM,
    )?.let { return it }

    if (!type.equals("RENDER_BLOCK_NAVIGATE", ignoreCase = true)) return null

    val nextComponentId =
        extractStringFieldFromJson(
            json = payload,
            fieldName = NAVBAR_NEXT_COMPONENT_ID_FIELD,
        ) ?: return null

    return nextComponentId.toNavbarCurrentPageOrNull()
}

private fun String.toNavbarCurrentPageOrNull(): String? {
    val screenTokenIndex = indexOf(NAVBAR_COMPONENT_SCREEN_TOKEN)
    if (screenTokenIndex <= 0) return null
    return substring(0, screenTokenIndex).takeIf { it.isNotBlank() }
}
