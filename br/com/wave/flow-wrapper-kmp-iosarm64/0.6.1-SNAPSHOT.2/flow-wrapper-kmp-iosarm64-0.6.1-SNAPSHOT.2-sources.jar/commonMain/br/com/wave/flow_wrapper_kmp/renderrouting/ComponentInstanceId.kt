package br.com.wave.flow_wrapper_kmp.renderrouting

// The WebView render-block-sdk stamps a per-instance UUID v4 onto the stable
// block id when it emits the navigate callback, e.g.
// `bottom-sheet-plan-details-c98f4f0e-5b53-479a-9b5e-70258d5c3705`. The native
// block index (warmed from the BFF tree) only knows the stable id
// `bottom-sheet-plan-details`, so we strip a trailing UUID to bridge the two.
// This is a transport quirk of the WebView SDK, not a routing rule — it stays
// agnostic of which component is being routed.
private val NATIVE_INSTANCE_SUFFIX =
    Regex("-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

internal fun stableComponentId(componentId: String): String =
    componentId.replace(NATIVE_INSTANCE_SUFFIX, "")
