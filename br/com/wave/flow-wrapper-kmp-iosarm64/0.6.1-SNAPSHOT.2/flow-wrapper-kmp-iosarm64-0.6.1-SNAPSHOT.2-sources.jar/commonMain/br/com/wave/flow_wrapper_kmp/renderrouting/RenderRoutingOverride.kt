package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * Debug/QA force: routes [target] for the requests it [appliesTo], winning over the
 * contract. An empty [targetIds] means "every target" — today's global force is this
 * type's degenerate case, not a second mechanism.
 *
 * Id-matching contract: a *flow* id matches exactly (flows never carry the WebView
 * per-instance UUID suffix). A *component* id matches when the raw ids are equal OR
 * when both sides, UUID-stripped, are equal — so a scope built from the stable id
 * catches the per-instance id copied from a live render, and vice-versa. No prefix
 * matching: prefix families are the contract layer's job ([RenderRoutingRule]); this
 * is an exact instrument. Blank/whitespace ids are dropped, so a request with a blank
 * field never matches a scoped override. A non-empty [targetIds] that normalises to no
 * valid id is a scope request with nothing in it, not "no scope" — it must never fall
 * back to matching every target; [appliesTo] returns false for everything in that case.
 */
internal data class RenderRoutingOverride(
    val target: RenderTarget,
    val targetIds: Set<String> = emptySet(),
) {
    private val ids: Set<String> =
        targetIds.mapNotNullTo(mutableSetOf()) { it.trim().takeIf(String::isNotEmpty) }

    /** Covers every request — the unscoped force, which decides the session on its own. */
    fun coversEveryTarget(): Boolean = targetIds.isEmpty()

    /** Routes at least one request: unscoped, or scoped to at least one usable id. */
    fun routesAnyTarget(): Boolean = targetIds.isEmpty() || ids.isNotEmpty()

    fun appliesTo(flowId: String?, componentId: String?): Boolean {
        if (targetIds.isEmpty()) return true
        if (ids.isEmpty()) return false
        val flow = flowId?.trim().orEmpty()
        val component = componentId?.trim().orEmpty()
        val stableComponent = stableComponentId(component)
        return ids.any { id ->
            (flow.isNotEmpty() && id == flow) ||
                (component.isNotEmpty() && (id == component || stableComponentId(id) == stableComponent))
        }
    }
}
