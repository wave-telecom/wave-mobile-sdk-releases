package br.com.wave.flow_wrapper_kmp.renderrouting

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Wire shape of the routing contract (see `docs/render-routing-flags.md`). Kept
 * separate from the domain model so the transport can evolve independently — the
 * DTO maps to [RenderRoutingPolicy] via [toPolicy].
 */
@Serializable
internal data class RenderRoutingEnvelopeDto(
    val version: Int = 1,
    val renderRouting: RenderRoutingDto? = null,
    val metadata: RenderRoutingMetadataDto? = null,
)

@Serializable
internal data class RenderRoutingDto(
    val default: String? = null,
    val rules: List<RenderRoutingRuleDto> = emptyList(),
)

@Serializable
internal data class RenderRoutingRuleDto(
    val renderer: String? = null,
    val match: RenderRoutingMatchDto = RenderRoutingMatchDto(),
)

@Serializable
internal data class RenderRoutingMatchDto(
    val flowId: String? = null,
    val componentId: String? = null,
    val componentIdPrefix: String? = null,
    val scrollable: Boolean? = null,
)

@Serializable
internal data class RenderRoutingMetadataDto(
    val features: List<RenderRoutingFeatureDto> = emptyList(),
)

@Serializable
internal data class RenderRoutingFeatureDto(
    val flows: List<RenderRoutingFeatureTargetDto> = emptyList(),
    val components: List<RenderRoutingFeatureTargetDto> = emptyList(),
    val theme: String? = null,
)

@Serializable
internal data class RenderRoutingFeatureTargetDto(
    val id: String? = null,
    val renderMode: String? = null,
    // For a kmp component: the flow that embeds it. The component is not fetchable
    // standalone (it is a block inside the flow tree), so this names the flow to warm.
    val sourceFlowId: String? = null,
)

private fun RenderRoutingMatchDto.isEmpty(): Boolean =
    flowId == null && componentId == null && componentIdPrefix == null && scrollable == null

internal fun RenderRoutingRuleDto.toRuleOrNull(): RenderRoutingRule? {
    // Drop rules with an empty match — they would capture everything and shadow the
    // default. Trim blanks to null so `"flowId": ""` is treated as "no constraint".
    if (match.isEmpty()) return null
    return RenderRoutingRule(
        target = RenderTarget.fromTokenOrDefault(renderer),
        flowId = flowId.normalizeOrNull(),
        componentId = componentId.normalizeOrNull(),
        componentIdPrefix = componentIdPrefix.normalizeOrNull(),
        scrollable = scrollable,
    ).takeIf { it.matchesAnything() }
}

private val RenderRoutingRuleDto.flowId get() = match.flowId
private val RenderRoutingRuleDto.componentId get() = match.componentId
private val RenderRoutingRuleDto.componentIdPrefix get() = match.componentIdPrefix
private val RenderRoutingRuleDto.scrollable get() = match.scrollable

private fun String?.normalizeOrNull(): String? = this?.trim()?.takeIf(String::isNotEmpty)

private fun RenderRoutingRule.matchesAnything(): Boolean =
    flowId != null || componentId != null || componentIdPrefix != null || scrollable != null

/**
 * A component feature → routing rule. The component `id` is a wildcard: a trailing
 * `*` means prefix match (`"bottom-sheet-*"` → any `bottom-sheet-…`, including the
 * instance-suffixed family `bottom-sheet-plan-details-<uuid>`); otherwise it's an
 * exact id. The `*` is a literal sentinel we strip — NOT a regex. Only `kmp`/`native`
 * components produce a rule; a `webview` component produces an explicit WEBVIEW rule (D4).
 */
private fun RenderRoutingFeatureTargetDto.toComponentRule(): RenderRoutingRule? {
    val target = RenderTarget.fromTokenOrDefault(renderMode)
    val raw = id.normalizeOrNull() ?: return null
    val source = sourceFlowId.normalizeOrNull()
    val rule =
        if (raw.endsWith("*")) {
            val prefix = raw.dropLast(1).normalizeOrNull() ?: return null
            RenderRoutingRule(target = target, componentIdPrefix = prefix, sourceFlowId = source)
        } else {
            RenderRoutingRule(target = target, componentId = raw, sourceFlowId = source)
        }
    return rule.takeIf { it.matchesAnything() }
}

/**
 * `metadata.features` → policy. `flows` declare which flows to WARM natively
 * (policy.warmFlowIds); `components` declare which blocks actually RENDER native
 * (routing rules). A flow declared kmp (D3) renders its whole tree native; a kmp
 * component's `sourceFlowId` names the flow to warm. Note: this shape carries
 * no `scrollable`, so a non-scroll constraint cannot be expressed here (it can in the
 * `renderRouting.rules` shape).
 */
private fun List<RenderRoutingFeatureDto>.toPolicy(): RenderRoutingPolicy {
    // Component rules. A webview component (D4) forces webview; a kmp component routes
    // native. Webview rules come first so an explicit webview component wins over a
    // native flow rule for the same flow.
    val componentRules =
        flatMap { feature -> feature.components.mapNotNull { it.toComponentRule() } }
            .sortedBy { if (it.target == RenderTarget.WEBVIEW) 0 else 1 }

    // Non-default flows (D3): a flow declared kmp (or web-module) renders its whole tree
    // that way — emit a flowId rule. WEBVIEW needs none; it's already the policy default.
    // Placed after component rules so a webview component still wins.
    val flowRules =
        flatMap { feature ->
            feature.flows.mapNotNull { flow ->
                val target = RenderTarget.fromTokenOrDefault(flow.renderMode)
                if (target == RenderTarget.WEBVIEW) return@mapNotNull null
                flow.id.normalizeOrNull()?.let { RenderRoutingRule(target = target, flowId = it) }
            }
        }

    // Flows to warm natively: native flows, plus the sourceFlowId of every native
    // component (the flow that embeds it — the component is not fetchable alone).
    val nativeFlowDeclarations =
        flatMap { feature ->
            feature.flows
                .filter { RenderTarget.fromTokenOrDefault(it.renderMode) == RenderTarget.NATIVE }
                .mapNotNull { it.id.normalizeOrNull() }
        }
    val componentSourceFlows =
        flatMap { feature ->
            feature.components
                .filter { RenderTarget.fromTokenOrDefault(it.renderMode) == RenderTarget.NATIVE }
                .mapNotNull { it.sourceFlowId.normalizeOrNull() }
        }
    val warmFlowIds = (nativeFlowDeclarations + componentSourceFlows).toSet()

    // The theme flag is a single SDK-wide setting; take the first feature that declares one.
    val themeToken = firstNotNullOfOrNull { it.theme.normalizeOrNull() }

    // At least one NATIVE-routed feature used the literal `native` token (not `kmp`).
    val nativeLeafRequested = any { feature ->
        (feature.flows + feature.components).any { isNativeLeafToken(it.renderMode) }
    }

    // The one thing the rules above cannot carry: a flow declared `webview` produces no
    // rule, because a rule saying WEBVIEW would only restate the default. The
    // declaration itself still matters — it is the contract naming the legacy engine —
    // so it travels on the policy instead of being inferred back out of the rules.
    // An entry with no usable id declares nothing routable and does not count.
    val webViewExplicitlyDeclared = any { feature ->
        (feature.flows + feature.components).any {
            isWebViewToken(it.renderMode) && it.id.normalizeOrNull() != null
        }
    }

    return RenderRoutingPolicy(
        default = RenderTarget.WEBVIEW,
        rules = componentRules + flowRules,
        warmFlowIds = warmFlowIds,
        themeToken = themeToken,
        nativeLeafRequested = nativeLeafRequested,
        webViewExplicitlyDeclared = webViewExplicitlyDeclared,
    )
}

internal fun RenderRoutingDto.toPolicy(): RenderRoutingPolicy {
    // Paired with the source dto so the renderer TOKEN survives the mapping: the mapped
    // rule only knows it resolved to WEBVIEW, which a rule with no renderer at all also
    // does. Dropped rules declare nothing, so only the surviving pairs are consulted.
    val mapped = rules.mapNotNull { dto -> dto.toRuleOrNull()?.let { dto.renderer to it } }
    return RenderRoutingPolicy(
        default = RenderTarget.fromTokenOrDefault(default),
        rules = mapped.map { it.second },
        nativeLeafRequested = rules.any { isNativeLeafToken(it.renderer) },
        webViewExplicitlyDeclared = mapped.any { isWebViewToken(it.first) },
    )
}

private val renderRoutingJson = Json {
    ignoreUnknownKeys = true
    isLenient = true
}

/**
 * Parse a routing contract document into a policy. Any malformed input degrades to
 * [RenderRoutingPolicy.WEBVIEW_ONLY] — the safe engine — rather than throwing into
 * the init path.
 */
internal fun parseRenderRoutingPolicy(json: String?): RenderRoutingPolicy {
    if (json.isNullOrBlank()) return RenderRoutingPolicy.WEBVIEW_ONLY
    return runCatching {
        val envelope = renderRoutingJson.decodeFromString(RenderRoutingEnvelopeDto.serializer(), json)
        val features = envelope.metadata?.features.orEmpty()
        when {
            features.isNotEmpty() ->
                features.toPolicy()
            envelope.renderRouting != null ->
                envelope.renderRouting.toPolicy()
            else ->
                RenderRoutingPolicy.WEBVIEW_ONLY
        }
    }.getOrDefault(RenderRoutingPolicy.WEBVIEW_ONLY)
}
