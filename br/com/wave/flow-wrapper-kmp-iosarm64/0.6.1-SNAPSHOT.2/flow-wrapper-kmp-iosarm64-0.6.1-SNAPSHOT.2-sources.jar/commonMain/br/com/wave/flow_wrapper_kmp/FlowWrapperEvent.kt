package br.com.wave.flow_wrapper_kmp

sealed class SDKEvent {
    data class Error(
        val componentId: String,
        val code: String,
        val message: String,
    ) : SDKEvent()

    data class ComponentLoaded(
        val componentId: String,
    ) : SDKEvent()

    data class Callback(
        val type: String,
        val payload: String,
        val origin: String,
    ) : SDKEvent()

    data class ActionTracked(
        val type: String,
        val payload: Map<String, String>,
        val timestamp: String,
        val origin: String,
    ) : SDKEvent()

    /**
     * The session's credential was rejected by the BFF (401) — seen either by the
     * native HTTP client or reported by the WebView page over the JS bridge; both
     * converge on this SAME case. The SDK does not retry on its own: the host owns
     * credential acquisition and must call [FlowWrapper.start] again with a fresh
     * waveToken to open a new session.
     */
    data object Unauthorized : SDKEvent()
}
