package br.com.wave.flow_wrapper_kmp.renderrouting

import br.com.wave.flow_wrapper_kmp.RenderTargetRef

/**
 * Whether [target] should render through the `:webblocks` module. Deliberately not a method
 * on the native bridge delegate: that seam answers native readiness/rendering and is swapped
 * wholesale by tests, while an engine decision for a non-native target does not belong behind
 * it.
 */
internal fun shouldRenderWebModule(target: RenderTargetRef, scroll: Boolean): Boolean =
    RenderRouting.targetFor(
        flowId = (target as? RenderTargetRef.Flow)?.flowId,
        componentId = (target as? RenderTargetRef.Component)?.componentId,
        scrollable = scroll,
    ) == RenderTarget.WEB_MODULE
