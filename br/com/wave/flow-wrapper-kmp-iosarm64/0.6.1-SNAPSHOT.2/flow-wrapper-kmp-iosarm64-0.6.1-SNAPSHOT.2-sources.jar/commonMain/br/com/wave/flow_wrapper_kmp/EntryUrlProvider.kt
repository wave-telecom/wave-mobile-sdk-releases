package br.com.wave.flow_wrapper_kmp

private const val BASE_URL_DEV = "https://dev.journeys.telcel.wavebybemobi.com"
private const val BASE_URL_PRD = "https://journeys.telcel.wavebybemobi.com"

data class EntryUrlContext(
    val externalCode: String,
    val environment: FlowWrapperEnvironment,
    val path: String,
    val themeMode: String? = null,
    val refresh: Boolean = false,
)

fun interface EntryUrlProvider {
    fun urlFor(context: EntryUrlContext): String
}

object DefaultEntryUrlProvider : EntryUrlProvider {
    override fun urlFor(context: EntryUrlContext): String {
        val baseUrl = when (context.environment) {
            FlowWrapperEnvironment.DEV -> BASE_URL_DEV
            FlowWrapperEnvironment.PRD -> BASE_URL_PRD
        }
        val url = StringBuilder(
            "$baseUrl${context.path}${context.path.querySeparator()}externalCode=${context.externalCode}",
        )
        // The wave token never travels in the URL: it lands in the page through
        // NativeHandler.fetchWaveToken() (see NativeHandlerBridge.kt) instead, so it
        // never reaches browser history, a Referer header, or an access log.
        context.themeMode?.let { url.append("&themeMode=").append(it) }
        if (context.refresh) url.append("&refresh=true")
        return url.toString()
    }
}

private fun String.querySeparator(): Char = if ('?' in this) '&' else '?'
