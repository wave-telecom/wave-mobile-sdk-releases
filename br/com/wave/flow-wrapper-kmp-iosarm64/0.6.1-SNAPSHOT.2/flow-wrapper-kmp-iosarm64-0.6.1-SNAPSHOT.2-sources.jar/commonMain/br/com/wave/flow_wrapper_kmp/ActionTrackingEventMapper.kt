package br.com.wave.flow_wrapper_kmp

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.time.Clock

internal const val EVENT_RENDER_BLOCK_ACTION_TRACK = "RENDER_BLOCK_ACTION_TRACK"
internal const val ACTION_TRACK_TYPE_CLICK = "click"

/**
 * The web page's own BFF call got a 401 and it is reporting that over the JS bridge —
 * the same fact the native HTTP client's auth interceptor reports for a native call.
 * Both converge on [SDKEvent.Unauthorized].
 */
internal const val EVENT_RENDER_BLOCK_UNAUTHORIZED = "RENDER_BLOCK_UNAUTHORIZED"

private val actionTrackingJson = Json { ignoreUnknownKeys = true }

/**
 * `true` when the WebView page is reporting, over the JS bridge, that its own BFF
 * call got a 401 — the counterpart of the native HTTP client's auth interceptor
 * seeing the same status. Both must resolve to the identical [SDKEvent.Unauthorized]
 * case.
 */
internal fun NativeCallbackMessage.isUnauthorizedCallback(): Boolean =
    type.equals(EVENT_RENDER_BLOCK_UNAUTHORIZED, ignoreCase = true)

internal fun NativeCallbackMessage.toActionTrackedEvent(origin: String): SDKEvent.ActionTracked? {
    if (!type.equals(EVENT_RENDER_BLOCK_ACTION_TRACK, ignoreCase = true) &&
        !type.equals(ACTION_TRACK_TYPE_CLICK, ignoreCase = true)
    ) {
        return null
    }

    val root = payload.toJsonObjectOrNull() ?: return null
    val actionData = root.actionDataObject(type) ?: return null

    return SDKEvent.ActionTracked(
        type = actionData.stringField("type") ?: ACTION_TRACK_TYPE_CLICK,
        payload = actionData.mapPayload(),
        timestamp = actionData.stringField("timestamp") ?: Clock.System.now().toString(),
        origin = origin,
    )
}

private fun String.toJsonObjectOrNull(): JsonObject? =
    runCatching { actionTrackingJson.parseToJsonElement(this).jsonObject }.getOrNull()

private fun JsonObject.actionDataObject(callbackType: String): JsonObject? {
    if (callbackType.equals(EVENT_RENDER_BLOCK_ACTION_TRACK, ignoreCase = true)) {
        return this["payload"] as? JsonObject ?: this
    }
    return this
}

private fun JsonObject.stringField(name: String): String? =
    (this[name] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }

private fun JsonObject.mapPayload(): Map<String, String> {
    val payloadObject = this["payload"] as? JsonObject ?: return emptyMap()
    return payloadObject.mapNotNull { (key, value) ->
        val primitive = value as? JsonPrimitive ?: return@mapNotNull null
        val stringValue = primitive.contentOrNull ?: primitive.toString()
        key to stringValue
    }.toMap()
}
