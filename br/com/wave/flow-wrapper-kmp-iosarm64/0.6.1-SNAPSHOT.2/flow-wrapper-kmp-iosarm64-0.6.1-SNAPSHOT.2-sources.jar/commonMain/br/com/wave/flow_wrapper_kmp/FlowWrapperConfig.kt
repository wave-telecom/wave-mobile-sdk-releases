package br.com.wave.flow_wrapper_kmp

enum class FlowWrapperEnvironment {
    DEV,
    PRD,
}

data class FlowWrapperConfig(
    val entryUrlProvider: EntryUrlProvider = DefaultEntryUrlProvider,
    /** Optional debug/QA override of the web-module base URL; null keeps the SDK
     *  default. The native BFF base URL has no counterpart: it comes from the
     *  session token's `base_url` claim. */
    val webModuleBaseUrlOverride: String? = null,
)
