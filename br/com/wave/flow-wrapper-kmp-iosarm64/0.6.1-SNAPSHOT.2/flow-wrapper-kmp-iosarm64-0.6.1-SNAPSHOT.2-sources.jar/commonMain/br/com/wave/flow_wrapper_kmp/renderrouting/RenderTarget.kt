package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * The three engines a render request can be served by — the SDK's only routing nouns.
 * Everything tenant-specific (which flow, which component) is backend data, never a
 * constant in SDK logic. [WEBVIEW] is the stable default; [NATIVE] is Compose (or the
 * platform-native leaf); [WEB_MODULE] is the `:webblocks` render arm.
 */
internal enum class RenderTarget {
    WEBVIEW,
    NATIVE,
    WEB_MODULE,
    ;

    companion object {
        /** Unknown / blank tokens fall back to [WEBVIEW] so a contract typo never lands on native. */
        fun fromTokenOrDefault(token: String?): RenderTarget =
            when (token?.trim()?.lowercase()) {
                "native", "kmp" -> NATIVE
                "webview" -> WEBVIEW
                WEB_MODULE_RENDER_MODE_TOKEN -> WEB_MODULE
                else -> WEBVIEW
            }
    }
}

/**
 * The `metadata.features[].renderMode` token that selects the web module. Provisional: the
 * field is emitted by the platform team that owns the init transform, not by either BFF in
 * this repo, so the value is expected to change once they ratify it — it is a constant here
 * precisely so that is a one-line edit.
 */
internal const val WEB_MODULE_RENDER_MODE_TOKEN = "webmodule"

/**
 * `kmp` routes NATIVE via the Compose leaf; `native` routes NATIVE via the platform-
 * native leaf (Android View). Both still map to [RenderTarget.NATIVE] above — routing
 * is unchanged; this only distinguishes the leaf preference.
 */
internal fun isNativeLeafToken(token: String?): Boolean =
    token?.trim()?.lowercase() == "native"

/**
 * The contract asked for the legacy engine in so many words. Not the same question as
 * "does this resolve to [RenderTarget.WEBVIEW]": [RenderTarget.fromTokenOrDefault]
 * answers WEBVIEW for an absent or unknown token too, and that is a fallback, not a
 * declaration.
 */
internal fun isWebViewToken(token: String?): Boolean =
    token?.trim()?.lowercase() == "webview"
