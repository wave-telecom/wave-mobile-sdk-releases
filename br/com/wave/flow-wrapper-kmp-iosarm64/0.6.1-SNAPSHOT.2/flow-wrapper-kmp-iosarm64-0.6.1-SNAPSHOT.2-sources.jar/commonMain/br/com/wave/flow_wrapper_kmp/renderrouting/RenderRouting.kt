package br.com.wave.flow_wrapper_kmp.renderrouting

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Central access point for render routing — the routing analogue of `FeatureFlags`,
 * internal to the SDK. `FlowWrapper.start` [resolve]s once at init and caches the
 * policy; [current]/[targetFor] then read it synchronously, which is what the render
 * path (composition) and warm-up need. Starts as [RenderRoutingPolicy.WEBVIEW_ONLY]
 * so any read before init is safe.
 */
internal object RenderRouting {
    private var source: RenderRoutingSource = DefaultRenderRoutingSource
    private var policy: RenderRoutingPolicy = RenderRoutingPolicy.WEBVIEW_ONLY
    // Debug/QA override: when non-null, forces the listed targets (or every target
    // when its id set is empty) to one engine, winning over the contract rules. null =
    // no override (the contract decides). Set via FlowDebug.RenderRouting; not part of
    // the host contract.
    private var override: RenderRoutingOverride? by mutableStateOf(null)

    /**
     * Replace the policy source. Reserved for init wiring — e.g. switching from the
     * bootstrap seed to a claim- or endpoint-backed source. Does not re-resolve;
     * the next [resolve] (or the explicit one at init) applies it.
     */
    fun installSource(source: RenderRoutingSource) {
        this.source = source
    }

    /** Resolve and cache the policy for this session. Called once at init, before warm-up. */
    fun resolve(session: RenderRoutingSessionContext): RenderRoutingPolicy {
        policy = source.policyFor(session)
        return policy
    }

    /** Pin a policy directly, bypassing the source. For tests and the synchronous claim path. */
    fun install(policy: RenderRoutingPolicy) {
        this.policy = policy
    }

    fun current(): RenderRoutingPolicy = policy

    fun targetFor(flowId: String?, componentId: String?, scrollable: Boolean): RenderTarget =
        override?.takeIf { it.appliesTo(flowId, componentId) }?.target ?: policy.resolve(
            flowId = flowId,
            componentId = componentId,
            scrollable = scrollable,
            defaultTarget = RenderTarget.WEBVIEW,
        )

    /**
     * Was the legacy webview explicitly asked for in this session — by the contract
     * ([RenderRoutingPolicy.webViewExplicitlyDeclared]) or by an effective QA force?
     * Read-only, and deliberately narrower than [targetFor]: a request that merely
     * *lands* on WEBVIEW through the default or the fallback did not ask for it, and
     * nothing costly is spent on that inference. The override is honoured the way
     * [targetFor] honours it — a force to WEBVIEW means yes, and an unscoped force to
     * another engine means no, because then nothing is left for the legacy engine.
     */
    fun sessionUsesWebView(): Boolean {
        val active = override
        if (active != null && active.routesAnyTarget()) {
            if (active.target == RenderTarget.WEBVIEW) return true
            if (active.coversEveryTarget()) return false
        }
        return policy.webViewExplicitlyDeclared
    }

    /** Debug/QA force override (wins over contract rules for the ids it applies to). null clears it. */
    fun installOverride(override: RenderRoutingOverride?) {
        this.override = override
    }

    fun activeOverride(): RenderRoutingOverride? = override

    internal fun resetForTests() {
        source = DefaultRenderRoutingSource
        policy = RenderRoutingPolicy.WEBVIEW_ONLY
        override = null
    }
}
