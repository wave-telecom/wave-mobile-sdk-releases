package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.18-rc.116"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-01T15:03:39.336605-03:00"
    const val GIT_SHA: String = "4257f28"
    const val GIT_BRANCH: String = "release/0.5.18"
    const val DESCRIPTION: String = "0.5.18-rc.116@2026-07-01T15:03:39.336605-03:00#4257f28"
}