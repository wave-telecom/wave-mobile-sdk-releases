package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRouting
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderTarget
import br.com.wave.flows.kmp.WarmTarget
import br.com.wave.flows.kmp.WarmTargetMode
import br.com.wave.flows.kmp.WarmTargetType

private const val NATIVE_RENDER_LOG_TAG = "FlowWrapperKmp"

// The WebView render-block-sdk stamps a per-instance UUID v4 onto the stable
// block id when it emits the navigate callback, e.g.
// `bottom-sheet-plan-details-c98f4f0e-5b53-479a-9b5e-70258d5c3705`. The native
// block index (warmed from the BFF tree) only knows the stable id
// `bottom-sheet-plan-details`, so we strip a trailing UUID to bridge the two.
// This is a transport quirk of the WebView SDK, not a routing rule — it stays
// agnostic of which component is being routed.
private val NATIVE_INSTANCE_SUFFIX =
    Regex("-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

private fun stableNativeComponentId(componentId: String): String =
    componentId.replace(NATIVE_INSTANCE_SUFFIX, "")

internal interface NativeBottomSheetBridgeDelegate {
    fun onSdkStart(
        apiKey: String,
        msisdn: String,
        onReady: () -> Unit,
    )

    fun shouldRenderNatively(
        componentId: String?,
        flowId: String?,
        scroll: Boolean,
    ): Boolean

    @Composable
    fun RenderBlock(
        componentId: String?,
        flowId: String?,
        onEvent: ((SDKEvent) -> Unit)?,
        modifier: Modifier = Modifier,
    )
}

internal var nativeBottomSheetBridgeDelegate: NativeBottomSheetBridgeDelegate =
    DefaultNativeBottomSheetBridgeDelegate

internal object DefaultNativeBottomSheetBridgeDelegate : NativeBottomSheetBridgeDelegate {
    private var startGeneration: Long = 0
    private var nativeWarmReady: Boolean = false

    override fun onSdkStart(
        apiKey: String,
        msisdn: String,
        onReady: () -> Unit,
    ) {
        val generation = ++startGeneration
        nativeWarmReady = false

        // Warm the flows the policy routes to native; the SDK no longer hard-codes them.
        val nativeFlowIds = RenderRouting.current().nativeFlowIds()
        if (nativeFlowIds.isEmpty()) {
            platformLogDebug(
                NATIVE_RENDER_LOG_TAG,
                "native_render_warm_skipped reason=no_native_routes",
            )
            onReady()
            return
        }

        runCatching {
            br.com.wave.flows.kmp.FlowWrapper.setMsisdn(
                apiKey = apiKey,
                msisdn = msisdn,
            )
            br.com.wave.flows.kmp.FlowWrapper.warm(
                targets = nativeFlowIds.map { id ->
                    WarmTarget(
                        slug = id,
                        type = WarmTargetType.FLOW,
                        mode = WarmTargetMode.FULL,
                    )
                },
                onReady = {
                    if (generation != startGeneration) return@warm
                    nativeWarmReady = nativeFlowIds.all { id ->
                        br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(id)
                    }
                    platformLogDebug(
                        NATIVE_RENDER_LOG_TAG,
                        "native_render_warm_finished flows=${nativeFlowIds.joinToString(",")} ready=$nativeWarmReady",
                    )
                    onReady()
                },
            )
        }.onFailure { error ->
            if (generation != startGeneration) return
            nativeWarmReady = false
            platformLogDebug(
                NATIVE_RENDER_LOG_TAG,
                "native_render_warm_failed message=${error.message}",
            )
            onReady()
        }
    }

    override fun shouldRenderNatively(
        componentId: String?,
        flowId: String?,
        scroll: Boolean,
    ): Boolean {
        // The decision is delegated entirely to the routing policy (backend-driven,
        // tenant-agnostic). Cache / warm-up readiness is deliberately NOT part of
        // the decision — a cache miss must surface as empty native content, never a
        // silent fall-through to the WebView (which would hide whether native
        // routing ever fired).
        return RenderRouting.targetFor(
            flowId = flowId,
            componentId = componentId,
            scrollable = scroll,
        ) == RenderTarget.NATIVE
    }

    @Composable
    override fun RenderBlock(
        componentId: String?,
        flowId: String?,
        onEvent: ((SDKEvent) -> Unit)?,
        modifier: Modifier,
    ) {
        // Bridge the WebView's per-instance id to the stable id the native
        // block index knows. Prefer the raw id if it happens to be cached;
        // otherwise fall back to the UUID-stripped id when that one resolves.
        val requestedId = componentId?.trim().orEmpty()
        val resolvedComponentId =
            when {
                requestedId.isEmpty() -> requestedId
                br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(requestedId) -> requestedId
                else -> {
                    val stable = stableNativeComponentId(requestedId)
                    if (stable != requestedId &&
                        br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(stable)
                    ) {
                        stable
                    } else {
                        requestedId
                    }
                }
            }
        br.com.wave.flows.kmp.RenderBlock(
            componentId = resolvedComponentId,
            flowId = flowId,
            modifier = modifier,
            onEvent = onEvent?.let { handler ->
                { nativeEvent ->
                    handler(nativeRenderBlockEventToWrapperEvent(nativeEvent))
                }
            },
        )
    }

    internal fun reset() {
        startGeneration = 0
        nativeWarmReady = false
    }
}

internal fun nativeRenderBlockEventToWrapperEvent(
    event: br.com.wave.flows.kmp.SDKEvent,
): SDKEvent = when (event) {
    is br.com.wave.flows.kmp.SDKEvent.Error ->
        SDKEvent.Error(
            componentId = event.componentId,
            code = event.code,
            message = event.message,
        )
    is br.com.wave.flows.kmp.SDKEvent.ComponentLoaded -> {
        platformLogDebug(
            NATIVE_RENDER_LOG_TAG,
            "render_loaded engine=native componentId=${event.componentId}",
        )
        SDKEvent.ComponentLoaded(componentId = event.componentId)
    }
    is br.com.wave.flows.kmp.SDKEvent.Callback ->
        SDKEvent.Callback(
            type = event.type,
            payload = event.payload.toWebViewCallbackEnvelope(event.type),
            origin = event.origin,
        )
}

private fun String.toWebViewCallbackEnvelope(type: String): String {
    if (!type.startsWith("RENDER_BLOCK_")) return this

    val trimmedPayload = trim()
    val payloadJson = when {
        trimmedPayload.isEmpty() -> "{}"
        trimmedPayload.startsWith("{") || trimmedPayload.startsWith("[") -> trimmedPayload
        else -> "\"${trimmedPayload.escapeJsonString()}\""
    }

    return """{"type":"${type.escapeJsonString()}","payload":$payloadJson}"""
}

private fun String.escapeJsonString(): String = buildString {
    this@escapeJsonString.forEach { char ->
        when (char) {
            '\\' -> append("\\\\")
            '"' -> append("\\\"")
            '\b' -> append("\\b")
            '\u000C' -> append("\\f")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> append(char)
        }
    }
}
