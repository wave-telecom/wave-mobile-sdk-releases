package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * Transitional routing seed — a hand-written JSON document standing in for what the
 * backend will eventually serve (the agreed `metadata.features` contract, "Proposta
 * A"). It is parsed by the **real** [parseRenderRoutingPolicy], so editing [SEED_JSON]
 * is the way to probe the contract locally: change it to a version the backend might
 * send, recompile, and watch routing/warm change. The **only** place tenant nouns
 * live, as data. When the backend serves the policy, install a real
 * [RenderRoutingSource] at init and delete this file. Flip [BOOTSTRAP_ENABLED] to
 * `false` to go fully-agnostic now (webview-only until a source is installed).
 */
internal object BootstrapRenderRouting {
    private const val BOOTSTRAP_ENABLED = true

    // HARDCODED contract for local testing — same shape the init will embed.
    // Edit freely. `bottom-sheet-*` = trailing-`*` prefix wildcard (the whole
    // instance-suffixed family). `flows` are WARM targets; `components` route.
    private val SEED_JSON = """
        {
          "metadata": {
            "features": [
              {
                "flows": [{ "id": "home-staging", "renderMode": "kmp" }],
                "components": [{ "id": "bottom-sheet-*", "renderMode": "kmp" }],
                "theme": "off"
              }
            ]
          }
        }
    """.trimIndent()

    val seedPolicy: RenderRoutingPolicy =
        if (BOOTSTRAP_ENABLED) parseRenderRoutingPolicy(SEED_JSON) else RenderRoutingPolicy.WEBVIEW_ONLY
}

/** Default source until init installs a real one: the bootstrap seed (today's behavior). */
internal object DefaultRenderRoutingSource : RenderRoutingSource {
    override fun policyFor(session: RenderRoutingSessionContext): RenderRoutingPolicy =
        BootstrapRenderRouting.seedPolicy
}
