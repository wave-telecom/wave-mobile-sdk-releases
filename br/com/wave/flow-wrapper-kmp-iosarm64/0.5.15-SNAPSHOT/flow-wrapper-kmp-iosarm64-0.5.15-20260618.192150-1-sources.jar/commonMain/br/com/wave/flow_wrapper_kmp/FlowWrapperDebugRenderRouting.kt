package br.com.wave.flow_wrapper_kmp

import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRouting
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderTarget

/**
 * Debug-only hook for sample apps and internal QA tooling. This is intentionally
 * outside [FlowWrapperConfig] so hosts do not receive a supported contract for
 * forcing the render engine globally.
 */
object FlowWrapperDebugRenderRouting {
    fun setGlobalDefaultRenderer(renderer: String): Boolean {
        val target =
            when (renderer.trim().lowercase()) {
                "kmp", "native" -> RenderTarget.NATIVE
                "webview", "web" -> RenderTarget.WEBVIEW
                else -> return false
            }
        RenderRouting.installGlobalDefault(target)
        platformLogDebug("FlowWrapperKmp", "debug_global_render_default renderer=$renderer target=$target")
        return true
    }

    fun globalDefaultRenderer(): String =
        when (RenderRouting.globalDefault()) {
            RenderTarget.NATIVE -> "kmp"
            RenderTarget.WEBVIEW -> "webview"
        }
}
