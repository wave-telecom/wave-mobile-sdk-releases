package br.com.wave.flow_wrapper_kmp.renderrouting

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Wire shape of the routing contract (see `docs/render-routing-flags.md`). Kept
 * separate from the domain model so the transport can evolve independently — the
 * DTO maps to [RenderRoutingPolicy] via [toPolicy].
 */
@Serializable
internal data class RenderRoutingEnvelopeDto(
    val version: Int = 1,
    val renderRouting: RenderRoutingDto? = null,
    val metadata: RenderRoutingMetadataDto? = null,
)

@Serializable
internal data class RenderRoutingDto(
    val default: String? = null,
    val rules: List<RenderRoutingRuleDto> = emptyList(),
)

@Serializable
internal data class RenderRoutingRuleDto(
    val renderer: String? = null,
    val match: RenderRoutingMatchDto = RenderRoutingMatchDto(),
)

@Serializable
internal data class RenderRoutingMatchDto(
    val flowId: String? = null,
    val componentId: String? = null,
    val componentIdPrefix: String? = null,
    val scrollable: Boolean? = null,
)

@Serializable
internal data class RenderRoutingMetadataDto(
    val features: List<RenderRoutingFeatureDto> = emptyList(),
)

@Serializable
internal data class RenderRoutingFeatureDto(
    val flows: List<RenderRoutingFeatureTargetDto> = emptyList(),
    val components: List<RenderRoutingFeatureTargetDto> = emptyList(),
    val theme: String? = null,
)

@Serializable
internal data class RenderRoutingFeatureTargetDto(
    val id: String? = null,
    val renderMode: String? = null,
)

private fun RenderRoutingMatchDto.isEmpty(): Boolean =
    flowId == null && componentId == null && componentIdPrefix == null && scrollable == null

internal fun RenderRoutingRuleDto.toRuleOrNull(): RenderRoutingRule? {
    // Drop rules with an empty match — they would capture everything and shadow the
    // default. Trim blanks to null so `"flowId": ""` is treated as "no constraint".
    if (match.isEmpty()) return null
    return RenderRoutingRule(
        target = RenderTarget.fromTokenOrDefault(renderer),
        flowId = flowId.normalizeOrNull(),
        componentId = componentId.normalizeOrNull(),
        componentIdPrefix = componentIdPrefix.normalizeOrNull(),
        scrollable = scrollable,
    ).takeIf { it.matchesAnything() }
}

private val RenderRoutingRuleDto.flowId get() = match.flowId
private val RenderRoutingRuleDto.componentId get() = match.componentId
private val RenderRoutingRuleDto.componentIdPrefix get() = match.componentIdPrefix
private val RenderRoutingRuleDto.scrollable get() = match.scrollable

private fun String?.normalizeOrNull(): String? = this?.trim()?.takeIf(String::isNotEmpty)

private fun RenderRoutingRule.matchesAnything(): Boolean =
    flowId != null || componentId != null || componentIdPrefix != null || scrollable != null

/**
 * A component feature → routing rule. The component `id` is a wildcard: a trailing
 * `*` means prefix match (`"bottom-sheet-*"` → any `bottom-sheet-…`, including the
 * instance-suffixed family `bottom-sheet-plan-details-<uuid>`); otherwise it's an
 * exact id. The `*` is a literal sentinel we strip — NOT a regex. Only `kmp`/`native`
 * components produce a rule; webview ones are the default and need none.
 */
private fun RenderRoutingFeatureTargetDto.toComponentRule(): RenderRoutingRule? {
    val target = RenderTarget.fromTokenOrDefault(renderMode)
    if (target == RenderTarget.WEBVIEW) return null
    val raw = id.normalizeOrNull() ?: return null
    val rule =
        if (raw.endsWith("*")) {
            val prefix = raw.dropLast(1).normalizeOrNull() ?: return null
            RenderRoutingRule(target = target, componentIdPrefix = prefix)
        } else {
            RenderRoutingRule(target = target, componentId = raw)
        }
    return rule.takeIf { it.matchesAnything() }
}

/**
 * `metadata.features` → policy. `flows` declare which flows to WARM natively
 * (policy.warmFlowIds); `components` declare which blocks actually RENDER native
 * (routing rules). Keeping them separate means listing a flow does NOT force its
 * whole tree to native — only the named components route. Note: this shape carries
 * no `scrollable`, so a non-scroll constraint cannot be expressed here (it can in the
 * `renderRouting.rules` shape).
 */
private fun List<RenderRoutingFeatureDto>.toPolicy(): RenderRoutingPolicy {
    val componentRules =
        flatMap { feature -> feature.components.mapNotNull { it.toComponentRule() } }

    val warmFlowIds =
        flatMap { feature ->
            feature.flows
                .filter { RenderTarget.fromTokenOrDefault(it.renderMode) == RenderTarget.NATIVE }
                .mapNotNull { it.id.normalizeOrNull() }
        }.toSet()

    // The theme flag is a single SDK-wide setting; take the first feature that declares one.
    val themeToken = firstNotNullOfOrNull { it.theme.normalizeOrNull() }

    return RenderRoutingPolicy(
        default = RenderTarget.WEBVIEW,
        rules = componentRules,
        warmFlowIds = warmFlowIds,
        themeToken = themeToken,
    )
}

internal fun RenderRoutingDto.toPolicy(): RenderRoutingPolicy =
    RenderRoutingPolicy(
        default = RenderTarget.fromTokenOrDefault(default),
        rules = rules.mapNotNull { it.toRuleOrNull() },
    )

private val renderRoutingJson = Json {
    ignoreUnknownKeys = true
    isLenient = true
}

/**
 * Parse a routing contract document into a policy. Any malformed input degrades to
 * [RenderRoutingPolicy.WEBVIEW_ONLY] — the safe engine — rather than throwing into
 * the init path.
 */
internal fun parseRenderRoutingPolicy(json: String?): RenderRoutingPolicy {
    if (json.isNullOrBlank()) return RenderRoutingPolicy.WEBVIEW_ONLY
    return runCatching {
        val envelope = renderRoutingJson.decodeFromString(RenderRoutingEnvelopeDto.serializer(), json)
        val features = envelope.metadata?.features.orEmpty()
        when {
            features.isNotEmpty() ->
                features.toPolicy()
            envelope.renderRouting != null ->
                envelope.renderRouting.toPolicy()
            else ->
                RenderRoutingPolicy.WEBVIEW_ONLY
        }
    }.getOrDefault(RenderRoutingPolicy.WEBVIEW_ONLY)
}
