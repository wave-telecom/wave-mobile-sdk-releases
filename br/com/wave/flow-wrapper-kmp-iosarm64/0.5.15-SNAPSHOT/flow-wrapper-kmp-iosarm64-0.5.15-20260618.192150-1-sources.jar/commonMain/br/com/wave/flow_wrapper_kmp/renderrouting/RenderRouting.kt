package br.com.wave.flow_wrapper_kmp.renderrouting

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Central access point for render routing — the routing analogue of `FeatureFlags`,
 * internal to the SDK. `FlowWrapper.start` [resolve]s once at init and caches the
 * policy; [current]/[targetFor] then read it synchronously, which is what the render
 * path (composition) and warm-up need. Starts as [RenderRoutingPolicy.WEBVIEW_ONLY]
 * so any read before init is safe.
 */
internal object RenderRouting {
    private var source: RenderRoutingSource = DefaultRenderRoutingSource
    private var policy: RenderRoutingPolicy = RenderRoutingPolicy.WEBVIEW_ONLY
    private var globalDefaultTarget by mutableStateOf(RenderTarget.WEBVIEW)

    /**
     * Replace the policy source. Reserved for init wiring — e.g. switching from the
     * bootstrap seed to a claim- or endpoint-backed source. Does not re-resolve;
     * the next [resolve] (or the explicit one at init) applies it.
     */
    fun installSource(source: RenderRoutingSource) {
        this.source = source
    }

    /** Resolve and cache the policy for this session. Called once at init, before warm-up. */
    fun resolve(session: RenderRoutingSessionContext): RenderRoutingPolicy {
        policy = source.policyFor(session)
        return policy
    }

    /** Pin a policy directly, bypassing the source. For tests and the synchronous claim path. */
    fun install(policy: RenderRoutingPolicy) {
        this.policy = policy
    }

    fun current(): RenderRoutingPolicy = policy

    fun targetFor(flowId: String?, componentId: String?, scrollable: Boolean): RenderTarget =
        policy.resolve(
            flowId = flowId,
            componentId = componentId,
            scrollable = scrollable,
            defaultTarget = globalDefaultTarget,
        )

    fun installGlobalDefault(target: RenderTarget) {
        globalDefaultTarget = target
    }

    fun globalDefault(): RenderTarget = globalDefaultTarget

    internal fun resetForTests() {
        source = DefaultRenderRoutingSource
        policy = RenderRoutingPolicy.WEBVIEW_ONLY
        globalDefaultTarget = RenderTarget.WEBVIEW
    }
}
