package br.com.wave.flow_wrapper_kmp

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.multiplatform.webview.web.LoadingState
import com.multiplatform.webview.web.WebView
import com.multiplatform.webview.web.rememberWebViewNavigator
import com.multiplatform.webview.web.rememberWebViewState
import com.multiplatform.webview.setting.WebSettings
import br.com.wave.flow_wrapper_kmp.featureflags.Feature
import br.com.wave.flow_wrapper_kmp.featureflags.FeatureFlags
import br.com.wave.flow_wrapper_kmp.generated.resources.Res
import br.com.wave.flow_wrapper_kmp.generated.resources.flow_wrapper_error_missing_entry_point
import br.com.wave.flow_wrapper_kmp.generated.resources.flow_wrapper_fallback_missing_entry_point
import org.jetbrains.compose.resources.stringResource

private const val DEFAULT_COMPONENT_ID = "balance-summary-1"
private const val PATH_PREFIX_FLOWS = "/flows/"
private const val PATH_PREFIX_COMPONENTS = "/components/"
private const val NAVBAR_FLOW_PATH = "/flows/navbar"
private const val ORIGIN_NATIVE_HANDLER_BRIDGE = "native_handler_bridge"
private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"

// Test markers on the REAL render branches (no fakes): a UI test asserts which engine
// composed for a given contract, while the WebView/native content still renders for real.
internal const val RENDER_ENGINE_NATIVE_TAG = "render_engine_native"
internal const val RENDER_ENGINE_WEBVIEW_TAG = "render_engine_webview"

private enum class FlowWrapperErrorCode(val value: String) {
    MissingEntryPoint("MISSING_ENTRY_POINT"),
}

internal sealed interface FlowWrapperEntry {
    data class Component(val componentId: String) : FlowWrapperEntry

    data class Flow(val flowId: String) : FlowWrapperEntry

    data object Missing : FlowWrapperEntry
}

internal fun resolveFlowWrapperEntry(componentId: String?, flowId: String?): FlowWrapperEntry {
    if (!componentId.isNullOrBlank()) return FlowWrapperEntry.Component(componentId)
    if (!flowId.isNullOrBlank()) return FlowWrapperEntry.Flow(flowId)
    return FlowWrapperEntry.Missing
}

internal fun FlowWrapperEntry.path(): String = when (this) {
    is FlowWrapperEntry.Component -> "$PATH_PREFIX_COMPONENTS$componentId"
    is FlowWrapperEntry.Flow -> "$PATH_PREFIX_FLOWS$flowId"
    FlowWrapperEntry.Missing -> ""
}

internal fun FlowWrapperEntry.id(): String = when (this) {
    is FlowWrapperEntry.Component -> componentId
    is FlowWrapperEntry.Flow -> flowId
    FlowWrapperEntry.Missing -> DEFAULT_COMPONENT_ID
}

internal fun isNavbarFlowPath(path: String): Boolean = path.substringBefore('?') == NAVBAR_FLOW_PATH

internal fun WebSettings.applyFlowWrapperDefaults(entryPath: String) {
    androidWebSettings.domStorageEnabled = true

    // Pin scale on every flow (drives the injected viewport `user-scalable=no`).
    supportZoom = false

    if (!isNavbarFlowPath(entryPath)) return

    // Technical debt: SDK is temporarily coupled to the navbar flow until this policy
    // can move to host configuration or be fixed in the web experience itself.
    iOSWebSettings.bounces = false
    iOSWebSettings.scrollEnabled = false
    iOSWebSettings.showHorizontalScrollIndicator = false
    iOSWebSettings.showVerticalScrollIndicator = false
}

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    scroll: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val errorMissingEntryPoint = stringResource(Res.string.flow_wrapper_error_missing_entry_point)
    val fallbackMissingEntryPoint = stringResource(Res.string.flow_wrapper_fallback_missing_entry_point)

    val renderNatively =
        nativeBottomSheetBridgeDelegate.shouldRenderNatively(componentId = componentId, flowId = flowId, scroll = scroll)
    LaunchedEffect(renderNatively, flowId, componentId, scroll) {
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "render_dispatch engine=${if (renderNatively) "native" else "webview"} " +
                "flowId=$flowId componentId=$componentId scroll=$scroll",
        )
    }
    if (renderNatively) {
        nativeBottomSheetBridgeDelegate.RenderBlock(
            componentId = componentId,
            flowId = flowId,
            onEvent = onEvent,
            modifier = modifier.testTag(RENDER_ENGINE_NATIVE_TAG),
        )
        return
    }

    when (val entry = resolveFlowWrapperEntry(componentId = componentId, flowId = flowId)) {
        is FlowWrapperEntry.Component, is FlowWrapperEntry.Flow -> {
            FlowWrapperViewInternal(
                modifier = modifier.testTag(RENDER_ENGINE_WEBVIEW_TAG),
                entryPath = entry.path(),
                entryId = entry.id(),
                scroll = scroll,
                onEvent = onEvent,
            )
        }
        FlowWrapperEntry.Missing -> {
            onEvent?.invoke(
                SDKEvent.Error(
                    componentId = DEFAULT_COMPONENT_ID,
                    code = FlowWrapperErrorCode.MissingEntryPoint.value,
                    message = errorMissingEntryPoint,
                )
            )
            FlowWrapperFallback(
                modifier = modifier,
                message = fallbackMissingEntryPoint,
            )
        }
    }
}

internal fun handleNativeBridgeMessage(
    params: String,
    onCallbackReceived: (NativeCallbackMessage) -> Unit,
): String {
    parseNativeBridgeParams(params)?.let(onCallbackReceived)
    return "{}"
}

internal fun parseNativeBridgeParams(params: String): NativeCallbackMessage? {
    if (params.isBlank()) return null
    return nativeCallbackMessageFromPayload(params)
}

private fun emitCallbackEvent(
    onEvent: ((SDKEvent) -> Unit)?,
    callbackMessage: NativeCallbackMessage,
    origin: String,
) {
    platformLogDebug(
        FLOW_WRAPPER_LOG_TAG,
        "callback origin=$origin type=${callbackMessage.type} payload=${callbackMessage.payload.asLogPayload()}",
    )
    onEvent?.invoke(
        SDKEvent.Callback(
            type = callbackMessage.type,
            payload = callbackMessage.payload,
            origin = origin,
        )
    )
}

private fun String.asLogPayload(maxLength: Int = 320): String {
    return if (length <= maxLength) this else take(maxLength) + "..."
}

@Composable
private fun FlowWrapperFallback(modifier: Modifier, message: String) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = message, style = MaterialTheme.typography.bodyMedium)
    }
}

private val HOST_SCROLL_PLACEHOLDER_HEIGHT = 600.dp

@Composable
internal fun FlowWrapperViewInternal(
    entryPath: String,
    entryId: String,
    modifier: Modifier = Modifier,
    scroll: Boolean = true,
    onEvent: ((SDKEvent) -> Unit)? = null,
) {
    val currentOnEventState = rememberUpdatedState(onEvent)
    val config = FlowWrapper.currentConfig()
    val flowWrapperConfig = config.flowWrapperConfig
    val resolvedEntryPath = remember(entryPath) { FlowWrapper.resolveEntryPathForRendering(entryPath) }

    val themeMode = FlowWrapper.currentThemeMode()
    val systemInDarkTheme = isSystemInDarkTheme()
    val themeQueryParam = resolveThemeQueryParam(themeMode, systemInDarkTheme)

    val entryUrl =
        remember(
            config.msisdn,
            config.environment,
            resolvedEntryPath,
            flowWrapperConfig.entryUrlProvider,
            themeQueryParam,
        ) {
            flowWrapperConfig.entryUrlProvider.urlFor(
                EntryUrlContext(
                    msisdn = config.msisdn,
                    environment = config.environment,
                    path = resolvedEntryPath,
                    themeMode = themeQueryParam,
                )
            )
        }

    var measuredHeightPx by remember(entryUrl) { mutableStateOf<Int?>(null) }

    val onNativeBridgeMessage: (String) -> Unit = { data ->
        handleNativeBridgeMessage(data) { callbackMessage ->
            if (callbackMessage.type == PAGE_HEIGHT_CALLBACK_TYPE) {
                extractPageHeightFromPayload(callbackMessage.payload)
                    ?.let { measuredHeightPx = it }
                return@handleNativeBridgeMessage
            }
            FlowWrapper.updateRuntimeStateFromCallback(
                entryPath = entryPath,
                callbackMessage = callbackMessage,
            )
            emitCallbackEvent(
                onEvent = currentOnEventState.value,
                callbackMessage = callbackMessage,
                origin = ORIGIN_NATIVE_HANDLER_BRIDGE,
            )
        }
    }

    val outerModifier =
        if (scroll) {
            modifier.fillMaxSize()
        } else {
            val heightDp = measuredHeightPx?.dp ?: HOST_SCROLL_PLACEHOLDER_HEIGHT
            modifier.fillMaxWidth().height(heightDp)
        }

    // key on entryUrl: any change (path, msisdn, theme) recreates the WebView so the page reloads
    key(entryUrl) {
        val navigator = rememberWebViewNavigator()
        val state =
            rememberWebViewState(entryUrl) {
                applyFlowWrapperDefaults(resolvedEntryPath)
            }

        LaunchedEffect(state.loadingState) {
            if (state.loadingState is LoadingState.Finished) {
                platformLogDebug(FLOW_WRAPPER_LOG_TAG, "render_loaded engine=webview componentId=$entryId")
                currentOnEventState.value?.invoke(SDKEvent.ComponentLoaded(componentId = entryId))
            }
        }

        val platformWebViewParams = rememberFlowWrapperPlatformWebViewParams(
            navigator = navigator,
            onNativeBridgeMessage = onNativeBridgeMessage,
        )

        val webViewFactory = rememberNativeHandlerWebViewFactory(
            onNativeBridgeMessage = onNativeBridgeMessage,
        )

        Box(modifier = outerModifier) {
            WebView(
                state = state,
                navigator = navigator,
                platformWebViewParams = platformWebViewParams,
                factory = webViewFactory,
                modifier = Modifier
                    .padding()
                    .fillMaxSize(),
            )
        }
    }
}

private fun resolveThemeQueryParam(mode: FlowThemeMode, systemInDarkTheme: Boolean): String? {
    // Dark mode gated off: omit the themeMode query param entirely, restoring the
    // exact pre-feature URL (the EntryUrlProvider skips the param when null).
    if (!FeatureFlags.isEnabled(Feature.DarkMode)) return null
    return when (mode) {
        FlowThemeMode.Light -> "light"
        FlowThemeMode.Dark -> "dark"
        FlowThemeMode.System -> if (systemInDarkTheme) "dark" else "light"
    }
}
