package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * The routing decisions for a session — pure data + logic, no tenant nouns, no I/O.
 * [resolve] applies rules in order (first match wins), else [default], so anything
 * the backend didn't explicitly route stays on the stable engine. Produced by a
 * [RenderRoutingSource], held by [RenderRouting].
 */
internal data class RenderRoutingPolicy(
    val default: RenderTarget = RenderTarget.WEBVIEW,
    val rules: List<RenderRoutingRule> = emptyList(),
    val warmFlowIds: Set<String> = emptySet(),
    // The backend serves routing AND the theme flag in one contract document, so the
    // resolved policy also carries the raw theme token (e.g. "off"/"dark"/"light").
    // Kept as the raw string so this package stays free of the host's FlowThemeMode;
    // FlowWrapper maps the token to the DarkMode feature flag + theme mode at start.
    val themeToken: String? = null,
) {
    fun resolve(flowId: String?, componentId: String?, scrollable: Boolean): RenderTarget =
        rules.firstOrNull { it.matches(flowId, componentId, scrollable) }?.target ?: default

    fun resolve(
        flowId: String?,
        componentId: String?,
        scrollable: Boolean,
        defaultTarget: RenderTarget,
    ): RenderTarget =
        rules.firstOrNull { it.matches(flowId, componentId, scrollable) }?.target ?: defaultTarget

    /**
     * Flow ids the SDK warms natively at init: flows explicitly declared as native
     * targets ([warmFlowIds]) plus any flow named by a NATIVE rule. Warming is
     * flow-scoped, so component-only rules contribute nothing on their own.
     */
    fun nativeFlowIds(): Set<String> =
        (warmFlowIds.asSequence() +
            rules.asSequence()
                .filter { it.target == RenderTarget.NATIVE }
                .mapNotNull { it.flowId })
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()

    companion object {
        /** Everything on the stable engine — the agnostic, backend-not-yet-wired default. */
        val WEBVIEW_ONLY = RenderRoutingPolicy(default = RenderTarget.WEBVIEW, rules = emptyList())
    }
}
