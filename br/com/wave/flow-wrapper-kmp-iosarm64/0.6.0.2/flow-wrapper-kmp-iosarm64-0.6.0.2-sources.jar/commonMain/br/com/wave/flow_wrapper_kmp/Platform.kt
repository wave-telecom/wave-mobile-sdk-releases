package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator

expect fun platform(): String

internal expect fun platformLogDebug(tag: String, message: String)

/**
 * [onWebViewProcessGone] is invoked when the platform reports the WebView render process was
 * killed (memory reclaim while backgrounded). It returns `true` when a recovery (WebView
 * recreation + reload) was armed, `false` when the recovery budget is spent and the caller
 * should render the static error page instead.
 */
@Composable
internal expect fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
    onWebViewProcessGone: () -> Boolean,
): PlatformWebViewParams?

/**
 * [initialWaveToken] is the credential to expose through
 * [NATIVE_HANDLER_METHOD_FETCH_WAVE_TOKEN] as soon as this WebView's JS context
 * exists — before the page's own scripts run. It does not change while this WebView
 * stays mounted (the SDK's only two session transitions are `start` and `logout`;
 * the latter is the host's cue to unmount).
 *
 * [allowedNativeHandlerOrigin] scopes where the credential method is reachable from,
 * so a third-party frame the page embeds cannot read it. iOS gets this for free from
 * `forMainFrameOnly`; Android needs the value to scope its own origin-restricted
 * injection — see Platform.android.kt's `installNativeHandlerBridge`, which falls
 * back to an unrestricted binding only on a WebView build too old for that path.
 */
@Composable
internal expect fun rememberNativeHandlerWebViewFactory(
    initialWaveToken: String?,
    allowedNativeHandlerOrigin: String,
    onNativeBridgeMessage: (String) -> Unit,
    onWebViewProcessGone: () -> Boolean,
): ((WebViewFactoryParam) -> NativeWebView)?

internal expect object PlatformFlowWrapperWarmupLauncher {
    fun launch(
        entryUrl: String,
        waveToken: String?,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle?
}
