package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.6.0.2"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-09-01T16:28:26.772762-03:00"
    const val GIT_SHA: String = "c43f72b9"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.6.0.2@2026-09-01T16:28:26.772762-03:00#c43f72b9"
}