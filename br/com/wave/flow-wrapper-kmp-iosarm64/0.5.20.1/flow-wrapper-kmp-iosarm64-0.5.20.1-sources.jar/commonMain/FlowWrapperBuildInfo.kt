package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.1"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-09T20:56:58.096745-03:00"
    const val GIT_SHA: String = "e49ba11"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20.1@2026-07-09T20:56:58.096745-03:00#e49ba11"
}