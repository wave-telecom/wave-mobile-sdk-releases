package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.6.1-SNAPSHOT.1"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-08-11T16:52:14.518539-03:00"
    const val GIT_SHA: String = "c073e3f3"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.1-SNAPSHOT.1@2026-08-11T16:52:14.518539-03:00#c073e3f3"
}