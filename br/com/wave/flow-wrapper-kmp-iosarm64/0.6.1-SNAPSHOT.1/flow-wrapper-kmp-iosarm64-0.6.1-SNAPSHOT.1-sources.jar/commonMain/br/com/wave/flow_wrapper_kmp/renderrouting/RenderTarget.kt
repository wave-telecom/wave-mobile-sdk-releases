package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * The two engines a render request can be served by — the SDK's only routing nouns.
 * Everything tenant-specific (which flow, which component) is backend data, never a
 * constant in SDK logic. [WEBVIEW] is the stable default; [NATIVE] is Compose.
 */
internal enum class RenderTarget {
    WEBVIEW,
    NATIVE,
    ;

    companion object {
        /** Unknown / blank tokens fall back to [WEBVIEW] so a contract typo never lands on native. */
        fun fromTokenOrDefault(token: String?): RenderTarget =
            when (token?.trim()?.lowercase()) {
                "native", "kmp" -> NATIVE
                else -> WEBVIEW
            }
    }
}

/**
 * `kmp` routes NATIVE via the Compose leaf; `native` routes NATIVE via the platform-
 * native leaf (Android View). Both still map to [RenderTarget.NATIVE] above — routing
 * is unchanged; this only distinguishes the leaf preference.
 */
internal fun isNativeLeafToken(token: String?): Boolean =
    token?.trim()?.lowercase() == "native"
