package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * The routing decisions for a session — pure data + logic, no tenant nouns, no I/O.
 * [resolve] applies rules in order (first match wins), else [default], so anything
 * the backend didn't explicitly route stays on the stable engine. Produced by a
 * [RenderRoutingSource], held by [RenderRouting].
 */
internal data class RenderRoutingPolicy(
    val default: RenderTarget = RenderTarget.WEBVIEW,
    val rules: List<RenderRoutingRule> = emptyList(),
    val warmFlowIds: Set<String> = emptySet(),
    // The backend serves routing AND the theme flag in one contract document, so the
    // resolved policy also carries the raw theme token (e.g. "off"/"dark"/"light").
    // Kept as the raw string so this package stays free of the host's FlowThemeMode;
    // FlowWrapper maps the token to the DarkMode feature flag + theme mode at start.
    val themeToken: String? = null,
    // Platform-agnostic record that the contract asked for the platform-native leaf
    // (a literal `native` token, as opposed to `kmp`) on at least one NATIVE-routed
    // feature. FlowWrapper maps this to RenderEngine.VIEW on Android; iOS's platform
    // gate keeps Compose regardless. WEBVIEW_ONLY keeps this at its default `false`.
    // Because this flag is process-wide, a contract mixing tokens across flows (one
    // `native`, another `kmp`) flips ALL NATIVE-routed flows to the View leaf on
    // Android — the per-flow Compose/View split is not expressible. Accepted, deferred
    // debt: no per-flow granularity today.
    val nativeLeafRequested: Boolean = false,
) {
    fun resolve(flowId: String?, componentId: String?, scrollable: Boolean): RenderTarget =
        rules.firstOrNull { it.matches(flowId, componentId, scrollable) }?.target ?: default

    fun resolve(
        flowId: String?,
        componentId: String?,
        scrollable: Boolean,
        defaultTarget: RenderTarget,
    ): RenderTarget =
        rules.firstOrNull { it.matches(flowId, componentId, scrollable) }?.target ?: defaultTarget

    /**
     * Flow ids the SDK warms natively at init: flows explicitly declared as native
     * targets ([warmFlowIds]) plus any flow named by a NATIVE rule. Warming is
     * flow-scoped, so component-only rules contribute nothing on their own.
     */
    fun nativeFlowIds(): Set<String> =
        (warmFlowIds.asSequence() +
            rules.asSequence()
                .filter { it.target == RenderTarget.NATIVE }
                .mapNotNull { it.flowId })
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()

    /**
     * Flow ids to warm so a specific request can render natively, preserving the
     * component->flow association lost by [nativeFlowIds]. A flow request warms the flow
     * itself; a component request warms only the source flow(s) of the NATIVE rule(s) that
     * match it (the component is a block inside that flow, not fetchable alone). Falls back
     * to [nativeFlowIds] when no matching rule names a source, so recovery still warms
     * something rather than nothing.
     */
    fun warmTargetsFor(flowId: String?, componentId: String?): Set<String> {
        val component = componentId?.trim().orEmpty()
        if (component.isNotEmpty()) {
            val sources = rules.asSequence()
                .filter { it.target == RenderTarget.NATIVE && it.matchesComponentId(component) }
                .mapNotNull { it.sourceFlowId?.trim()?.takeIf(String::isNotEmpty) }
                .toSet()
            return sources.ifEmpty { nativeFlowIds() }
        }
        val flow = flowId?.trim().orEmpty()
        return if (flow.isNotEmpty()) setOf(flow) else emptySet()
    }

    companion object {
        /** Everything on the stable engine — the agnostic, backend-not-yet-wired default. */
        val WEBVIEW_ONLY = RenderRoutingPolicy(default = RenderTarget.WEBVIEW, rules = emptyList())
    }
}
