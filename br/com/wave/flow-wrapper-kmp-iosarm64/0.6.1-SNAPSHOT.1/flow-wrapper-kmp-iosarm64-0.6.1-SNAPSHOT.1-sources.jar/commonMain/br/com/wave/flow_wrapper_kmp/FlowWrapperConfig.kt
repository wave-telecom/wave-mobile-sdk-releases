package br.com.wave.flow_wrapper_kmp

enum class FlowWrapperEnvironment {
    DEV,
    PRD,
}

data class FlowWrapperConfig(val entryUrlProvider: EntryUrlProvider = DefaultEntryUrlProvider)
