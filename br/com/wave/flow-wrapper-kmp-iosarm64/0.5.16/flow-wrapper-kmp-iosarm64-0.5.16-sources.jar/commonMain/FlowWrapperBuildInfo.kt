package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.16"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-26T19:29:40.594984-03:00"
    const val GIT_SHA: String = "47dadd2"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.16@2026-06-26T19:29:40.594984-03:00#47dadd2"
}