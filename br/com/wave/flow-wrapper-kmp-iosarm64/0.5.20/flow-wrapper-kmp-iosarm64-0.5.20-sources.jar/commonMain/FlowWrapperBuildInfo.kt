package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-07T12:13:56.247134-03:00"
    const val GIT_SHA: String = "5619eef"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20@2026-07-07T12:13:56.247134-03:00#5619eef"
}