package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.6.0"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-08-10T11:41:00.810094-03:00"
    const val GIT_SHA: String = "c3ad5f2b"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.6.0@2026-08-10T11:41:00.810094-03:00#c3ad5f2b"
}