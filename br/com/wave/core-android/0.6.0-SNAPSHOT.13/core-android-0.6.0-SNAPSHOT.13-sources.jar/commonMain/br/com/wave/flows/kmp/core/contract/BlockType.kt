package br.com.wave.flows.kmp.core.contract

enum class BlockType {
    ACCORDION,
    BOTTOM_SHEET,
    BUTTON,
    CARD,
    CAROUSEL,
    CHART,
    CONTAINER,
    DIVIDER,
    IMAGE,
    LIST,
    RADIO_GROUP,
    SKELETON,
    SPACER,
    TABS,
    TEXT,
    TOOLBAR,
    UNKNOWN,
}
