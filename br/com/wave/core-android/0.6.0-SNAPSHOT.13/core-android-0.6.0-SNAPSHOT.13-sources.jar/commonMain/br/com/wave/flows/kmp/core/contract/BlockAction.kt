package br.com.wave.flows.kmp.core.contract

sealed interface BlockActionConfig

data class NavigateConfig(
    val originId: String,
    val destinationId: String,
) : BlockActionConfig

data class BackConfig(
    val referenceId: String,
) : BlockActionConfig

data class OpenUrlConfig(
    val externalDestinationUrl: String,
) : BlockActionConfig

data class ShowHideConfig(
    val referenceId: String,
) : BlockActionConfig

data object RefreshConfig : BlockActionConfig

data class DelegatedHostActionConfig(
    val rawJson: String,
) : BlockActionConfig

enum class BlockActionType {
    CLICK,
}

enum class BlockActionTarget {
    NAVIGATE,
    SHOW,
    HIDE,
    BACK,
    OPEN_URL,
    REFRESH,
    HOST_DELEGATED,
}

data class BlockAction(
    val type: BlockActionType = BlockActionType.CLICK,
    val onAction: BlockActionTarget,
    val config: BlockActionConfig,
)
