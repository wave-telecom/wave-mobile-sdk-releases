package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.LocalOverscrollFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.core.ScrollInfo
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.registry.ComposeRendererRegistry
import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.composeblocks.theme.ProvideFlowTheme
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockActionTarget
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.CardBlockConfig
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.runtime.buildRenderPlan
import br.com.wave.flows.kmp.core.visibility.buildInitialVisibilityState
import br.com.wave.flows.kmp.runtime.MonotonicRuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.api.RefreshSignalRegistry
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun RenderBlockRoute(
    componentId: String,
    contractProvider: ScreenContractProvider,
    hostEventHandler: HostEventHandler,
    externalCode: String? = null,
    sessionToken: Int = 0,
    onContractLoaded: (ScreenContract) -> Unit = {},
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    onFetchFresh: (suspend (String, String?) -> ScreenContract)? = null,
    onPeekSkeleton: (suspend (String, String?) -> ScreenContract?)? = null,
    onScroll: ((ScrollInfo) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val routeStateKey = remember(componentId, externalCode, sessionToken) {
        "$sessionToken|${externalCode.orEmpty()}|$componentId"
    }
    // External signal bumped by FlowWrapper.refresh() for this (componentId, externalCode).
    val externalRefreshCounter by RefreshSignalRegistry.counterFlow(componentId, externalCode).collectAsState(initial = 0)
    val initialCachedContract = remember(componentId, externalCode) {
        contractProvider.peekCachedScreenContract(componentId, externalCode)
    }
    // Tracks whether a PTR-triggered reload is in flight so the old content
    // remains visible with the spinner overlay instead of blanking the screen.
    var isRefreshing by remember { mutableStateOf(false) }
    // Bumped by the self-contained PTR path to re-run the fetch below.
    var ptrRefreshCounter by remember { mutableStateOf(0) }
    val contract by produceState<ScreenContract?>(
        initialValue = initialCachedContract,
        componentId,
        externalCode,
        externalRefreshCounter,
        ptrRefreshCounter,
    ) {
        val isReload = ptrRefreshCounter > 0 || externalRefreshCounter > 0
        // First load reuses the warm cache peek; a refresh instead shows the
        // skeleton (liveBlock-excluded) so the user never sees the stale full
        // contract — and never falls back to it — while the fresh fetch runs.
        val interim = if (isReload) {
            onPeekSkeleton?.invoke(componentId, externalCode)
        } else {
            initialCachedContract ?: contractProvider.getCachedScreenContract(componentId, externalCode)
        }
        // Always publish the interim — including `null` — so a refresh
        // with no skeleton available drives the route through the loading
        // state (spinner) instead of silently freezing on the previous
        // contract during the network round-trip. Without this, the
        // `MutableState` inside `produceState` keeps the stale value and
        // the user sees no feedback that a refresh is in flight.
        if (isReload) {
            RenderBlockInteractionCache.clearAll()
        }
        value = interim
        try {
            // A refresh forces a BFF round-trip (network-only chain) so the
            // contract is genuinely re-fetched; it falls back to the full
            // chain only if the SDK did not wire the capability.
            value = if (isReload) {
                onFetchFresh?.invoke(componentId, externalCode)
                    ?: contractProvider.getScreenContract(componentId, externalCode)
            } else {
                contractProvider.getScreenContract(componentId, externalCode)
            }
            isRefreshing = false
        } catch (error: Throwable) {
            // A superseded run (e.g. a rapid double-pull bumping
            // ptrRefreshCounter) is cancelled by produceState; let that
            // cancellation propagate instead of treating it as a fetch failure.
            if (error is kotlin.coroutines.cancellation.CancellationException) throw error
            // The BFF (or any source in the chain) failed. Try to recover
            // via the cache; if there is nothing to fall back to, surface
            // the error to the host instead of crashing the main thread.
            val fallback = contractProvider.getCachedScreenContract(componentId, externalCode)
            if (fallback != null) {
                value = fallback
                isRefreshing = false
                return@produceState
            }
            isRefreshing = false
            val errorCode = if (isReload) {
                "CONTRACT_REFRESH_FAILED"
            } else if (interim == null) {
                "CONTRACT_LOAD_FAILED"
            } else {
                "CONTRACT_REFRESH_FAILED"
            }
            hostEventHandler.onHostEvent(
                HostEvent.Error(
                    RenderBlockError(
                        code = errorCode,
                        message = "Failed to resolve contract \"$componentId\": ${error.message ?: "unknown error"}",
                    ),
                ),
            )
        }
    }

    // Snapshot the produced state into a local value. Without this, a
    // `LaunchedEffect` whose body still dereferences `contract!!` can race
    // with a refresh that resets the state to `null` between composition
    // and the effect being dispatched — producing an NPE in the middle of
    // an in-flight animation (chart, etc.).
    val resolvedContract = contract
    if (resolvedContract == null) {
        // Material3 circular spinner centred in the slot. Host themes it
        // via MaterialTheme.colorScheme.primary — no Telcel-specific color
        // is hardcoded in the SDK.
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(modifier = Modifier.size(40.dp))
        }
        return
    }

    LaunchedEffect(resolvedContract.id) {
        onContractLoaded(resolvedContract)
    }

    val onPtrRefresh: () -> Unit = {
        isRefreshing = true
        if (onFetchFresh != null) {
            // Self-contained path: bumping the counter re-runs the producer,
            // which force-fetches from the BFF. It must NOT also ask the host
            // to refresh — that would double-fetch.
            ptrRefreshCounter++
        } else {
            hostEventHandler.onHostEvent(HostEvent.Refresh)
        }
    }

    CompositionLocalProvider(
        LocalRenderRouteStateKey provides routeStateKey,
    ) {
        RenderBlockScreen(
            contract = resolvedContract,
            hostEventHandler = hostEventHandler,
            scroll = scroll,
            pullToRefreshEnabled = pullToRefreshEnabled,
            isRefreshing = isRefreshing,
            onPtrRefresh = onPtrRefresh,
            onScroll = onScroll,
            modifier = modifier,
            contractProvider = contractProvider,
            externalCode = externalCode,
        )
    }
}

@Composable
fun RenderBlockScreen(
    contract: ScreenContract,
    hostEventHandler: HostEventHandler,
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    isRefreshing: Boolean = false,
    onPtrRefresh: () -> Unit = {},
    onScroll: ((ScrollInfo) -> Unit)? = null,
    modifier: Modifier = Modifier,
    // Monotonic clock driving the refresh cooldown. Injectable so tests can advance it
    // deterministically and exercise the wall-clock gate (not just the coroutine delay).
    cooldownClock: RuntimeClock = MonotonicRuntimeClock,
    contractProvider: ScreenContractProvider? = null,
    externalCode: String? = null,
) {
    val routeStateKey = LocalRenderRouteStateKey.current
    val cachedVisibility = remember(routeStateKey) {
        RenderBlockInteractionCache.getVisibility(routeStateKey)
    }
    val visibilityState = remember(contract.id) {
        mutableStateMapOf<String, Boolean>().apply {
            putAll(cachedVisibility ?: buildInitialVisibilityState(contract.root))
            // The root of any contract is always visible: hidden-by-default
            // only makes sense for nested blocks whose siblings toggle them.
            // When a block (e.g. a bottom-sheet) is promoted to root via the
            // LiveBlockIndex, its inherited hidden state would prune the plan.
            put(contract.root.id, true)
        }
    }
    // Hand the screen-level theme catalog (if any) to the global store so
    // `@{token}` resolution downstream works against the BFF-served palette.
    // Empty catalogs (legacy contracts) are ignored, preserving back-compat.
    LaunchedEffect(contract.themeCatalog) {
        if (contract.themeCatalog.isNotEmpty()) {
            FlowThemeStore.setCatalog(contract.themeCatalog)
        }
    }

    val visibilitySnapshot = visibilityState.toMap()
    val plan = remember(contract.root, visibilitySnapshot) {
        buildRenderPlan(
            block = contract.root,
            rendererRegistry = ComposeRendererRegistry.supportedRendererTypes,
            visibility = visibilitySnapshot,
        )
    }

    plan.errors.forEach { hostEventHandler.onHostEvent(HostEvent.Error(it)) }

    // Maps each tab content block id to its page index, so the content
    // container can slide in the right direction when the active tab changes.
    val tabContentOrder = remember(contract.root) { collectTabContentOrder(contract.root) }

    val rootNode = plan.node ?: return
    val rootListState = rememberLazyListState()
    // A bottom-sheet promoted to root is host-driven: the host owns the modal
    // chrome and sizes the sheet to its content. Filling max height here would
    // stretch the content Column to the host's max-height cap and leave the
    // empty space below it. Wrap the height instead so the sheet fits content.
    val isHostDrivenBottomSheet = rootNode.block.type == BlockType.BOTTOM_SHEET
    val rootModifier = modifier
        .then(if (isHostDrivenBottomSheet) Modifier.fillMaxWidth().wrapContentHeight() else Modifier.fillMaxSize())
        .background(contract.root.config.style.backgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent)
    val renderContext = RenderBlockRenderContext(
        hostEventHandler = hostEventHandler,
        currentVisibility = { visibilityState.toMap() },
        onVisibilityChange = {
            visibilityState.putAll(it)
            if (routeStateKey.isNotBlank()) {
                RenderBlockInteractionCache.putVisibility(
                    routeId = routeStateKey,
                    visibility = visibilityState.toMap(),
                )
            }
        },
        cooldownClock = cooldownClock,
        contractProvider = contractProvider,
        externalCode = externalCode,
    )

    // `LocalIsRootBlock` is `true` only for this root dispatch so renderers
    // that need to know whether they're the topmost node of a host-driven
    // RenderBlock invocation (currently only `renderBottomSheetNode`) can
    // pick a different code path. Children must reset it to `false` to
    // avoid leaking the flag down the tree.
    //
    // ProvideFlowTheme wraps everything so `@{token}` references inside the
    // block tree resolve against the active palette. Idempotent — wrapping
    // an already-themed scope is harmless (the inner provider just re-reads
    // the same `FlowThemeStore` state).
    ProvideFlowTheme {
    CompositionLocalProvider(
        LocalIsRootBlock provides true,
        LocalTabContentOrder provides tabContentOrder,
        LocalTabSwipeRegistry provides remember { TabSwipeRegistry() },
    ) {
        if (rootNode.block.contractErrors.isEmpty() &&
            rootNode.block.type == BlockType.LIST &&
            (rootNode.block.config as? ListBlockConfig)?.orientation == BlockOrientation.VERTICAL
        ) {
            RenderLazyRootListNode(
                node = rootNode,
                renderContext = renderContext,
                state = rootListState,
                scroll = scroll,
                pullToRefreshEnabled = pullToRefreshEnabled,
                isRefreshing = isRefreshing,
                onPtrRefresh = onPtrRefresh,
                onScroll = onScroll,
                modifier = rootModifier,
            )
        } else {
            RenderResolvedNode(
                node = rootNode,
                renderContext = renderContext,
                modifier = rootModifier,
                parentOrientation = null,
            )
        }
    }
    }
}

/**
 * Walks the block tree and returns `contentReferenceId -> page index` for every
 * tab option of every `tabs` block. Used to drive the slide animation direction
 * when switching tabs.
 */
private fun collectTabContentOrder(root: BlockNode): Map<String, Int> {
    val order = mutableMapOf<String, Int>()
    fun walk(node: BlockNode) {
        (node.config as? TabsBlockConfig)?.options?.forEachIndexed { index, option ->
            order[option.contentReferenceId] = index
        }
        node.children.forEach(::walk)
    }
    walk(root)
    return order
}

/** Layout the root list node renders in, selected by the per-instance `scroll` flag. */
internal enum class RootListLayout { LAZY, WRAP_CONTENT }

/**
 * `true` (the SDK owns the scroll) renders a [LazyColumn]; `false` (the host owns the
 * outer scroll) renders a wrap-content [Column] — never a non-scrollable LazyColumn,
 * which would claim infinite height in a nested-scroll context.
 */
internal fun rootListLayoutFor(scroll: Boolean): RootListLayout =
    if (scroll) RootListLayout.LAZY else RootListLayout.WRAP_CONTENT

/**
 * Builds the [ScrollInfo] payload for one scroll frame. Direction is derived by
 * comparing the current list position against the previous frame's position:
 * moving to a later item, or further into the same item, means content moved up,
 * i.e. the user scrolled down.
 */
private const val SCROLL_CALLBACK_ENABLED = false

internal fun scrollInfoFor(
    offset: Int,
    index: Int,
    lastOffset: Int,
    lastIndex: Int,
): ScrollInfo =
    ScrollInfo(
        offsetPx = offset,
        firstVisibleItemIndex = index,
        isScrollingDown = index > lastIndex || (index == lastIndex && offset > lastOffset),
    )

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RenderLazyRootListNode(
    node: ResolvedRenderNode,
    renderContext: RenderBlockRenderContext,
    state: LazyListState,
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    isRefreshing: Boolean = false,
    onPtrRefresh: () -> Unit = {},
    onScroll: ((ScrollInfo) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val config = node.block.config as ListBlockConfig

    // Experiment build: the per-frame scroll callback is suspected of causing
    // scroll jank on low-end devices (host couples it to layout). This snapshot
    // ships with the callback disabled so the hypothesis can be tested in the
    // client app; the host never receives ScrollInfo in this build.
    @Suppress("SimplifyBooleanWithConstants", "KotlinConstantConditions")
    if (SCROLL_CALLBACK_ENABLED && onScroll != null) {
        var lastOffset by remember { mutableStateOf(0) }
        var lastIndex by remember { mutableStateOf(0) }
        LaunchedEffect(state) {
            snapshotFlow {
                state.firstVisibleItemScrollOffset to state.firstVisibleItemIndex
            }.collect { (offset, index) ->
                onScroll(
                    scrollInfoFor(
                        offset = offset,
                        index = index,
                        lastOffset = lastOffset,
                        lastIndex = lastIndex,
                    ),
                )
                lastOffset = offset
                lastIndex = index
            }
        }
    }

    when (rootListLayoutFor(scroll)) {
        RootListLayout.LAZY -> {
            val scope = rememberCoroutineScope()
            // Disable the platform overscroll effect (iOS bounce / Android stretch) on
            // the root list. With it on, pulling past the edge moves the scrollable
            // content over the fixed root `.background()` painted in `RenderBlockScreen`
            // (outside the scroll node), revealing that color "behind" the blocks. Null
            // overscroll makes the list stop hard at the edge, so nothing leaks through.
            val listModifier = modifier
                .then(if (shouldFillWidth(config.style, parentOrientation = null)) Modifier.fillMaxWidth() else Modifier)
                .applyBlockStyle(config.style)
                .desktopLikeLazyListInput { delta ->
                    scope.launch { state.scrollBy(delta) }
                }
            val lazyColumn: @Composable (Modifier) -> Unit = { columnModifier ->
                CompositionLocalProvider(LocalOverscrollFactory provides null) {
                    LazyColumn(
                        state = state,
                        modifier = columnModifier,
                        verticalArrangement = Arrangement.spacedBy(config.spacing.dp),
                        horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
                        contentPadding = config.style.toPaddingValues(),
                    ) {
                        items(
                            items = node.children,
                            key = { child -> child.block.id },
                            contentType = { child -> child.block.type.name },
                        ) { child ->
                            RenderResolvedNode(
                                node = child,
                                renderContext = renderContext,
                                parentOrientation = BlockOrientation.VERTICAL,
                            )
                        }
                    }
                }
            }
            if (pullToRefreshEnabled) {
                PullToRefreshBox(
                    isRefreshing = isRefreshing,
                    onRefresh = onPtrRefresh,
                    modifier = listModifier,
                ) {
                    lazyColumn(Modifier.fillMaxSize())
                }
            } else {
                lazyColumn(listModifier)
            }
        }
        RootListLayout.WRAP_CONTENT -> {
            // Host owns the outer scroll; render children in a wrap-content Column
            // so the host scroll container measures this node correctly. A
            // LazyColumn with userScrollEnabled=false would still claim infinite
            // height and crash in a nested-scroll context.
            Column(
                modifier = modifier
                    .then(if (shouldFillWidth(config.style, parentOrientation = null)) Modifier.fillMaxWidth() else Modifier)
                    .applyBlockStyle(config.style)
                    .padding(config.style.toPaddingValues()),
                verticalArrangement = Arrangement.spacedBy(config.spacing.dp),
                horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
            ) {
                node.children.forEach { child ->
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.VERTICAL,
                    )
                }
            }
        }
    }
}

private fun Modifier.desktopLikeLazyListInput(onScroll: (Float) -> Unit): Modifier =
    pointerInput(Unit) {
        detectVerticalDragGestures { change, dragAmount ->
            change.consume()
            onScroll(-dragAmount)
        }
    }

@Composable
internal fun RenderResolvedNode(
    node: ResolvedRenderNode,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
    modifier: Modifier = Modifier,
    wrapActionClick: Boolean = true,
) {
    // A `refresh` action triggers an (expensive) screen reload, so the block that
    // owns it disables itself for a cooldown right after being tapped — guarding
    // against rapid re-taps. The cooldown is held in a process-wide store, NOT in
    // `remember` here: the refresh rebuilds this very subtree (a `showPreload`
    // contract even flashes a spinner), which would reset any state remembered in
    // it the moment the refresh completes — and the button would never stay
    // disabled. Keyed by route + block id so distinct screens don't share a lock.
    val isRefreshAction = node.block.action?.onAction == BlockActionTarget.REFRESH
    val cooldownKey = "${LocalRenderRouteStateKey.current}|${node.block.id}"
    val cooldownUntil = if (isRefreshAction) RefreshCooldownStore.lockedUntilMillis(cooldownKey) else null
    val refreshLocked = cooldownUntil != null && renderContext.cooldownClock.nowMillis() < cooldownUntil
    if (refreshLocked) {
        // Re-enable once the window elapses. Re-arms on every rebuild for the
        // *remaining* time (derived from the absolute deadline), so a refresh
        // mid-cooldown neither extends nor restarts it.
        LaunchedEffect(cooldownKey, cooldownUntil) {
            val remaining = cooldownUntil - renderContext.cooldownClock.nowMillis()
            if (remaining > 0) delay(remaining)
            RefreshCooldownStore.release(cooldownKey)
        }
    }

    val clickModifier = when {
        !wrapActionClick || node.block.action == null -> modifier
        isRefreshAction -> modifier.clickable(enabled = !refreshLocked) {
            RefreshCooldownStore.lock(cooldownKey, renderContext.cooldownClock.nowMillis() + REFRESH_DISABLE_MILLIS)
            renderContext.dispatchNodeAction(node)
        }
        else -> modifier.clickable { renderContext.dispatchNodeAction(node) }
    }

    // While locked, surface the card's `variants.disabled` palette to the renderer
    // (and through it to the text/icon children) so the button reads as inactive.
    val cardConfig = node.block.config as? CardBlockConfig
    val disabledVariant = if (isRefreshAction && refreshLocked) {
        DisabledVariantOverride(
            active = true,
            contentColorHex = cardConfig?.disabledColorHex,
            backgroundColorHex = cardConfig?.disabledBackgroundColorHex,
        )
    } else {
        DisabledVariantOverride()
    }

    if (node.block.contractErrors.isNotEmpty()) {
        renderFallbackNode(
            node = node,
            modifier = clickModifier,
            renderContext = renderContext,
        )
        return
    }

    // Capture the "I'm the root of this RenderBlock call" signal *before*
    // dispatching, then reset it for the rest of the subtree. Only the
    // current node may see itself as root; every descendant is, by
    // definition, nested. This avoids the flag leaking through long
    // renderer chains (list → card → bottom-sheet etc.).
    val isRoot = LocalIsRootBlock.current
    CompositionLocalProvider(
        LocalIsRootBlock provides false,
        LocalDisabledVariant provides disabledVariant,
    ) {
        when (node.block.type) {
            BlockType.TEXT -> renderTextNode(node, clickModifier)
            BlockType.RICH_TEXT -> renderRichTextNode(node, clickModifier)
            BlockType.BUTTON -> renderButtonNode(node, clickModifier, renderContext)
            BlockType.CARD -> renderCardNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.CAROUSEL -> renderCarouselNode(node, clickModifier, renderContext)
            BlockType.CHART -> renderChartNode(node, clickModifier, renderContext)
            BlockType.CONTAINER -> renderContainerNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.DIVIDER -> renderDividerNode(node, clickModifier)
            BlockType.GRID -> renderGridNode(node, clickModifier, renderContext)
            BlockType.IMAGE -> renderImageNode(node, clickModifier)
            BlockType.LIST -> renderListNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.RADIO_GROUP -> renderRadioGroupNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.SKELETON -> renderSkeletonNode(node, clickModifier)
            BlockType.SUB_COMPONENT -> renderSubComponentNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.SPACER -> renderSpacerNode(node, clickModifier)
            BlockType.TOOLBAR -> renderToolbarNode(node, clickModifier, renderContext)
            BlockType.TABS -> renderTabsNode(node, clickModifier, renderContext)
            BlockType.BOTTOM_SHEET -> renderBottomSheetNode(node, clickModifier, renderContext, isRoot = isRoot)
            BlockType.ACCORDION -> renderAccordionNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.UNKNOWN -> renderFallbackNode(node, clickModifier, renderContext)
        }
    }
}
