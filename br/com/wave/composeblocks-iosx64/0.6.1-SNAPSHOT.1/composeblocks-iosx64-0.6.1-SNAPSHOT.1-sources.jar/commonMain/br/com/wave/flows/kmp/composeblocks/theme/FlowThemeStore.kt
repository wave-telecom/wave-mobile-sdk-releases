package br.com.wave.flows.kmp.composeblocks.theme

import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemeMode
import br.com.wave.flows.kmp.core.theme.ThemePalette
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-wide theme state. Holds the [catalog] of available palettes and the
 * host's selected [ThemeMode]; the active palette is computed by combining
 * those two with the system dark-mode signal (which is read in the Compose
 * layer — see [LocalFlowTheme]).
 *
 * It is intentionally a singleton: the host calls
 * `FlowWrapper.setTheme(...)` from anywhere and the change reaches every
 * mounted `RenderBlock` because the resolver reads off these `StateFlow`s.
 *
 * The store is stateless about *user preference*: the SDK does not persist
 * the choice across launches. If the app wants that, it persists itself and
 * re-applies on start (see SDK docs).
 */
object FlowThemeStore {

    private val _catalog = MutableStateFlow(FlowThemeCatalog.empty())
    val catalog: StateFlow<FlowThemeCatalog> = _catalog.asStateFlow()

    private val _mode = MutableStateFlow<ThemeMode>(ThemeMode.Auto)
    val mode: StateFlow<ThemeMode> = _mode.asStateFlow()

    // The id last resolved by the Compose layer (`ProvideFlowTheme`). Used so
    // [toggle] knows which palette is active without re-deriving it (which would
    // require reading isSystemInDarkTheme(), a @Composable). Reported by the
    // provider on every composition change.
    private val _currentActiveId = MutableStateFlow<ThemeId?>(null)
    val currentActiveId: StateFlow<ThemeId?> = _currentActiveId.asStateFlow()

    internal fun reportActiveId(id: ThemeId?) {
        _currentActiveId.value = id
    }

    /** Replace the catalog. Called by [setCatalog] at init (bundled JSON or BFF init payload). */
    fun setCatalog(catalog: FlowThemeCatalog) {
        _catalog.value = catalog
    }

    /** Lock to a specific theme (sets mode to [ThemeMode.Explicit]). */
    fun setTheme(id: ThemeId) {
        _mode.value = ThemeMode.Explicit(id)
    }

    /** Switch to Auto (follow system) or a specific [ThemeMode]. */
    fun setMode(mode: ThemeMode) {
        _mode.value = mode
    }

    /**
     * Flips between light and dark. After toggling, mode is [ThemeMode.Explicit]
     * — the user expressed intent, so we stop following the system. Uses
     * [currentActiveId] (reported by `ProvideFlowTheme`) as the starting point.
     * No-op if no theme is currently active (empty catalog).
     */
    fun toggle() {
        val active = _currentActiveId.value ?: return
        val other = _catalog.value.toggle(active) ?: return
        _mode.value = ThemeMode.Explicit(other.id)
    }

    /**
     * Resolves a [ThemeMode] + system signal into a concrete [ThemePalette].
     * Returns null when the catalog is empty (back-compat: render literally).
     *
     * - [ThemeMode.Explicit] picks that id; if absent, falls back to the
     *   first palette in the catalog (defensive — shouldn't happen since
     *   [setTheme] takes a [ThemeId]).
     * - [ThemeMode.Auto] picks `dark` if the system is dark, otherwise
     *   `light`. If the catalog has only one palette, that one is returned
     *   (Auto degenerates gracefully).
     */
    fun resolveActive(
        catalog: FlowThemeCatalog,
        mode: ThemeMode,
        systemDark: Boolean,
    ): ThemePalette? {
        if (catalog.isEmpty()) return null
        return when (mode) {
            is ThemeMode.Explicit -> catalog.byId(mode.themeId) ?: catalog.all.first()
            ThemeMode.Auto -> {
                val preferred = if (systemDark) ThemeId.Dark else ThemeId.Light
                catalog.byId(preferred) ?: catalog.all.first()
            }
        }
    }

    /**
     * Resolves a [ThemeMode] + system signal into a plain dark/light boolean — the same
     * three-state mapping [resolveActive] uses for palette selection, but catalog-free (dark
     * vs. light is a property of the mode itself, not of a palette): [ThemeMode.Explicit]
     * pins the answer to whichever [ThemeId] it carries, [ThemeMode.Auto] follows [systemDark].
     * Pure — the testable seam for host render paths that need a boolean instead of a
     * resolved [ThemePalette] (see `flowThemeIsDark`).
     */
    fun resolveIsDark(mode: ThemeMode, systemDark: Boolean): Boolean =
        when (mode) {
            is ThemeMode.Explicit -> mode.themeId == ThemeId.Dark
            ThemeMode.Auto -> systemDark
        }
}
