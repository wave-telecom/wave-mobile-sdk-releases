package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockStateEffect
import br.com.wave.flows.kmp.core.contract.BlockStyle
import br.com.wave.flows.kmp.core.contract.TabOption
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.visibility.setBlockVisibility
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache
import br.com.wave.flows.kmp.runtime.api.applyStateEffect
import kotlinx.coroutines.flow.map

// Default chip label line height (sp) when the tabs contract omits `lineHeight`.
private const val TAB_DEFAULT_LINE_HEIGHT_SP = 20

@Composable
internal fun renderTabsNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as TabsBlockConfig
    val stateEffect = config.stateEffect
    if (stateEffect != null) {
        renderStateEffectTabsNode(node, modifier, renderContext, config, stateEffect)
    } else {
        renderLegacyTabsNode(node, modifier, renderContext, config)
    }
}

/**
 * `stateEffect == null`: legacy visibility-toggle tabs, unchanged from before
 * Part B — the chip bar owns its content panes' visibility directly and
 * registers swipe-to-switch over them.
 */
@Composable
private fun renderLegacyTabsNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    config: TabsBlockConfig,
) {
    val options = config.options

    val routeStateKey = LocalRenderRouteStateKey.current
    val initialTabId = options.firstOrNull()?.id
    val cachedTabId = remember(routeStateKey, node.block.id) {
        RenderBlockInteractionCache.getSelection(
            routeId = routeStateKey,
            blockId = node.block.id,
            slot = "tabs.activeTabId",
        )
    }
    val effectiveInitialTabId = cachedTabId?.takeIf { saved -> options.any { it.id == saved } } ?: initialTabId
    var activeTabId by remember(node.block.id, routeStateKey) { mutableStateOf(effectiveInitialTabId) }

    // Selects a tab by id and propagates the change to the visibility model
    // (each tab references a content block via contentReferenceId). Shared by
    // the tab chips (click) and the swipe gesture over the content below.
    val selectTab: (String?) -> Unit = { targetId ->
        if (targetId != null) {
            activeTabId = targetId
            if (routeStateKey.isNotBlank()) {
                RenderBlockInteractionCache.putSelection(
                    routeId = routeStateKey,
                    blockId = node.block.id,
                    value = targetId,
                    slot = "tabs.activeTabId",
                )
            }
            var state = renderContext.currentVisibility()
            options.forEach { candidate ->
                state = setBlockVisibility(
                    state = state,
                    blockId = candidate.contentReferenceId,
                    value = candidate.id == targetId,
                )
            }
            renderContext.onVisibilityChange(state)
        }
    }

    // Wire horizontal swipe over the tab content (a sibling block) to tab
    // switching. The content container looks this handler up by its own id and
    // calls it with +1 (next) / -1 (previous). Registered for every tab so a
    // swipe started on any tab's content resolves against the live selection.
    val swipeRegistry = LocalTabSwipeRegistry.current
    val orderedIds = remember(options) { options.map { it.id } }
    val contentRefIds = remember(options) { options.map { it.contentReferenceId } }
    // Register the swipe handler exactly once per (registry, tab set) and read
    // the live selection through rememberUpdatedState — so the single stable
    // lambda always sees the current tab without re-registering each
    // recomposition (which, against the snapshot-backed registry, would loop).
    val currentActiveTabId by rememberUpdatedState(activeTabId)
    val currentSelectTab by rememberUpdatedState(selectTab)
    if (swipeRegistry != null) {
        DisposableEffect(swipeRegistry, orderedIds, contentRefIds) {
            val onSwipe: (Int) -> Unit = { delta ->
                val currentIndex = orderedIds.indexOf(currentActiveTabId)
                if (currentIndex >= 0) {
                    val target = (currentIndex + delta).coerceIn(0, orderedIds.size - 1)
                    if (target != currentIndex) currentSelectTab(orderedIds[target])
                }
            }
            contentRefIds.forEach { refId -> swipeRegistry.register(refId, onSwipe) }
            onDispose {
                contentRefIds.forEach { refId -> swipeRegistry.unregister(refId) }
            }
        }
    }

    val activeColor = config.activeColorHex?.toThemedComposeColorOrNull() ?: Color.Unspecified
    val activeBackground = config.activeBackgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent
    val inactiveColor = config.inactiveColorHex?.toThemedComposeColorOrNull() ?: Color.Unspecified
    val inactiveBackground = config.inactiveBackgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent
    val fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize
    val fontFamily = config.fontFamily.toComposeFontFamilyOrNull()
    val fontWeight = config.fontWeight?.toComposeFontWeight()
    // Chip label line height: honored from the contract when present, else the tab
    // default (unlike plain text/buttons, the chip keeps a default so the pill has a
    // consistent height even when the contract omits it).
    val lineHeight = (config.lineHeightSp ?: TAB_DEFAULT_LINE_HEIGHT_SP).sp

    val tabScrollState = rememberScrollState()

    Column(
        modifier = modifier
            .then(if (config.style.width == null) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(tabScrollState),
            horizontalArrangement = Arrangement.spacedBy(config.gap.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            options.forEach { option ->
                val isActive = option.id == activeTabId
                TabChip(
                    option = option,
                    isActive = isActive,
                    activeColor = activeColor,
                    activeBackground = activeBackground,
                    inactiveColor = inactiveColor,
                    inactiveBackground = inactiveBackground,
                    fontSize = fontSize,
                    fontFamily = fontFamily,
                    fontWeight = fontWeight,
                    lineHeight = lineHeight,
                    chipStyle = config.chipStyle,
                    onClick = { selectTab(option.id) },
                )
            }
        }

        node.children.forEach { child ->
            RenderResolvedNode(
                node = child,
                renderContext = renderContext,
                parentOrientation = BlockOrientation.VERTICAL,
            )
        }
    }
}

/**
 * `stateEffect != null` (Part B): the chip bar no longer owns tab-content
 * visibility (that's the legacy path) — it only reflects/writes a generic
 * cross-block Int property, in step with a paired carousel that declares the
 * same [stateEffect] pair back at this tabs block. No visibility toggle, no
 * swipe registration: `core.applyInitialTabVisibility` and
 * `RenderBlockScreen.collectTabContentOrder` are both gated to skip
 * `stateEffect`-bearing tabs, so those legacy content-pane concerns never
 * apply to the carousel's slides here.
 */
@Composable
private fun renderStateEffectTabsNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    config: TabsBlockConfig,
    stateEffect: BlockStateEffect,
) {
    val options = config.options
    val routeStateKey = LocalRenderRouteStateKey.current

    val activeIndex by RenderBlockInteractionCache.blockPropertyFlow(
        routeId = routeStateKey,
        blockId = node.block.id,
        property = stateEffect.property,
    ).map { it ?: 0 }.collectAsState(
        initial = RenderBlockInteractionCache.getBlockPropertyOrNull(
            routeId = routeStateKey,
            blockId = node.block.id,
            property = stateEffect.property,
        ) ?: 0,
    )

    val activeColor = config.activeColorHex?.toThemedComposeColorOrNull() ?: Color.Unspecified
    val activeBackground = config.activeBackgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent
    val inactiveColor = config.inactiveColorHex?.toThemedComposeColorOrNull() ?: Color.Unspecified
    val inactiveBackground = config.inactiveBackgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent
    val fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize
    val fontFamily = config.fontFamily.toComposeFontFamilyOrNull()
    val fontWeight = config.fontWeight?.toComposeFontWeight()
    val lineHeight = (config.lineHeightSp ?: TAB_DEFAULT_LINE_HEIGHT_SP).sp
    val tabScrollState = rememberScrollState()

    Column(
        modifier = modifier
            .then(if (config.style.width == null) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(tabScrollState),
            horizontalArrangement = Arrangement.spacedBy(config.gap.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            options.forEachIndexed { index, option ->
                TabChip(
                    option = option,
                    isActive = index == activeIndex,
                    activeColor = activeColor,
                    activeBackground = activeBackground,
                    inactiveColor = inactiveColor,
                    inactiveBackground = inactiveBackground,
                    fontSize = fontSize,
                    fontFamily = fontFamily,
                    fontWeight = fontWeight,
                    lineHeight = lineHeight,
                    chipStyle = config.chipStyle,
                    onClick = {
                        if (routeStateKey.isNotBlank()) {
                            RenderBlockInteractionCache.putBlockProperty(
                                routeId = routeStateKey,
                                blockId = node.block.id,
                                property = stateEffect.property,
                                value = index,
                            )
                            applyStateEffect(routeStateKey, stateEffect, index)
                        }
                    },
                )
            }
        }

        node.children.forEach { child ->
            RenderResolvedNode(
                node = child,
                renderContext = renderContext,
                parentOrientation = BlockOrientation.VERTICAL,
            )
        }
    }
}

@Composable
private fun TabChip(
    option: TabOption,
    isActive: Boolean,
    activeColor: Color,
    activeBackground: Color,
    inactiveColor: Color,
    inactiveBackground: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    fontFamily: androidx.compose.ui.text.font.FontFamily?,
    fontWeight: FontWeight?,
    lineHeight: androidx.compose.ui.unit.TextUnit,
    chipStyle: BlockStyle,
    onClick: () -> Unit,
) {
    val background = if (isActive) activeBackground else inactiveBackground
    val textColor = if (isActive) activeColor else inactiveColor
    // Chip metrics come from the contract; fall back to the default pill
    // (20dp radius, 16x8 padding) when the contract doesn't specify them.
    val shape = RoundedCornerShape((chipStyle.borderRadius ?: 20).dp)
    // Pill outline from the contract. Without this the inactive chip (which relies
    // on its border to be visible against a light background) renders borderless;
    // the active chip's filled background usually makes its same-color border blend in.
    val chipBorder = chipStyle.toBorderStroke()
    val chipPadding = PaddingValues(
        start = (chipStyle.paddingLeft ?: chipStyle.padding ?: 16).dp,
        end = (chipStyle.paddingRight ?: chipStyle.padding ?: 16).dp,
        top = (chipStyle.paddingTop ?: chipStyle.padding ?: 8).dp,
        bottom = (chipStyle.paddingBottom ?: chipStyle.padding ?: 8).dp,
    )
    Row(
        modifier = Modifier
            .clip(shape)
            .background(background, shape)
            .then(if (chipBorder != null) Modifier.border(chipBorder, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(chipPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Build an explicit TextStyle (mirroring RenderBlockTextRenderer) instead
        // of passing loose params over the inherited LocalTextStyle. With an
        // explicit style, the unset `letterSpacing` resolves to 0 — matching the
        // contract-driven body text — rather than keeping the Material default
        // tracking that made the chip label render wider.
        Text(
            text = option.label,
            style = TextStyle(
                color = textColor,
                fontSize = fontSize,
                fontFamily = fontFamily,
                fontWeight = fontWeight,
                lineHeight = lineHeight,
                lineHeightStyle = LineHeightStyle(
                    alignment = LineHeightStyle.Alignment.Center,
                    trim = LineHeightStyle.Trim.None,
                ),
            ),
        )
    }
}
