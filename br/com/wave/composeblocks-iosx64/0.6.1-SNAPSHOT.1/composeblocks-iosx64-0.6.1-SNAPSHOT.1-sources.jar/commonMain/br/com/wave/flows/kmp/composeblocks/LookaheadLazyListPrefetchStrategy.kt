package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.lazy.LazyListLayoutInfo
import androidx.compose.foundation.lazy.LazyListPrefetchScope
import androidx.compose.foundation.lazy.LazyListPrefetchStrategy
import androidx.compose.foundation.lazy.layout.LazyLayoutPrefetchState
import androidx.compose.foundation.lazy.layout.NestedPrefetchScope

/** How many items past the viewport edge the root list precomposes while scrolling. */
internal const val ROOT_LIST_LOOKAHEAD_ITEM_COUNT = 2

/**
 * Indices to prefetch for one scroll frame: the [aheadItemCount] items past the
 * viewport edge in the scroll direction, closest first, clamped to the list
 * bounds. Pure so the windowing logic is unit-testable without a LazyColumn.
 */
internal fun lookaheadPrefetchTargets(
    scrollingForward: Boolean,
    firstVisibleIndex: Int,
    lastVisibleIndex: Int,
    totalItemsCount: Int,
    aheadItemCount: Int,
): List<Int> = if (scrollingForward) {
    ((lastVisibleIndex + 1)..(lastVisibleIndex + aheadItemCount)).filter { it < totalItemsCount }
} else {
    ((firstVisibleIndex - 1) downTo (firstVisibleIndex - aheadItemCount)).filter { it >= 0 }
}

/**
 * Prefetch strategy for the root block list that precomposes [aheadItemCount]
 * items ahead of the scroll direction instead of the default single item.
 *
 * Server-driven blocks have very uneven composition costs: a `carousel` block
 * composes every card eagerly (free-scrolling `Row`), so the frame in which it
 * enters the viewport pays for N full card subtrees at once. Looking further
 * ahead moves that cost into idle time of earlier frames, before the block
 * reaches the viewport edge — the scroll gesture itself stays on budget.
 */
@OptIn(ExperimentalFoundationApi::class)
internal class LookaheadLazyListPrefetchStrategy(
    private val aheadItemCount: Int = ROOT_LIST_LOOKAHEAD_ITEM_COUNT,
) : LazyListPrefetchStrategy {

    private val scheduled = mutableMapOf<Int, LazyLayoutPrefetchState.PrefetchHandle>()
    private var scrollingForward = true

    override fun LazyListPrefetchScope.onScroll(delta: Float, layoutInfo: LazyListLayoutInfo) {
        val visible = layoutInfo.visibleItemsInfo
        if (visible.isEmpty()) return
        val forward = delta < 0
        if (forward != scrollingForward) {
            scrollingForward = forward
            cancelAllScheduled()
        }
        lookaheadPrefetchTargets(
            scrollingForward = forward,
            firstVisibleIndex = visible.first().index,
            lastVisibleIndex = visible.last().index,
            totalItemsCount = layoutInfo.totalItemsCount,
            aheadItemCount = aheadItemCount,
        ).forEach { index ->
            scheduled.getOrPut(index) { schedulePrefetch(index) }
        }
    }

    override fun LazyListPrefetchScope.onVisibleItemsUpdated(layoutInfo: LazyListLayoutInfo) {
        val visible = layoutInfo.visibleItemsInfo
        if (visible.isEmpty()) {
            cancelAllScheduled()
            return
        }
        // A handle whose item became visible has served its purpose; one that
        // fell outside the lookahead window (fast fling skipping past items,
        // data-set change) is cancelled so it doesn't hold a stale
        // precomposition alive.
        val visibleRange = visible.first().index..visible.last().index
        val keepRange = (visibleRange.first - aheadItemCount)..(visibleRange.last + aheadItemCount)
        scheduled.entries.removeAll { (index, handle) ->
            when {
                index in visibleRange -> true
                index !in keepRange -> {
                    handle.cancel()
                    true
                }
                else -> false
            }
        }
    }

    override fun NestedPrefetchScope.onNestedPrefetch(firstVisibleItemIndex: Int) {
        // Mirrors the default strategy: when the outer list prefetches this
        // list's block, precompose the first couple of nested items too.
        repeat(DEFAULT_NESTED_PREFETCH_ITEM_COUNT) { offset ->
            schedulePrecomposition(firstVisibleItemIndex + offset)
        }
    }

    private fun cancelAllScheduled() {
        scheduled.values.forEach(LazyLayoutPrefetchState.PrefetchHandle::cancel)
        scheduled.clear()
    }

    private companion object {
        const val DEFAULT_NESTED_PREFETCH_ITEM_COUNT = 2
    }
}
