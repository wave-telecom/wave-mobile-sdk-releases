package br.com.wave.flows.kmp.composeblocks

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.CarouselBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache
import br.com.wave.flows.kmp.runtime.api.applyStateEffect
import kotlinx.coroutines.flow.map
import kotlin.math.roundToInt

@Composable
internal fun renderCarouselNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as CarouselBlockConfig
    val children = node.children
    val fullWidth = config.itemWidth <= 0
    val spacing = config.spacing

    val density = LocalDensity.current
    val routeStateKey = LocalRenderRouteStateKey.current

    // Equalize card heights to the tallest, mirroring the web's flexbox stretch.
    // A free-scrolling Row (present mode) / an eagerly-composed pager (absent
    // mode, via `beyondViewportPageCount`) sees every card on the first measure
    // pass: each card reports its natural height, we keep the max, then pin
    // every card to it. (IntrinsicSize.Max would be the idiomatic way, but it
    // is unstable through `horizontalScroll`/`HorizontalPager` and jams the
    // parent LazyColumn's scrolling — so we measure explicitly instead.)
    //
    // The resolved height is cached process-wide keyed by route + block + a slot
    // that fingerprints everything the measurement depends on (content, item
    // width, density). The parent LazyColumn disposes this composable whenever
    // the carousel leaves the viewport; without the cache, every re-entry
    // restarts the equalization from 0 and pays the natural-height →
    // onSizeChanged → pinned-height relayout cascade again, in the middle of
    // the user's scroll gesture. Seeding from the cache pins the final height
    // on the very first frame. A contract refresh clears the cache
    // (RenderBlockInteractionCache.clearAll), and any content/density change
    // lands on a different slot, so a stale height is never re-applied.
    val heightCacheEnabled = routeStateKey.isNotBlank()
    val heightCacheSlot = remember(children, config.itemWidth, density) {
        carouselHeightCacheSlot(
            itemWidth = config.itemWidth,
            contentFingerprint = children.hashCode(),
            density = density.density,
            fontScale = density.fontScale,
        )
    }
    var maxHeightPx by remember(children) {
        mutableStateOf(
            if (heightCacheEnabled) {
                RenderBlockInteractionCache.getCounter(routeStateKey, node.block.id, heightCacheSlot)
            } else {
                0
            },
        )
    }

    Column(
        modifier = modifier
            .then(if (config.style.width == null) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (children.isEmpty()) return@Column

        if (fullWidth) {
            // Absent `itemWidth` ⇒ web `flex: 0 0 100%` + embla `align:'start'`:
            // each slide fills the carousel's own content width, paging snaps
            // one slide per view. `pagerState.currentPage` is the single source
            // of truth for the active index (Part B's hoistable seam).
            val pagerState = rememberPagerState(pageCount = { children.size })
            // A carousel with no `stateEffect` still needs to remember its own
            // page across a rebuild/restore; it reuses the literal "activeIndex"
            // slot on its own block id (no peer to sync with in that case).
            val syncProperty = config.stateEffect?.property ?: "activeIndex"

            val rawTargetIndex by RenderBlockInteractionCache.blockPropertyFlow(
                routeId = routeStateKey,
                blockId = node.block.id,
                property = syncProperty,
            ).map { it ?: 0 }.collectAsState(
                initial = RenderBlockInteractionCache.getBlockPropertyOrNull(
                    routeId = routeStateKey,
                    blockId = node.block.id,
                    property = syncProperty,
                ) ?: 0,
            )
            // Reviewer minor: clamp a channel-driven target to the ACTUAL slide
            // count before it ever reaches the pager — a stale/corrupt index or a
            // tabs/carousel option-count mismatch must degrade to a valid page,
            // never throw or scroll wild (mirrors `CarouselScrollView.scrollToIndex`'s
            // own `coerceIn` on the View engine).
            val targetIndex = rawTargetIndex.coerceIn(0, (children.size - 1).coerceAtLeast(0))
            // First land (initial composition or a restored non-zero index) jumps
            // straight there; any later external write (peer tab tap) animates.
            var hasLanded by remember(node.block.id, routeStateKey) { mutableStateOf(false) }
            LaunchedEffect(targetIndex) {
                if (targetIndex != pagerState.currentPage) {
                    if (hasLanded) pagerState.animateScrollToPage(targetIndex) else pagerState.scrollToPage(targetIndex)
                }
                hasLanded = true
            }
            // The restore target read ONCE at first composition — 0 on a fresh
            // mount, or a persisted index from a prior visit (the cache is a
            // session-singleton, cleared only on PTR/refresh, so a plain
            // navigate-away-and-back remounts with a FRESH `pagerState` at page 0
            // while the channel still holds the last index). A fresh `pagerState`
            // makes `snapshotFlow { settledPage }` emit that 0 immediately on
            // subscription — which can race AHEAD of this same recomposition's
            // own `scrollToPage(restoreTarget)` above — so that first emission may
            // be stale pre-restore scaffolding, not a real settle; writing it would
            // clobber a non-zero restore (own AND peer slot) before it ever lands.
            val restoreTarget = remember(node.block.id, routeStateKey) { targetIndex }
            var restoreReachedOrLifted by remember(node.block.id, routeStateKey) { mutableStateOf(restoreTarget == 0) }
            // Emits once per snap-settle (own persistence +, when declared, the
            // peer tabs' highlight). `StateFlow` writes are idempotent (equal
            // value -> no emission) and reads are `distinctUntilChanged`, so the
            // one programmatic round-trip this creates (tap -> peer scroll ->
            // settle -> write-back of the SAME index) terminates immediately as
            // a no-op — no debounce/echo-guard needed.
            LaunchedEffect(pagerState, routeStateKey) {
                snapshotFlow { pagerState.settledPage }.collect { settled ->
                    if (!restoreReachedOrLifted && settled != restoreTarget && targetIndex == restoreTarget) {
                        // Still-stale pre-restore snapshot: the pager hasn't
                        // reached the restore target yet AND nothing user/peer-
                        // driven has moved the live target away from it either —
                        // skip the write rather than clobber the pending restore.
                        return@collect
                    }
                    // Either genuinely reached `restoreTarget`, or the live target
                    // already changed (a tab tap / peer write mid-restore is real
                    // user intent, not stale scaffolding) — lift suppression for
                    // good and write normally from here on.
                    restoreReachedOrLifted = true
                    if (routeStateKey.isNotBlank()) {
                        RenderBlockInteractionCache.putBlockProperty(
                            routeId = routeStateKey,
                            blockId = node.block.id,
                            property = syncProperty,
                            value = settled,
                        )
                        config.stateEffect?.let { applyStateEffect(routeStateKey, it, settled) }
                    }
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (maxHeightPx > 0) {
                            Modifier.height(with(density) { maxHeightPx.toDp() })
                        } else {
                            Modifier
                        },
                    ),
                pageSize = PageSize.Fill,
                pageSpacing = spacing.dp,
                userScrollEnabled = children.size > 1,
                beyondViewportPageCount = children.size,
            ) { page ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                        .onSizeChanged {
                            if (it.height > maxHeightPx) {
                                maxHeightPx = it.height
                                if (heightCacheEnabled) {
                                    RenderBlockInteractionCache.putCounter(
                                        routeId = routeStateKey,
                                        blockId = node.block.id,
                                        value = it.height,
                                        slot = heightCacheSlot,
                                    )
                                }
                            }
                        },
                ) {
                    RenderResolvedNode(
                        node = children[page],
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                        modifier = Modifier.fillMaxHeight(),
                    )
                }
            }

            if (config.showIndicators && children.size > 1) {
                carouselIndicators(count = children.size, activeIndex = pagerState.currentPage)
            }
        } else {
            val itemWidth = config.itemWidth
            val scrollState = rememberScrollState()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(spacing.dp),
            ) {
                children.forEach { child ->
                    Box(
                        modifier = Modifier
                            .width(itemWidth.dp)
                            .then(
                                if (maxHeightPx > 0) {
                                    Modifier.height(with(density) { maxHeightPx.toDp() })
                                } else {
                                    Modifier
                                },
                            )
                            .onSizeChanged {
                                if (it.height > maxHeightPx) {
                                    maxHeightPx = it.height
                                    if (heightCacheEnabled) {
                                        RenderBlockInteractionCache.putCounter(
                                            routeId = routeStateKey,
                                            blockId = node.block.id,
                                            value = it.height,
                                            slot = heightCacheSlot,
                                        )
                                    }
                                }
                            },
                    ) {
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.HORIZONTAL,
                            modifier = Modifier.fillMaxHeight(),
                        )
                    }
                }
            }

            if (config.showIndicators && children.size > 1) {
                // No paged snapping here (free scroll), so derive the active dot from
                // the scroll offset: each card advances by itemWidth + spacing.
                val activeIndex by remember(itemWidth, spacing, children.size) {
                    derivedStateOf {
                        val stridePx = with(density) { (itemWidth + spacing).dp.toPx() }
                        if (stridePx <= 0f) {
                            0
                        } else {
                            (scrollState.value / stridePx).roundToInt().coerceIn(0, children.size - 1)
                        }
                    }
                }
                carouselIndicators(count = children.size, activeIndex = activeIndex)
            }
        }
    }
}

@Composable
private fun carouselIndicators(count: Int, activeIndex: Int) {
    Row(
        modifier = Modifier
            .padding(top = 20.dp)
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
    ) {
        repeat(count) { index ->
            val isActive = activeIndex == index
            val dotColor by animateColorAsState(
                targetValue = if (isActive) Color(0xFF00529B) else Color(0xFFD0D0D0),
                animationSpec = tween(durationMillis = 200),
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor, CircleShape),
            )
        }
    }
}

/**
 * Slot under which a carousel's equalized height is cached in
 * [RenderBlockInteractionCache]. Encodes every input the measurement depends
 * on — card content, item width, display density and font scale — so any
 * change lands on a different slot and re-measures instead of pinning a
 * stale height.
 */
internal fun carouselHeightCacheSlot(
    itemWidth: Int,
    contentFingerprint: Int,
    density: Float,
    fontScale: Float,
): String = "carouselMaxHeightPx|$itemWidth|$contentFingerprint|$density|$fontScale"
