package br.com.wave.flows.kmp.composeblocks

import kotlin.math.abs
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.SubcomposeLayout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.registry.ComposeRendererRegistry
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.contract.SkeletonBlockConfig
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.renderplan.createRenderPlan
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache

@Composable
internal fun renderListNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as ListBlockConfig
    val compactHorizontalItem = LocalCompactHorizontalItem.current
    val chartOverlayContent = LocalChartOverlayContent.current
    if (config.orientation == BlockOrientation.VERTICAL) {
        val tabOrder = LocalTabContentOrder.current
        val tabContentChild = node.children.firstOrNull { it.block.id in tabOrder }
        // When this list hosts a tab's content, let a horizontal swipe anywhere
        // over it (including the chart) switch tabs. The handler is registered
        // by the sibling `tabs` block via the screen-scoped swipe registry.
        val swipeHandler = tabContentChild?.let { LocalTabSwipeRegistry.current?.handlerFor(it.block.id) }
        val swipeModifier = if (swipeHandler != null) Modifier.tabSwipeGesture(swipeHandler) else Modifier
        CompositionLocalProvider(LocalCompactHorizontalItem provides false) {
            Column(
                modifier = modifier
                    .then(
                        if (shouldFillWidth(config.style, parentOrientation) && !compactHorizontalItem) {
                            Modifier.fillMaxWidth()
                        } else {
                            Modifier
                        },
                    )
                    // Fills the parent's height only when it will do useful work.
                    // Tab-content stretch fills the reserved tab height regardless
                    // of arrangement. The `expand` arm requires a space-* arrangement
                    // so there is something to distribute (e.g. pinning a card's
                    // button to the bottom). Without a distributing arrangement,
                    // filling the parent only manufactures empty space — the
                    // plan-details bottom-sheet over-grow. Skip entirely inside a
                    // horizontal row: `expand` there means "share the width", and
                    // fillMaxHeight makes the row collapse vertically.
                    .then(
                        if (shouldFillParentHeight(config, LocalStretchTabContentHeight.current) &&
                            parentOrientation != BlockOrientation.HORIZONTAL
                        ) {
                            Modifier.fillMaxHeight()
                        } else {
                            Modifier
                        },
                    )
                    .applyBlockStyle(config.style)
                    .padding(
                        if (compactHorizontalItem) {
                            config.style.toVerticalPaddingValues()
                        } else {
                            config.style.toPaddingValues()
                        },
                    )
                    .then(swipeModifier),
                verticalArrangement = config.verticalAlign.toVerticalArrangement(config.spacing),
                horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
            ) {
                if (tabContentChild != null) {
                    // This list hosts a tab's content: animate a tab switch with a
                    // directional horizontal slide — right→left when moving to a
                    // later tab, left→right when going back to an earlier one.
                    val tabContent: @Composable () -> Unit = {
                        val stretch = LocalStretchTabContentHeight.current
                        val fillHeight = if (stretch) Modifier.fillMaxHeight() else Modifier
                        AnimatedContent(
                            targetState = tabContentChild,
                            modifier = fillHeight,
                            transitionSpec = {
                                val from = tabOrder[initialState.block.id] ?: 0
                                val to = tabOrder[targetState.block.id] ?: 0
                                if (to >= from) {
                                    (slideInHorizontally { w -> w } + fadeIn()) togetherWith
                                        (slideOutHorizontally { w -> -w } + fadeOut())
                                } else {
                                    (slideInHorizontally { w -> -w } + fadeIn()) togetherWith
                                        (slideOutHorizontally { w -> w } + fadeOut())
                                }
                            },
                            label = "tabContent",
                        ) { child ->
                            RenderResolvedNode(
                                node = child,
                                renderContext = renderContext,
                                parentOrientation = BlockOrientation.VERTICAL,
                                modifier = fillHeight,
                            )
                        }
                    }
                    val candidates = rememberTabHeightCandidates(node, tabOrder, renderContext)
                    if (candidates.size > 1) {
                        TabContentWithReservedHeight(
                            candidates = candidates,
                            renderContext = renderContext,
                            hostBlockId = node.block.id,
                            content = tabContent,
                        )
                    } else {
                        tabContent()
                    }
                } else {
                    node.children.forEach { child ->
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.VERTICAL,
                        )
                    }
                }
            }
        }
    } else {
        val centerUnalignedChartOverlayRow = chartOverlayContent && config.horizontalAlign == null
        val expandLastItem = node.children.lastOrNull()?.containsDivider() == true
        val expandIndexes = node.children.mapIndexedNotNull { index, child ->
            val childConfig = child.block.config
            // A width-less skeleton in a horizontal row would otherwise measure with
            // unbounded width, where `fillMaxWidth()` is a no-op → a 0-width (invisible)
            // bar. Treat it as an expand item so the layout splits the remaining width
            // among such bars (matching the contract's space-between skeleton rows).
            val skeletonWantsWidth = childConfig is SkeletonBlockConfig &&
                childConfig.width.isNullOrBlank()
            val shouldExpand = (childConfig is ListBlockConfig && childConfig.expand) ||
                childConfig.style.fullWidth == true ||
                skeletonWantsWidth
            if (shouldExpand) index else null
        }.toSet()
        // Text dropped straight into a horizontal row would otherwise measure with
        // unbounded width and lay out as a single line that overflows the row (the
        // web flexbox shrinks the item to fit; Compose's row does not). Mark every
        // un-truncated, width-less text/rich-text as a "shrink" item: the layout
        // caps it at the width still available so it stays on one line when it fits
        // (labels, prices) and wraps when it doesn't (the suspension alert message).
        // `fullWidth`/`expand` items already fill the row, so they are left to that
        // path instead.
        val shrinkIndexes = node.children.mapIndexedNotNull { index, child ->
            if (index in expandIndexes) return@mapIndexedNotNull null
            val childConfig = child.block.config
            val wantsShrink = when (childConfig) {
                is TextBlockConfig -> !childConfig.truncate && childConfig.style.width == null
                is RichTextBlockConfig -> !childConfig.truncate && childConfig.style.width == null
                else -> false
            }
            if (wantsShrink) index else null
        }.toSet()
        AdaptiveHorizontalListLayout(
            modifier = modifier
                .then(
                    if (shouldFillWidth(config.style, parentOrientation) && !centerUnalignedChartOverlayRow) {
                        Modifier.fillMaxWidth()
                    } else {
                        Modifier
                    },
                )
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            spacing = config.spacing,
            horizontalAlign = if (centerUnalignedChartOverlayRow) "center" else config.horizontalAlign,
            verticalAlign = config.verticalAlign,
            expandIndexes = expandIndexes,
            shrinkIndexes = shrinkIndexes,
            expandLastItem = expandLastItem,
        ) {
            node.children.forEachIndexed { index, child ->
                // Shrink items are width-capped by the layout, so they must NOT opt
                // into the compact single-line path (`wrapContentWidth(unbounded)` +
                // `maxLines = 1`) that the text renderer applies to horizontal-row
                // children — that would re-measure them unbounded and defeat the cap.
                val compact = index !in shrinkIndexes
                CompositionLocalProvider(LocalCompactHorizontalItem provides compact) {
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                    )
                }
            }
        }
    }
}

private fun ResolvedRenderNode.containsDivider(): Boolean {
    return block.type == BlockType.DIVIDER || children.any { it.containsDivider() }
}

// `expand` only does useful work when the list has a `space-*` arrangement that
// can distribute the parent's extra height (e.g. pin a button to a card's foot).
// With a default/top arrangement there is nothing to distribute, so filling the
// parent height only manufactures empty space — the plan-details bottom-sheet
// over-grow. Tab-content stretch is a separate, deliberate fill and stays
// unconditional. Cross-reference: toVerticalArrangement() in RenderBlockStyle.kt
// lists the same space-* strings for arrangement mapping — intentional local
// duplication to keep the fill-height rule self-contained here.
internal fun shouldFillParentHeight(config: ListBlockConfig, stretchTabHeight: Boolean): Boolean {
    if (stretchTabHeight) return true
    if (!config.expand) return false
    return config.verticalAlign.isSpaceArrangement()
}

// Only space-* values (which distribute free space) are treated as "has something to
// distribute". `end` and `bottom` arrangements also legitimately need a filled parent to
// push content to the far edge, but no contract uses them today. They are intentionally
// excluded here — revisit if a contract introduces an end/bottom-aligned expand list.
internal fun String?.isSpaceArrangement(): Boolean = when (this?.lowercase()) {
    "space-between", "spacebetween",
    "space-around", "spacearound",
    "space-evenly", "spaceevenly" -> true
    else -> false
}

@Composable
private fun rememberTabHeightCandidates(
    hostNode: ResolvedRenderNode,
    tabOrder: Map<String, Int>,
    renderContext: RenderBlockRenderContext,
): List<ResolvedRenderNode> {
    return remember(hostNode.block, tabOrder) {
        val baseVisibility = renderContext.currentVisibility()
        hostNode.block.children
            .filter { it.id in tabOrder }
            .mapNotNull { child ->
                val visibility = baseVisibility.toMutableMap().apply { put(child.id, true) }
                createRenderPlan(
                    block = child,
                    rendererRegistry = ComposeRendererRegistry.supportedRendererTypes,
                    visibility = visibility,
                ).node
            }
    }
}

@Composable
private fun TabContentWithReservedHeight(
    candidates: List<ResolvedRenderNode>,
    renderContext: RenderBlockRenderContext,
    hostBlockId: String,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    val routeStateKey = LocalRenderRouteStateKey.current
    // The reserved height (tallest tab content) is cached process-wide, like the
    // carousel's equalized height: the parent LazyColumn disposes this composable
    // whenever the tabs block leaves the viewport, and without the cache every
    // re-entry re-runs the probe — which subcomposes EVERY tab's full content
    // just to measure it — and then flips `reservedHeightPx` 0 → measured,
    // switching composition branch below and rebuilding the visible tab content.
    // The slot fingerprints everything the measurement depends on (tab contents,
    // available width, density, font scale), so a contract/layout change misses
    // the cache and re-probes instead of pinning a stale height. A refresh
    // clears the cache (RenderBlockInteractionCache.clearAll).
    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val cacheEnabled = routeStateKey.isNotBlank() && constraints.hasBoundedWidth
        val maxWidthPx = if (constraints.hasBoundedWidth) constraints.maxWidth else 0
        val heightCacheSlot = remember(candidates, maxWidthPx, density) {
            tabsReservedHeightCacheSlot(
                maxWidthPx = maxWidthPx,
                contentFingerprint = candidates.hashCode(),
                density = density.density,
                fontScale = density.fontScale,
            )
        }
        val seededFromCache = remember(candidates, heightCacheSlot) {
            cacheEnabled &&
                RenderBlockInteractionCache.getCounter(routeStateKey, hostBlockId, heightCacheSlot) > 0
        }
        var reservedHeightPx by remember(candidates, heightCacheSlot) {
            mutableStateOf(
                if (cacheEnabled) {
                    RenderBlockInteractionCache.getCounter(routeStateKey, hostBlockId, heightCacheSlot)
                } else {
                    0
                },
            )
        }
        // First-ever visit: the probe runs (and keeps running, so late growth —
        // e.g. an async image — still raises the reserved height) and persists
        // every value it discovers. On a cache-seeded re-entry the probe is
        // skipped entirely: the settled height is already known, so there is no
        // reason to compose N tab subtrees again just to re-measure them.
        if (!seededFromCache) {
            TabHeightProbe(candidates = candidates, renderContext = renderContext) { tallest ->
                if (tallest > reservedHeightPx) {
                    reservedHeightPx = tallest
                    if (cacheEnabled) {
                        RenderBlockInteractionCache.putCounter(
                            routeId = routeStateKey,
                            blockId = hostBlockId,
                            value = tallest,
                            slot = heightCacheSlot,
                        )
                    }
                }
            }
        }
        if (reservedHeightPx > 0) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(with(density) { reservedHeightPx.toDp() }),
            ) {
                CompositionLocalProvider(LocalStretchTabContentHeight provides true) {
                    content()
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxWidth()) {
                content()
            }
        }
    }
}

/**
 * Slot under which a tabs host's reserved content height is cached in
 * [RenderBlockInteractionCache]. Encodes every input the probe measurement
 * depends on — the tab contents, the available width, display density and
 * font scale — so any change lands on a different slot and re-probes instead
 * of pinning a stale height.
 */
internal fun tabsReservedHeightCacheSlot(
    maxWidthPx: Int,
    contentFingerprint: Int,
    density: Float,
    fontScale: Float,
): String = "tabsReservedHeightPx|$maxWidthPx|$contentFingerprint|$density|$fontScale"

@Composable
private fun TabHeightProbe(
    candidates: List<ResolvedRenderNode>,
    renderContext: RenderBlockRenderContext,
    onTallest: (Int) -> Unit,
) {
    SubcomposeLayout(modifier = Modifier.fillMaxWidth()) { constraints ->
        val measureConstraints = constraints.copy(minHeight = 0)
        val tallest = subcompose(Unit) {
            CompositionLocalProvider(LocalTabHeightMeasurementPass provides true) {
                candidates.forEach { candidate ->
                    Box(modifier = Modifier.fillMaxWidth()) {
                        RenderResolvedNode(
                            node = candidate,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.VERTICAL,
                        )
                    }
                }
            }
        }.maxOfOrNull { it.measure(measureConstraints).height } ?: 0
        onTallest(tallest)
        layout(0, 0) {}
    }
}

/**
 * Detects a horizontal swipe over a tab's content and commits a tab change on
 * release: drag left → next tab (`+1`), drag right → previous (`-1`). Only
 * horizontal-dominant drags are consumed, so the vertical scroll of the screen
 * keeps working. The threshold avoids accidental switches on small drags.
 */
internal fun Modifier.tabSwipeGesture(onSwipe: (Int) -> Unit): Modifier =
    this.pointerInput(onSwipe) {
        val thresholdPx = 56.dp.toPx()
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            var totalDx = 0f
            var totalDy = 0f
            var isTabSwipe = false
            while (true) {
                val event = awaitPointerEvent()
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (change.changedToUpIgnoreConsumed()) {
                    if (isTabSwipe) {
                        when {
                            totalDx <= -thresholdPx -> onSwipe(1)
                            totalDx >= thresholdPx -> onSwipe(-1)
                        }
                    }
                    break
                }
                val positionChange = change.positionChange()
                totalDx += positionChange.x
                totalDy += positionChange.y
                // Only claim the drag once it's a deliberate, horizontal-dominant
                // tab swipe past the threshold. Before that, leave it unconsumed
                // so the parent vertical scroll (and any horizontally scrollable
                // child, e.g. a carousel) still receives it instead of being
                // starved.
                if (!isTabSwipe && abs(totalDx) >= thresholdPx && abs(totalDx) > abs(totalDy)) {
                    isTabSwipe = true
                }
                if (isTabSwipe) change.consume()
            }
        }
    }
