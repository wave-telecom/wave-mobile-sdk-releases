package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.CardBlockConfig
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderCardNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as CardBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    // Set while this card sits in its post-tap `refresh` cooldown: paint the
    // `variants.disabled` palette and push the disabled content colour onto the
    // text/icon children, taking priority over the base/selected styling.
    val disabledVariant = LocalDisabledVariant.current
    // A card with no authored background paints nothing — it stays transparent
    // so the (theme-resolved) page/parent background shows through. Falling back
    // to a fixed `colorScheme.surface` here used to hardcode a light surface,
    // which left colorless cards stuck white in dark mode (FLW-1155).
    //
    // When this card is the selected item of a radio-group, paint its OWN
    // `variants.selected.backgroundColor` (if it declares one). This keeps the
    // highlight on the block that owns it — e.g. the navbar's icon wrapper —
    // instead of the group painting the whole item (icon + label).
    val containerColor = if (disabledVariant.active) {
        disabledVariant.backgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent
    } else {
        config.selectedBackgroundColorHex
            ?.takeIf { radioGroupOverride.active }
            ?.toThemedComposeColorOrNull()
            ?: config.style.backgroundColorHex?.toThemedComposeColorOrNull()
            ?: Color.Transparent
    }
    // The selected pill's rounded shape lives in `variants.selected.borderRadius`,
    // not the base style — apply it when this card is the active radio-group item.
    val cardShape = config.selectedBorderRadius
        ?.takeIf { radioGroupOverride.active }
        ?.let { RoundedCornerShape(it.dp) }
        ?: config.style.toRoundedCornerShape()
    val contentColorOverride = disabledVariant.contentColorHex
        ?.takeIf { disabledVariant.active }
        ?.toThemedComposeColorOrNull()
        ?: config.style.colorHex?.toThemedComposeColorOrNull()
        ?: LocalContentColorOverride.current
    val elevationDp = (config.elevation ?: 0).dp
    val isTransparentWrapper = containerColor == Color.Transparent && elevationDp == 0.dp
    val isBorderedContentChip = config.style.width == null &&
        config.style.borderWidth != null &&
        elevationDp == 0.dp &&
        config.style.backgroundColorHex == null
    val isLeafCard = node.children.isEmpty()
    val isSwatchWrapper = node.children.size == 1 &&
        node.children[0].block.config is CardBlockConfig &&
        node.children[0].children.isEmpty()
    val wrapsContent = isBorderedContentChip || isLeafCard || isSwatchWrapper
    Card(
        modifier = modifier
            .then(if (shouldFillWidth(config.style, parentOrientation) && !wrapsContent) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style, includeBackground = false),
        shape = cardShape,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = elevationDp),
    ) {
        val swatchGap = if (isSwatchWrapper) (config.style.borderWidth ?: 0).dp else 0.dp
        // Only fill the card's height when it directly hosts an `expand` list (e.g.
        // a space-between content list that pins the button to the card's foot).
        // Filling unconditionally would make every card greedily grab the height a
        // parent row offers, stretching wrap-content cards (tags, badges).
        val hasExpandChild = node.children.any { (it.block.config as? ListBlockConfig)?.expand == true }
        val contentHeightModifier = if (hasExpandChild) Modifier.fillMaxHeight() else Modifier
        CompositionLocalProvider(LocalContentColorOverride provides contentColorOverride) {
            Column(modifier = contentHeightModifier.padding(config.style.toPaddingValues(defaultPadding = if (isTransparentWrapper) 0 else 12)).padding(swatchGap)) {
                node.children.forEach { child ->
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.VERTICAL,
                    )
                }
            }
        }
    }
}
