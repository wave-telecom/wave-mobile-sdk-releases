package br.com.wave.flows.kmp.composeblocks.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemePalette

/**
 * What flows down the Compose tree so any block can resolve `@{token}`
 * references against the active palette without touching the store directly.
 *
 * [activeId] = the id we actually picked for this composition (may be
 * synthesised from Auto + system signal — not necessarily `mode.themeId`).
 * [palette] = the [ThemePalette] for [activeId], or null when no catalog is
 * configured (back-compat: tokens left unresolved → renderer falls back to
 * literal hex / null).
 */
data class ActiveFlowTheme(
    val activeId: ThemeId?,
    val palette: ThemePalette?,
) {
    /** Resolves `"@{Text.Black_primary}"` to its hex value, or null. */
    fun resolveReference(raw: String): String? = palette?.resolveReference(raw)

    companion object {
        /** The "no theme configured" value — preserves legacy literal-hex rendering. */
        val None: ActiveFlowTheme = ActiveFlowTheme(activeId = null, palette = null)
    }
}

val LocalFlowTheme: ProvidableCompositionLocal<ActiveFlowTheme> =
    staticCompositionLocalOf { ActiveFlowTheme.None }

/**
 * Wraps [content] with a [LocalFlowTheme] computed from the global
 * [FlowThemeStore]. Reads `isSystemInDarkTheme()` so Auto mode reacts to
 * the OS — when the user flips dark mode in settings, this re-evaluates
 * and the screen re-resolves its tokens.
 *
 * Call this once near the root of `RenderBlock` (a single provider covers
 * the whole subtree; nested calls are harmless but redundant).
 */
@Composable
fun ProvideFlowTheme(content: @Composable () -> Unit) {
    val catalog by FlowThemeStore.catalog.collectAsState()
    val mode by FlowThemeStore.mode.collectAsState()
    val systemDark = isSystemInDarkTheme()

    val active = remember(catalog, mode, systemDark) {
        val palette = FlowThemeStore.resolveActive(catalog, mode, systemDark)
        ActiveFlowTheme(activeId = palette?.id, palette = palette)
    }

    // Report so non-composable code (block action dispatch) can drive
    // [FlowThemeStore.toggle] from the right starting point.
    LaunchedEffect(active.activeId) {
        FlowThemeStore.reportActiveId(active.activeId)
    }

    CompositionLocalProvider(LocalFlowTheme provides active, content = content)
}
