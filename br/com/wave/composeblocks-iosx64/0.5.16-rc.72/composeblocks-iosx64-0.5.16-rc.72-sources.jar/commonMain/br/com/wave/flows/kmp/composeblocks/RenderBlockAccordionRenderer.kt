package br.com.wave.flows.kmp.composeblocks

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.AccordionBlockConfig
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache

@Composable
internal fun renderAccordionNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as AccordionBlockConfig
    val routeStateKey = LocalRenderRouteStateKey.current
    val cachedExpanded = remember(routeStateKey, node.block.id) {
        RenderBlockInteractionCache.getToggle(
            routeId = routeStateKey,
            blockId = node.block.id,
            slot = "accordion.expanded",
        )
    }
    val initialExpanded = cachedExpanded ?: config.defaultOpen
    var expanded by remember(node.block.id, routeStateKey) { mutableStateOf(initialExpanded) }
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "accordion-icon-rotation",
    )

    val widthModifier = when {
        config.style.width != null -> Modifier
        config.fullWidth == false || config.wrapContent == true -> Modifier.wrapContentWidth()
        shouldFillWidth(config.style, parentOrientation) -> Modifier.fillMaxWidth()
        else -> Modifier
    }

    Column(
        modifier = modifier
            .then(widthModifier)
            .applyBlockStyle(config.style),
    ) {
        AccordionHeader(
            config = config,
            expanded = expanded,
            rotation = rotation,
            onToggle = {
                expanded = !expanded
                if (routeStateKey.isNotBlank()) {
                    RenderBlockInteractionCache.putToggle(
                        routeId = routeStateKey,
                        blockId = node.block.id,
                        value = expanded,
                        slot = "accordion.expanded",
                    )
                }
            },
        )

        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.fillMaxWidth()) {
                node.children.forEach { child ->
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.VERTICAL,
                    )
                }
            }
        }
    }
}

@Composable
private fun AccordionHeader(
    config: AccordionBlockConfig,
    expanded: Boolean,
    rotation: Float,
    onToggle: () -> Unit,
) {
    val titleColor = config.style.colorHex?.toThemedComposeColorOrNull() ?: Color.Unspecified
    val iconColor = config.iconColorHex?.toThemedComposeColorOrNull() ?: titleColor
    val iconWidth = (config.iconWidth ?: 24).dp
    val iconHeight = (config.iconHeight ?: 24).dp
    val titleFontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize
    val titleFontWeight = config.fontWeight?.toComposeFontWeight()
    val titleFontFamily = config.fontFamily.toComposeFontFamilyOrNull()
    val titleFontStyle = config.fontStyle.toComposeFontStyleOrNull()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(config.style.toPaddingValues(defaultPadding = 16)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = config.title.orEmpty(),
            style = TextStyle(
                color = titleColor,
                fontSize = titleFontSize,
                fontFamily = titleFontFamily,
                fontWeight = titleFontWeight,
                fontStyle = titleFontStyle,
            ),
            modifier = Modifier.weight(1f, fill = true),
        )
        Spacer(modifier = Modifier.width(8.dp))
        AccordionIcon(
            config = config,
            expanded = expanded,
            rotation = rotation,
            iconColor = iconColor,
            modifier = Modifier.size(width = iconWidth, height = iconHeight),
        )
    }
}

@Composable
private fun AccordionIcon(
    config: AccordionBlockConfig,
    expanded: Boolean,
    rotation: Float,
    iconColor: Color,
    modifier: Modifier,
) {
    val contentDescription = if (expanded) "Collapse" else "Expand"
    val rotatedModifier = modifier.rotate(rotation)
    val iconUrl = config.iconUrl?.takeIf(String::isNotBlank)

    when {
        iconUrl != null -> LocalRenderBlockImageContent.current?.invoke(
            iconUrl,
            contentDescription,
            rotatedModifier,
            ContentScale.Fit,
            null,
        ) ?: Icon(
            imageVector = Icons.Filled.KeyboardArrowDown,
            contentDescription = contentDescription,
            tint = if (iconColor == Color.Unspecified) LocalContentColor.current else iconColor,
            modifier = rotatedModifier,
        )

        else -> Icon(
            imageVector = Icons.Filled.KeyboardArrowDown,
            contentDescription = contentDescription,
            tint = if (iconColor == Color.Unspecified) LocalContentColor.current else iconColor,
            modifier = rotatedModifier,
        )
    }
}

private fun String?.toComposeFontStyleOrNull(): FontStyle? {
    return when (this?.lowercase()) {
        "normal" -> FontStyle.Normal
        "italic", "oblique" -> FontStyle.Italic
        else -> null
    }
}
