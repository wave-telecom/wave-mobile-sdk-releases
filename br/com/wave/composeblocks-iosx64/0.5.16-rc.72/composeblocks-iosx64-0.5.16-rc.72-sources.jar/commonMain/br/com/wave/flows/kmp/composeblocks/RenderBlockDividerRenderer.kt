package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Divider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.DividerBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderDividerNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as DividerBlockConfig
    if (config.orientation == BlockOrientation.HORIZONTAL) {
        Divider(modifier = modifier.fillMaxWidth().applyBlockStyle(config.style))
    } else {
        Spacer(modifier = modifier.height(1.dp).applyBlockStyle(config.style))
    }
}
