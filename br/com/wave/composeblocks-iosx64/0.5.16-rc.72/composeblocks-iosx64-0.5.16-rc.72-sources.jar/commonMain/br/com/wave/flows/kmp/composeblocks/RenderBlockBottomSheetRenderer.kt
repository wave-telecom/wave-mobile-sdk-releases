package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BottomSheetBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.visibility.setBlockVisibility

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun renderBottomSheetNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    isRoot: Boolean,
) {
    val config = node.block.config as BottomSheetBlockConfig
    val padding = config.style.toPaddingValues(defaultPadding = 16)

    if (isRoot) {
        // The block sits at the top of a host-driven RenderBlock call
        // (resolved from the in-RAM block index after a navigate callback
        // with `context.localCache`). The host owns the modal chrome —
        // we just emit content.
        Column(
            modifier = modifier.fillMaxWidth().padding(padding),
        ) {
            node.children.forEach { child ->
                RenderResolvedNode(
                    node = child,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.VERTICAL,
                )
            }
        }
        return
    }

    // Legacy path: bottom-sheet is a nested child whose visibility was
    // toggled by an `onAction: "show"` somewhere up the tree. SDK keeps
    // the Material chrome so existing contracts keep working.
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    LaunchedEffect(node.block.id) { sheetState.show() }

    ModalBottomSheet(
        onDismissRequest = {
            renderContext.onVisibilityChange(
                setBlockVisibility(
                    state = renderContext.currentVisibility(),
                    blockId = node.block.id,
                    value = false,
                ),
            )
        },
        sheetState = sheetState,
        containerColor = config.style.backgroundColorHex?.toThemedComposeColorOrNull() ?: Color.White,
        shape = config.style.toRoundedCornerShape(),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(padding),
        ) {
            node.children.forEach { child ->
                RenderResolvedNode(
                    node = child,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.VERTICAL,
                )
            }
        }
    }
}
