package br.com.wave.flows.kmp.runtime.api.sources

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.api.BffScreenContractCache

/**
 * Top-of-chain source backed by the process-wide [BffScreenContractCache].
 *
 * Lookups are synchronous and side-effect-free; this source never performs
 * I/O. It supports [ContractSource.trySync] so the non-suspend peek path
 * (used during composition) can short-circuit here.
 *
 * Writes happen out-of-band via [BffScreenContractCache.put] called by
 * downstream sources after a successful disk read or network fetch.
 */
internal class InMemoryRamSource : ContractSource {
    override suspend fun tryGet(query: ContractQuery): ScreenContract? = trySync(query)

    override fun trySync(query: ContractQuery): ScreenContract? =
        BffScreenContractCache.get(
            baseUrl = query.baseUrl,
            externalCode = query.externalCode,
            componentId = query.componentId,
            mode = query.mode.wireValue,
        )
}
