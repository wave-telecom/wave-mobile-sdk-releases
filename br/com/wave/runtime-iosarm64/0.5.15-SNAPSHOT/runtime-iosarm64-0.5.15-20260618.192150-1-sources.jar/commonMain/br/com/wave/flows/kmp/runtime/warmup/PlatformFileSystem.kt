package br.com.wave.flows.kmp.runtime.warmup

import okio.FileSystem

internal expect fun systemFileSystem(): FileSystem
