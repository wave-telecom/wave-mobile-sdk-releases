package br.com.wave.flows.kmp.runtime.contract.dto.action

import br.com.wave.flows.kmp.core.contract.VerbatimHostCallbackJson
import br.com.wave.flows.kmp.runtime.contract.mapping.support.TransportValueCoercions
import kotlinx.serialization.DeserializationStrategy
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonContentPolymorphicSerializer
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

@Serializable(with = ActionDtoSerializer::class)
internal sealed interface ActionDto {
    val type: String?
    val onAction: String?
}

internal object ActionDtoSerializer : JsonContentPolymorphicSerializer<ActionDto>(ActionDto::class) {
    override fun selectDeserializer(element: JsonElement): DeserializationStrategy<ActionDto> {
        val obj = element as? JsonObject
        val rawAction = (obj?.get("onAction") as? JsonPrimitive)?.contentOrNull
        return when (TransportValueCoercions.normalizeEnumValue(rawAction)) {
            "navigate" -> NavigateActionDto.serializer()
            "show" -> ShowActionDto.serializer()
            "hide" -> HideActionDto.serializer()
            "back" -> BackActionDto.serializer()
            "openurl" -> OpenUrlActionDto.serializer()
            "refresh" -> RefreshActionDto.serializer()
            "render_block_navigate", "iframenavigation", "downloadfile" -> DelegatedHostActionDto.serializer()
            "togglethememode" -> ToggleThemeModeActionDto.serializer()
            else -> UnknownActionDto.serializer()
        }
    }
}

@Serializable
internal data class NavigateActionConfigDto(
    val originId: String? = null,
    val origindId: String? = null,
    val destinationId: String? = null,
)

@Serializable
internal data class ReferenceIdActionConfigDto(
    val referenceId: String? = null,
)

@Serializable
internal data class OpenUrlActionConfigDto(
    val externalDestinationUrl: String? = null,
)

@Serializable
internal data class NavigateActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: VerbatimHostCallbackJson? = null,
) : ActionDto

@Serializable
internal data class ShowActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: ReferenceIdActionConfigDto? = null,
) : ActionDto

@Serializable
internal data class HideActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: ReferenceIdActionConfigDto? = null,
) : ActionDto

@Serializable
internal data class BackActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: ReferenceIdActionConfigDto? = null,
) : ActionDto

@Serializable
internal data class OpenUrlActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: OpenUrlActionConfigDto? = null,
) : ActionDto

@Serializable
internal data class RefreshActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
) : ActionDto

@Serializable
internal data class DelegatedHostActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: JsonObject? = null,
) : ActionDto

@Serializable
internal data class ToggleThemeModeActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
) : ActionDto

@Serializable
internal data class UnknownActionDto(
    override val type: String? = null,
    override val onAction: String? = null,
    val config: JsonObject? = null,
) : ActionDto
