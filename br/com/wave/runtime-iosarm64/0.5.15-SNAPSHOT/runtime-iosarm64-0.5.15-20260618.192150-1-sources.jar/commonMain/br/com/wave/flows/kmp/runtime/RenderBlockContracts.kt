package br.com.wave.flows.kmp.runtime

import br.com.wave.flows.kmp.core.contract.ScreenContractProvider

data class RenderBlockSdkConfig(
    val contractProvider: ScreenContractProvider,
    val defaultComponentId: String = DEFAULT_COMPONENT_ID,
)

sealed class RenderBlockSdkEvent {
    data class Error(
        val componentId: String,
        val code: String,
        val message: String,
    ) : RenderBlockSdkEvent()

    data class ComponentLoaded(
        val componentId: String,
    ) : RenderBlockSdkEvent()

    data class Callback(
        val type: String,
        val payload: String,
        val origin: String,
    ) : RenderBlockSdkEvent()
}

interface RenderBlockHost {
    fun onRenderBlockEvent(event: RenderBlockSdkEvent): Boolean = false
}

const val EVENT_RENDER_BLOCK_NAVIGATE = "RENDER_BLOCK_NAVIGATE"
const val EVENT_RENDER_BLOCK_BACK = "RENDER_BLOCK_BACK"
const val EVENT_RENDER_BLOCK_OPEN_URL = "RENDER_BLOCK_OPEN_URL"
const val EVENT_RENDER_BLOCK_REFRESH = "RENDER_BLOCK_REFRESH"
const val EVENT_RENDER_BLOCK_ACTION = "RENDER_BLOCK_ACTION"
const val ORIGIN_NATIVE_RENDER_BLOCK = "native_render_block"

const val DEFAULT_COMPONENT_ID = "home"
const val DEFAULT_BFF_BASE_URL = "https://journeys-bff-dev-api-twucozrzia-uc.a.run.app/"

fun resolveEntry(
    componentId: String?,
    flowId: String?,
    defaultComponentId: String,
): String {
    if (!componentId.isNullOrBlank()) return componentId
    if (!flowId.isNullOrBlank()) return flowId
    return defaultComponentId
}
