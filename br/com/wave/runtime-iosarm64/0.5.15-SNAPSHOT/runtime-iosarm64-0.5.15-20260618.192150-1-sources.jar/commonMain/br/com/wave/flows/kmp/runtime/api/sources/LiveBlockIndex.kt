package br.com.wave.flows.kmp.runtime.api.sources

import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.ScreenContract
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/**
 * Process-wide index that maps any block id seen by the parser to a
 * synthetic [ScreenContract] rooted at that block.
 *
 * Populated as a side effect of contracts entering the resolver chain
 * (network, disk). Lets the host ask `RenderBlock(componentId = X)` for a
 * block that is **already on screen** (e.g. an in-tree bottom-sheet
 * wrapper) and have it resolved in-memory, without round-tripping the BFF
 * for an endpoint that does not exist.
 *
 * Scope: keyed by `(baseUrl, externalCode, blockId)`. Cleared per session
 * by [BffScreenContractProvider.clearCache] just like the contract cache.
 */
internal object LiveBlockIndex {

    internal data class IndexKey(
        val baseUrl: String,
        val externalCode: String,
        val blockId: String,
    )

    private val entries = MutableStateFlow<Map<IndexKey, ScreenContract>>(emptyMap())

    fun get(query: ContractQuery): ScreenContract? =
        entries.value[IndexKey(query.baseUrl, query.externalCode, query.componentId)]

    /**
     * Walk [contract]'s tree and register every node with a non-blank id
     * under the session keyed by [contractQuery]. Each entry exposes the
     * node as the root of a synthetic [ScreenContract] so the renderer
     * can consume it through the same code path as a top-level fetch.
     */
    fun register(contractQuery: ContractQuery, contract: ScreenContract) {
        val newEntries = mutableMapOf<IndexKey, ScreenContract>()
        walk(contract.root) { node ->
            val key = IndexKey(contractQuery.baseUrl, contractQuery.externalCode, node.id)
            newEntries[key] = ScreenContract(
                id = node.id,
                type = "synthetic-block",
                root = node,
            )
        }
        if (newEntries.isEmpty()) return
        entries.update { current -> current + newEntries }
    }

    fun clearSession(baseUrl: String, externalCode: String) {
        entries.update { current ->
            current.filterKeys { it.baseUrl != baseUrl || it.externalCode != externalCode }
        }
    }

    fun clearAll() {
        entries.value = emptyMap()
    }

    private fun walk(node: BlockNode, visit: (BlockNode) -> Unit) {
        if (node.id.isNotBlank()) visit(node)
        node.children.forEach { walk(it, visit) }
    }
}

/**
 * [ContractSource] that delegates to the in-process [LiveBlockIndex].
 *
 * Sits at the very top of the resolver chain. Synchronous and side
 * effect–free, so it participates in `peekCachedScreenContract`'s sync
 * path without any I/O.
 */
internal class LiveBlockIndexSource : ContractSource {
    override suspend fun tryGet(query: ContractQuery): ScreenContract? = LiveBlockIndex.get(query)
    override fun trySync(query: ContractQuery): ScreenContract? = LiveBlockIndex.get(query)
}
