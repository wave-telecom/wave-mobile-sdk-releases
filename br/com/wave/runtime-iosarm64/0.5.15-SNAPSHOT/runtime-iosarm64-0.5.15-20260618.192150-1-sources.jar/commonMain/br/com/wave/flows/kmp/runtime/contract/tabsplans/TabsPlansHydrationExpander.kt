package br.com.wave.flows.kmp.runtime.contract.tabsplans

import br.com.wave.flows.kmp.runtime.contract.dto.block.BlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BottomSheetBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.BottomSheetBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ButtonBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ButtonBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CardBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.CardBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ChartDataPointDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.DividerBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.DividerBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ListBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.ListBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabOptionDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansCategoryDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansExtrasDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansGroupDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansPlanDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TabsPlansUsageDataPointDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TextBlockConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.block.TextBlockDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.ActionDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.ReferenceIdActionConfigDto
import br.com.wave.flows.kmp.runtime.contract.dto.action.ShowActionDto
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlin.math.round

internal class TabsPlansHydrationExpander : TabsPlansBlockExpander {
    override fun supports(block: TabsPlansBlockDto): Boolean {
        return block.type == "tabs-plans"
    }

    override fun expand(block: TabsPlansBlockDto, reporter: ContractAnomalyReporter): BlockDto {
        val groups = block.config?.data.orEmpty()
        return ListBlockDto(
            id = block.id ?: "consumo-section",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 16,
                orientation = "vertical",
                visibility = block.config?.visibility,
            ),
            children = groups.flatMapIndexed { groupIndex, group -> buildGroup(groupIndex, group, block.action) },
            action = null,
        )
    }

    private fun buildGroup(
        groupIndex: Int,
        group: TabsPlansGroupDto,
        getMoreDataAction: ActionDto?,
    ): List<BlockDto> {
        val groupId = "tabs-plans-group-$groupIndex"
        val options = group.options.orEmpty()
        val categories = group.categories.orEmpty()
        val children = mutableListOf<BlockDto>()

        children += TextBlockDto(
            id = "$groupId-title",
            type = "text",
            config = TextBlockConfigDto(
                align = "center",
                color = "#222222",
                value = group.title.orEmpty(),
                fontSize = 24,
                fontFamily = FONT_FAMILY,
                fontWeight = 600,
                marginBottom = 16,
            ),
        )

        if (options.size > 1) {
            children += TabsBlockDto(
                id = "$groupId-tabs",
                type = "tabs",
                config = TabsBlockConfigDto(
                    gap = 12,
                    activeColor = "#FFFFFF",
                    activeBackgroundColor = "#0071D1",
                    inactiveColor = "#0071D1",
                    inactiveBackgroundColor = "#FFFFFF",
                    fontSize = 14,
                    fontFamily = FONT_FAMILY,
                    fontWeight = 600,
                    options = options.mapIndexed { optionIndex, option ->
                        val value = option.value ?: "tab-$groupIndex-$optionIndex"
                        TabOptionDto(
                            id = value,
                            label = option.label ?: value,
                            contentReferenceId = value,
                        )
                    },
                ),
            )
        }

        val categoryBlocks = categories.mapIndexed { categoryIndex, category ->
            buildCategory(groupIndex, categoryIndex, category, getMoreDataAction)
        }

        children += ListBlockDto(
            id = "$groupId-categories",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 16,
                orientation = "vertical",
            ),
            children = categoryBlocks,
        )

        return listOf(
            ListBlockDto(
                id = groupId,
                type = "list",
                config = ListBlockConfigDto(
                    spacing = 16,
                    orientation = "vertical",
                    marginBottom = 24,
                ),
                children = children,
            ),
        )
    }

    private fun buildCategory(
        groupIndex: Int,
        categoryIndex: Int,
        category: TabsPlansCategoryDto,
        getMoreDataAction: ActionDto?,
    ): BlockDto {
        val categoryId = category.referenceId ?: "tabs-plans-group-$groupIndex-category-$categoryIndex"
        val plans = category.plans.orEmpty()
        return ListBlockDto(
            id = categoryId,
            type = "list",
            config = ListBlockConfigDto(
                spacing = 16,
                orientation = "vertical",
            ),
            children = plans.mapIndexed { planIndex, plan ->
                buildPlanCard(
                    idPrefix = "$categoryId-plan-$planIndex",
                    plan = plan,
                    getMoreDataAction = getMoreDataAction,
                )
            },
        )
    }

    private fun buildPlanCard(
        idPrefix: String,
        plan: TabsPlansPlanDto,
        getMoreDataAction: ActionDto?,
    ): BlockDto {
        val bottomSheetId = "$idPrefix-details-bottom-sheet"
        val contentChildren = mutableListOf<BlockDto>()
        contentChildren += TextBlockDto(
            id = "$idPrefix-name",
            type = "text",
            config = TextBlockConfigDto(
                color = "#222222",
                value = plan.name.orEmpty(),
                fontSize = 20,
                fontFamily = FONT_FAMILY,
                fontWeight = 600,
                marginBottom = 4,
            ),
        )

        if (plan.unlimited == true) {
            contentChildren += buildUnlimitedPlanContent(idPrefix, plan)
        } else {
            contentChildren += buildLimitedPlanContent(idPrefix, plan, bottomSheetId)
        }

        if (plan.showGetMoreData == true) {
            contentChildren += ListBlockDto(
                id = "$idPrefix-get-more-data-wrapper",
                type = "list",
                config = ListBlockConfigDto(
                    orientation = "vertical",
                    horizontalAlign = "center",
                    marginTop = 16,
                ),
                children = listOf(
                    ButtonBlockDto(
                        id = "$idPrefix-get-more-data",
                        type = "button",
                        action = getMoreDataAction,
                        config = ButtonBlockConfigDto(
                            color = "#FFFFFF",
                            value = "Quiero más datos",
                            padding = 48,
                            fontSize = 16,
                            fontWeight = 600,
                            paddingTop = 8,
                            paddingBottom = 8,
                            borderRadius = 28,
                            backgroundColor = "#7B1FA2",
                        ),
                    ),
                ),
            )
        }

        val blocks = mutableListOf<BlockDto>()
        blocks += CardBlockDto(
            id = "$idPrefix-card",
            type = "card",
            config = CardBlockConfigDto(
                padding = 16,
                paddingLeft = 12,
                paddingRight = 12,
                borderRadius = 16,
                backgroundColor = "#FFFFFF",
            ),
            children = listOf(
                ListBlockDto(
                    id = "$idPrefix-card-content",
                    type = "list",
                    config = ListBlockConfigDto(
                        spacing = 8,
                        orientation = "vertical",
                        horizontalAlign = "center",
                    ),
                    children = contentChildren,
                ),
            ),
        )
        if (plan.unlimited != true) {
            blocks += buildPlanDetailsBottomSheet(bottomSheetId, plan)
        }

        return ListBlockDto(
            id = idPrefix,
            type = "list",
            config = ListBlockConfigDto(
                spacing = 0,
                orientation = "vertical",
            ),
            children = blocks,
        )
    }

    private fun buildLimitedPlanContent(
        idPrefix: String,
        plan: TabsPlansPlanDto,
        bottomSheetId: String,
    ): BlockDto {
        val totalData = formatDataAmount(plan.totalData ?: 0)
        val usedData = formatDataAmount(plan.usedData ?: 0)
        val availableData = formatDataAmount(plan.availableData ?: 0)
        val showDetailsButton = DETAILS_CATEGORIES.contains(plan.category.orEmpty().trim().uppercase())
        val children = mutableListOf<BlockDto>()

        if (showDetailsButton) {
            children += ListBlockDto(
                id = "$idPrefix-details-action-wrapper",
                type = "list",
                config = ListBlockConfigDto(
                    orientation = "vertical",
                    horizontalAlign = "center",
                ),
                children = listOf(
                    ButtonBlockDto(
                        id = "$idPrefix-details-action",
                        type = "button",
                        action = buildShowAction(bottomSheetId),
                        config = ButtonBlockConfigDto(
                            color = "#1E88E5",
                            value = "Mostrar detalles",
                            fontSize = 16,
                            fontWeight = 600,
                            borderRadius = 0,
                            backgroundColor = "transparent",
                        ),
                    ),
                ),
            )
        }

        children += ListBlockDto(
            id = "$idPrefix-usage-summary",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 108,
                orientation = "horizontal",
                horizontalAlign = "space-between",
                verticalAlign = "center",
            ),
            children = listOf(
                buildDataAmountPair("$idPrefix-included", "Incluidos", totalData, "#222222"),
                buildDataAmountPair("$idPrefix-used", "Usados", usedData, "#222222"),
            ),
        )

        children += ListBlockDto(
            id = "$idPrefix-chart-section",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 8,
                orientation = "vertical",
                verticalAlign = "center",
                horizontalAlign = "center",
            ),
            children = listOf(
                ChartBlockDto(
                    id = "$idPrefix-chart",
                    type = "chart",
                    config = ChartBlockConfigDto(
                        type = "semi-circle",
                        size = 220,
                        data = plan.usageData.orEmpty().map { point ->
                            ChartDataPointDto(
                                key = point.key,
                                fill = point.fill,
                                value = point.value,
                            )
                        },
                    ),
                    children = listOf(
                        ListBlockDto(
                            id = "$idPrefix-available-wrapper",
                            type = "list",
                            config = ListBlockConfigDto(
                                spacing = 2,
                                orientation = "vertical",
                                marginBottom = 8,
                                verticalAlign = "center",
                                horizontalAlign = "center",
                            ),
                            children = listOf(
                                TextBlockDto(
                                    id = "$idPrefix-available-label",
                                    type = "text",
                                    config = TextBlockConfigDto(
                                        color = "#757575",
                                        value = "Te quedan",
                                        fontSize = 16,
                                        fontFamily = FONT_FAMILY,
                                        fontWeight = 400,
                                    ),
                                ),
                                buildInlineAmount("$idPrefix-available", availableData, "#00529B"),
                            ),
                        ),
                    ),
                ),
                buildCutoffMessage("$idPrefix-cutoff", plan),
            ),
        )

        return ListBlockDto(
            id = "$idPrefix-limited-content",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 16,
                orientation = "vertical",
            ),
            children = children,
        )
    }

    private fun buildUnlimitedPlanContent(
        idPrefix: String,
        plan: TabsPlansPlanDto,
    ): BlockDto {
        val children = mutableListOf<BlockDto>()
        children += TextBlockDto(
            id = "$idPrefix-unlimited-label",
            type = "text",
            config = TextBlockConfigDto(
                color = "#00529B",
                value = "Ilimitados",
                fontSize = 32,
                fontFamily = FONT_FAMILY,
                fontWeight = 600,
                visibility = true,
            ),
        )

        val period = plan.period
        if (!period.isNullOrBlank()) {
            children += ListBlockDto(
                id = "$idPrefix-period-wrapper",
                type = "list",
                config = ListBlockConfigDto(
                    spacing = 4,
                    orientation = "horizontal",
                    horizontalAlign = "center",
                ),
                children = listOf(
                    TextBlockDto(
                        id = "$idPrefix-period",
                        type = "text",
                        config = TextBlockConfigDto(
                            color = "#757575",
                            value = period,
                            fontSize = 16,
                            fontFamily = FONT_FAMILY,
                            fontWeight = 400,
                            visibility = true,
                        ),
                    ),
                ),
            )
        }

        if (plan.usedData != null && plan.name != "Noches Sin Límite") {
            children += ListBlockDto(
                id = "$idPrefix-unlimited-used-wrapper",
                type = "list",
                config = ListBlockConfigDto(
                    spacing = 4,
                    orientation = "vertical",
                    horizontalAlign = "center",
                ),
                children = listOf(
                    TextBlockDto(
                        id = "$idPrefix-unlimited-used-label",
                        type = "text",
                        config = TextBlockConfigDto(
                            color = "#757575",
                            value = "Has usado:",
                            fontSize = 16,
                            fontFamily = FONT_FAMILY,
                            fontWeight = 400,
                            visibility = true,
                        ),
                    ),
                    TextBlockDto(
                        id = "$idPrefix-unlimited-used-value",
                        type = "text",
                        config = TextBlockConfigDto(
                            color = "#222222",
                            value = formatDataLabel(formatDataAmount(plan.usedData)),
                            fontSize = 16,
                            fontFamily = FONT_FAMILY,
                            fontWeight = 600,
                            visibility = true,
                        ),
                    ),
                ),
            )
        }
        children += buildCutoffMessage("$idPrefix-cutoff", plan)

        return ListBlockDto(
            id = "$idPrefix-unlimited-content",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 8,
                orientation = "vertical",
                horizontalAlign = "center",
                margin = 8,
            ),
            children = children,
        )
    }

    private fun buildDataAmountPair(
        idPrefix: String,
        label: String,
        amount: FormattedDataAmount,
        color: String,
    ): BlockDto {
        return ListBlockDto(
            id = "$idPrefix-wrapper",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 4,
                orientation = "vertical",
                horizontalAlign = "center",
            ),
            children = listOf(
                TextBlockDto(
                    id = "$idPrefix-label",
                    type = "text",
                    config = TextBlockConfigDto(
                        color = "#757575",
                        value = label,
                        fontSize = 16,
                        fontFamily = FONT_FAMILY,
                        fontWeight = 400,
                    ),
                ),
                buildInlineAmount(idPrefix, amount, color),
            ),
        )
    }

    private fun buildInlineAmount(
        idPrefix: String,
        amount: FormattedDataAmount,
        color: String,
    ): BlockDto {
        return ListBlockDto(
            id = "$idPrefix-value-wrapper",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 2,
                orientation = "horizontal",
                horizontalAlign = "center",
                verticalAlign = "baseline",
            ),
            children = listOf(
                TextBlockDto(
                    id = "$idPrefix-value",
                    type = "text",
                    config = TextBlockConfigDto(
                        color = color,
                        value = amount.value,
                        fontSize = 28,
                        fontFamily = FONT_FAMILY,
                        fontWeight = 600,
                    ),
                ),
                TextBlockDto(
                    id = "$idPrefix-unit",
                    type = "text",
                    config = TextBlockConfigDto(
                        color = color,
                        value = amount.unit,
                        fontSize = 28,
                        fontFamily = FONT_FAMILY,
                        fontWeight = 600,
                    ),
                ),
            ),
        )
    }

    private fun buildCutoffMessage(idPrefix: String, plan: TabsPlansPlanDto): BlockDto {
        return ListBlockDto(
            id = "$idPrefix-wrapper",
            type = "list",
            config = ListBlockConfigDto(
                spacing = 4,
                orientation = "horizontal",
                horizontalAlign = "center",
            ),
            children = listOf(
                TextBlockDto(
                    id = idPrefix,
                    type = "text",
                    config = TextBlockConfigDto(
                        color = "#757575",
                        value = flattenCutoffMessage(plan),
                        fontSize = 13,
                        fontFamily = FONT_FAMILY,
                        fontWeight = 400,
                    ),
                ),
            ),
        )
    }

    private fun buildPlanDetailsBottomSheet(id: String, plan: TabsPlansPlanDto): BlockDto {
        val detailItems = buildPlanDetailItems(plan)
        val detailRows = detailItems.mapIndexed { index, item ->
            ListBlockDto(
                id = "$id-row-$index-${item.id}",
                type = "list",
                config = ListBlockConfigDto(
                    spacing = 24,
                    orientation = "horizontal",
                    verticalAlign = "top",
                ),
                children = listOf(
                    TextBlockDto(
                        id = "$id-row-$index-label",
                        type = "text",
                        config = TextBlockConfigDto(
                            color = "#4A4A4A",
                            value = "${item.label}:",
                            width = 132,
                            fontSize = 14,
                            fontFamily = FONT_FAMILY,
                            fontWeight = 400,
                        ),
                    ),
                    TextBlockDto(
                        id = "$id-row-$index-value",
                        type = "text",
                        config = TextBlockConfigDto(
                            color = "#222222",
                            value = item.value,
                            fontSize = 14,
                            fontFamily = FONT_FAMILY,
                            fontWeight = 700,
                        ),
                    ),
                ),
            )
        }
        val footnoteRows = listOf(1, 2).map { footnote ->
            TextBlockDto(
                id = "$id-footnote-$footnote",
                type = "text",
                config = TextBlockConfigDto(
                    color = "#757575",
                    value = "${FOOTNOTE_MARKS[footnote]}${FOOTNOTE_TEXT[footnote]}",
                    fontSize = 12,
                    fontFamily = FONT_FAMILY,
                    fontWeight = 400,
                ),
            )
        }

        return BottomSheetBlockDto(
            id = id,
            type = "bottom-sheet",
            config = BottomSheetBlockConfigDto(
                visibility = false,
                backgroundColor = "#FFFFFF",
            ),
            children = listOf(
                ListBlockDto(
                    id = "$id-content",
                    type = "list",
                    config = ListBlockConfigDto(
                        spacing = 20,
                        orientation = "vertical",
                    ),
                    children = listOf(
                        TextBlockDto(
                            id = "$id-title",
                            type = "text",
                            config = TextBlockConfigDto(
                                align = "center",
                                color = "#00529B",
                                value = plan.name.orEmpty(),
                                fontSize = 18,
                                fontFamily = FONT_FAMILY,
                                fontWeight = 700,
                            ),
                        ),
                        DividerBlockDto(
                            id = "$id-divider",
                            type = "divider",
                            config = DividerBlockConfigDto(
                                color = "#D9D9D9",
                                orientation = "horizontal",
                            ),
                        ),
                        ListBlockDto(
                            id = "$id-details",
                            type = "list",
                            config = ListBlockConfigDto(
                                spacing = 16,
                                orientation = "vertical",
                            ),
                            children = detailRows,
                        ),
                        ListBlockDto(
                            id = "$id-footnotes",
                            type = "list",
                            config = ListBlockConfigDto(
                                spacing = 4,
                                orientation = "vertical",
                            ),
                            children = footnoteRows,
                        ),
                    ),
                ),
            ),
        )
    }

    private fun buildPlanDetailItems(plan: TabsPlansPlanDto): List<PlanDetailItem> {
        val items = mutableListOf<PlanDetailItem>()
        formatPlanCutoffDate(plan)?.let {
            items += PlanDetailItem("cutoffDate", "Fecha de corte", it, emptyList())
        }
        items += buildSocialDetailItem(plan)
        items += buildWhatsAppDetailItem(plan)
        items += buildCallsAndSmsDetailItem(plan)
        buildIncludedServicesDetailItem(plan)?.let(items::add)
        return items
    }

    private fun buildSocialDetailItem(plan: TabsPlansPlanDto): PlanDetailItem {
        val value = getSocialExtrasValue(plan.extras ?: plan.extra)
        if (value == "No incluido") return PlanDetailItem("social", "Redes sociales", value, emptyList())
        val footnote = getServiceFootnote(plan, "social")
        return PlanDetailItem("social", withFootnote("Redes sociales", footnote), value, listOf(footnote))
    }

    private fun buildWhatsAppDetailItem(plan: TabsPlansPlanDto): PlanDetailItem {
        val value = getWhatsAppValue(plan.extras ?: plan.extra)
        if (value == "No incluido") return PlanDetailItem("whatsapp", "WhatsApp", value, emptyList())
        val footnote = getServiceFootnote(plan, "whatsapp")
        return PlanDetailItem("whatsapp", withFootnote("WhatsApp", footnote), value, listOf(footnote))
    }

    private fun buildCallsAndSmsDetailItem(plan: TabsPlansPlanDto): PlanDetailItem {
        val extras = plan.extras ?: plan.extra
        val hasCalls = extras?.calls ?: true
        val hasSms = extras?.sms ?: true
        if (!hasCalls && !hasSms) return PlanDetailItem("callsAndSms", "Minutos y SMS", "No incluido", emptyList())
        if (hasCalls && hasSms) {
            val voiceFootnote = getServiceFootnote(plan, "voice")
            val smsFootnote = getServiceFootnote(plan, "sms")
            if (voiceFootnote == smsFootnote) {
                return PlanDetailItem("callsAndSms", withFootnote("Minutos y SMS", voiceFootnote), "Ilimitados", listOf(voiceFootnote))
            }
            return PlanDetailItem(
                "callsAndSms",
                "Minutos${FOOTNOTE_MARKS[voiceFootnote]} y SMS${FOOTNOTE_MARKS[smsFootnote]}",
                "Ilimitados",
                listOf(voiceFootnote, smsFootnote).distinct().sorted(),
            )
        }
        if (hasCalls) {
            val voiceFootnote = getServiceFootnote(plan, "voice")
            return PlanDetailItem("callsAndSms", withFootnote("Minutos", voiceFootnote), "Ilimitados", listOf(voiceFootnote))
        }
        val smsFootnote = getServiceFootnote(plan, "sms")
        return PlanDetailItem("callsAndSms", withFootnote("SMS", smsFootnote), "Ilimitados", listOf(smsFootnote))
    }

    private fun buildIncludedServicesDetailItem(plan: TabsPlansPlanDto): PlanDetailItem? {
        val included = plan.includedServices.orEmpty()
        if (included.isEmpty()) return null
        return PlanDetailItem("includedServices", "Benefícios", included.joinToString("\n"), emptyList())
    }

    private fun getSocialExtrasValue(extras: TabsPlansExtrasDto?): String {
        if (extras == null) return "Facebook, X, Snapchat y Instagram ilimitados"
        val labels = listOfNotNull(
            "Facebook".takeIf { extras.facebook == true },
            "Messenger".takeIf { extras.messenger == true },
            "X".takeIf { extras.x == true },
            "Snapchat".takeIf { extras.snapchat == true },
            "Instagram".takeIf { extras.instagram == true },
        )
        if (labels.isEmpty()) return "No incluido"
        return "${formatLabelList(labels)} ${if (labels.size == 1) "ilimitado" else "ilimitados"}"
    }

    private fun getWhatsAppValue(extras: TabsPlansExtrasDto?): String {
        if (extras == null) return "Ilimitado"
        return if (extras.whatsapp == true) "Ilimitado" else "No incluido"
    }

    private fun getServiceFootnote(plan: TabsPlansPlanDto, service: String): Int {
        val enabled = when (service) {
            "sms" -> plan.borderlessServices?.sms
            "data" -> plan.borderlessServices?.data
            "voice" -> plan.borderlessServices?.voice
            "whatsapp" -> plan.borderlessServices?.whatsapp
            "social" -> plan.borderlessServices?.social
            else -> null
        }
        return if (enabled == true) 1 else 2
    }

    private fun withFootnote(label: String, footnote: Int?): String {
        if (footnote == null) return label
        return "$label${FOOTNOTE_MARKS[footnote]}"
    }

    private fun formatLabelList(labels: List<String>): String {
        return when (labels.size) {
            0 -> ""
            1 -> labels[0]
            2 -> "${labels[0]} y ${labels[1]}"
            else -> "${labels.dropLast(1).joinToString(", ")} y ${labels.last()}"
        }
    }

    private fun flattenCutoffMessage(plan: TabsPlansPlanDto): String {
        val msg = plan.cutoffMessage ?: return ""
        return when (msg) {
            is JsonPrimitive -> msg.contentOrNull.orEmpty()
            is JsonArray -> msg.joinToString(separator = "") { item ->
                runCatching { item.jsonObject["text"]?.jsonPrimitive?.contentOrNull.orEmpty() }.getOrDefault("")
            }
            else -> msg.toString()
        }
    }

    private fun formatPlanCutoffDate(plan: TabsPlansPlanDto): String? {
        val value = plan.endDate?.trim().orEmpty()
        if (value.isBlank()) return null
        val parts = Regex("^(\\d{4})-(\\d{2})-(\\d{2})").find(value)?.groupValues
        if (parts == null || parts.size < 4) return value
        val day = parts[3]
        val month = MONTHS_ES[parts[2]] ?: return value
        return "$day de $month"
    }

    private fun formatDataAmount(kb: Int): FormattedDataAmount {
        if (kb <= 0) return FormattedDataAmount("0", "MB")
        val bytes = kb.toLong() * 1024L
        val mb = 1024.0 * 1024.0
        val gb = 1024.0 * 1024.0 * 1024.0
        return if (bytes >= gb) {
            FormattedDataAmount(trimTrailingZeros((round((bytes / gb) * 10.0) / 10.0).toString()), "GB")
        } else {
            FormattedDataAmount(trimTrailingZeros((round((bytes / mb) * 10.0) / 10.0).toString()), "MB")
        }
    }

    private fun formatDataLabel(amount: FormattedDataAmount): String = "${amount.value} ${amount.unit}"

    private fun trimTrailingZeros(value: String): String {
        return value
            .replace(Regex("\\.0+$"), "")
            .replace(Regex("(\\.\\d*[1-9])0+$"), "$1")
    }

    private fun buildShowAction(referenceId: String): ActionDto {
        return ShowActionDto(
            type = "click",
            onAction = "show",
            config = ReferenceIdActionConfigDto(referenceId = referenceId),
        )
    }

    private data class FormattedDataAmount(val value: String, val unit: String)
    private data class PlanDetailItem(val id: String, val label: String, val value: String, val footnotes: List<Int>)

    private companion object {
        const val TEMPLATE_ID = "home.consumption.tabs"
        const val FONT_FAMILY = "Telceltype"
        val DETAILS_CATEGORIES = setOf(
            "AMIGO SIN LÍMITE",
            "INTERNET AMIGO",
            "MÁS DATOS",
            "MÁS DATOS PARA TU CASA",
            "VIAJERO INTERNET",
            "VIAJERO WHATSAPP",
        )
        val FOOTNOTE_MARKS = mapOf(1 to "¹", 2 to "²")
        val FOOTNOTE_TEXT = mapOf(
            1 to "Beneficios Sin Frontera (México, E.U.A. y Canadá)",
            2 to "Beneficios dentro de México",
        )
        val MONTHS_ES = mapOf(
            "01" to "enero",
            "02" to "febrero",
            "03" to "marzo",
            "04" to "abril",
            "05" to "mayo",
            "06" to "junio",
            "07" to "julio",
            "08" to "agosto",
            "09" to "septiembre",
            "10" to "octubre",
            "11" to "noviembre",
            "12" to "diciembre",
        )
    }
}
