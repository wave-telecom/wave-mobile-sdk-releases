package br.com.wave.flows.kmp.runtime.api

import br.com.wave.flows.kmp.core.contract.ScreenContract
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

internal object BffScreenContractCache {
    private data class CacheKey(
        val baseUrl: String,
        val externalCode: String,
        val componentId: String,
        val mode: String,
    )

    private val cache = MutableStateFlow<Map<CacheKey, ScreenContract>>(emptyMap())

    fun get(
        baseUrl: String,
        externalCode: String,
        componentId: String,
        mode: String = "full",
    ): ScreenContract? {
        return cache.value[CacheKey(normalizeBaseUrl(baseUrl), externalCode, componentId, mode)]
    }

    fun put(
        baseUrl: String,
        externalCode: String,
        componentId: String,
        contract: ScreenContract,
        mode: String = "full",
    ) {
        val key = CacheKey(normalizeBaseUrl(baseUrl), externalCode, componentId, mode)
        cache.update { current ->
            current + (key to contract)
        }
    }

    fun clearSession(
        baseUrl: String,
        externalCode: String,
    ) {
        val normalizedBaseUrl = normalizeBaseUrl(baseUrl)
        cache.update { current ->
            current.filterKeys { key ->
                key.baseUrl != normalizedBaseUrl || key.externalCode != externalCode
            }
        }
    }

    fun clearAll() {
        cache.value = emptyMap()
    }

    /**
     * Drops a single entry from the in-memory cache. Surgical refresh
     * helper: callers can invalidate a specific component for a specific
     * mode (e.g. only `full`) while leaving the rest of the cache —
     * including the same component's `skeleton` entry — intact.
     */
    fun remove(
        baseUrl: String,
        externalCode: String,
        componentId: String,
        mode: String,
    ) {
        val key = CacheKey(normalizeBaseUrl(baseUrl), externalCode, componentId, mode)
        cache.update { current -> current - key }
    }

    private fun normalizeBaseUrl(baseUrl: String): String {
        return baseUrl.trimEnd('/')
    }
}

object RenderBlockInteractionCache {
    private data class SelectionKey(
        val routeId: String,
        val blockId: String,
        val slot: String,
    )

    private data class ToggleKey(
        val routeId: String,
        val blockId: String,
        val slot: String,
    )

    private val selections = MutableStateFlow<Map<SelectionKey, String>>(emptyMap())
    private val toggles = MutableStateFlow<Map<ToggleKey, Boolean>>(emptyMap())
    private val visibilityByRoute = MutableStateFlow<Map<String, Map<String, Boolean>>>(emptyMap())

    fun getSelection(
        routeId: String,
        blockId: String,
        slot: String = "selection",
    ): String? = selections.value[SelectionKey(routeId = routeId, blockId = blockId, slot = slot)]

    fun putSelection(
        routeId: String,
        blockId: String,
        value: String,
        slot: String = "selection",
    ) {
        val key = SelectionKey(routeId = routeId, blockId = blockId, slot = slot)
        selections.update { current -> current + (key to value) }
    }

    fun getToggle(
        routeId: String,
        blockId: String,
        slot: String = "toggle",
    ): Boolean? = toggles.value[ToggleKey(routeId = routeId, blockId = blockId, slot = slot)]

    fun putToggle(
        routeId: String,
        blockId: String,
        value: Boolean,
        slot: String = "toggle",
    ) {
        val key = ToggleKey(routeId = routeId, blockId = blockId, slot = slot)
        toggles.update { current -> current + (key to value) }
    }

    fun getVisibility(routeId: String): Map<String, Boolean>? = visibilityByRoute.value[routeId]

    fun putVisibility(
        routeId: String,
        visibility: Map<String, Boolean>,
    ) {
        visibilityByRoute.update { current -> current + (routeId to visibility) }
    }

    fun clearAll() {
        selections.value = emptyMap()
        toggles.value = emptyMap()
        visibilityByRoute.value = emptyMap()
    }
}

fun clearBffScreenContractCache() {
    BffScreenContractCache.clearAll()
    RenderBlockInteractionCache.clearAll()
    br.com.wave.flows.kmp.runtime.api.sources.LiveBlockIndex.clearAll()
}
