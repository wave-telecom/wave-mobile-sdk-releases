package br.com.wave.flows.kmp.runtime.contract.mapping.support

object NoOpContractAnomalyReporter : ContractAnomalyReporter

object NoOpAnomalyReporter : ContractAnomalyReporter by NoOpContractAnomalyReporter
