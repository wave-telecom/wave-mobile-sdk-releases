package br.com.wave.flows.kmp.runtime.api.init

internal data class InitEntryDto(
    val slug: String = "",
    val type: String = "",
)
