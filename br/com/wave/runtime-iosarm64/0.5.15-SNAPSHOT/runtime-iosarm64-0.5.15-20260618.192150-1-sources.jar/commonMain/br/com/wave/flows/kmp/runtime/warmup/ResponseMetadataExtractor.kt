package br.com.wave.flows.kmp.runtime.warmup

import kotlin.time.Clock
import kotlin.time.Instant
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.jsonObject

internal object ResponseMetadataExtractor {
    private const val SECONDS_TO_MS = 1000L
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    fun extractExpiresInMs(json: String): Long? {
        return try {
            val root = this.json.parseToJsonElement(json).jsonObject
            val cache = root["meta"]?.jsonObject?.get("cache")?.jsonObject ?: return null
            val expiresIn = cache["expiresIn"] ?: return null

            when (expiresIn) {
                is JsonPrimitive -> {
                    expiresIn.longOrNull?.takeIf { it > 0 }?.let { it * SECONDS_TO_MS }
                        ?: expiresIn.contentOrNull?.let(::parseIsoToTtl)
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseIsoToTtl(iso: String): Long? {
        return try {
            val epochMs = Instant.parse(iso).toEpochMilliseconds()
            val ttl = epochMs - Clock.System.now().toEpochMilliseconds()
            if (ttl > 0) ttl else null
        } catch (e: Exception) {
            null
        }
    }
}
