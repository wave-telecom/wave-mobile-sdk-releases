package br.com.wave.flows.kmp.runtime.contract.dto

import br.com.wave.flows.kmp.runtime.contract.dto.block.BlockDto
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

@Serializable
internal data class ScreenContractDto(
    val id: String? = null,
    val type: String? = null,
    val name: String? = null,
    val blocks: BlockDto? = null,
    val root: BlockDto? = null,
    val meta: MetaDto? = null,
    /**
     * Optional theme contract delivered alongside the screen — sibling of
     * `blocks`/`meta`. Kept as a raw [JsonElement] here so the runtime can
     * lean on `ThemeParser` to turn it into a typed
     * [br.com.wave.flows.kmp.core.theme.FlowThemeCatalog] without
     * complicating this envelope.
     */
    val theme: JsonElement? = null,
) {
    fun primaryRootBlockOrNull(): BlockDto? = blocks ?: root
}

@Serializable
internal data class MetaDto(
    val expiresIn: String? = null,
)
