package br.com.wave.flows.kmp.runtime.api

data class ApiResponse<T>(
    val code: Int,
    val body: T?,
) {
    val isSuccessful: Boolean
        get() = code in 200..299
}
