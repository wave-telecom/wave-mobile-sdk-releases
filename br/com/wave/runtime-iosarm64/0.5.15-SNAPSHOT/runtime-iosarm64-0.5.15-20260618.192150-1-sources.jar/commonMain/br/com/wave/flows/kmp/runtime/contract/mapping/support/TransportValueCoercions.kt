package br.com.wave.flows.kmp.runtime.contract.mapping.support

import br.com.wave.flows.kmp.core.contract.BlockOrientation

/** Transport-level normalization helpers. */
object TransportValueCoercions {

    /**
     * Normalizes a raw string value for case-insensitive enum lookup.
     * Returns the lowercased, trimmed value or null if blank/null.
     */
    fun normalizeEnumValue(rawValue: String?): String? {
        if (rawValue.isNullOrBlank()) return null
        return rawValue.trim().lowercase()
    }
}

internal fun parseOrientationValue(value: String?): BlockOrientation {
    return if (value.equals("horizontal", ignoreCase = true)) {
        BlockOrientation.HORIZONTAL
    } else {
        BlockOrientation.VERTICAL
    }
}
