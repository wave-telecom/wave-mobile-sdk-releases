package br.com.wave.flows.kmp.runtime.api.sources

import br.com.wave.flows.kmp.core.contract.ScreenContract

/**
 * Single lookup unit in the contract-resolution chain.
 *
 * Each source represents one place where a [ScreenContract] might live —
 * in-memory cache, disk warmup cache, BFF, or any future store. A source
 * answers a [ContractQuery] with the contract if it has it, or `null` if
 * it doesn't. Sources MUST NOT throw to signal absence — only to signal
 * unrecoverable errors that should abort the whole chain.
 *
 * The chain is composed externally (see [BffScreenContractProvider]), so
 * each source has a single responsibility and can be added/removed
 * without modifying its peers.
 */
internal interface ContractSource {
    suspend fun tryGet(query: ContractQuery): ScreenContract?

    /**
     * Optional fast-path for sources that can answer without I/O.
     * Default: declines (returns `null`) so the chain falls through to
     * the next sync-capable source.
     */
    fun trySync(query: ContractQuery): ScreenContract? = null
}

internal data class ContractQuery(
    val baseUrl: String,
    val externalCode: String,
    val componentId: String,
    val mode: ContractMode,
)

internal enum class ContractMode(val wireValue: String) {
    FULL("full"),
    SKELETON("skeleton"),
}
