package br.com.wave.flows.kmp.runtime.contract.mapping.support

interface ContractAnomalyReporter {
    fun report(anomaly: ContractAnomaly) {}

    fun reportCoercion(field: String, originalValue: Any?, coercedValue: Any?) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.COERCION,
                parserContext = "transport",
                fieldPath = field,
                rawValue = originalValue,
                coercedValue = coercedValue,
            ),
        )
    }

    fun reportUnknownKey(context: String, key: String) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.UNKNOWN_KEY,
                parserContext = context,
                fieldPath = key,
            ),
        )
    }

    fun reportMalformedField(field: String, rawValue: Any?, recovery: String? = null) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.MALFORMED_FIELD,
                parserContext = "parser",
                fieldPath = field,
                rawValue = rawValue,
                recovery = recovery,
            ),
        )
    }

    fun reportMalformedObject(field: String, rawValue: Any?, recovery: String? = null) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.MALFORMED_OBJECT,
                parserContext = "parser",
                fieldPath = field,
                rawValue = rawValue,
                recovery = recovery,
            ),
        )
    }

    fun reportMalformedValue(field: String, rawValue: Any?) {
        reportMalformedObject(field = field, rawValue = rawValue)
    }

    fun reportUnknownEnumValue(field: String, rawValue: String?, recovery: String? = null) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.UNKNOWN_ENUM,
                parserContext = "parser",
                fieldPath = field,
                rawValue = rawValue,
                recovery = recovery,
            ),
        )
    }

    fun reportFallbackApplied(field: String, rawValue: Any?, recovery: String) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.FALLBACK_APPLIED,
                parserContext = "parser",
                fieldPath = field,
                rawValue = rawValue,
                recovery = recovery,
            ),
        )
    }

    fun reportPrecedenceConflict(
        context: String,
        preferredField: String,
        ignoredField: String,
    ) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.PRECEDENCE_CONFLICT,
                parserContext = context,
                fieldPath = preferredField,
                details = "Ignored $ignoredField because $preferredField takes precedence",
            ),
        )
    }

    fun reportCollectionItemRecovered(field: String, rawValue: Any?, recovery: String) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.COLLECTION_ITEM_RECOVERED,
                parserContext = "parser",
                fieldPath = field,
                rawValue = rawValue,
                recovery = recovery,
            ),
        )
    }

    fun reportCollectionItemDropped(field: String, rawValue: Any?, recovery: String) {
        report(
            ContractAnomaly(
                type = ContractAnomalyType.COLLECTION_ITEM_DROPPED,
                parserContext = "parser",
                fieldPath = field,
                rawValue = rawValue,
                recovery = recovery,
            ),
        )
    }
}
