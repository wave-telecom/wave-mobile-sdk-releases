package br.com.wave.flows.kmp.runtime.api

import io.ktor.client.HttpClient

object BffApiFactory {
    fun create(
        client: HttpClient,
        baseUrl: String,
    ): BffApi {
        return KtorBffApi(
            client = client,
            baseUrl = baseUrl.trimEnd('/'),
        )
    }
}
