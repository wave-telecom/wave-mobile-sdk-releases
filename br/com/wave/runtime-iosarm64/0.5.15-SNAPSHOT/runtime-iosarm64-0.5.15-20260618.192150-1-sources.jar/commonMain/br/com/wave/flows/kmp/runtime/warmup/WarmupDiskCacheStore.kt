package br.com.wave.flows.kmp.runtime.warmup

import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.SystemRuntimeClock
import okio.FileSystem
import okio.Path
import okio.Path.Companion.toPath

class WarmupDiskCacheStore(
    private val cacheDir: Path,
    private val fileSystem: FileSystem = systemFileSystem(),
    private val clock: RuntimeClock = SystemRuntimeClock,
) {

    private fun childPath(name: String): Path {
        return "$cacheDir/$name".toPath()
    }

    fun read(key: WarmupCacheKey): String? {
        return try {
            val file = childPath(key.toFileName())
            val content = fileSystem.read(file) { readUtf8() }
            val newlineIndex = content.indexOf('\n')
            if (newlineIndex < 0) {
                fileSystem.delete(file, mustExist = false)
                return null
            }
            val expiresAt = content.substring(0, newlineIndex).toLongOrNull() ?: run {
                fileSystem.delete(file, mustExist = false)
                return null
            }
            if (clock.nowMillis() > expiresAt) {
                fileSystem.delete(file, mustExist = false)
                return null
            }
            content.substring(newlineIndex + 1)
        } catch (e: Exception) {
            null
        }
    }

    fun write(key: WarmupCacheKey, json: String, ttlMs: Long) {
        try {
            fileSystem.createDirectories(cacheDir)
            val expiresAt = clock.nowMillis() + ttlMs
            val target = childPath(key.toFileName())
            val temp = childPath("${key.toFileName()}.tmp")
            fileSystem.write(temp) {
                writeUtf8("$expiresAt\n$json")
            }
            fileSystem.delete(target, mustExist = false)
            fileSystem.atomicMove(temp, target)
        } catch (e: Exception) {
            try {
                fileSystem.delete(childPath("${key.toFileName()}.tmp"), mustExist = false)
            } catch (_: Exception) {
            }
        }
    }

    fun removeExpired() {
        try {
            fileSystem.list(cacheDir).forEach { file ->
                try {
                    val firstLine = fileSystem.read(file) {
                        readUtf8().lineSequence().firstOrNull()
                    }
                    val expiresAt = firstLine?.toLongOrNull() ?: 0L
                    if (clock.nowMillis() > expiresAt) {
                        fileSystem.delete(file, mustExist = false)
                    }
                } catch (e: Exception) {
                    fileSystem.delete(file, mustExist = false)
                }
            }
        } catch (e: Exception) {
        }
    }
}
