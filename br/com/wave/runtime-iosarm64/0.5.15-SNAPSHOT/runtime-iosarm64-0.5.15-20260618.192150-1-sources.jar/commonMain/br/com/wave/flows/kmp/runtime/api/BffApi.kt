package br.com.wave.flows.kmp.runtime.api

interface BffApi {
    suspend fun getInit(externalCode: String): ApiResponse<String>

    suspend fun getFlowContract(
        flowId: String,
        externalCode: String,
    ): ApiResponse<String>

    suspend fun getFlowContractSkeleton(
        flowId: String,
        externalCode: String,
        mode: String,
    ): ApiResponse<String>

    suspend fun getComponentContract(
        componentId: String,
        externalCode: String,
    ): ApiResponse<String>
}
