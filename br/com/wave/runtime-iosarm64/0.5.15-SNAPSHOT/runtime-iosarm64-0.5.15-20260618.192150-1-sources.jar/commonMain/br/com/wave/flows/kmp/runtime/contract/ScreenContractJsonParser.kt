package br.com.wave.flows.kmp.runtime.contract

import br.com.wave.flows.kmp.core.contract.BlockActionTarget
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.mapping.support.NoOpContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.mapping.support.parseOrientationValue
import br.com.wave.flows.kmp.runtime.contract.parsing.DefaultScreenContractParserBackend
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

private val blockTypeByWireValue = mapOf(
    "button" to BlockType.BUTTON,
    "card" to BlockType.CARD,
    "carousel" to BlockType.CAROUSEL,
    "chart" to BlockType.CHART,
    "container" to BlockType.CONTAINER,
    "divider" to BlockType.DIVIDER,
    "grid" to BlockType.GRID,
    "image" to BlockType.IMAGE,
    "icon" to BlockType.IMAGE,
    "list" to BlockType.LIST,
    "radio-group" to BlockType.RADIO_GROUP,
    "rich-text" to BlockType.RICH_TEXT,
    "skeleton" to BlockType.SKELETON,
    "spacer" to BlockType.SPACER,
    "tabs" to BlockType.TABS,
    "text" to BlockType.TEXT,
    "toolbar" to BlockType.TOOLBAR,
    "bottom-sheet" to BlockType.BOTTOM_SHEET,
    "accordion" to BlockType.ACCORDION,
)

private val actionTargetByWireValue = mapOf(
    "navigate" to BlockActionTarget.NAVIGATE,
    "show" to BlockActionTarget.SHOW,
    "hide" to BlockActionTarget.HIDE,
    "back" to BlockActionTarget.BACK,
    "openurl" to BlockActionTarget.OPEN_URL,
    "refresh" to BlockActionTarget.REFRESH,
    "render_block_navigate" to BlockActionTarget.HOST_DELEGATED,
    "iframenavigation" to BlockActionTarget.HOST_DELEGATED,
    "downloadfile" to BlockActionTarget.HOST_DELEGATED,
    "togglethememode" to BlockActionTarget.TOGGLE_THEME_MODE,
)

fun parseScreenContract(json: String): ScreenContract {
    return parseScreenContract(json, reporter = NoOpContractAnomalyReporter)
}

fun parseScreenContract(
    json: String,
    reporter: ContractAnomalyReporter,
): ScreenContract {
    return DefaultScreenContractParserBackend.parse(json, reporter)
}

fun parseScreenContract(root: JsonObject): ScreenContract {
    return parseScreenContract(root, reporter = NoOpContractAnomalyReporter)
}

fun parseScreenContract(
    root: JsonObject,
    reporter: ContractAnomalyReporter,
): ScreenContract {
    return DefaultScreenContractParserBackend.parse(root, reporter)
}

internal fun parseBlockType(value: String?): BlockType {
    return value?.trim()?.lowercase()?.let(blockTypeByWireValue::get)
        ?: error("Unsupported block type: $value")
}

internal fun parseActionTarget(value: String?): BlockActionTarget {
    return value?.trim()?.lowercase()?.let(actionTargetByWireValue::get)
        ?: error("Unsupported action target: $value")
}

internal fun parseOrientation(value: String?): BlockOrientation {
    return parseOrientationValue(value)
}

internal fun JsonObject.stringOrDefault(name: String, defaultValue: String): String {
    return (this[name] as? JsonPrimitive)?.contentOrNull ?: defaultValue
}
