package br.com.wave.flows.kmp.runtime.contract.mapping.support

enum class ContractAnomalyType {
    COERCION,
    UNKNOWN_KEY,
    MALFORMED_FIELD,
    MALFORMED_OBJECT,
    UNKNOWN_ENUM,
    FALLBACK_APPLIED,
    PRECEDENCE_CONFLICT,
    COLLECTION_ITEM_RECOVERED,
    COLLECTION_ITEM_DROPPED,
}

data class ContractAnomaly(
    val type: ContractAnomalyType,
    val parserContext: String,
    val fieldPath: String? = null,
    val rawValue: Any? = null,
    val coercedValue: Any? = null,
    val recovery: String? = null,
    val details: String? = null,
)
