package br.com.wave.flows.kmp.runtime.contract.theme

import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemePalette
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/**
 * Wire shape (mirrors the web SDK's `ThemeContract`):
 *
 * ```
 * {
 *   "id": "...",
 *   "name": "...",
 *   "variables": {
 *     "default": { ... } | [],
 *     "light":   { "backgrounds": { "white": "#FFF" }, ... },
 *     "dark":    { ... },
 *     "darkula": { ... }            // optional extra scopes
 *   }
 * }
 * ```
 *
 * Each non-`default` scope under `variables` becomes one [ThemePalette].
 * The `default` scope is deep-merged into each as a fallback, so a theme
 * that omits a token inherits the default value.
 *
 * The token tree is flattened with dot-path keys (`backgrounds.white`) and
 * lowercased — the resolver does the same normalization on lookup, so
 * `@{Backgrounds.White}` and `@{backgrounds.white}` both hit the same key.
 *
 * Non-string leaves (numbers, typed `{ value, unit }` tokens used by the web
 * SDK for sizes) are coerced to strings; size tokens are not yet consumed by
 * the KMP renderer — TECH DEBT: handle typed tokens when we wire spacings.
 */
object ThemeParser {

    /** Parse the `theme` JsonObject from a BFF response into a catalog. */
    fun parse(themeJson: JsonObject): FlowThemeCatalog {
        val variables = themeJson["variables"] as? JsonObject ?: return FlowThemeCatalog.empty()

        val defaultScope = flattenScope(variables["default"])

        val palettes = mutableListOf<ThemePalette>()
        for ((scopeName, scopeNode) in variables) {
            if (scopeName.equals("default", ignoreCase = true)) continue
            val scopeTokens = flattenScope(scopeNode)
            val merged = defaultScope + scopeTokens   // scope wins on conflict
            palettes.add(
                ThemePalette(
                    id = ThemeId(scopeName.lowercase()),
                    displayName = scopeName.replaceFirstChar { it.uppercase() },
                    tokens = merged,
                ),
            )
        }
        return runCatching { FlowThemeCatalog.of(palettes) }.getOrElse {
            // Missing light/dark — TECH DEBT: surface to a reporter once we
            // have one wired here. For now fail-soft to keep rendering with
            // literal hex (back-compat).
            FlowThemeCatalog.empty()
        }
    }

    /** Same as [parse] but tolerates the value not being a JsonObject. */
    fun parseElement(element: JsonElement?): FlowThemeCatalog =
        (element as? JsonObject)?.let(::parse) ?: FlowThemeCatalog.empty()

    /** Walks the nested group/token tree and emits `group.token` -> value. */
    private fun flattenScope(node: JsonElement?): Map<String, String> {
        val obj = node as? JsonObject ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        walk(obj, prefix = "", into = out)
        return out
    }

    private fun walk(node: JsonObject, prefix: String, into: MutableMap<String, String>) {
        for ((rawKey, value) in node) {
            val key = ThemePalette.normalizeTokenKey(rawKey)
            val path = if (prefix.isEmpty()) key else "$prefix.$key"
            when (value) {
                is JsonObject -> {
                    // Typed token: { value, unit? } => keep value (units not
                    // applied to colours; size tokens are TECH DEBT).
                    val typedValue = (value["value"] as? JsonPrimitive)?.contentOrNull
                    if (typedValue != null && value.size <= 2) {
                        into[path] = typedValue
                    } else {
                        walk(value, path, into)
                    }
                }
                is JsonPrimitive -> {
                    value.contentOrNull?.let { into[path] = it }
                }
                is JsonArray -> {
                    // Empty array (e.g. "default": []) is a no-op; nothing else
                    // is expected at a leaf so we ignore it silently.
                }
            }
        }
    }
}
