package br.com.wave.flows.kmp.runtime.contract.parsing

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.contract.dto.ScreenContractDto
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.mapping.support.NoOpContractAnomalyReporter
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

internal interface ScreenContractParserBackend {
    fun parse(
        json: String,
        reporter: ContractAnomalyReporter = NoOpContractAnomalyReporter,
    ): ScreenContract

    fun parse(
        root: JsonObject,
        reporter: ContractAnomalyReporter = NoOpContractAnomalyReporter,
    ): ScreenContract
}

internal object DtoScreenContractParserBackend : ScreenContractParserBackend {
    private val contractJson = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    override fun parse(
        json: String,
        reporter: ContractAnomalyReporter,
    ): ScreenContract {
        val root = stripWebVariants(
            normalizeLegacyScreenContractRoot(contractJson.parseToJsonElement(json).jsonObject),
        )
        val dto = contractJson.decodeFromJsonElement(ScreenContractDto.serializer(), root)
        return dto.toScreenContract(reporter, contractJson)
    }

    override fun parse(
        root: JsonObject,
        reporter: ContractAnomalyReporter,
    ): ScreenContract {
        val dto = contractJson.decodeFromJsonElement(
            ScreenContractDto.serializer(),
            stripWebVariants(normalizeLegacyScreenContractRoot(root)),
        )
        return dto.toScreenContract(reporter, contractJson)
    }

    private fun normalizeLegacyScreenContractRoot(root: JsonObject): JsonObject {
        if ("blocks" in root || "root" in root) return root
        if ("type" !in root) return root

        return buildJsonObject {
            root["id"]?.let { put("id", it) }
            put("blocks", root)
        }
    }

    /**
     * WORKAROUND (contract bug): the BFF serves both a mobile and a web variant
     * of each subtree, distinguished by a `-web` suffix on the block id, and
     * toggles them via `config.visibility`. For the native app the visibility
     * comes inverted — the `-web` branch is `visible=true` and the native one
     * `visible=false` — so the native renderer would show the web layout
     * (e.g. the `grid` block).
     *
     * Until the BFF fixes the visibility, drop every `-web` block and, for each
     * sibling whose `<id>-web` pair was dropped, force the native one visible.
     * No-op on contracts without `-web` ids.
     *
     * KILL-SWITCH: this is a temporary contract workaround. The `forceVisible`
     * step is unconditional, so once the BFF serves correct visibility it would
     * wrongly override an intentionally-hidden native block. When that ships,
     * flip [STRIP_WEB_VARIANTS] to `false` (one line) instead of unwinding the
     * logic. Kept ON by default to preserve today's behavior.
     */
    private fun stripWebVariants(root: JsonObject): JsonObject {
        if (!STRIP_WEB_VARIANTS) return root
        val blocks = root["blocks"] as? JsonObject ?: return root
        val cleaned = dropWebVariants(blocks) as JsonObject
        return JsonObject(root.toMutableMap().apply { put("blocks", cleaned) })
    }

    private fun dropWebVariants(element: JsonElement): JsonElement = when (element) {
        is JsonArray -> JsonArray(element.map { dropWebVariants(it) })
        is JsonObject -> {
            val children = element["children"] as? JsonArray
            if (children == null) {
                JsonObject(element.mapValues { (_, v) -> dropWebVariants(v) })
            } else {
                val nativePairs = children
                    .mapNotNull { (it as? JsonObject)?.blockId() }
                    .filter { it.endsWith(WEB_SUFFIX) }
                    .map { it.removeSuffix(WEB_SUFFIX) }
                    .toSet()
                val kept = children
                    .filter { (it as? JsonObject)?.blockId()?.endsWith(WEB_SUFFIX) != true }
                    .map { child ->
                        val obj = child as? JsonObject ?: return@map dropWebVariants(child)
                        val activated = if (obj.blockId() in nativePairs) obj.forceVisible() else obj
                        dropWebVariants(activated)
                    }
                JsonObject(element.toMutableMap().apply { put("children", JsonArray(kept)) })
            }
        }
        else -> element
    }

    private fun JsonObject.blockId(): String? = this["id"]?.jsonPrimitive?.contentOrNull

    private fun JsonObject.forceVisible(): JsonObject {
        val config = (this["config"] as? JsonObject) ?: JsonObject(emptyMap())
        val newConfig = JsonObject(config.toMutableMap().apply { put("visibility", JsonPrimitive(true)) })
        return JsonObject(this.toMutableMap().apply { put("config", newConfig) })
    }

    private const val WEB_SUFFIX = "-web"

    // Flip to `false` once the BFF serves correct (non-inverted) `-web`
    // visibility — see [stripWebVariants]. ON preserves current behavior.
    private const val STRIP_WEB_VARIANTS = true
}

internal object DefaultScreenContractParserBackend : ScreenContractParserBackend by DtoScreenContractParserBackend
