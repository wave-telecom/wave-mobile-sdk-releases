package br.com.wave.flows.kmp.runtime.api.sources

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeLogger
import br.com.wave.flows.kmp.runtime.api.BffApi
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.parseScreenContract

/**
 * Last-resort source that fetches contracts from the BFF over HTTP.
 *
 * The BFF only serves contracts in `full` mode at this layer, so queries
 * for [ContractMode.SKELETON] decline immediately. The source first tries
 * the `flow` endpoint and, when the BFF responds 404/400, falls back to
 * the `component` endpoint — a quirk of the current BFF that the SDK
 * absorbs here.
 *
 * Non-2xx responses, empty bodies, and parse failures all yield `null`
 * instead of throwing. The chain decides what to do when every source
 * declines; the network source itself never aborts main-thread coroutines.
 */
internal class BffNetworkSource(
    private val api: BffApi,
    private val reporter: ContractAnomalyReporter,
    private val logger: RuntimeLogger,
    private val clock: RuntimeClock,
    private val onSuccess: (ContractQuery, ScreenContract) -> Unit,
) : ContractSource {

    override suspend fun tryGet(query: ContractQuery): ScreenContract? {
        if (query.mode != ContractMode.FULL) return null

        val startMs = clock.nowMillis()
        val response = fetchWithFallback(query) ?: return null
        val elapsedMs = clock.nowMillis() - startMs

        if (!response.isSuccessful) {
            logger.warn("BFF declined '${query.componentId}' (HTTP ${response.code}) in ${elapsedMs}ms")
            return null
        }

        val body = response.body
        if (body.isNullOrBlank()) {
            logger.warn("BFF returned empty body for '${query.componentId}' (HTTP ${response.code})")
            return null
        }

        val contract = runCatching { parseScreenContract(body, reporter) }
            .onFailure { logger.warn("BFF parse failed for '${query.componentId}': ${it.message}") }
            .getOrNull() ?: return null

        logger.info("BFF served '${query.componentId}' in ${elapsedMs}ms")
        onSuccess(query, contract)
        return contract
    }

    private suspend fun fetchWithFallback(query: ContractQuery): br.com.wave.flows.kmp.runtime.api.ApiResponse<String>? {
        val flowResponse = api.getFlowContract(query.componentId, query.externalCode)
        if (flowResponse.isSuccessful) return flowResponse
        if (!shouldFallbackToComponent(flowResponse.code)) return flowResponse
        return api.getComponentContract(query.componentId, query.externalCode)
    }

    private fun shouldFallbackToComponent(httpCode: Int): Boolean = httpCode == 404 || httpCode == 400
}
