package br.com.wave.flows.kmp.runtime.api.init

internal data class InitResponseDto(
    val preloadable: List<InitEntryDto> = emptyList(),
    val cacheable: List<InitEntryDto> = emptyList(),
    val defaults: Map<String, InitEntryDto> = emptyMap(),
    val metadata: InitMetadataDto = InitMetadataDto(),
)

internal data class InitMetadataDto(
    val features: List<InitFeatureDto> = emptyList(),
)

internal data class InitFeatureDto(
    val flows: List<InitFeatureTargetDto> = emptyList(),
    val components: List<InitFeatureTargetDto> = emptyList(),
    val theme: String? = null,
)

internal data class InitFeatureTargetDto(
    val id: String = "",
    val renderMode: String = "",
)
