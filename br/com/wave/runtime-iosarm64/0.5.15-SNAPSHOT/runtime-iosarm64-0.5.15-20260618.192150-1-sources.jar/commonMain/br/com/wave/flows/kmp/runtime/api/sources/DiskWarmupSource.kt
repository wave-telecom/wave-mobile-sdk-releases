package br.com.wave.flows.kmp.runtime.api.sources

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.RuntimeLogger
import br.com.wave.flows.kmp.runtime.contract.mapping.support.ContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.contract.parseScreenContract
import br.com.wave.flows.kmp.runtime.warmup.WarmupCacheKey
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore

/**
 * Persistent warmup cache backed by [WarmupDiskCacheStore].
 *
 * The disk store does not know whether a slug corresponds to a `flow` or a
 * `component`, so each lookup probes both keys in order. On hit, the raw
 * JSON is parsed into a [ScreenContract] and forwarded to [onHit] so the
 * RAM cache can warm itself; the contract is then returned to the chain.
 *
 * Parse failures are swallowed (logged through [reporter] when possible)
 * and the source declines — the chain may still recover from network.
 */
internal class DiskWarmupSource(
    private val store: WarmupDiskCacheStore,
    private val reporter: ContractAnomalyReporter,
    private val logger: RuntimeLogger,
    private val onHit: (ContractQuery, ScreenContract) -> Unit,
) : ContractSource {
    override suspend fun tryGet(query: ContractQuery): ScreenContract? {
        val candidates = listOf(
            WarmupCacheKey(query.baseUrl, query.externalCode, "flow", query.componentId, query.mode.wireValue),
            WarmupCacheKey(query.baseUrl, query.externalCode, "component", query.componentId, query.mode.wireValue),
        )
        for (key in candidates) {
            val json = store.read(key) ?: continue
            val contract = runCatching { parseScreenContract(json, reporter) }
                .onFailure { logger.warn("Disk cache parse failed for '${query.componentId}': ${it.message}") }
                .getOrNull() ?: continue
            onHit(query, contract)
            return contract
        }
        return null
    }
}
