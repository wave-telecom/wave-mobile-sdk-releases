package br.com.wave.flows.kmp.runtime.contract.mapping.support

internal const val LEGACY_TENANT_ICON_BASE_URL = "https://static.dev.telcel.wavebybemobi.com/experience/icons/"

internal fun normalizeLegacyIconUrl(
    url: String?,
    rawType: String?,
): String? {
    if (!rawType.equals("icon", ignoreCase = true)) return url

    val normalized = url
        ?.substringAfterLast('/')
        ?.substringBefore('?')
        ?.lowercase()

    return when (normalized) {
        "home.svg", "homeicon" -> LEGACY_TENANT_ICON_BASE_URL + "home.svg"
        "consumption.svg", "consumoicon" -> LEGACY_TENANT_ICON_BASE_URL + "consumption.svg"
        "packages.svg", "paqueteicon" -> LEGACY_TENANT_ICON_BASE_URL + "packages.svg"
        "services.svg", "servicioicon" -> LEGACY_TENANT_ICON_BASE_URL + "services.svg"
        "help.svg", "ayudaicon" -> LEGACY_TENANT_ICON_BASE_URL + "help.svg"
        else -> url
    }
}
