package br.com.wave.flows.kmp.runtime.warmup

import okio.ByteString.Companion.encodeUtf8

data class WarmupCacheKey(
    val baseUrl: String,
    val externalCode: String,
    val entryType: String, // "flow" or "component"
    val slug: String,
    val mode: String, // "full" or "skeleton"
) {
    fun toFileName(): String {
        val raw = "$baseUrl|$externalCode|$entryType|$slug|$mode"
        return raw.encodeUtf8().sha256().hex() + ".cache"
    }
}
