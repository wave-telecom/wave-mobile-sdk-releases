package br.com.wave.flows.kmp.runtime.warmup

import okio.FileSystem

internal actual fun systemFileSystem(): FileSystem = FileSystem.SYSTEM
