package br.com.wave.flows.kmp.core

/**
 * Scroll position snapshot emitted to the `onScroll` callback on each frame where
 * the root LazyColumn state changes. All fields use only Kotlin stdlib types so the
 * class is usable from any KMP target without platform-specific or Compose dependencies.
 *
 * @param offsetPx Pixel offset of the first visible item from the top of the list.
 * @param firstVisibleItemIndex Index of the first fully (or partially) visible item.
 * @param isScrollingDown `true` while the user scrolls downward (content moves up).
 */
data class ScrollInfo(
    val offsetPx: Int,
    val firstVisibleItemIndex: Int,
    val isScrollingDown: Boolean,
)
