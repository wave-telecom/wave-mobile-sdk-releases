package br.com.wave.flows.kmp.core.contract

sealed interface BlockConfig {
    val style: BlockStyle
}

data class TextBlockConfig(
    val value: String,
    override val style: BlockStyle = BlockStyle(),
    val fontSizeSp: Int? = null,
    val lineHeightSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val align: String? = null,
    val strikethrough: Boolean = false,
    val truncate: Boolean = false,
) : BlockConfig

/**
 * Mirror of the web `RichText` block — a paragraph composed of styled
 * inline segments. Block-level font props apply as defaults; each
 * segment can override them and add color / decoration.
 */
data class RichTextBlockConfig(
    override val style: BlockStyle = BlockStyle(),
    val segments: List<RichTextSegment> = emptyList(),
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val color: String? = null,
    val align: String? = null,
    val strikethrough: Boolean = false,
    val truncate: Boolean = false,
) : BlockConfig

data class RichTextSegment(
    val text: String,
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val color: String? = null,
    val strikethrough: Boolean = false,
    val underline: Boolean = false,
)

data class ButtonBlockConfig(
    val value: String,
    override val style: BlockStyle = BlockStyle(),
    val fontSizeSp: Int? = null,
    val lineHeightSp: Int? = null,
    val fontWeight: Int? = null,
    val align: String? = null,
) : BlockConfig

data class CardBlockConfig(
    override val style: BlockStyle = BlockStyle(),
    val elevation: Int? = null,
) : BlockConfig

data class ContainerBlockConfig(
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class GridBlockConfig(
    val columns: Int = 1,
    val gap: Int = 0,
    val maxColumnSize: Int? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ListBlockConfig(
    val spacing: Int,
    val orientation: BlockOrientation,
    val align: String? = null,
    val verticalAlign: String? = null,
    val horizontalAlign: String? = null,
    val expand: Boolean = false,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class DividerBlockConfig(
    val orientation: BlockOrientation,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ImageBlockConfig(
    val url: String,
    val altText: String? = null,
    val aspectRatio: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val align: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class RadioGroupBlockConfig(
    val orientation: BlockOrientation,
    val activeIndex: Int? = null,
    val activeColorHex: String? = null,
    val activeBackgroundColorHex: String? = null,
    val spacing: Int = 0,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class CarouselBlockConfig(
    val itemWidth: Int,
    val showIndicators: Boolean,
    val showButtons: Boolean? = null,
    val spacing: Int = 0,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ChartDataPoint(
    val key: String,
    val value: Int,
    val fill: String,
)

data class ChartBlockConfig(
    val type: String,
    val data: List<ChartDataPoint>,
    val size: Int,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class SpacerBlockConfig(
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ToolbarBlockConfig(
    val title: String,
    val align: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class TabOption(
    val id: String,
    val label: String,
    val contentReferenceId: String,
)

data class TabsBlockConfig(
    val options: List<TabOption>,
    val gap: Int = 0,
    val activeColorHex: String? = null,
    val activeBackgroundColorHex: String? = null,
    val inactiveColorHex: String? = null,
    val inactiveBackgroundColorHex: String? = null,
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    // Padding/borderRadius on a `tabs` block describe each chip, not the bar.
    // They're stripped from [style] (the bar) and carried here for the chips.
    val chipStyle: BlockStyle = BlockStyle(),
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class BottomSheetBlockConfig(
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class AccordionBlockConfig(
    val title: String? = null,
    val defaultOpen: Boolean = false,
    val iconColorHex: String? = null,
    val iconUrl: String? = null,
    val iconWidth: Int? = null,
    val iconHeight: Int? = null,
    val wrapContent: Boolean? = null,
    val fullWidth: Boolean? = null,
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class UnknownBlockConfig(
    val rawType: String?,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig
