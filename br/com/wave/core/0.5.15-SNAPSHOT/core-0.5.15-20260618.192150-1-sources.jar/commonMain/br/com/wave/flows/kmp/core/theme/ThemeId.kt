package br.com.wave.flows.kmp.core.theme

import kotlin.jvm.JvmInline

/**
 * Strongly-typed identifier for a [ThemePalette]. The set of valid ids is
 * runtime-discovered (comes from the BFF), not compile-time-enumerated — so
 * any string is acceptable, but the type tags it apart from arbitrary strings.
 *
 * Companion constants exist for the two ids the SDK treats specially:
 * [Light] and [Dark] are required to be present in any catalog (so the
 * Auto mode has something to switch between). Custom ids (`darkula`, …) are
 * looked up via [FlowThemeCatalog.get] or constructed directly as
 * `ThemeId("darkula")`.
 */
@JvmInline
value class ThemeId(val value: String) {
    init {
        require(value.isNotBlank()) { "ThemeId must not be blank." }
    }

    companion object {
        val Light: ThemeId = ThemeId("light")
        val Dark: ThemeId = ThemeId("dark")
    }
}
