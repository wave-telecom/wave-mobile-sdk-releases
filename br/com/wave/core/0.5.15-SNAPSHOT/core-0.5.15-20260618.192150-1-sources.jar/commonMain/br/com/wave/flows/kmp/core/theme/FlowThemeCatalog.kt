package br.com.wave.flows.kmp.core.theme

/**
 * The set of [ThemePalette]s the SDK knows about, with typed accessors for
 * the well-known ids and open lookup for custom ones.
 *
 * Invariant: any non-empty catalog MUST contain both [ThemeId.Light] and
 * [ThemeId.Dark]. Construct via [of] to enforce it (or via [empty] for the
 * "no theme configured" backward-compatible case — see [isEmpty]).
 *
 * Order: [all] preserves insertion order so toggling rotates predictably
 * (the host sees palettes in the same order they were declared in the wire
 * payload).
 */
class FlowThemeCatalog private constructor(
    private val byId: Map<ThemeId, ThemePalette>,
    val all: List<ThemePalette>,
) {
    val light: ThemePalette? = byId[ThemeId.Light]
    val dark: ThemePalette? = byId[ThemeId.Dark]

    fun isEmpty(): Boolean = all.isEmpty()
    fun isNotEmpty(): Boolean = all.isNotEmpty()

    fun byId(id: ThemeId): ThemePalette? = byId[id]
    operator fun get(name: String): ThemePalette? = byId[ThemeId(name)]
    operator fun contains(id: ThemeId): Boolean = id in byId

    /**
     * Returns the palette that follows [current] in the catalog (wrapping
     * around). The basis for the generalised "toggle" semantics: for a binary
     * `[light, dark]` catalog this flips between the two; for `[light, dark,
     * darkula]` it rotates through all three; for a one-element catalog
     * it returns the same palette (no-op toggle).
     */
    fun next(current: ThemeId): ThemePalette? {
        if (all.isEmpty()) return null
        val idx = all.indexOfFirst { it.id == current }
        val nextIdx = if (idx < 0) 0 else (idx + 1) % all.size
        return all[nextIdx]
    }

    companion object {
        val Empty: FlowThemeCatalog = FlowThemeCatalog(emptyMap(), emptyList())

        /** Use when no theme is configured — render falls back to literal hex (back-compat). */
        fun empty(): FlowThemeCatalog = Empty

        /**
         * Builds the catalog from an ordered list of palettes. Requires
         * `light` and `dark` to be present so [ThemeMode.Auto] can resolve.
         * The caller (typically the BFF response parser) decides the order.
         */
        fun of(palettes: List<ThemePalette>): FlowThemeCatalog {
            if (palettes.isEmpty()) return Empty
            val byId = LinkedHashMap<ThemeId, ThemePalette>(palettes.size)
            for (p in palettes) {
                require(p.id !in byId) { "Duplicate theme id: ${p.id.value}" }
                byId[p.id] = p
            }
            require(ThemeId.Light in byId && ThemeId.Dark in byId) {
                "FlowThemeCatalog requires both 'light' and 'dark' palettes; got ${byId.keys.map { it.value }}."
            }
            return FlowThemeCatalog(byId, palettes.toList())
        }
    }
}
