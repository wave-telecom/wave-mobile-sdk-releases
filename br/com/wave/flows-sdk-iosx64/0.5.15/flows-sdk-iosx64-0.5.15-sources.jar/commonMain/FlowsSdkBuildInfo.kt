package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-rc.67-1-g98ec45f"
    const val COMPILED_AT_BRT: String = "2026-06-23T13:49:28.101995-03:00"
    const val GIT_SHA: String = "98ec45f"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.15-rc.67-1-g98ec45f@2026-06-23T13:49:28.101995-03:00#98ec45f"
}