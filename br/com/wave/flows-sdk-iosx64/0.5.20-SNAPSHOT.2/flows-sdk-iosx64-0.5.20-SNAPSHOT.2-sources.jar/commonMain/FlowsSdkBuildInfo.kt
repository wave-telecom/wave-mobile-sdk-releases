package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.1-2-gef3ee15"
    const val COMPILED_AT_BRT: String = "2026-07-03T17:21:40.541939-03:00"
    const val GIT_SHA: String = "ef3ee15"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.1-2-gef3ee15@2026-07-03T17:21:40.541939-03:00#ef3ee15"
}