package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.13-rc.50-1-g509ab87"
    const val COMPILED_AT_BRT: String = "2026-06-12T15:19:55.304259-03:00"
    const val GIT_SHA: String = "509ab87"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.13-rc.50-1-g509ab87@2026-06-12T15:19:55.304259-03:00#509ab87"
}