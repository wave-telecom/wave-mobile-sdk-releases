package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.19-2-g135f1f9"
    const val COMPILED_AT_BRT: String = "2026-07-02T18:09:44.02421-03:00"
    const val GIT_SHA: String = "135f1f9"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.19-2-g135f1f9@2026-07-02T18:09:44.02421-03:00#135f1f9"
}