package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.1-SNAPSHOT.1-62-gd9d00aeb"
    const val COMPILED_AT_BRT: String = "2026-08-19T21:07:38.565897-03:00"
    const val GIT_SHA: String = "d9d00aeb"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.1-SNAPSHOT.1-62-gd9d00aeb@2026-08-19T21:07:38.565897-03:00#d9d00aeb"
}