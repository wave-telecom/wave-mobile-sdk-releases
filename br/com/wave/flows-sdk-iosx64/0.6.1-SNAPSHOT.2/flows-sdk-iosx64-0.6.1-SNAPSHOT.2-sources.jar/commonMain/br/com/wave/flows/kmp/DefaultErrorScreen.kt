package br.com.wave.flows.kmp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.composeblocks.RenderBlockScreen
import br.com.wave.flows.kmp.composeblocks.theme.ProvideFlowTheme
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.runtime.api.init.INIT_DEFAULT_ROLE_ERROR
import br.com.wave.flows.kmp.runtime.api.init.InitDefaultEntry
import br.com.wave.flows.kmp.runtime.api.init.InitDefaults
import br.com.wave.flows.kmp.webblocks.RenderBlockWebFallbackError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Bounds resolution of the client's BFF-provisioned error screen, spent across two phases in
 * series ([DEFAULT_ERROR_NOMINATION_GRACE_MS] then the contract fetch) so the total never exceeds
 * this one documented budget. An unbounded fetch here would turn the "friendly error screen" into
 * exactly the never-ending spinner it exists to prevent.
 */
internal const val DEFAULT_ERROR_CONTRACT_TIMEOUT_MS = 5_000L

/**
 * How long [FlowDefaultErrorScreen] waits for `init`'s error-role nomination before settling this
 * composition's floor. Short: this only covers `init` still being in flight at mount, not a slow
 * `init` in general — a genuinely slow `init` still lands on the floor within
 * [DEFAULT_ERROR_CONTRACT_TIMEOUT_MS], it just does not get a second full budget to try again.
 * Spent out of that one total, not on top of it.
 */
internal const val DEFAULT_ERROR_NOMINATION_GRACE_MS = 300L

/** Reported when the client's BFF-provisioned error screen itself could not be resolved. */
internal const val DEFAULT_ERROR_SCREEN_UNAVAILABLE = "DEFAULT_ERROR_SCREEN_UNAVAILABLE"

/**
 * The BFF-nominated component id for the error role, or `null` when no role entry has been
 * published yet, the role is missing, or its slug is blank. [entries] is [InitDefaults.entries]'
 * current value — pure so [defaultErrorComponentId] is testable without composing.
 */
internal fun defaultErrorComponentId(entries: Map<String, InitDefaultEntry>): String? =
    entries[INIT_DEFAULT_ROLE_ERROR]?.slug?.trim()?.takeIf { it.isNotEmpty() }

/**
 * The component id nominated for [INIT_DEFAULT_ROLE_ERROR], read from [entries] within [timeoutMs].
 *
 * [entries] replays its current value, so an already-published nomination resolves without waiting;
 * otherwise the wait covers the ordinary case of `init` still being in flight when the error screen
 * mounts. `null` once [timeoutMs] elapses with nothing nominated, so the caller falls to its floor
 * instead of hanging. Collection stops at the first nomination — later publications are ignored.
 */
internal suspend fun awaitDefaultErrorComponentId(
    entries: StateFlow<Map<String, InitDefaultEntry>>,
    timeoutMs: Long,
): String? = withTimeoutOrNull(timeoutMs) {
    entries.map(::defaultErrorComponentId).filterNotNull().first()
}

/**
 * Cache-first, bounded resolution of the error contract: [ScreenContractProvider.getCachedScreenContract]
 * wins outright (the BFF marks this component `cacheable`, so the cached copy is the one that
 * works when the network is the problem); a cache miss falls to a fresh fetch bounded by
 * [timeoutMs]. Never throws — an exception or a timeout both resolve to `null` so the caller can
 * fall through to the copy-free floor instead of hanging.
 */
internal suspend fun resolveDefaultErrorContract(
    provider: ScreenContractProvider,
    componentId: String,
    externalCode: String?,
    timeoutMs: Long,
): ScreenContract? {
    provider.getCachedScreenContract(componentId, externalCode)?.let { return it }
    return withTimeoutOrNull(timeoutMs) {
        runCatching { provider.getScreenContract(componentId, externalCode) }
            .onFailure { if (it is CancellationException) throw it }
            .getOrNull()
    }
}

internal sealed interface DefaultErrorScreenState {
    data object Resolving : DefaultErrorScreenState
    data class Resolved(val contract: ScreenContract) : DefaultErrorScreenState
    data object Unavailable : DefaultErrorScreenState
}

/** Shared terminal-state decision once a [slug] is known (or known absent). */
private suspend fun resolveScreenState(
    slug: String?,
    resolve: suspend (componentId: String) -> ScreenContract?,
): DefaultErrorScreenState {
    slug ?: return DefaultErrorScreenState.Unavailable
    val contract = resolve(slug) ?: return DefaultErrorScreenState.Unavailable
    return DefaultErrorScreenState.Resolved(contract)
}

/**
 * The terminal state [FlowDefaultErrorScreen] settles on for one [entries] snapshot. Pure over its
 * inputs so the decision is testable without composing.
 */
internal suspend fun resolveDefaultErrorScreenState(
    entries: Map<String, InitDefaultEntry>,
    resolve: suspend (componentId: String) -> ScreenContract?,
): DefaultErrorScreenState = resolveScreenState(defaultErrorComponentId(entries), resolve)

/**
 * [resolveDefaultErrorScreenState] over the live [InitDefaults.entries] flow: the nomination comes
 * from [awaitDefaultErrorComponentId], bounded by [nominationGraceMs]. Bounding [resolve] itself is
 * the caller's responsibility (see [FlowDefaultErrorScreen], which spends the remainder of
 * [DEFAULT_ERROR_CONTRACT_TIMEOUT_MS] on it) — the two never both get a full copy of that budget.
 */
internal suspend fun resolveDefaultErrorScreenState(
    entries: StateFlow<Map<String, InitDefaultEntry>>,
    nominationGraceMs: Long,
    resolve: suspend (componentId: String) -> ScreenContract?,
): DefaultErrorScreenState = resolveScreenState(awaitDefaultErrorComponentId(entries, nominationGraceMs), resolve)

/**
 * The web arm's single failure surface: renders the component the BFF nominates for
 * [INIT_DEFAULT_ROLE_ERROR] as an opaque, full-bleed overlay, falling back to `:webblocks`' own
 * copy-free floor ([RenderBlockWebFallbackError]) when that component is missing, unresolvable,
 * or would take longer than [DEFAULT_ERROR_CONTRACT_TIMEOUT_MS] to fetch. Never paints diagnostic
 * text — the cause reaches [hostEventHandler] and [FlowWrapper.runtimeLogger] only.
 */
@Composable
internal fun FlowDefaultErrorScreen(
    onRetry: () -> Unit,
    hostEventHandler: HostEventHandler,
    modifier: Modifier = Modifier,
) {
    val config = FlowWrapper.requireConfig()
    val currentHostEventHandler by rememberUpdatedState(hostEventHandler)

    var state by remember { mutableStateOf<DefaultErrorScreenState>(DefaultErrorScreenState.Resolving) }

    // Single observer of InitDefaults.entries for this composition's whole lifetime — not keyed on
    // the nomination itself, so a late-arriving slug cannot restart an in-flight contract fetch.
    LaunchedEffect(Unit) {
        var attemptedComponentId: String? = null
        val resolved = resolveDefaultErrorScreenState(
            entries = InitDefaults.entries,
            nominationGraceMs = DEFAULT_ERROR_NOMINATION_GRACE_MS,
        ) { componentId ->
            attemptedComponentId = componentId
            resolveDefaultErrorContract(
                provider = config.contractProvider,
                componentId = componentId,
                externalCode = config.externalCode,
                timeoutMs = DEFAULT_ERROR_CONTRACT_TIMEOUT_MS - DEFAULT_ERROR_NOMINATION_GRACE_MS,
            )
        }
        state = resolved
        if (resolved != DefaultErrorScreenState.Unavailable) return@LaunchedEffect
        val diagnostic = if (attemptedComponentId == null) {
            "FlowDefaultErrorScreen: no component nominated for role $INIT_DEFAULT_ROLE_ERROR within ${DEFAULT_ERROR_NOMINATION_GRACE_MS}ms"
        } else {
            "FlowDefaultErrorScreen: component '$attemptedComponentId' could not be resolved within ${DEFAULT_ERROR_CONTRACT_TIMEOUT_MS}ms"
        }
        FlowWrapper.runtimeLogger.warn(diagnostic)
        currentHostEventHandler.onHostEvent(
            HostEvent.Error(RenderBlockError(code = DEFAULT_ERROR_SCREEN_UNAVAILABLE, message = diagnostic)),
        )
    }

    Box(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        when (val current = state) {
            is DefaultErrorScreenState.Resolved -> ProvideRenderBlockContentSeams {
                ProvideFlowTheme {
                    RenderBlockScreen(
                        contract = current.contract,
                        hostEventHandler = currentHostEventHandler,
                        scroll = false,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            // Bounded by DEFAULT_ERROR_NOMINATION_GRACE_MS on the never-nominated path — an opaque
            // blank screen here, but for that grace only, not the full contract timeout.
            DefaultErrorScreenState.Resolving -> Unit
            DefaultErrorScreenState.Unavailable -> RenderBlockWebFallbackError(onRetry = onRetry, modifier = Modifier.fillMaxSize())
        }
    }
}
