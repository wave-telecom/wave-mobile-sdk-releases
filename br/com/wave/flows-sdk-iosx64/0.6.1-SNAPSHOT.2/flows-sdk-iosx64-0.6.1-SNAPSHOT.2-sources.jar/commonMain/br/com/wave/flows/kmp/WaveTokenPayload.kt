package br.com.wave.flows.kmp

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * The claims the SDK reads out of the wave token. Everything is optional and unknown
 * fields are ignored: the payload is the client backend's to define and grow, and a
 * claim the SDK has never heard of must never break a session.
 *
 * [baseUrl] is the BFF the session talks to — it is why the token is decoded at all.
 * [environment] selects the journeys WebView host on the hybrid wrapper, exactly as
 * the API Key JWT's claim of the same name used to. [externalCode], [tenant] and
 * [expiresAt] are read back for the subscriber identity and the token's TTL.
 *
 * The [SerialName]s below are a wire contract with the wave-auth-api issuing service
 * (`POST /auth/session`), not this SDK's naming choice — do not "tidy" them to match
 * the Kotlin property names, that is exactly the drift that made a real token decode
 * to all-nulls before.
 *
 * The signature is NOT verified: the token was minted and signed by the integrator's
 * backend, which the BFF validates at the other end. The SDK only reads the payload.
 */
@Serializable
internal data class WaveTokenPayload(
    @SerialName("base_url") val baseUrl: String? = null,
    @SerialName("env") val environment: String? = null,
    val externalCode: String? = null,
    val tenant: String? = null,
    @SerialName("exp") val expiresAt: Long? = null,
)

private const val JWT_PARTS = 3
private const val JWT_PAYLOAD_INDEX = 1

private val waveTokenPayloadJson = Json { ignoreUnknownKeys = true; isLenient = true }

// JWT segments are base64url WITHOUT '=' padding, so decode with padding optional.
@OptIn(ExperimentalEncodingApi::class)
private val jwtBase64 = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL)

/**
 * Decodes the wave token's payload, or `null` when it is not a JWT the SDK can read
 * (wrong segment count, bad base64, unparseable JSON).
 *
 * Total by design — callers decide what a `null` means in their context. A token the
 * host just supplied is a config error worth failing on ([requireWaveTokenPayload]);
 * a token read back from the keystore is stored data, and is dropped instead.
 */
@OptIn(ExperimentalEncodingApi::class)
internal fun decodeWaveTokenPayloadOrNull(token: String): WaveTokenPayload? {
    val parts = token.split('.')
    if (parts.size != JWT_PARTS) return null
    val payloadJson = runCatching { jwtBase64.decode(parts[JWT_PAYLOAD_INDEX]).decodeToString() }
        .getOrNull() ?: return null
    return runCatching { waveTokenPayloadJson.decodeFromString<WaveTokenPayload>(payloadJson) }
        .getOrNull()
}

/**
 * Fail-fast variant for a token the host supplied explicitly: a credential the SDK
 * cannot read a [WaveTokenPayload.baseUrl] or [WaveTokenPayload.environment] out of
 * has nowhere to route to, so it fails here — clearly, as an auth/config error at
 * start — instead of later, mis-attributed as a per-request content-load failure or,
 * for `env`, silently routed to a guessed environment.
 *
 * The message is a fixed string and the underlying cause is deliberately NOT chained,
 * so no fragment of the token can leak through an underlying base64/JSON error. It
 * names the wire claims (`base_url`, `env`) rather than the Kotlin property names —
 * that is what an integrator has to go fix on their token.
 */
internal fun requireWaveTokenPayload(token: String): WaveTokenPayload {
    val payload = decodeWaveTokenPayloadOrNull(token)
    require(
        payload != null &&
            !payload.baseUrl.isNullOrBlank() &&
            !payload.environment.isNullOrBlank() &&
            !payload.externalCode.isNullOrBlank(),
    ) {
        "FlowWrapper.start received an invalid waveToken: it must be a JWT whose payload carries a " +
            "non-blank base_url, env and externalCode."
    }
    return payload
}

/**
 * The subscriber identifier a wave token carries, off its `externalCode` claim —
 * readable before any session opens, so `start` can derive the identifier from the
 * SAME token it is about to open a session with, rather than trusting a second value
 * a host might pass out of sync with it. `null` for a token this SDK cannot read at
 * all; callers that need a required identifier go through [requireWaveTokenPayload]
 * first.
 */
fun waveTokenExternalCode(waveToken: String): String? =
    decodeWaveTokenPayloadOrNull(waveToken)?.externalCode?.trim()?.takeIf(String::isNotEmpty)

/**
 * The raw `env` claim a wave token carries, read off the token itself rather than off
 * the open session — so a caller can reject an environment this build cannot route to
 * BEFORE the token is used to open one. `null` for a token this SDK cannot read at all,
 * or one carrying no claim; mapping the raw value onto an environment (and deciding
 * that an unmappable one is fatal) belongs to the caller that owns that whitelist.
 */
fun waveTokenEnvironmentClaim(waveToken: String): String? =
    decodeWaveTokenPayloadOrNull(waveToken)?.environment?.trim()?.takeIf(String::isNotEmpty)
