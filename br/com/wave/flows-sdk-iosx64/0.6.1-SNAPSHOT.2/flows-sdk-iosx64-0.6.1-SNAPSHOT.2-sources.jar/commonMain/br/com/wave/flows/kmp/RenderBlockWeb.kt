package br.com.wave.flows.kmp

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.composeblocks.NativeSkeletonLoading
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider
import br.com.wave.flows.kmp.runtime.debugSkeletonCacheReadSkipped
import br.com.wave.flows.kmp.webblocks.RawSubComponentProvider
import br.com.wave.flows.kmp.webblocks.RenderBlockWebScreen
import io.ktor.http.encodeURLPathPart
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

private const val ORIGIN_WEB_MODULE_RENDER_BLOCK = "web_module_render_block"

/** The arm's own BFF envelope fetch (pre-mount, before `RenderBlockWebScreen` exists) failed. */
private const val RENDER_BLOCK_WEB_ARM_FETCH_FAILED = "RENDER_BLOCK_WEB_ARM_FETCH_FAILED"

/** A `fetchSubComponent` request could not be answered; the requesting placeholder stays unresolved. */
private const val RENDER_BLOCK_WEB_SUB_COMPONENT_FETCH_FAILED = "RENDER_BLOCK_WEB_SUB_COMPONENT_FETCH_FAILED"

/** The session token's `env` claim is absent or not one of the recognized environments. */
private const val RENDER_BLOCK_WEB_UNRESOLVED_ENVIRONMENT = "RENDER_BLOCK_WEB_UNRESOLVED_ENVIRONMENT"

/**
 * Byte-identical to `EntryUrlProvider.kt`'s `BASE_URL_DEV`/`BASE_URL_PRD` pair. Not unified
 * with that file: the legacy WebView's host resolution is under an explicit do-not-touch
 * decision by the repo owner, and the Gradle dependency between the two wrappers runs
 * `flow-wrapper-kmp -> flows-sdk` (one-way), so this module cannot see the other's constants.
 */
private const val DEV_WEB_MODULE_BASE_URL = "https://dev.journeys.telcel.wavebybemobi.com"
internal const val DEFAULT_WEB_MODULE_BASE_URL = "https://journeys.telcel.wavebybemobi.com"

/** The DEV/PRD host for [env], mirroring the claim values `FlowWrapper.resolveSessionEnvironment` accepts. Anything else has no host. */
private fun webModuleBaseUrlFor(env: String): String? =
    when (env.trim().uppercase()) {
        "DEV" -> DEV_WEB_MODULE_BASE_URL
        "PRD" -> DEFAULT_WEB_MODULE_BASE_URL
        else -> null
    }

/**
 * An explicit override always wins. Otherwise the session's `env` claim picks DEV or PRD —
 * never a hardcoded default: an absent or unrecognized claim returns `null` rather than
 * guessing a host, so the caller can fail instead of fetching a DEV contract into a PRD page.
 */
internal fun effectiveWebModuleBaseUrl(): String? {
    val override = FlowWrapper.webModuleBaseUrlOverride?.trim()?.takeIf { it.isNotEmpty() }
    if (override != null) return override
    return waveTokenEnvironment()?.let(::webModuleBaseUrlFor)
}

/**
 * Render-route path for [componentId]/[flowId] under [baseUrl], mirroring the legacy
 * webview shell's `/components/{id}` and `/flows/{id}` routes. [componentId] wins when both
 * are non-blank, matching the fetch priority in [RenderBlockWeb].
 */
internal fun webModuleRenderRouteUrl(baseUrl: String, componentId: String?, flowId: String?): String {
    val path = when {
        !componentId.isNullOrBlank() -> "/components/${componentId.encodeURLPathPart()}"
        !flowId.isNullOrBlank() -> "/flows/${flowId.encodeURLPathPart()}"
        else -> error("RenderBlockWeb: componentId and flowId are both null or blank")
    }
    return baseUrl.trimEnd('/') + path
}

/**
 * The SDK's web-module leaf: fetches the raw BFF envelope through the SAME `BffApi`/
 * `externalCode` [FlowWrapper.start] already built (no second HTTP stack), and drives
 * `:webblocks`' [RenderBlockWebScreen]. [componentId] wins over [flowId] when both are
 * non-blank, matching [webModuleRenderRouteUrl]'s own priority.
 */
@Composable
fun RenderBlockWeb(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    onScroll: ((ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
    modifier: Modifier = Modifier,
) {
    val config = FlowWrapper.requireConfig()
    val effectiveComponentId = componentId?.takeIf { it.isNotBlank() }
    val effectiveFlowId = flowId?.takeIf { it.isNotBlank() }
    val entryId = effectiveComponentId ?: effectiveFlowId
        ?: error("RenderBlockWeb: componentId and flowId are both null or blank")
    val isComponent = effectiveComponentId != null

    var contractJson by remember(entryId, isComponent, config.externalCode) { mutableStateOf<JsonElement?>(null) }
    var fetchFailed by remember(entryId, isComponent, config.externalCode) { mutableStateOf(false) }
    // True for the whole fetch effect below, including the FIRST load. Only observed by
    // RenderBlockWebScreen once contractJson is non-null (the first-load skeleton branch
    // below renders instead of that screen), so it never double-draws with that branch.
    var fetchInFlight by remember(entryId, isComponent, config.externalCode) { mutableStateOf(false) }
    var refreshTick by remember(entryId, isComponent, config.externalCode) { mutableStateOf(0) }
    var skeleton by remember(entryId, isComponent, config.externalCode) { mutableStateOf<ScreenContract?>(null) }
    var resolvedBaseUrl by remember(entryId, isComponent, config.externalCode) { mutableStateOf<String?>(null) }

    val currentOnEvent by rememberUpdatedState(onEvent)
    val hostEventHandler = remember(entryId) {
        object : HostEventHandler {
            override fun onHostEvent(event: HostEvent) {
                if (event is HostEvent.Refresh) refreshTick++
                currentOnEvent?.invoke(event.toSdkEvent(entryId, ORIGIN_WEB_MODULE_RENDER_BLOCK))
            }
        }
    }

    // Do NOT clear contractJson here: on a refresh (refreshTick change) this effect reruns
    // while `RenderBlockWebScreen` is still mounted with the old contract. Nulling it would
    // drop to `NativeSkeletonLoading`, unmounting the WebView and forcing a full page reload
    // for what `RenderBlockWebScreen` already handles as an in-place `pushRender`. The state
    // above is `remember`ed on the same identity keys this effect uses EXCEPT `refreshTick`,
    // so a different entry or a different subscriber starts from a fresh `null` — only a
    // refresh keeps the previous contract on screen while the new one is in flight.
    LaunchedEffect(entryId, isComponent, config.externalCode, refreshTick) {
        fetchFailed = false
        fetchInFlight = true
        val entryKind = if (isComponent) "component" else "flow"
        skeleton = fetchWebModuleSkeleton(config, entryId)
        val baseUrl = effectiveWebModuleBaseUrl()
        if (baseUrl == null) {
            fetchFailed = true
            fetchInFlight = false
            val diagnostic = "RenderBlockWeb: no resolvable web-module host for entryId=$entryId " +
                "(the session's env claim is absent or unrecognized)"
            FlowWrapper.runtimeLogger.warn(diagnostic)
            hostEventHandler.onHostEvent(
                HostEvent.Error(RenderBlockError(code = RENDER_BLOCK_WEB_UNRESOLVED_ENVIRONMENT, message = diagnostic)),
            )
            return@LaunchedEffect
        }
        resolvedBaseUrl = baseUrl
        runCatching {
            val response = if (isComponent) {
                config.api.getComponentContract(entryId, config.externalCode)
            } else {
                config.api.getFlowContract(entryId, config.externalCode)
            }
            if (response.isSuccessful) {
                response.body ?: error("RenderBlockWeb: empty body for entryId=$entryId (code=${response.code})")
            } else {
                error("RenderBlockWeb: contract fetch failed for entryId=$entryId (code=${response.code})")
            }
        }.onSuccess { raw ->
            contractJson = Json.parseToJsonElement(raw)
            FlowWrapper.runtimeLogger.info("RenderBlockWeb: fetch succeeded for $entryKind entryId=$entryId")
        }.onFailure { throwable ->
            fetchFailed = true
            val diagnostic = throwable.message ?: "RenderBlockWeb: contract fetch failed for entryId=$entryId"
            FlowWrapper.runtimeLogger.warn("RenderBlockWeb: fetch failed for $entryKind entryId=$entryId: $diagnostic")
            hostEventHandler.onHostEvent(
                HostEvent.Error(RenderBlockError(code = RENDER_BLOCK_WEB_ARM_FETCH_FAILED, message = diagnostic)),
            )
        }
        fetchInFlight = false
    }

    val rawSubComponentProvider = remember(entryId, config.externalCode) {
        RawSubComponentProvider { id, externalCode ->
            val response = config.api.getComponentContract(id, externalCode ?: config.externalCode)
            if (response.isSuccessful) {
                response.body
            } else {
                val diagnostic = "RenderBlockWeb: sub-component fetch failed for id=$id (code=${response.code})"
                FlowWrapper.runtimeLogger.warn(diagnostic)
                hostEventHandler.onHostEvent(
                    HostEvent.Error(
                        RenderBlockError(code = RENDER_BLOCK_WEB_SUB_COMPONENT_FETCH_FAILED, message = diagnostic),
                    ),
                )
                null
            }
        }
    }
    // A fresh lambda per recomposition is fine: RenderBlockWebScreen re-reads `onScroll`
    // through `rememberUpdatedState` instead of capturing it once.
    val coreOnScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)? =
        onScroll?.let { handler -> { info -> handler(info.toPublicScrollInfo()) } }

    val resolvedContractJson = contractJson
    val currentBaseUrl = resolvedBaseUrl
    val themeMode = if (rememberFlowThemeIsDark()) ThemeId.Dark else ThemeId.Light
    when (renderBlockWebPhase(fetchFailed, resolvedContractJson, currentBaseUrl)) {
        RenderBlockWebPhase.Error -> FlowDefaultErrorScreen(
            onRetry = { refreshTick++ },
            hostEventHandler = hostEventHandler,
            modifier = modifier,
        )
        RenderBlockWebPhase.Skeleton -> NativeSkeletonLoading(skeleton, themeMode, modifier)
        // renderBlockWebPhase only returns Content once both are non-null; the `!!`s just
        // recover the smart cast the compiler loses once that check moved into a function.
        RenderBlockWebPhase.Content -> RenderBlockWebScreen(
            url = webModuleRenderRouteUrl(currentBaseUrl!!, effectiveComponentId, effectiveFlowId),
            contractJson = resolvedContractJson!!,
            refreshInFlight = fetchInFlight,
            hostEventHandler = hostEventHandler,
            themeMode = themeMode,
            onScroll = coreOnScroll,
            scrollThrottleMs = scrollThrottleMs,
            rawSubComponentProvider = rawSubComponentProvider,
            externalCode = config.externalCode,
            loading = { NativeSkeletonLoading(skeleton, themeMode, Modifier.fillMaxSize()) },
            error = { failure -> FlowDefaultErrorScreen(onRetry = failure.retry, hostEventHandler = hostEventHandler) },
            modifier = modifier,
        )
    }
}

/** Which of [RenderBlockWeb]'s three mutually-exclusive branches to render. */
internal enum class RenderBlockWebPhase { Error, Skeleton, Content }

/**
 * A failed refresh keeps showing the retained [resolvedContractJson] instead of dropping to
 * the error screen: the home page timestamps the information it displays, so stale content
 * is not dishonest, and the failure is still signalled to the integrator via the host event
 * fired alongside the fetch failure (see the `onFailure` branch above). The error phase wins
 * only when there is nothing to keep — first load included, since [resolvedContractJson] is
 * null then too.
 */
internal fun renderBlockWebPhase(
    fetchFailed: Boolean,
    resolvedContractJson: JsonElement?,
    currentBaseUrl: String?,
): RenderBlockWebPhase = when {
    fetchFailed && resolvedContractJson == null -> RenderBlockWebPhase.Error
    resolvedContractJson == null -> RenderBlockWebPhase.Skeleton
    // Only reached once the LaunchedEffect above has resolved a host and used it to fetch
    // resolvedContractJson successfully, so currentBaseUrl is expected non-null here; falling
    // through to the arm's own failure floor instead of asserting keeps a future break of
    // that invariant from crashing the host app.
    currentBaseUrl == null -> RenderBlockWebPhase.Error
    else -> RenderBlockWebPhase.Content
}

/**
 * Best-effort skeleton for the pre-contract loading window — reads the process-wide
 * contract cache the SDK's own warmup already populated, never fetches, never throws.
 * `null` when [FlowWrapperRuntimeConfig.contractProvider] is not a [BffScreenContractProvider]
 * (mirrors the cast [RenderBlockRouteWrapper] already uses for the native leaf).
 */
private suspend fun fetchWebModuleSkeleton(config: FlowWrapperRuntimeConfig, entryId: String): ScreenContract? {
    val provider = config.contractProvider as? BffScreenContractProvider
    if (provider == null) {
        FlowWrapper.runtimeLogger.debugSkeletonCacheReadSkipped(config.contractProvider::class.simpleName)
        return null
    }
    // The read/hit/miss diagnostic lives in [BffScreenContractProvider.getCachedSkeletonContract]
    // itself, keyed by the exact fields the provider's own query uses — never a second,
    // independently re-read copy of the base URL or externalCode.
    return provider.getCachedSkeletonContract(entryId, config.externalCode)
}
