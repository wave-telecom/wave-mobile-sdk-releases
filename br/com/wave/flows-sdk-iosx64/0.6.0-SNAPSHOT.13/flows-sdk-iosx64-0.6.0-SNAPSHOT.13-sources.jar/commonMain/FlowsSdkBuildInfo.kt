package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "v0.5.9-42-g14125d9"
    const val COMPILED_AT_BRT: String = "2026-05-20T20:59:01.772028-03:00"
    const val GIT_SHA: String = "14125d9"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "v0.5.9-42-g14125d9@2026-05-20T20:59:01.772028-03:00#14125d9"
}