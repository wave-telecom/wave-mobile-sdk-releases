package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.6-5-gfc82d14"
    const val COMPILED_AT_BRT: String = "2026-07-07T11:33:38.757714-03:00"
    const val GIT_SHA: String = "fc82d14"
    const val GIT_BRANCH: String = "release/0.5.20"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.6-5-gfc82d14@2026-07-07T11:33:38.757714-03:00#fc82d14"
}