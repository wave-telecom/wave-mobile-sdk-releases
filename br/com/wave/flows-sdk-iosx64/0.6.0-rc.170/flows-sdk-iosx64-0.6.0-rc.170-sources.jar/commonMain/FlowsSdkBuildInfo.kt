package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.3-0-g1ce0262a"
    const val COMPILED_AT_BRT: String = "2026-08-09T23:37:16.398545-03:00"
    const val GIT_SHA: String = "1ce0262a"
    const val GIT_BRANCH: String = "release/0.6.0"
    const val DESCRIPTION: String = "0.5.20.3-0-g1ce0262a@2026-08-09T23:37:16.398545-03:00#1ce0262a"
}