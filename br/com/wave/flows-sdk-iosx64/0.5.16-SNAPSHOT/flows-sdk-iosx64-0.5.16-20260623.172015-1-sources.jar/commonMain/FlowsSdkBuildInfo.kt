package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-3-g42d93fa"
    const val COMPILED_AT_BRT: String = "2026-06-23T14:21:34.190674-03:00"
    const val GIT_SHA: String = "42d93fa"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-3-g42d93fa@2026-06-23T14:21:34.190674-03:00#42d93fa"
}