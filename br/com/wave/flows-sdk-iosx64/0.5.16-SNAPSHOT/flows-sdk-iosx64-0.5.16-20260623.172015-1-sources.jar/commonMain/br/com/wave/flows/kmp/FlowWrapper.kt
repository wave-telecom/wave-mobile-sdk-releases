package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockImageContent
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockFontResolver
import br.com.wave.flows.kmp.composeblocks.RenderBlockRoute
import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.composeblocks.theme.ProvideFlowTheme
import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemeMode
import br.com.wave.flows.kmp.runtime.contract.theme.ThemeParser
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.runtime.DEFAULT_BFF_BASE_URL
import br.com.wave.flows.kmp.runtime.DEFAULT_COMPONENT_ID
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_ACTION
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_BACK
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_NAVIGATE
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_OPEN_URL
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_REFRESH
import br.com.wave.flows.kmp.runtime.ORIGIN_NATIVE_RENDER_BLOCK
import br.com.wave.flows.kmp.runtime.api.BffApiFactory
import br.com.wave.flows.kmp.runtime.api.BffApi
import br.com.wave.flows.kmp.runtime.api.clearBffScreenContractCache
import br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider
import br.com.wave.flows.kmp.runtime.warmup.WarmupCoordinator
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore
import br.com.wave.flows.kmp.runtime.warmup.WarmupEntry
import br.com.wave.flows.kmp.runtime.resolveEntry
import io.ktor.client.HttpClient
import coil3.ImageLoader
import coil3.annotation.ExperimentalCoilApi
import coil3.network.ktor3.KtorNetworkFetcherFactory
import coil3.svg.SvgDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okio.Path.Companion.toPath

internal data class FlowWrapperRuntimeConfig(
    val contractProvider: ScreenContractProvider,
    val defaultComponentId: String = DEFAULT_COMPONENT_ID,
    val httpClient: HttpClient,
    val imageHttpClient: HttpClient,
    val imageLoader: ImageLoader,
    val api: BffApi,
    val externalCode: String,
    val diskCache: WarmupDiskCacheStore?,
)

enum class WarmTargetType {
    FLOW,
    COMPONENT,
}

enum class WarmTargetMode {
    FULL,
    SKELETON,
}

data class WarmTarget(
    val slug: String,
    val type: WarmTargetType,
    val mode: WarmTargetMode = WarmTargetMode.FULL,
)

private const val WARM_MODE_FULL = "full"
private const val WARM_MODE_SKELETON = "skeleton"

sealed class SDKEvent {
    data class Error(
        val componentId: String,
        val code: String,
        val message: String,
    ) : SDKEvent()

    data class ComponentLoaded(
        val componentId: String,
    ) : SDKEvent()

    data class Callback(
        val type: String,
        val payload: String,
        val origin: String,
    ) : SDKEvent()

    data class ActionTracked(
        val type: String,
        val payload: Map<String, String>,
        val timestamp: String,
        val origin: String,
    ) : SDKEvent()
}

object FlowWrapper {
    private var runtimeConfig: FlowWrapperRuntimeConfig? = null
    private val sdkScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var warmupJob: Job? = null
    private var renderSessionToken by mutableIntStateOf(0)

    /**
     * Switch the host-selected theme mode — system / light / dark, mirroring the
     * hibrido wrapper's contract so this SDK is a native-only drop-in. [FlowThemeMode.System]
     * follows the OS; [FlowThemeMode.Light]/[FlowThemeMode.Dark] pin the palette. Takes effect
     * immediately — any mounted `RenderBlock` re-resolves `@{token}` references in place.
     */
    fun setThemeMode(mode: FlowThemeMode) {
        FlowThemeStore.setMode(
            when (mode) {
                FlowThemeMode.System -> ThemeMode.Auto
                FlowThemeMode.Light -> ThemeMode.Explicit(ThemeId.Light)
                FlowThemeMode.Dark -> ThemeMode.Explicit(ThemeId.Dark)
            },
        )
    }

    /**
     * [context] feeds the device-metadata CDR headers (FLW-1104): on Android
     * pass an `android.content.Context`; on iOS it is unused (pass `null`).
     */
    fun start(
        context: Any?,
        apiKey: String,
        msisdn: String,
        onReady: (() -> Unit)? = null,
    ) {
        PlatformDeviceInfoProvider.setHostContext(context)
        start(apiKey, msisdn, onReady)
    }

    // Retained for backward compatibility; emits no device-metadata headers.
    fun start(
        apiKey: String,
        msisdn: String,
        onReady: (() -> Unit)? = null,
    ) {
        setMsisdn(apiKey = apiKey, msisdn = msisdn)

        // "Fake init": parse the bundled theme JSON and seed the catalog so
        // the host can show a theme selector before any screen loads.
        // TECH DEBT: replace bundled JSON with a real BFF init payload once
        // the backend exposes one.
        val catalog = loadBundledThemeCatalog()
        FlowThemeStore.setCatalog(catalog)

        warmDefaultEntries { onReady?.invoke() }
    }

    fun setMsisdn(
        apiKey: String,
        msisdn: String,
    ) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        warmupJob?.cancel()
        runtimeConfig?.imageLoader?.shutdown()
        runtimeConfig?.imageHttpClient?.close()
        runtimeConfig?.httpClient?.close()
        renderSessionToken += 1
        clearBffScreenContractCache()
        SdkApiHeaderStore.clear()

        val externalCode = sanitizedMsisdn.filter(Char::isDigit)

        // Must run before the client is built and any BFF call fires.
        configureSdkApiHeaders(buildDeviceHeaders())

        val httpClient = createPlatformHttpClient()
        val imageHttpClient = createPlatformImageHttpClient()
        val imageLoader = createFlowImageLoader(imageHttpClient)
        val warmupCacheDir = platformWarmupCacheDir()
        val diskCache =
            warmupCacheDir
                ?.takeIf { it.isNotBlank() }
                ?.toPath()
                ?.let(::WarmupDiskCacheStore)
        val api = BffApiFactory.create(
            client = httpClient,
            baseUrl = DEFAULT_BFF_BASE_URL,
        )
        val contractProvider =
            BffScreenContractProvider(
                baseUrl = DEFAULT_BFF_BASE_URL,
                externalCode = externalCode,
                diskCache = diskCache,
                api = api,
            )

        runtimeConfig =
            FlowWrapperRuntimeConfig(
                contractProvider = contractProvider,
                httpClient = httpClient,
                imageHttpClient = imageHttpClient,
                imageLoader = imageLoader,
                api = api,
                externalCode = externalCode,
                diskCache = diskCache,
            )
    }

    fun warm(
        targets: List<WarmTarget>,
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                    ).warm(
                        targets.map { target ->
                            WarmupEntry(
                                slug = target.slug,
                                type = when (target.type) {
                                    WarmTargetType.FLOW -> "flow"
                                    WarmTargetType.COMPONENT -> "component"
                                },
                                mode = when (target.mode) {
                                    WarmTargetMode.FULL -> WARM_MODE_FULL
                                    WarmTargetMode.SKELETON -> WARM_MODE_SKELETON
                                },
                            )
                        },
                    )
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    /**
     * Hybrid native init: fetch `/api/init` and hand the raw body to [onInitJson]
     * (where the wrapper installs the render-routing policy), then signal [onReady].
     * Unlike [start]/[warmDefaultEntries] it does NOT warm the init's declared
     * entries — native warm targets come from the routing policy.
     */
    fun warmFromInit(
        onInitJson: suspend (String) -> Unit,
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                    ).fetchInit(onInitJson)
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Best-effort: on failure the wrapper keeps the seed policy.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    fun hasCachedComponent(componentId: String): Boolean {
        val normalizedComponentId = componentId.trim()
        if (normalizedComponentId.isEmpty()) return false
        val config = runtimeConfig ?: return false
        return config.contractProvider.peekCachedScreenContract(
            componentId = normalizedComponentId,
            externalCode = config.externalCode,
        ) != null
    }

    private fun warmDefaultEntries(
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        // "Fake init": parse the bundled theme JSON and seed the catalog so
        // the host can show a theme selector before any screen loads.
        // TECH DEBT: replace bundled JSON with a real BFF init payload once
        // the backend exposes one.
        val catalog = loadBundledThemeCatalog()
        FlowThemeStore.setCatalog(catalog)

        if (config.diskCache == null) {
            runOnUiThread { onReady?.invoke() }
            return
        }

        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                    ).warmup()
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    private val themeJsonParser = Json { ignoreUnknownKeys = true; isLenient = true }

    /**
     * Parses [BUNDLED_THEME_JSON] into a [FlowThemeCatalog]. Failures degrade
     * to [FlowThemeCatalog.empty] — the SDK then renders legacy literal-hex
     * blocks unchanged (back-compat).
     */
    private fun loadBundledThemeCatalog(): FlowThemeCatalog {
        return runCatching {
            val root = themeJsonParser.parseToJsonElement(
                br.com.wave.flows.kmp.theme.BUNDLED_THEME_JSON,
            ) as? JsonObject ?: return FlowThemeCatalog.empty()
            ThemeParser.parse(root)
        }.getOrElse { FlowThemeCatalog.empty() }
    }

    internal fun requireConfig(): FlowWrapperRuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentRenderSessionToken(): Int = renderSessionToken

    /**
     * Drops the cached `full` contract for [componentId] so the next
     * lookup goes through the chain and reaches the BFF again. The
     * companion `skeleton` entry is preserved, so a re-mounted
     * `RenderBlock` can still surface the cached skeleton while the
     * fresh fetch is in flight.
     *
     * **This call alone does not trigger a re-fetch.** It only clears
     * the cache. The host is responsible for re-mounting the relevant
     * `RenderBlock` — typically by bumping a per-component
     * `refreshToken` and passing it as the `refreshToken` parameter of
     * the composable. Splitting these two concerns lets the host
     * refresh a single component without disturbing siblings (e.g. the
     * navbar) and without resetting global state.
     *
     * Safe to call without an active session — does nothing if
     * `start()` was never called.
     */
    fun refresh(componentId: String, externalCode: String? = null) {
        val provider = runtimeConfig?.contractProvider as? BffScreenContractProvider ?: return
        provider.invalidate(componentId = componentId, externalCode = externalCode)
    }
}

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    refreshToken: Int = 0,
    modifier: Modifier = Modifier,
) {
    val config = FlowWrapper.requireConfig()
    val resolvedComponentId = resolveEntry(componentId, flowId, config.defaultComponentId)
    val renderSessionToken = FlowWrapper.currentRenderSessionToken()
    // Prefer a font resolver supplied by the host (so an app can ship the
    // fonts in its own resource bundle and resolve them) and fall back to the
    // SDK's bundled TelcelType resolver. Needed because library `composeResources`
    // are not packaged into the consuming app by the KMP library plugin, so the
    // SDK's own fonts may not be present at runtime.
    val fontResolver = LocalRenderBlockFontResolver.current ?: rememberFlowRenderBlockFontResolver()

    CompositionLocalProvider(
        LocalRenderBlockImageContent provides FlowRenderBlockImageContent,
        LocalRenderBlockFontResolver provides fontResolver,
    ) {
        ProvideFlowTheme {
            RenderBlockRouteWrapper(
                resolvedComponentId = resolvedComponentId,
                renderSessionToken = renderSessionToken,
                refreshToken = refreshToken,
                onEvent = onEvent,
                modifier = modifier,
                config = config,
            )
        }
    }
}

@Composable
private fun RenderBlockRouteWrapper(
    resolvedComponentId: String,
    renderSessionToken: Int,
    refreshToken: Int,
    onEvent: ((SDKEvent) -> Unit)?,
    modifier: Modifier,
    config: FlowWrapperRuntimeConfig,
) {
    RenderBlockRoute(
            componentId = resolvedComponentId,
            contractProvider = config.contractProvider,
            sessionToken = renderSessionToken,
            refreshToken = refreshToken,
            hostEventHandler = FlowWrapperHostEventHandler(
                componentId = resolvedComponentId,
                onEvent = onEvent,
            ),
            onContractLoaded = { contract ->
                onEvent?.invoke(SDKEvent.ComponentLoaded(contract.id))
            },
            modifier = modifier,
        )
}

@OptIn(ExperimentalCoilApi::class)
private fun createFlowImageLoader(httpClient: HttpClient): ImageLoader {
    val context = platformImageLoaderContext()
    return ImageLoader.Builder(context)
        .components {
            add(KtorNetworkFetcherFactory(httpClient))
            add(SvgDecoder.Factory())
        }
        .build()
}

private class FlowWrapperHostEventHandler(
    private val componentId: String,
    private val onEvent: ((SDKEvent) -> Unit)?,
) : HostEventHandler {
    override fun onHostEvent(event: HostEvent) {
        onEvent?.invoke(event.toSdkEvent(componentId))
    }
}

private fun HostEvent.toSdkEvent(componentId: String): SDKEvent {
    return when (this) {
        is HostEvent.Error -> SDKEvent.Error(
            componentId = componentId,
            code = error.code,
            message = error.message,
        )

        is HostEvent.ActionTracked -> event.toSdkActionTracked(origin = ORIGIN_NATIVE_RENDER_BLOCK)

        is HostEvent.DelegatedHostAction -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_ACTION,
            payload = rawJson,
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        HostEvent.Refresh -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_REFRESH,
            payload = buildJsonObject {
                put("componentId", JsonPrimitive(componentId))
            }.toString(),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        is HostEvent.Navigation -> SDKEvent.Callback(
            type = navigationType(event),
            payload = navigationPayload(event),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )
    }
}

private fun navigationType(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> EVENT_RENDER_BLOCK_NAVIGATE
        NavigationEvent.Back -> EVENT_RENDER_BLOCK_BACK
        is NavigationEvent.External -> EVENT_RENDER_BLOCK_OPEN_URL
    }
}

private fun navigationPayload(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> event.verbatim.toString()

        NavigationEvent.Back -> "{}"

        is NavigationEvent.External -> buildJsonObject {
            put("url", JsonPrimitive(event.url))
        }.toString()
    }
}
