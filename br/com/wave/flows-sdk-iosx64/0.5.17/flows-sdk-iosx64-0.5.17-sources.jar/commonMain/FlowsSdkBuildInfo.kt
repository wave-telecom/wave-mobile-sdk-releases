package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-rc.109-2-gc625984"
    const val COMPILED_AT_BRT: String = "2026-06-29T12:22:56.921752-03:00"
    const val GIT_SHA: String = "c625984"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.17-rc.109-2-gc625984@2026-06-29T12:22:56.921752-03:00#c625984"
}