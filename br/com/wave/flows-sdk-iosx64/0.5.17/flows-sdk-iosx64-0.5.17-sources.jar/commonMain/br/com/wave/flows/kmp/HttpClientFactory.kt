package br.com.wave.flows.kmp

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig

/**
 * Creates the platform [HttpClient] used for **all** BFF API calls, applying
 * the given [config] on top of the platform engine (OkHttp on Android, Darwin
 * on iOS).
 */
internal expect fun newPlatformHttpClient(config: HttpClientConfig<*>.() -> Unit = {}): HttpClient

/**
 * The single [HttpClient] through which every BFF API call flows. The
 * [SdkApiHeaders] plugin lets the SDK attach session-wide headers (configured
 * at init via [configureSdkApiHeaders]) to every request.
 */
fun createPlatformHttpClient(): HttpClient = newPlatformHttpClient {
    install(SdkApiHeaders)
}

/**
 * Dedicated client for image fetches.
 *
 * Kept as a separate factory (rather than reusing [createPlatformHttpClient])
 * so the image transport can evolve independently if the BFF/CDN ever
 * demands different handling — but right now the default engine
 * configuration (OkHttp on Android, Darwin on iOS) is sufficient against
 * the production hosts. No tenant-specific headers, no User-Agent override,
 * no Referer injection.
 */
fun createPlatformImageHttpClient(): HttpClient = HttpClient()
