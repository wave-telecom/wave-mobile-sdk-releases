package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-rc.94-1-gde46082"
    const val COMPILED_AT_BRT: String = "2026-06-26T20:35:05.361421-03:00"
    const val GIT_SHA: String = "de46082"
    const val GIT_BRANCH: String = "hotfix/v16-render-routing"
    const val DESCRIPTION: String = "0.5.16-rc.94-1-gde46082@2026-06-26T20:35:05.361421-03:00#de46082"
}