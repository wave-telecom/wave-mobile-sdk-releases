package br.com.wave.flows.kmp.core.runtime

/**
 * Side effects produced by [dispatchBlockAction] that the SDK *itself* must
 * handle — i.e. they do not cross the host boundary (which is what
 * `HostEvent`s are for).
 *
 * Today there is exactly one: [ToggleThemeMode]. New SDK-internal actions
 * (e.g. opening a built-in language picker, toggling a per-session flag…)
 * are added as additional cases.
 */
sealed interface InternalSdkEffect {
    /** Rotate the active theme through the catalog (handled by the composeblocks layer). */
    data object ToggleThemeMode : InternalSdkEffect
}
