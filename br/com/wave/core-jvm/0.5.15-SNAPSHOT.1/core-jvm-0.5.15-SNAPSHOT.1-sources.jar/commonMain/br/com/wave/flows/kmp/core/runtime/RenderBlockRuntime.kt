package br.com.wave.flows.kmp.core.runtime

import br.com.wave.flows.kmp.core.actions.ActionResolution
import br.com.wave.flows.kmp.core.actions.resolveBlockAction
import br.com.wave.flows.kmp.core.contract.BlockAction
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.createDelegatedHostEvent
import br.com.wave.flows.kmp.core.host.createNavigationHostEvent
import br.com.wave.flows.kmp.core.host.createTrackedActionEvent
import br.com.wave.flows.kmp.core.renderplan.RenderPlanResult
import br.com.wave.flows.kmp.core.renderplan.createRenderPlan
import br.com.wave.flows.kmp.core.visibility.VisibilityState
import br.com.wave.flows.kmp.core.visibility.setBlockVisibility

data class BlockActionResult(
    val hostEvents: List<HostEvent>,
    val visibility: VisibilityState,
    /**
     * Effects that stay inside the SDK (theme toggle today). The caller —
     * usually the composeblocks dispatcher — processes these in addition to
     * forwarding [hostEvents] to the host.
     */
    val internalEffects: List<InternalSdkEffect> = emptyList(),
)

fun buildRenderPlan(
    block: BlockNode,
    rendererRegistry: Set<String>,
    visibility: VisibilityState,
): RenderPlanResult {
    return createRenderPlan(block, rendererRegistry, visibility)
}

fun dispatchBlockAction(
    action: BlockAction,
    blockId: String,
    visibility: VisibilityState,
    timestamp: String,
): BlockActionResult {
    val hostEvents = mutableListOf<HostEvent>()
    val internalEffects = mutableListOf<InternalSdkEffect>()
    hostEvents += createTrackedActionEvent(
        type = action.type.name.lowercase(),
        payload = mapOf("blockId" to blockId),
        timestamp = timestamp,
    )

    val nextVisibility = when (val result = resolveBlockAction(action)) {
        is ActionResolution.Navigation -> {
            hostEvents += createNavigationHostEvent(result.event)
            visibility
        }

        is ActionResolution.Visibility -> setBlockVisibility(
            state = visibility,
            blockId = result.referenceId,
            value = result.visible,
        )

        ActionResolution.Refresh -> {
            hostEvents += HostEvent.Refresh
            visibility
        }

        is ActionResolution.DelegatedHostAction -> {
            hostEvents += createDelegatedHostEvent(result.rawJson)
            visibility
        }

        ActionResolution.ToggleThemeMode -> {
            internalEffects += InternalSdkEffect.ToggleThemeMode
            visibility
        }
    }

    return BlockActionResult(
        hostEvents = hostEvents,
        visibility = nextVisibility,
        internalEffects = internalEffects,
    )
}
