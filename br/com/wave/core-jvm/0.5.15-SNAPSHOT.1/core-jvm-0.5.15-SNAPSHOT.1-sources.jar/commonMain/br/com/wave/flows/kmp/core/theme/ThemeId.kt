package br.com.wave.flows.kmp.core.theme

import kotlin.jvm.JvmInline

/**
 * Strongly-typed identifier for a [ThemePalette]. The SDK recognizes [Light]
 * and [Dark]; a non-empty [FlowThemeCatalog] contains exactly those two.
 */
@JvmInline
value class ThemeId(val value: String) {
    init {
        require(value.isNotBlank()) { "ThemeId must not be blank." }
    }

    companion object {
        val Light: ThemeId = ThemeId("light")
        val Dark: ThemeId = ThemeId("dark")
    }
}
