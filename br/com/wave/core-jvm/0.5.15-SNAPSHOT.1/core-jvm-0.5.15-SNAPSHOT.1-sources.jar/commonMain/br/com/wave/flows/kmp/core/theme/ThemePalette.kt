package br.com.wave.flows.kmp.core.theme

/**
 * A theme as the SDK and host see it: an id, a human-readable label, and a
 * flat lookup of normalized token keys (`"text.black_primary"`, lowercase
 * dot-path) to hex colour strings (`"#FFFFFF"` or `"#AARRGGBB"`).
 *
 * The hex string layer is intentional. Storing already-parsed Compose `Color`
 * values would couple this `core` module to Compose; keeping the token map as
 * `String → String` keeps `core` UI-agnostic. The composeblocks renderer
 * resolves the hex string to `Color` at point of use (the existing
 * `String.toComposeColorOrNull()` step, now theme-aware).
 *
 * Tokens carry only the value. The token *vocabulary* (which names exist) is
 * defined by the BFF; the SDK does not enumerate it.
 */
data class ThemePalette(
    val id: ThemeId,
    val displayName: String,
    val tokens: Map<String, String>,
) {
    /**
     * Resolves a `@{token}` reference (case-insensitive, dot-path) to its hex
     * string. Returns null if the input is not a reference or the token is
     * unknown — callers fall back to the literal string (so plain hex like
     * `#FFAA00` passes through unchanged).
     */
    fun resolveReference(raw: String): String? {
        val key = parseReferenceKey(raw) ?: return null
        return tokens[normalizeTokenKey(key)]
    }

    companion object {
        private val REFERENCE_REGEX = Regex("^@\\{([^}]+)\\}$")

        /** Extracts `Text.Black_primary` from `"@{Text.Black_primary}"`. */
        fun parseReferenceKey(raw: String): String? =
            REFERENCE_REGEX.matchEntire(raw.trim())?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }

        /** Lowercases and collapses whitespace to `_` so `Text.Black primary` ≡ `text.black_primary`. */
        fun normalizeTokenKey(key: String): String =
            key.trim().lowercase().replace(Regex("\\s+"), "_")
    }
}
