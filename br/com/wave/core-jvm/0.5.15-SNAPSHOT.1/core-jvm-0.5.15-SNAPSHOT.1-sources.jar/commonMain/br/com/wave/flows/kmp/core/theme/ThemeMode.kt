package br.com.wave.flows.kmp.core.theme

/**
 * How the host wants the active theme to be picked.
 *
 *  - [Auto]      follow the OS — resolves to [ThemeId.Light] or
 *                [ThemeId.Dark] based on `isSystemInDarkTheme()`.
 *  - [Explicit]  use exactly the given [ThemeId], ignoring the system.
 *
 * Internal representation only. The *host* contract is deliberately narrow —
 * system / light / dark, matching the WebView SDK's `FlowThemeMode`. A host
 * never picks an arbitrary palette: the active palette set (tenant / seasonal
 * themes) is BFF-driven via the screen contract. [Explicit] is reached only
 * with [ThemeId.Light] / [ThemeId.Dark] from that host contract.
 */
sealed interface ThemeMode {
    data object Auto : ThemeMode
    data class Explicit(val themeId: ThemeId) : ThemeMode
}
