package br.com.wave.flows.kmp.core.contract

enum class BlockType {
    ACCORDION,
    BOTTOM_SHEET,
    BUTTON,
    CARD,
    CAROUSEL,
    CHART,
    CONTAINER,
    DIVIDER,
    GRID,
    IMAGE,
    LIST,
    RADIO_GROUP,
    RICH_TEXT,
    SKELETON,
    SPACER,
    TABS,
    TEXT,
    TOOLBAR,
    UNKNOWN,
}
