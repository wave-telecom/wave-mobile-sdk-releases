package br.com.wave.flows.kmp.core.actions

import br.com.wave.flows.kmp.core.contract.BackConfig
import br.com.wave.flows.kmp.core.contract.BlockAction
import br.com.wave.flows.kmp.core.contract.BlockActionTarget
import br.com.wave.flows.kmp.core.contract.DelegatedHostActionConfig
import br.com.wave.flows.kmp.core.contract.NavigateConfig
import br.com.wave.flows.kmp.core.contract.OpenUrlConfig
import br.com.wave.flows.kmp.core.contract.ShowHideConfig
import br.com.wave.flows.kmp.core.contract.VerbatimHostCallbackJson

sealed interface NavigationEvent {
    data class Navigate(
        val nextComponentId: String,
        val verbatim: VerbatimHostCallbackJson,
    ) : NavigationEvent

    data object Back : NavigationEvent
    data class External(val url: String) : NavigationEvent
}

sealed interface ActionResolution {
    data class Navigation(val event: NavigationEvent) : ActionResolution
    data class Visibility(val referenceId: String, val visible: Boolean) : ActionResolution
    data object Refresh : ActionResolution
    data class DelegatedHostAction(val rawJson: String) : ActionResolution

    /**
     * Cycle the active theme through the SDK catalog. Unlike the other
     * resolutions, this one is consumed *inside* the SDK (composeblocks
     * forwards it to the theme store) instead of being dispatched to the host.
     */
    data object ToggleThemeMode : ActionResolution
}

fun resolveBlockAction(action: BlockAction): ActionResolution {
    return when (action.onAction) {
        BlockActionTarget.NAVIGATE -> {
            val config = action.config as NavigateConfig
            ActionResolution.Navigation(
                NavigationEvent.Navigate(
                    nextComponentId = config.destinationId,
                    verbatim = config.verbatim,
                ),
            )
        }

        BlockActionTarget.BACK -> ActionResolution.Navigation(NavigationEvent.Back)

        BlockActionTarget.OPEN_URL -> {
            val config = action.config as OpenUrlConfig
            ActionResolution.Navigation(NavigationEvent.External(config.externalDestinationUrl))
        }

        BlockActionTarget.SHOW -> {
            val config = action.config as ShowHideConfig
            ActionResolution.Visibility(config.referenceId, true)
        }

        BlockActionTarget.HIDE -> {
            val config = action.config as ShowHideConfig
            ActionResolution.Visibility(config.referenceId, false)
        }

        BlockActionTarget.REFRESH -> ActionResolution.Refresh

        BlockActionTarget.HOST_DELEGATED -> {
            val config = action.config as DelegatedHostActionConfig
            ActionResolution.DelegatedHostAction(rawJson = config.rawJson)
        }

        BlockActionTarget.TOGGLE_THEME_MODE -> ActionResolution.ToggleThemeMode
    }
}
