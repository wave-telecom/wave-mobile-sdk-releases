package br.com.wave.flows.kmp.core.theme

/**
 * The light and dark [ThemePalette]s the SDK renders with. The SDK theme is
 * light/dark only.
 *
 * Invariant: a non-empty catalog contains exactly [ThemeId.Light] and
 * [ThemeId.Dark]. Build via [of] (which enforces it) or [empty] for the
 * "no theme configured" case (see [isEmpty]).
 */
class FlowThemeCatalog private constructor(
    private val byId: Map<ThemeId, ThemePalette>,
    val all: List<ThemePalette>,
) {
    val light: ThemePalette? = byId[ThemeId.Light]
    val dark: ThemePalette? = byId[ThemeId.Dark]

    fun isEmpty(): Boolean = all.isEmpty()
    fun isNotEmpty(): Boolean = all.isNotEmpty()

    fun byId(id: ThemeId): ThemePalette? = byId[id]
    operator fun contains(id: ThemeId): Boolean = id in byId

    /** The other palette relative to [current] — the light/dark flip. Null if empty. */
    fun toggle(current: ThemeId): ThemePalette? =
        all.firstOrNull { it.id != current } ?: all.firstOrNull()

    companion object {
        val Empty: FlowThemeCatalog = FlowThemeCatalog(emptyMap(), emptyList())

        /** Use when no theme is configured — render falls back to literal hex (back-compat). */
        fun empty(): FlowThemeCatalog = Empty

        /**
         * Builds the catalog from light and dark palettes. Requires both to be
         * present so [ThemeMode.Auto] can resolve; any other id is rejected.
         */
        fun of(palettes: List<ThemePalette>): FlowThemeCatalog {
            if (palettes.isEmpty()) return Empty
            val byId = LinkedHashMap<ThemeId, ThemePalette>(palettes.size)
            for (p in palettes) {
                require(p.id !in byId) { "Duplicate theme id: ${p.id.value}" }
                require(p.id == ThemeId.Light || p.id == ThemeId.Dark) {
                    "FlowThemeCatalog accepts only 'light'/'dark'; got '${p.id.value}'."
                }
                byId[p.id] = p
            }
            require(ThemeId.Light in byId && ThemeId.Dark in byId) {
                "FlowThemeCatalog requires both 'light' and 'dark' palettes; got ${byId.keys.map { it.value }}."
            }
            return FlowThemeCatalog(byId, palettes.toList())
        }
    }
}
