package br.com.wave.flows.kmp.core.contract

import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog

data class BlockNode(
    val id: String,
    val type: BlockType,
    val config: BlockConfig,
    val children: List<BlockNode> = emptyList(),
    val action: BlockAction? = null,
    val contractErrors: List<RenderBlockError> = emptyList(),
)

data class ScreenContract(
    val id: String,
    val type: String,
    val root: BlockNode,
    /**
     * Theme catalog delivered alongside this screen. Empty when the BFF
     * sends no `theme` field — blocks then render with literal hex from
     * config (back-compat). Non-empty enables `@{token}` resolution against
     * the active palette.
     */
    val themeCatalog: FlowThemeCatalog = FlowThemeCatalog.empty(),
)
