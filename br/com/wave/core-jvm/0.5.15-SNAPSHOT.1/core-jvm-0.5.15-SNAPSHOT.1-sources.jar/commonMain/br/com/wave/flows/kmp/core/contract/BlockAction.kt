package br.com.wave.flows.kmp.core.contract

sealed interface BlockActionConfig

data class NavigateConfig(
    val destinationId: String,
    val verbatim: VerbatimHostCallbackJson,
) : BlockActionConfig

data class BackConfig(
    val referenceId: String,
) : BlockActionConfig

data class OpenUrlConfig(
    val externalDestinationUrl: String,
) : BlockActionConfig

data class ShowHideConfig(
    val referenceId: String,
) : BlockActionConfig

data object RefreshConfig : BlockActionConfig

data class DelegatedHostActionConfig(
    val rawJson: String,
) : BlockActionConfig

/**
 * Toggles the active theme — flips between light and dark. No config payload is
 * needed from the BFF; the SDK consults its own active theme.
 */
data object ToggleThemeModeConfig : BlockActionConfig

enum class BlockActionType {
    CLICK,
}

enum class BlockActionTarget {
    NAVIGATE,
    SHOW,
    HIDE,
    BACK,
    OPEN_URL,
    REFRESH,
    HOST_DELEGATED,
    /** SDK-internal: cycle the active theme through the catalog. */
    TOGGLE_THEME_MODE,
}

data class BlockAction(
    val type: BlockActionType = BlockActionType.CLICK,
    val onAction: BlockActionTarget,
    val config: BlockActionConfig,
)
