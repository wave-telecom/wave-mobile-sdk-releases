package br.com.wave.flows.kmp.core.host

import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.errors.RenderBlockError

data class ActionData(
    val type: String,
    val payload: Map<String, String>,
    val timestamp: String,
)

sealed interface HostEvent {
    data class Navigation(val event: NavigationEvent) : HostEvent
    data class ActionTracked(val event: ActionData) : HostEvent
    data class Error(val error: RenderBlockError) : HostEvent
    data object Refresh : HostEvent
    data class DelegatedHostAction(val rawJson: String) : HostEvent
}

interface HostEventHandler {
    fun onHostEvent(event: HostEvent)
}

@Deprecated(
    message = "Dead path — no internal call-sites. Implement HostEventHandler.onHostEvent instead. " +
        "See docs/tech-debt-renderblock-refresh-agnosticity.md.",
    level = DeprecationLevel.WARNING,
)
data class HostEventHandlers(
    val onError: ((RenderBlockError) -> Unit)? = null,
    val onNavigate: ((NavigationEvent) -> Unit)? = null,
    val onActionTracked: ((ActionData) -> Unit)? = null,
    val onRefresh: (() -> Unit)? = null,
    val onDelegatedHostAction: ((String) -> Unit)? = null,
)

fun createTrackedActionEvent(
    type: String,
    payload: Map<String, String>,
    timestamp: String,
): HostEvent {
    return HostEvent.ActionTracked(
        ActionData(
            type = type,
            payload = payload,
            timestamp = timestamp,
        ),
    )
}

fun createNavigationHostEvent(event: NavigationEvent): HostEvent {
    return HostEvent.Navigation(event)
}

fun createErrorHostEvent(error: RenderBlockError): HostEvent {
    return HostEvent.Error(error)
}

fun createDelegatedHostEvent(rawJson: String): HostEvent {
    return HostEvent.DelegatedHostAction(rawJson)
}

@Deprecated(
    message = "Dead path — no internal call-sites. Implement HostEventHandler.onHostEvent instead. " +
        "See docs/tech-debt-renderblock-refresh-agnosticity.md.",
    level = DeprecationLevel.WARNING,
)
fun dispatchHostEvent(
    event: HostEvent,
    handlers: HostEventHandlers,
) {
    when (event) {
        is HostEvent.Navigation -> handlers.onNavigate?.invoke(event.event)
        is HostEvent.ActionTracked -> handlers.onActionTracked?.invoke(event.event)
        is HostEvent.Error -> handlers.onError?.invoke(event.error)
        HostEvent.Refresh -> handlers.onRefresh?.invoke()
        is HostEvent.DelegatedHostAction -> handlers.onDelegatedHostAction?.invoke(event.rawJson)
    }
}
