package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.2"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-22T10:28:55.268405-03:00"
    const val GIT_SHA: String = "ef10177"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20.2@2026-07-22T10:28:55.268405-03:00#ef10177"
}