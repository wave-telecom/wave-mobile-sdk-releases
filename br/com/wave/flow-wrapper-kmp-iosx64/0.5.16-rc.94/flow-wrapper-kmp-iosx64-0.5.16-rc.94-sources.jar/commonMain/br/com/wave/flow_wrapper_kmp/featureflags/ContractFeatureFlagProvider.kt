package br.com.wave.flow_wrapper_kmp.featureflags

/**
 * Feature-flag values derived from the backend render contract (the same document
 * that drives render routing). Installed at [FlowWrapper.start][br.com.wave.flow_wrapper_kmp.FlowWrapper.start]
 * so the contract's `theme` field controls [Feature.DarkMode]. Any flag not carried
 * by the contract falls back to [DefaultFeatureFlagProvider] — so unknown flags keep
 * their safe, SDK-owned default.
 */
internal class ContractFeatureFlagProvider(
    private val darkMode: Boolean,
) : FeatureFlagProvider {
    override fun isEnabled(feature: Feature): Boolean =
        if (feature == Feature.DarkMode) darkMode else DefaultFeatureFlagProvider.isEnabled(feature)
}
