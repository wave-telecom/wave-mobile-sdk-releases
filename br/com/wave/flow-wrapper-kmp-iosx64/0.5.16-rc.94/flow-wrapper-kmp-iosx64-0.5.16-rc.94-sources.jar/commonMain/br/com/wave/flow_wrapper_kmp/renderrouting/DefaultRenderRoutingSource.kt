package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * Default routing source until init installs the real policy: webview-only. The real
 * contract arrives via the BFF init (parsed by [parseRenderRoutingPolicy] and installed
 * with [RenderRouting.install]); before it lands, frame 1 stays on webview — the safe
 * default. (No hardcoded seed: the backend now serves the contract.)
 */
internal object DefaultRenderRoutingSource : RenderRoutingSource {
    override fun policyFor(session: RenderRoutingSessionContext): RenderRoutingPolicy =
        RenderRoutingPolicy.WEBVIEW_ONLY
}
