package br.com.wave.flow_wrapper_kmp

private const val PATH_PREFIX_FLOWS = "/flows/"
private const val PATH_PREFIX_COMPONENTS = "/components/"

/**
 * Stable, explicit identity of what is being rendered, so routing, readiness, recovery
 * and fallback all reason over the SAME thing instead of passing a loose componentId to
 * some places and flowId to others. A non-blank componentId wins (it is the concrete
 * block); otherwise the flow is the target; [of] returns null when neither is present.
 */
internal sealed interface RenderTargetRef {
    data class Flow(val flowId: String) : RenderTargetRef

    data class Component(val componentId: String) : RenderTargetRef

    companion object {
        fun of(componentId: String?, flowId: String?): RenderTargetRef? {
            componentId?.trim()?.takeIf(String::isNotEmpty)?.let { return Component(it) }
            flowId?.trim()?.takeIf(String::isNotEmpty)?.let { return Flow(it) }
            return null
        }
    }
}

internal fun RenderTargetRef.path(): String = when (this) {
    is RenderTargetRef.Component -> "$PATH_PREFIX_COMPONENTS$componentId"
    is RenderTargetRef.Flow -> "$PATH_PREFIX_FLOWS$flowId"
}

internal fun RenderTargetRef.id(): String = when (this) {
    is RenderTargetRef.Component -> componentId
    is RenderTargetRef.Flow -> flowId
}
