package br.com.wave.flow_wrapper_kmp

/**
 * Public scroll snapshot emitted by the hybrid wrapper.
 *
 * This keeps the host contract anchored in the wrapper package instead of
 * leaking the native engine's internal modules.
 */
data class ScrollInfo(
    val offsetPx: Int,
    val firstVisibleItemIndex: Int,
    val isScrollingDown: Boolean,
)

internal fun br.com.wave.flows.kmp.ScrollInfo.toPublicScrollInfo(): ScrollInfo =
    ScrollInfo(
        offsetPx = offsetPx,
        firstVisibleItemIndex = firstVisibleItemIndex,
        isScrollingDown = isScrollingDown,
    )
