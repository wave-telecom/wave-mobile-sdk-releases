package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * One routing decision: use [target] when a request matches every non-null
 * predicate (AND); a null predicate means "don't care". The concrete values
 * (`"home"`, `"bottom-sheet-"`) are backend data, not SDK constants.
 * [componentIdPrefix] covers instance-suffixed id families like
 * `bottom-sheet-plan-details-<uuid>`. A rule with no predicate is inert — an empty
 * match would capture everything, which is [RenderRoutingPolicy.default]'s job.
 */
internal data class RenderRoutingRule(
    val target: RenderTarget,
    val flowId: String? = null,
    val componentId: String? = null,
    val componentIdPrefix: String? = null,
    val scrollable: Boolean? = null,
    // For a component rule: the flow that embeds this component (the component is a block
    // inside the flow tree, not fetchable alone). Used by warm/recovery, not by matching.
    val sourceFlowId: String? = null,
) {
    private val hasPredicate: Boolean =
        flowId != null || componentId != null || componentIdPrefix != null || scrollable != null

    fun matches(flowId: String?, componentId: String?, scrollable: Boolean): Boolean {
        if (!hasPredicate) return false
        val requestFlowId = flowId?.trim().orEmpty()
        val requestComponentId = componentId?.trim().orEmpty()

        if (this.flowId != null && this.flowId != requestFlowId) return false
        if (this.componentId != null && this.componentId != requestComponentId) return false
        if (this.componentIdPrefix != null && !requestComponentId.startsWith(this.componentIdPrefix)) {
            return false
        }
        if (this.scrollable != null && this.scrollable != scrollable) return false
        return true
    }

    /** Matches on componentId/prefix only (ignores flow + scrollable) — for warm-target lookup. */
    fun matchesComponentId(componentId: String): Boolean {
        val request = componentId.trim()
        return when {
            this.componentId != null -> this.componentId == request
            this.componentIdPrefix != null -> request.startsWith(this.componentIdPrefix)
            else -> false
        }
    }
}
