package br.com.wave.flow_wrapper_kmp.featureflags

/**
 * Catalog of SDK capabilities that can be toggled on or off.
 *
 * Each entry gates a capability that is still being validated internally and is
 * therefore not yet ready for general release. As a capability is validated it
 * is enabled in [DefaultFeatureFlagProvider] (and, in the future, may be sourced
 * remotely — see [FeatureFlagProvider]).
 *
 * Internal to the SDK: the host application neither sees nor controls these.
 */
internal enum class Feature {
    /**
     * Light/dark theming. Kept disabled until the theme contract is validated
     * internally, so client QA cannot reach the unvalidated dark theme.
     */
    DarkMode,
}
