package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRouting
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRoutingPolicy
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderTarget
import br.com.wave.flow_wrapper_kmp.renderrouting.parseRenderRoutingPolicy
import br.com.wave.flows.kmp.WarmTarget
import br.com.wave.flows.kmp.WarmTargetMode
import br.com.wave.flows.kmp.WarmTargetType

private const val NATIVE_RENDER_LOG_TAG = "FlowWrapperKmp"

// The WebView render-block-sdk stamps a per-instance UUID v4 onto the stable
// block id when it emits the navigate callback, e.g.
// `bottom-sheet-plan-details-c98f4f0e-5b53-479a-9b5e-70258d5c3705`. The native
// block index (warmed from the BFF tree) only knows the stable id
// `bottom-sheet-plan-details`, so we strip a trailing UUID to bridge the two.
// This is a transport quirk of the WebView SDK, not a routing rule — it stays
// agnostic of which component is being routed.
private val NATIVE_INSTANCE_SUFFIX =
    Regex("-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

private fun stableNativeComponentId(componentId: String): String =
    componentId.replace(NATIVE_INSTANCE_SUFFIX, "")

internal interface NativeRenderBridgeDelegate {
    fun onSdkStart(
        apiKey: String,
        msisdn: String,
        onReady: () -> Unit,
    )

    /** Engine decision for [target] (routing policy, backend-driven). */
    fun shouldRenderNatively(target: RenderTargetRef, scroll: Boolean): Boolean

    /** Whether [target]'s native content is cached and ready to render. */
    fun isNativeContentReady(target: RenderTargetRef): Boolean

    /** Recover native readiness for [target] by warming the right flow, then report. */
    fun recoverNativeContent(target: RenderTargetRef, onResult: (Boolean) -> Unit)

    @Composable
    fun RenderBlock(
        target: RenderTargetRef,
        onEvent: ((SDKEvent) -> Unit)?,
        scroll: Boolean = true,
        pullToRefreshEnabled: Boolean = false,
        onScroll: ((ScrollInfo) -> Unit)? = null,
        modifier: Modifier = Modifier,
    )
}

internal var nativeRenderBridgeDelegate: NativeRenderBridgeDelegate =
    DefaultNativeRenderBridgeDelegate

internal object DefaultNativeRenderBridgeDelegate : NativeRenderBridgeDelegate {
    private var startGeneration: Long = 0
    private var nativeWarmReady: Boolean = false

    override fun onSdkStart(
        apiKey: String,
        msisdn: String,
        onReady: () -> Unit,
    ) {
        val generation = ++startGeneration
        nativeWarmReady = false

        // Hybrid native init: fetch the BFF init, install the real routing policy from
        // its metadata.features, then warm the flows that policy marks native. The seed
        // policy (resolved synchronously in start) covers frame 1; if init fails we keep
        // the seed and warm its flows.
        var resolvedPolicy: RenderRoutingPolicy? = null
        runCatching {
            br.com.wave.flows.kmp.FlowWrapper.setMsisdn(apiKey = apiKey, msisdn = msisdn)
            br.com.wave.flows.kmp.FlowWrapper.warmFromInit(
                onInitJson = { json -> resolvedPolicy = parseRenderRoutingPolicy(json) },
                onReady = onReady@{
                    if (generation != startGeneration) return@onReady
                    resolvedPolicy?.let { policy ->
                        RenderRouting.install(policy)
                        FlowWrapper.applyContractTheme(policy.themeToken)
                    }
                    warmNativeFlows(generation, onReady)
                },
            )
        }.onFailure { error ->
            if (generation != startGeneration) return
            nativeWarmReady = false
            platformLogDebug(
                NATIVE_RENDER_LOG_TAG,
                "native_render_init_failed message=${error.message}",
            )
            onReady()
        }
    }

    private fun warmNativeFlows(generation: Long, onReady: () -> Unit) {
        val nativeFlowIds = RenderRouting.current().nativeFlowIds()
        if (nativeFlowIds.isEmpty()) {
            platformLogDebug(
                NATIVE_RENDER_LOG_TAG,
                "native_render_warm_skipped reason=no_native_routes",
            )
            onReady()
            return
        }

        runCatching {
            br.com.wave.flows.kmp.FlowWrapper.warm(
                // Seed SKELETON alongside FULL for the same native flows, mirroring
                // WarmupCoordinator.warmup() (preloadable -> skeleton, cacheable -> full).
                // The skeleton entry is what pull-to-refresh surfaces as the interim
                // value via getCachedSkeletonContract(); without it PTR shows a spinner.
                targets = nativeFlowIds.flatMap { id ->
                    listOf(
                        WarmTarget(
                            slug = id,
                            type = WarmTargetType.FLOW,
                            mode = WarmTargetMode.SKELETON,
                        ),
                        WarmTarget(
                            slug = id,
                            type = WarmTargetType.FLOW,
                            mode = WarmTargetMode.FULL,
                        ),
                    )
                },
                onReady = {
                    if (generation != startGeneration) return@warm
                    nativeWarmReady = nativeFlowIds.all { id ->
                        br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(id)
                    }
                    platformLogDebug(
                        NATIVE_RENDER_LOG_TAG,
                        "native_render_warm_finished flows=${nativeFlowIds.joinToString(",")} ready=$nativeWarmReady",
                    )
                    onReady()
                },
            )
        }.onFailure { error ->
            if (generation != startGeneration) return
            nativeWarmReady = false
            platformLogDebug(
                NATIVE_RENDER_LOG_TAG,
                "native_render_warm_failed message=${error.message}",
            )
            onReady()
        }
    }

    override fun shouldRenderNatively(target: RenderTargetRef, scroll: Boolean): Boolean =
        // Engine decision delegated to the routing policy, over the SAME target identity
        // that readiness/recovery use below. Readiness is NOT part of this decision.
        RenderRouting.targetFor(
            flowId = (target as? RenderTargetRef.Flow)?.flowId,
            componentId = (target as? RenderTargetRef.Component)?.componentId,
            scrollable = scroll,
        ) == RenderTarget.NATIVE

    override fun isNativeContentReady(target: RenderTargetRef): Boolean {
        val id = nativeCacheId(target)
        return id.isNotEmpty() && br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(id)
    }

    override fun recoverNativeContent(target: RenderTargetRef, onResult: (Boolean) -> Unit) {
        val warmTargets = recoveryWarmTargets(target)
        if (warmTargets.isEmpty()) {
            onResult(false)
            return
        }
        runCatching {
            br.com.wave.flows.kmp.FlowWrapper.warm(
                targets = warmTargets,
                onReady = {
                    val ok = isNativeContentReady(target)
                    platformLogDebug(NATIVE_RENDER_LOG_TAG, "native_render_recover target=$target ok=$ok")
                    onResult(ok)
                },
            )
        }.onFailure { error ->
            platformLogDebug(
                NATIVE_RENDER_LOG_TAG,
                "native_render_recover_failed target=$target message=${error.message}",
            )
            onResult(false)
        }
    }

    // The cache id that backs a target: a Flow is cached under its slug; a Component
    // under its (UUID-stripped) id, resolvable from the warmed flow tree.
    private fun nativeCacheId(target: RenderTargetRef): String =
        when (target) {
            is RenderTargetRef.Flow -> target.flowId
            is RenderTargetRef.Component -> resolveNativeComponentId(target.componentId)
        }

    // Flows to warm to recover the target, resolved by the policy over the SAME target
    // identity: the flow itself for a Flow; only the source flow(s) embedding a Component
    // (not every native flow).
    private fun recoveryWarmTargets(target: RenderTargetRef): List<WarmTarget> {
        val flowIds = when (target) {
            is RenderTargetRef.Flow ->
                RenderRouting.current().warmTargetsFor(flowId = target.flowId, componentId = null)
            is RenderTargetRef.Component ->
                RenderRouting.current().warmTargetsFor(flowId = null, componentId = target.componentId)
        }
        return flowIds.map { WarmTarget(it, WarmTargetType.FLOW, WarmTargetMode.FULL) }
    }

    // Bridge the WebView's per-instance id to the stable id the native block index
    // knows: prefer the raw id if cached, else the UUID-stripped id when it resolves.
    private fun resolveNativeComponentId(componentId: String): String {
        val requestedId = componentId.trim()
        if (requestedId.isEmpty()) return requestedId
        if (br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(requestedId)) return requestedId
        val stable = stableNativeComponentId(requestedId)
        return if (stable != requestedId &&
            br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(stable)
        ) {
            stable
        } else {
            requestedId
        }
    }

    @Composable
    override fun RenderBlock(
        target: RenderTargetRef,
        onEvent: ((SDKEvent) -> Unit)?,
        scroll: Boolean,
        pullToRefreshEnabled: Boolean,
        onScroll: ((ScrollInfo) -> Unit)?,
        modifier: Modifier,
    ) {
        val componentId =
            (target as? RenderTargetRef.Component)?.let { resolveNativeComponentId(it.componentId) }
        val flowId = (target as? RenderTargetRef.Flow)?.flowId
        br.com.wave.flows.kmp.RenderBlock(
            componentId = componentId,
            flowId = flowId,
            scroll = scroll,
            pullToRefreshEnabled = pullToRefreshEnabled,
            onScroll = onScroll?.let { handler -> { info -> handler(info.toPublicScrollInfo()) } },
            modifier = modifier,
            onEvent = onEvent?.let { handler ->
                { nativeEvent ->
                    handler(nativeRenderBlockEventToWrapperEvent(nativeEvent))
                }
            },
        )
    }

    internal fun reset() {
        startGeneration = 0
        nativeWarmReady = false
    }
}

internal fun nativeRenderBlockEventToWrapperEvent(
    event: br.com.wave.flows.kmp.SDKEvent,
): SDKEvent = when (event) {
    is br.com.wave.flows.kmp.SDKEvent.Error ->
        SDKEvent.Error(
            componentId = event.componentId,
            code = event.code,
            message = event.message,
        )
    is br.com.wave.flows.kmp.SDKEvent.ComponentLoaded -> {
        platformLogDebug(NATIVE_RENDER_LOG_TAG, "render_loaded engine=native componentId=${event.componentId}")
        SDKEvent.ComponentLoaded(componentId = event.componentId)
    }
    is br.com.wave.flows.kmp.SDKEvent.Callback ->
        SDKEvent.Callback(
            type = event.type,
            payload = event.payload.toWebViewCallbackEnvelope(event.type),
            origin = event.origin,
        )
    is br.com.wave.flows.kmp.SDKEvent.ActionTracked ->
        SDKEvent.ActionTracked(
            type = event.type,
            payload = event.payload,
            timestamp = event.timestamp,
            origin = event.origin,
        )
}

private fun String.toWebViewCallbackEnvelope(type: String): String {
    if (!type.startsWith("RENDER_BLOCK_")) return this

    val trimmedPayload = trim()
    val payloadJson = when {
        trimmedPayload.isEmpty() -> "{}"
        trimmedPayload.startsWith("{") || trimmedPayload.startsWith("[") -> trimmedPayload
        else -> "\"${trimmedPayload.escapeJsonString()}\""
    }

    return """{"type":"${type.escapeJsonString()}","payload":$payloadJson}"""
}

private fun String.escapeJsonString(): String = buildString {
    this@escapeJsonString.forEach { char ->
        when (char) {
            '\\' -> append("\\\\")
            '"' -> append("\\\"")
            '\b' -> append("\\b")
            '\u000C' -> append("\\f")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> append(char)
        }
    }
}
