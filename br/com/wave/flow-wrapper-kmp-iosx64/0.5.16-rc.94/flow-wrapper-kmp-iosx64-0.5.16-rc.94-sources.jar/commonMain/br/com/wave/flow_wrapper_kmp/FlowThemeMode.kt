package br.com.wave.flow_wrapper_kmp

enum class FlowThemeMode { System, Light, Dark }
