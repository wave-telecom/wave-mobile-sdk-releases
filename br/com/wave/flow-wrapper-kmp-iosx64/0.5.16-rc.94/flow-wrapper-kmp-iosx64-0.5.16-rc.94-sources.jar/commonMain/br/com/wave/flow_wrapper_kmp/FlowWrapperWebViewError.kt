package br.com.wave.flow_wrapper_kmp

internal enum class FlowWrapperWebViewErrorState(
    val logValue: String,
    val headline: String,
    val message: String,
) {
    Network(
        logValue = "network",
        headline = "Connection failed",
        message = "Please check your internet connection and try again.",
    ),
    Http(
        logValue = "http",
        headline = "Content unavailable",
        message = "We couldn't load this content right now. Please try again.",
    ),
    Ssl(
        logValue = "ssl",
        headline = "Secure connection failed",
        message = "Please check your connection and try again.",
    ),
    Process(
        logValue = "process",
        headline = "WebView closed unexpectedly",
        message = "We couldn't load this content right now. Please try again.",
    ),
    Navigation(
        logValue = "navigation",
        headline = "Unable to open content",
        message = "We couldn't load this content right now. Please try again.",
    ),
    SafeBrowsing(
        logValue = "safe_browsing",
        headline = "Content blocked",
        message = "This content could not be displayed.",
    ),
    Unknown(
        logValue = "unknown",
        headline = "Something went wrong",
        message = "Please try again in a few moments.",
    ),
}

internal fun flowWrapperWebViewErrorLogMessage(
    state: FlowWrapperWebViewErrorState,
): String {
    return "webview_custom_error_page reason=${state.logValue}"
}

internal fun flowWrapperWebViewErrorHtml(
    state: FlowWrapperWebViewErrorState,
): String {
    return """
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Connection error</title>
        <style>
          body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f5f7fa;
            color: #1f2937;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            padding: 24px;
            box-sizing: border-box;
          }
          main {
            max-width: 420px;
            text-align: center;
            background: #ffffff;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
          }
          h1 {
            margin: 0 0 12px;
            font-size: 20px;
          }
          p {
            margin: 0;
            line-height: 1.5;
            color: #4b5563;
          }
        </style>
      </head>
      <body>
        <main>
          <h1>${state.headline}</h1>
          <p>${state.message}</p>
        </main>
      </body>
    </html>
    """.trimIndent()
}
