package br.com.wave.flow_wrapper_kmp.featureflags

/**
 * Central access point for SDK feature flags.
 *
 * Internal to the SDK — the host application can neither read nor change these.
 * Reads delegate to a [FeatureFlagProvider]; the default is the static
 * [DefaultFeatureFlagProvider]. A future remote-backed provider (JWT claim or
 * feature-flag endpoint) can be wired in during initialization via
 * [installProvider] without touching any call site.
 *
 * Usage:
 * ```
 * if (FeatureFlags.isEnabled(Feature.DarkMode)) { ... }
 * ```
 */
internal object FeatureFlags {
    private var provider: FeatureFlagProvider = DefaultFeatureFlagProvider

    fun isEnabled(feature: Feature): Boolean = provider.isEnabled(feature)

    /**
     * Replaces the active provider. Reserved for a future backend-backed source
     * resolved during SDK initialization; unused by the current static setup.
     */
    fun installProvider(provider: FeatureFlagProvider) {
        this.provider = provider
    }

    internal fun resetForTests() {
        provider = DefaultFeatureFlagProvider
    }
}
