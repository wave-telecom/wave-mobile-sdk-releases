package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/** Coordinated outcome for a natively-routed [RenderTargetRef]. */
internal enum class NativeRenderOutcome { RenderNative, AwaitNative, FallbackWebView }

/**
 * Outcome before any recovery: ready content renders native immediately; a miss renders
 * native optimistically while recovery runs. Pure so the readiness->recovery->fallback
 * decisions are testable without the Compose runtime.
 */
internal fun initialNativeRenderOutcome(ready: Boolean): NativeRenderOutcome =
    if (ready) NativeRenderOutcome.RenderNative else NativeRenderOutcome.AwaitNative

/** Outcome once a recovery attempt reports back: success renders native, failure falls back. */
internal fun recoveredNativeRenderOutcome(recovered: Boolean): NativeRenderOutcome =
    if (recovered) NativeRenderOutcome.RenderNative else NativeRenderOutcome.FallbackWebView

/**
 * Coordinates readiness -> recovery -> fallback for a natively-routed [target] so the
 * render path only composes. Thin shell over [initialNativeRenderOutcome] /
 * [recoveredNativeRenderOutcome]: it owns the Compose state and runs one recovery on a
 * miss. All steps reason over the same [target] identity.
 */
@Composable
internal fun rememberNativeRenderOutcome(
    target: RenderTargetRef,
    delegate: NativeRenderBridgeDelegate = nativeRenderBridgeDelegate,
): NativeRenderOutcome {
    var outcome by remember(target) {
        mutableStateOf(initialNativeRenderOutcome(delegate.isNativeContentReady(target)))
    }
    LaunchedEffect(target) {
        if (outcome == NativeRenderOutcome.AwaitNative) {
            delegate.recoverNativeContent(target) { ready ->
                outcome = recoveredNativeRenderOutcome(ready)
            }
        }
    }
    return outcome
}
