package br.com.wave.flow_wrapper_kmp.renderrouting

/**
 * Context a [RenderRoutingSource] may need to resolve the policy. Additive: new
 * fields can be appended without touching existing sources. [rawClaims] carries the
 * decoded init payload when the init layer embeds routing metadata.
 */
internal data class RenderRoutingSessionContext(
    val apiKey: String,
    val msisdn: String,
    val rawClaims: String? = null,
)

/**
 * Supplies the [RenderRoutingPolicy] — the Open/Closed seam. Swapping the source
 * (init-token claim, a `/render-routing` endpoint, a test seed) is a new
 * implementation plus one [RenderRouting.installSource] call; no routing *reader*
 * changes. [policyFor] must return promptly: routing has to be settled before
 * warm-up (which derives native targets from [RenderRoutingPolicy.nativeFlowIds]),
 * so any remote fetch must already be done. [RenderRoutingPolicy.WEBVIEW_ONLY] is a
 * safe fallback.
 */
internal fun interface RenderRoutingSource {
    fun policyFor(session: RenderRoutingSessionContext): RenderRoutingPolicy
}

/** A fixed-policy source — for tests and for pinning a known policy. */
internal class StaticRenderRoutingSource(
    private val policy: RenderRoutingPolicy,
) : RenderRoutingSource {
    override fun policyFor(session: RenderRoutingSessionContext): RenderRoutingPolicy = policy
}
