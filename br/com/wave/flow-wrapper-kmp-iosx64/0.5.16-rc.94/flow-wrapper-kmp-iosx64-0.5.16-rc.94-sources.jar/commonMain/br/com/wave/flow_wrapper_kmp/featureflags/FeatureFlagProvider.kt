package br.com.wave.flow_wrapper_kmp.featureflags

/**
 * Resolves whether a given [Feature] is enabled.
 *
 * Today the only implementation is [DefaultFeatureFlagProvider], which holds
 * static, SDK-owned values. The interface exists so that the source of truth can
 * later become remote — for example a claim embedded in the init JWT, or a
 * dedicated feature-flag endpoint resolved during initialization — without
 * changing any call site that reads a flag.
 */
internal interface FeatureFlagProvider {
    fun isEnabled(feature: Feature): Boolean
}

/**
 * Static, SDK-owned feature flag values.
 *
 * Flip a flag to `true` here once the corresponding capability has been
 * validated internally. This is intentionally compile-time for now; a
 * backend-backed [FeatureFlagProvider] can replace it later via
 * [FeatureFlags.installProvider].
 */
internal object DefaultFeatureFlagProvider : FeatureFlagProvider {
    private val enabled: Map<Feature, Boolean> =
        mapOf(
            // Dark mode is not yet validated internally — keep it off.
            Feature.DarkMode to false,
        )

    override fun isEnabled(feature: Feature): Boolean = enabled[feature] ?: false
}
