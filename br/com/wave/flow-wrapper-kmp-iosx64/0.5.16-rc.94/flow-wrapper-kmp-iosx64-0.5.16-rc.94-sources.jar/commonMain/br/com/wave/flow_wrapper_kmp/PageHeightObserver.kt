package br.com.wave.flow_wrapper_kmp

internal const val PAGE_HEIGHT_CALLBACK_TYPE = "PAGE_HEIGHT"

internal const val PAGE_HEIGHT_OBSERVER_JS =
    "(function(){" +
        "if(window.__waveHeightObserverInstalled)return;" +
        "window.__waveHeightObserverInstalled=true;" +
        "function post(h){" +
            "var p=JSON.stringify({type:'PAGE_HEIGHT',payload:{height:h}});" +
            "try{" +
                "if(window.NativeHandler&&typeof window.NativeHandler.sendDataToApp==='function'){" +
                    "window.NativeHandler.sendDataToApp(p);return;" +
                "}" +
                "if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.NativeHandler){" +
                    "window.webkit.messageHandlers.NativeHandler.postMessage(p);return;" +
                "}" +
            "}catch(e){}" +
        "}" +
        "var last=-1;" +
        "function measure(){" +
            "var h=Math.max(" +
                "document.documentElement?document.documentElement.scrollHeight:0," +
                "document.body?document.body.scrollHeight:0" +
            ");" +
            "if(h>0&&h!==last){last=h;post(h);}" +
        "}" +
        "measure();" +
        "if(typeof ResizeObserver!=='undefined'){" +
            "var ro=new ResizeObserver(measure);" +
            "if(document.body)ro.observe(document.body);" +
            "if(document.documentElement)ro.observe(document.documentElement);" +
        "}" +
        "window.addEventListener('load',measure);" +
    "})();"

internal fun extractPageHeightFromPayload(payload: String): Int? {
    val raw = extractStringFieldFromJson(json = payload, fieldName = "height")
        ?: extractIntegerLikeField(payload = payload, fieldName = "height")
        ?: return null
    return raw.trim().toDoubleOrNull()?.toInt()?.takeIf { it > 0 }
}

private fun extractIntegerLikeField(payload: String, fieldName: String): String? {
    val key = "\"$fieldName\""
    val keyIndex = payload.indexOf(key)
    if (keyIndex < 0) return null
    val colonIndex = payload.indexOf(':', startIndex = keyIndex + key.length)
    if (colonIndex < 0) return null
    val start = colonIndex + 1
    val end = payload.indexOfAny(charArrayOf(',', '}', ']'), startIndex = start)
        .takeIf { it > start } ?: payload.length
    return payload.substring(start, end).trim().takeIf { it.isNotEmpty() }
}
