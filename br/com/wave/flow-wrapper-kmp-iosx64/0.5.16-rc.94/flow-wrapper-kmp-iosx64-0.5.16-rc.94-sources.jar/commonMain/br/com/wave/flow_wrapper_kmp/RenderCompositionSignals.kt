package br.com.wave.flow_wrapper_kmp

/**
 * Inert hook letting an optional debug layer observe which render blocks are in composition,
 * WITHOUT the render path depending on the debug object. A published build with the debug
 * object stripped never installs an [observer], so the calls in RenderBlock are cheap
 * null-checked no-ops and nothing is tracked — removing FlowDebug cannot break rendering.
 * [FlowDebug.Renders] is what installs the observer.
 */
internal object RenderCompositionSignals {
    var observer: RenderCompositionObserver? = null
}

internal interface RenderCompositionObserver {
    fun onEnter(id: String, engine: String)

    fun onExit(id: String)
}
