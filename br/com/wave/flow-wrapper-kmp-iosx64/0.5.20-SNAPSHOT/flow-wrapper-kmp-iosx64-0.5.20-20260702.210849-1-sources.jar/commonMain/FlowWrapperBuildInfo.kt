package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-02T18:10:02.377335-03:00"
    const val GIT_SHA: String = "135f1f9"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT@2026-07-02T18:10:02.377335-03:00#135f1f9"
}