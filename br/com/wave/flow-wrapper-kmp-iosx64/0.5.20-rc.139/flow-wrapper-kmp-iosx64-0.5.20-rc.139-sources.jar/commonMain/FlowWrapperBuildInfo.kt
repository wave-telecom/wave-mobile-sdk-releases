package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-rc.139"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-07T11:34:03.16142-03:00"
    const val GIT_SHA: String = "fc82d14"
    const val GIT_BRANCH: String = "release/0.5.20"
    const val DESCRIPTION: String = "0.5.20-rc.139@2026-07-07T11:34:03.16142-03:00#fc82d14"
}