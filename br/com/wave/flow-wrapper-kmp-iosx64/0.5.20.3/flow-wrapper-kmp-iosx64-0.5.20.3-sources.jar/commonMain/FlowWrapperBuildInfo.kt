package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.3"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-22T11:04:00.66644-03:00"
    const val GIT_SHA: String = "1ce0262"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20.3@2026-07-22T11:04:00.66644-03:00#1ce0262"
}