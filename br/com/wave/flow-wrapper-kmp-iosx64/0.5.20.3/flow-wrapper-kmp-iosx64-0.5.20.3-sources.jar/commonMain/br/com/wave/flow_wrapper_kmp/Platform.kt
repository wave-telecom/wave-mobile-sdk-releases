package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator

expect fun platform(): String

internal expect fun platformLogDebug(tag: String, message: String)

/**
 * [onWebViewProcessGone] is invoked when the platform reports the WebView render process was
 * killed (memory reclaim while backgrounded). It returns `true` when a recovery (WebView
 * recreation + reload) was armed, `false` when the recovery budget is spent and the caller
 * should render the static error page instead.
 */
@Composable
internal expect fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
    onWebViewProcessGone: () -> Boolean,
): PlatformWebViewParams?

@Composable
internal expect fun rememberNativeHandlerWebViewFactory(
    onNativeBridgeMessage: (String) -> Unit,
    onWebViewProcessGone: () -> Boolean,
): ((WebViewFactoryParam) -> NativeWebView)?

internal expect object PlatformFlowWrapperWarmupLauncher {
    fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle?
}
