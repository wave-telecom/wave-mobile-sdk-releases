package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-rc.171"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-08-10T11:09:27.836046-03:00"
    const val GIT_SHA: String = "e740aa92"
    const val GIT_BRANCH: String = "release/0.6.0"
    const val DESCRIPTION: String = "0.6.0-rc.171@2026-08-10T11:09:27.836046-03:00#e740aa92"
}