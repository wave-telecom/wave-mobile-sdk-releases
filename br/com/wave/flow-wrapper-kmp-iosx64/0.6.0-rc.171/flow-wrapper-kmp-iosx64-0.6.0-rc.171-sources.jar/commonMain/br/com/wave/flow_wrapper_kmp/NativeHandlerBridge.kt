package br.com.wave.flow_wrapper_kmp

/**
 * `NativeHandler` is the SDK's one and only JS-visible bridge object, registered on
 * both platforms (see `Platform.android.kt`/`Platform.ios.kt`). This file adds the
 * session credential to its protocol instead of standing up a second bridge object
 * for it — two objects doing the same kind of native↔page conversation is
 * duplication a previous commit introduced (`WaveAuthBridge`) and this one removes.
 *
 * `window.NativeHandler.fetchWaveToken()` returns the current wave token, or an
 * empty string when the session has none (before `start`, or after `logout`). The
 * value does not change while a WebView stays mounted — the web SDK is expected to
 * call it once during its own init and again before any authenticated request, since
 * a new WebView load (a new session, or a re-mount after logout) is the only way it
 * moves.
 *
 * No version field or schema marker is part of this contract. The consumer
 * negotiates by checking whether the method exists
 * (`typeof window.NativeHandler.fetchWaveToken === 'function'`) before calling it —
 * the idiomatic feature-detection path in JavaScript, and the only one that works
 * while older app versions (without this method) are still in users' hands.
 */
internal const val NATIVE_HANDLER_BRIDGE_NAME = "NativeHandler"

// The single source of truth for the method name: both platform install sites call
// nativeHandlerFetchWaveTokenRedefineScript below rather than duplicating the string,
// so there is exactly one place this can ever drift between Android and iOS.
internal const val NATIVE_HANDLER_METHOD_FETCH_WAVE_TOKEN = "fetchWaveToken"

/**
 * The origin `NATIVE_HANDLER_BRIDGE_NAME`'s credential method must be scoped to when
 * a platform supports origin-restricted injection (see `Platform.android.kt`'s
 * `installNativeHandlerCredential`): the scheme and host (and port, if not the
 * scheme default) of [url], with no path — a foreign iframe the page embeds never
 * matches this and never sees the credential.
 *
 * Falls back to `"*"` (unrestricted) for a [url] with no readable scheme/host, which
 * only happens for a caller-constructed URL this SDK's own `EntryUrlProvider` would
 * never produce.
 */
internal fun nativeHandlerAllowedOriginFor(url: String): String {
    val schemeEnd = url.indexOf("://")
    if (schemeEnd < 0) return "*"
    val afterScheme = url.substring(schemeEnd + 3)
    val authorityEnd = afterScheme.indexOfFirst { it == '/' || it == '?' || it == '#' }
    val authority = if (authorityEnd >= 0) afterScheme.substring(0, authorityEnd) else afterScheme
    if (authority.isEmpty()) return "*"
    return url.substring(0, schemeEnd + 3) + authority
}

/**
 * Redefines `window.NativeHandler.fetchWaveToken` to return [token] (or an empty
 * string). Used to bake the initial value into a document-start script on both
 * platforms (see the platform-specific `rememberNativeHandlerWebViewFactory` actuals).
 */
internal fun nativeHandlerFetchWaveTokenRedefineScript(token: String?): String =
    "window.$NATIVE_HANDLER_BRIDGE_NAME=window.$NATIVE_HANDLER_BRIDGE_NAME||{};" +
        "window.$NATIVE_HANDLER_BRIDGE_NAME.$NATIVE_HANDLER_METHOD_FETCH_WAVE_TOKEN=" +
        "function(){return ${token.orEmpty().toNativeHandlerJsLiteral()};};"

// Wave tokens are JWT-shaped (base64url segments, A-Za-z0-9-_.) so this never has
// real work to do — kept anyway because the value crosses into a raw script string.
private fun String.toNativeHandlerJsLiteral(): String = buildString {
    append('"')
    this@toNativeHandlerJsLiteral.forEach { char ->
        when (char) {
            '\\' -> append("\\\\")
            '"' -> append("\\\"")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            else -> append(char)
        }
    }
    append('"')
}
