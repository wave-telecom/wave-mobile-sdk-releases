package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-rc.109"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-29T12:06:04.872075-03:00"
    const val GIT_SHA: String = "7663246"
    const val GIT_BRANCH: String = "release/0.5.17"
    const val DESCRIPTION: String = "0.5.17-rc.109@2026-06-29T12:06:04.872075-03:00#7663246"
}