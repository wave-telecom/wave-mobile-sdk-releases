package br.com.wave.flow_wrapper_kmp

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.multiplatform.webview.web.LoadingState
import com.multiplatform.webview.web.WebView
import com.multiplatform.webview.web.rememberWebViewNavigator
import com.multiplatform.webview.web.rememberWebViewState
import com.multiplatform.webview.setting.WebSettings
import br.com.wave.flows.kmp.generateWebViewAuthToken
import br.com.wave.flow_wrapper_kmp.featureflags.Feature
import br.com.wave.flow_wrapper_kmp.featureflags.FeatureFlags
import br.com.wave.flow_wrapper_kmp.generated.resources.Res
import br.com.wave.flow_wrapper_kmp.generated.resources.flow_wrapper_error_missing_entry_point
import br.com.wave.flow_wrapper_kmp.generated.resources.flow_wrapper_fallback_missing_entry_point
import org.jetbrains.compose.resources.stringResource

private const val DEFAULT_COMPONENT_ID = "balance-summary-1"
private const val NAVBAR_FLOW_PATH = "/flows/navbar"
private const val ORIGIN_NATIVE_HANDLER_BRIDGE = "native_handler_bridge"
private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"

// Test markers on the REAL render branches (no fakes): a UI test asserts which engine
// composed for a given contract, while the WebView/native content still renders for real.
internal const val RENDER_ENGINE_NATIVE_TAG = "render_engine_native"
internal const val RENDER_ENGINE_WEBVIEW_TAG = "render_engine_webview"

/**
 * Default interval between scroll-callback emissions, in milliseconds; pass `0`
 * to disable throttling. Re-exported for hybrid hosts, which cannot see the
 * renderer module that owns the value (single source of truth).
 */
const val DEFAULT_SCROLL_THROTTLE_MS: Long =
    br.com.wave.flows.kmp.DEFAULT_SCROLL_THROTTLE_MS

private enum class FlowWrapperErrorCode(val value: String) {
    MissingEntryPoint("MISSING_ENTRY_POINT"),
}

internal fun isNavbarFlowPath(path: String): Boolean = path.substringBefore('?') == NAVBAR_FLOW_PATH

internal fun WebSettings.applyFlowWrapperDefaults(entryPath: String) {
    androidWebSettings.domStorageEnabled = true

    // Pin scale on every flow (drives the injected viewport `user-scalable=no`).
    supportZoom = false

    if (!isNavbarFlowPath(entryPath)) return

    // Technical debt: SDK is temporarily coupled to the navbar flow until this policy
    // can move to host configuration or be fixed in the web experience itself.
    iOSWebSettings.bounces = false
    iOSWebSettings.scrollEnabled = false
    iOSWebSettings.showHorizontalScrollIndicator = false
    iOSWebSettings.showVerticalScrollIndicator = false
}

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    onScroll: ((ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
    modifier: Modifier = Modifier,
) {
    val effectivePullToRefresh = pullToRefreshEnabled && scroll
    val errorMissingEntryPoint = stringResource(Res.string.flow_wrapper_error_missing_entry_point)
    val fallbackMissingEntryPoint = stringResource(Res.string.flow_wrapper_fallback_missing_entry_point)

    val target = RenderTargetRef.of(componentId, flowId)
    val renderNatively = target != null && nativeRenderBridgeDelegate.shouldRenderNatively(target, scroll)
    LaunchedEffect(renderNatively, flowId, componentId, scroll) {
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "render_dispatch engine=${if (renderNatively) "native" else "webview"} " +
                "flowId=$flowId componentId=$componentId scroll=$scroll",
        )
    }
    if (renderNatively && target != null) {
        when (rememberNativeRenderOutcome(target)) {
            NativeRenderOutcome.RenderNative, NativeRenderOutcome.AwaitNative -> {
                TrackRenderComposition(target.id(), "kmp")
                nativeRenderBridgeDelegate.RenderBlock(
                    target = target,
                    onEvent = onEvent,
                    scroll = scroll,
                    pullToRefreshEnabled = effectivePullToRefresh,
                    onScroll = onScroll,
                    scrollThrottleMs = scrollThrottleMs,
                    modifier = modifier.testTag(RENDER_ENGINE_NATIVE_TAG),
                )
                return
            }
            NativeRenderOutcome.FallbackWebView -> {
                // TODO(webview-removal): once the WebView route no longer exists, route to
                // an ERROR screen here instead of falling back to the WebView below.
                LaunchedEffect(target) {
                    platformLogDebug(FLOW_WRAPPER_LOG_TAG, "native_render_fallback_webview target=$target")
                }
            }
        }
    }

    when (target) {
        null -> {
            onEvent?.invoke(
                SDKEvent.Error(
                    componentId = DEFAULT_COMPONENT_ID,
                    code = FlowWrapperErrorCode.MissingEntryPoint.value,
                    message = errorMissingEntryPoint,
                )
            )
            FlowWrapperFallback(
                modifier = modifier,
                message = fallbackMissingEntryPoint,
            )
        }
        else -> {
            // TODO(TD-4): onScroll is not forwarded to the WebView variant.
            // The WebView scroll position is opaque to the host; wiring it
            // requires a JS↔native bridge message or a platform scroll-observer.
            // See docs/tech-debt-inventory.md TD-4.
            TrackRenderComposition(target.id(), "webview")
            FlowWrapperViewInternal(
                modifier = modifier.testTag(RENDER_ENGINE_WEBVIEW_TAG),
                entryPath = target.path(),
                entryId = target.id(),
                scroll = scroll,
                onEvent = onEvent,
            )
        }
    }
}

/**
 * The active Flow theme's surface colour, for host chrome that PRESENTS a
 * [RenderBlock] but is composed OUTSIDE it — e.g. a host-owned bottom-sheet
 * shell whose background would otherwise be a hardcoded constant and ignore
 * dark mode. Mode-aware: near-white in light, dark in dark. Returns [fallback]
 * when no theme is configured. Delegates to the native SDK's resolver so the
 * shell matches the themed content inside.
 */
@Composable
fun rememberFlowThemeSurfaceColor(fallback: Color): Color =
    br.com.wave.flows.kmp.rememberFlowThemeSurfaceColor(fallback)

// Reports this block's presence in composition to the optional debug observer. Null in a
// published build without FlowDebug — a cheap no-op, nothing tracked.
@Composable
private fun TrackRenderComposition(id: String, engine: String) {
    DisposableEffect(id, engine) {
        RenderCompositionSignals.observer?.onEnter(id, engine)
        onDispose { RenderCompositionSignals.observer?.onExit(id) }
    }
}

internal fun handleNativeBridgeMessage(
    params: String,
    onCallbackReceived: (NativeCallbackMessage) -> Unit,
): String {
    parseNativeBridgeParams(params)?.let(onCallbackReceived)
    return "{}"
}

internal fun parseNativeBridgeParams(params: String): NativeCallbackMessage? {
    if (params.isBlank()) return null
    return nativeCallbackMessageFromPayload(params)
}

private fun emitCallbackEvent(
    onEvent: ((SDKEvent) -> Unit)?,
    callbackMessage: NativeCallbackMessage,
    origin: String,
) {
    callbackMessage.toActionTrackedEvent(origin)?.let { actionEvent ->
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "action_tracked origin=$origin type=${actionEvent.type} payload=${actionEvent.payload}",
        )
        onEvent?.invoke(actionEvent)
        return
    }

    platformLogDebug(
        FLOW_WRAPPER_LOG_TAG,
        "callback origin=$origin type=${callbackMessage.type} payload=${callbackMessage.payload.asLogPayload()}",
    )
    onEvent?.invoke(
        SDKEvent.Callback(
            type = callbackMessage.type,
            payload = callbackMessage.payload,
            origin = origin,
        )
    )
}

private fun String.asLogPayload(maxLength: Int = 320): String {
    return if (length <= maxLength) this else take(maxLength) + "..."
}

@Composable
private fun FlowWrapperFallback(modifier: Modifier, message: String) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = message, style = MaterialTheme.typography.bodyMedium)
    }
}

private val HOST_SCROLL_PLACEHOLDER_HEIGHT = 600.dp

@Composable
internal fun FlowWrapperViewInternal(
    entryPath: String,
    entryId: String,
    modifier: Modifier = Modifier,
    scroll: Boolean = true,
    onEvent: ((SDKEvent) -> Unit)? = null,
) {
    val currentOnEventState = rememberUpdatedState(onEvent)
    val config = FlowWrapper.currentConfig()
    val flowWrapperConfig = config.flowWrapperConfig
    val resolvedEntryPath = remember(entryPath) { FlowWrapper.resolveEntryPathForRendering(entryPath) }

    val themeMode = FlowWrapper.currentThemeMode()
    val systemInDarkTheme = isSystemInDarkTheme()
    val themeQueryParam = resolveThemeQueryParam(themeMode, systemInDarkTheme)

    val authToken = remember(config.msisdn, config.apiKey) {
        generateWebViewAuthToken(config.msisdn, config.apiKey)
    }

    val baseUrl =
        remember(
            config.msisdn,
            config.environment,
            resolvedEntryPath,
            flowWrapperConfig.entryUrlProvider,
            themeQueryParam,
            authToken,
        ) {
            flowWrapperConfig.entryUrlProvider.urlFor(
                EntryUrlContext(
                    msisdn = config.msisdn,
                    environment = config.environment,
                    path = resolvedEntryPath,
                    themeMode = themeQueryParam,
                    token = authToken,
                )
            )
        }
    val refreshUrl =
        remember(
            config.msisdn,
            config.environment,
            resolvedEntryPath,
            flowWrapperConfig.entryUrlProvider,
            themeQueryParam,
            authToken,
        ) {
            flowWrapperConfig.entryUrlProvider.urlFor(
                EntryUrlContext(
                    msisdn = config.msisdn,
                    environment = config.environment,
                    path = resolvedEntryPath,
                    themeMode = themeQueryParam,
                    token = authToken,
                    refresh = true,
                )
            )
        }
    val requestedRefreshTick = FlowWrapper.webViewRefreshTick(entryId) // observable read: wakes this block when armed while composed
    // remember on (baseUrl, refreshUrl, requestedRefreshTick) so entryUrl is NOT re-derived from
    // the mutable applied-tick read on every recomposition: it only recomputes on a real arm
    // (requestedRefreshTick changes) or a natural URL rebuild, never on an incidental recompose
    // (e.g. the page-height callback) after the arm is marked applied.
    val entryUrl =
        remember(baseUrl, refreshUrl, requestedRefreshTick) {
            resolveEntryUrl(
                baseUrl,
                refreshUrl,
                requestedRefreshTick,
                FlowWrapper.webViewAppliedRefreshTick(entryId),
            )
        }
    // Mark the arm consumed AFTER the (possible) refresh load is committed. The applied
    // marker is non-observable and entryUrl is now frozen by `remember`, so this write never
    // flips entryUrl back: it stays on the refresh URL until the next natural rebuild — no
    // second WebView recreation, no double load.
    LaunchedEffect(entryId, requestedRefreshTick) {
        FlowWrapper.markWebViewRefreshApplied(entryId, requestedRefreshTick)
    }

    var measuredHeightPx by remember(entryUrl) { mutableStateOf<Int?>(null) }

    val onNativeBridgeMessage: (String) -> Unit = { data ->
        handleNativeBridgeMessage(data) { callbackMessage ->
            if (callbackMessage.type == PAGE_HEIGHT_CALLBACK_TYPE) {
                extractPageHeightFromPayload(callbackMessage.payload)
                    ?.let { measuredHeightPx = it }
                return@handleNativeBridgeMessage
            }
            FlowWrapper.updateRuntimeStateFromCallback(
                entryPath = entryPath,
                callbackMessage = callbackMessage,
            )
            emitCallbackEvent(
                onEvent = currentOnEventState.value,
                callbackMessage = callbackMessage,
                origin = ORIGIN_NATIVE_HANDLER_BRIDGE,
            )
        }
    }

    val outerModifier =
        if (scroll) {
            modifier.fillMaxSize()
        } else {
            val heightDp = measuredHeightPx?.dp ?: HOST_SCROLL_PLACEHOLDER_HEIGHT
            modifier.fillMaxWidth().height(heightDp)
        }

    // key on (entryUrl, requestedRefreshTick): entryUrl covers path/msisdn/theme changes, but a
    // second consecutive refresh() with no natural URL rebuild in between resolves
    // to the SAME refreshUrl entryUrl is already frozen at, so entryUrl alone would not change and
    // the WebView would not recreate — the tick forces recreation on every new arm regardless.
    key(entryUrl, requestedRefreshTick) {
        val navigator = rememberWebViewNavigator()
        val state =
            rememberWebViewState(entryUrl) {
                applyFlowWrapperDefaults(resolvedEntryPath)
            }

        LaunchedEffect(state.loadingState) {
            if (state.loadingState is LoadingState.Finished) {
                platformLogDebug(FLOW_WRAPPER_LOG_TAG, "render_loaded engine=webview componentId=$entryId")
                currentOnEventState.value?.invoke(SDKEvent.ComponentLoaded(componentId = entryId))
            }
        }

        val platformWebViewParams = rememberFlowWrapperPlatformWebViewParams(
            navigator = navigator,
            onNativeBridgeMessage = onNativeBridgeMessage,
        )

        val webViewFactory = rememberNativeHandlerWebViewFactory(
            onNativeBridgeMessage = onNativeBridgeMessage,
        )

        Box(modifier = outerModifier) {
            WebView(
                state = state,
                navigator = navigator,
                platformWebViewParams = platformWebViewParams,
                factory = webViewFactory,
                modifier = Modifier
                    .padding()
                    .fillMaxSize(),
            )
        }
    }
}

/**
 * Selects the URL to load: when the host-requested refresh tick differs from the last
 * applied tick a one-shot cache bypass is pending, so [refreshUrl] loads exactly once;
 * otherwise [baseUrl]. Both ticks are FlowWrapper-singleton-scoped, so a refresh arm
 * issued while this block was NOT composed survives a dispose/remount and still fires on
 * the next load.
 */
internal fun resolveEntryUrl(
    baseUrl: String,
    refreshUrl: String,
    requestedRefreshTick: Int,
    appliedRefreshTick: Int,
): String = if (requestedRefreshTick != appliedRefreshTick) refreshUrl else baseUrl

internal fun resolveThemeQueryParam(mode: FlowThemeMode, systemInDarkTheme: Boolean): String {
    // Dark mode gated off: lock to light (visual theming not validated yet) — never follow
    // the system into dark.
    if (!FeatureFlags.isEnabled(Feature.DarkMode)) return "light"
    return when (mode) {
        FlowThemeMode.Light -> "light"
        FlowThemeMode.Dark -> "dark"
        FlowThemeMode.System -> if (systemInDarkTheme) "dark" else "light"
    }
}
