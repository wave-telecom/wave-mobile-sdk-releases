package br.com.wave.flow_wrapper_kmp

private const val BASE_URL_DEV = "https://dev.journeys.telcel.wavebybemobi.com"
private const val BASE_URL_PRD = "https://journeys.telcel.wavebybemobi.com"

data class EntryUrlContext(
    val msisdn: String,
    val environment: FlowWrapperEnvironment,
    val path: String,
    val themeMode: String? = null,
    // Encrypted BTF token, when the session has a new-format key; null for legacy
    // keys, in which case the WebView loads with only externalCode (pre-BTF behavior).
    val token: String? = null,
    val refresh: Boolean = false,
)

fun interface EntryUrlProvider {
    fun urlFor(context: EntryUrlContext): String
}

object DefaultEntryUrlProvider : EntryUrlProvider {
    override fun urlFor(context: EntryUrlContext): String {
        val baseUrl = when (context.environment) {
            FlowWrapperEnvironment.DEV -> BASE_URL_DEV
            FlowWrapperEnvironment.PRD -> BASE_URL_PRD
        }
        val externalCode = context.msisdn.filter(Char::isDigit)
        val url = StringBuilder("$baseUrl${context.path}${context.path.querySeparator()}externalCode=$externalCode")
        // token is base64url-no-padding (A-Za-z0-9-_), so it is URL-safe as-is.
        context.token?.takeIf(String::isNotBlank)?.let { url.append("&token=").append(it) }
        context.themeMode?.let { url.append("&themeMode=").append(it) }
        if (context.refresh) url.append("&refresh=true")
        return url.toString()
    }
}

private fun String.querySeparator(): Char = if ('?' in this) '&' else '?'
