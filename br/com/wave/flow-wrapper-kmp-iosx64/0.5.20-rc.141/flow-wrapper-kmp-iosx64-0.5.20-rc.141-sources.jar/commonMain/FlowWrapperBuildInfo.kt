package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-rc.141"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-07T11:55:03.975842-03:00"
    const val GIT_SHA: String = "a7e1f5d"
    const val GIT_BRANCH: String = "release/0.5.20"
    const val DESCRIPTION: String = "0.5.20-rc.141@2026-07-07T11:55:03.975842-03:00#a7e1f5d"
}