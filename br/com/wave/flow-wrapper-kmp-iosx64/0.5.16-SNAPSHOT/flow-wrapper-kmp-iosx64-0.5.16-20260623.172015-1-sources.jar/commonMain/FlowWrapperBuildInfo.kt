package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-SNAPSHOT"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-23T14:21:55.46249-03:00"
    const val GIT_SHA: String = "42d93fa"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.16-SNAPSHOT@2026-06-23T14:21:55.46249-03:00#42d93fa"
}