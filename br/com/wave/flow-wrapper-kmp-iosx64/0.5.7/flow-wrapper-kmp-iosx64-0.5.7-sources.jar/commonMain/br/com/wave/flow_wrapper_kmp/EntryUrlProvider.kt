package br.com.wave.flow_wrapper_kmp

private const val BASE_URL_DEV = "https://telcel-dev-wave-journeys-web.vercel.app"
private const val BASE_URL_PRD = "https://telcel-prd-wave-journeys-web.vercel.app"

data class EntryUrlContext(
    val msisdn: String,
    val environment: FlowWrapperEnvironment,
    val path: String,
)

fun interface EntryUrlProvider {
    fun urlFor(context: EntryUrlContext): String
}

object DefaultEntryUrlProvider : EntryUrlProvider {
    override fun urlFor(context: EntryUrlContext): String {
        val baseUrl = when (context.environment) {
            FlowWrapperEnvironment.DEV -> BASE_URL_DEV
            FlowWrapperEnvironment.PRD -> BASE_URL_PRD
        }
        val separator = if ('?' in context.path) '&' else '?'
        val externalCode = context.msisdn.filter(Char::isDigit)
        return "$baseUrl${context.path}${separator}externalCode=$externalCode"
    }
}
