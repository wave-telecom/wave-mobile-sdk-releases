package br.com.wave.flow_wrapper_kmp

import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

internal data class DecodedApiKey(
    val environment: FlowWrapperEnvironment,
)

internal object ApiKeyDecoder {

    private const val FIELD_ENVIRONMENT = "environment"
    private const val JWT_PARTS = 3
    private const val JWT_PAYLOAD_INDEX = 1

    @OptIn(ExperimentalEncodingApi::class)
    fun decode(apiKey: String): DecodedApiKey {
        val parts = apiKey.split('.')
        require(parts.size == JWT_PARTS) {
            "apiKey is not a valid JWT (expected $JWT_PARTS parts, got ${parts.size})."
        }

        val payload = parts[JWT_PAYLOAD_INDEX]
        val json = runCatching { Base64.UrlSafe.decode(payload).decodeToString() }
            .recoverCatching { Base64.decode(payload).decodeToString() }
            .getOrElse { cause ->
                throw IllegalArgumentException(
                    "apiKey payload is not a valid base64-encoded value.",
                    cause,
                )
            }

        val environmentRaw = TopLevelJsonFieldExtractor(json).stringField(FIELD_ENVIRONMENT)

        require(!environmentRaw.isNullOrBlank()) {
            "apiKey payload must contain a non-blank '$FIELD_ENVIRONMENT' field."
        }

        val environment = runCatching {
            FlowWrapperEnvironment.valueOf(environmentRaw.trim().uppercase())
        }.getOrElse { cause ->
            throw IllegalArgumentException(
                "apiKey contains an unknown environment: '$environmentRaw'.",
                cause,
            )
        }

        return DecodedApiKey(environment = environment)
    }
}
