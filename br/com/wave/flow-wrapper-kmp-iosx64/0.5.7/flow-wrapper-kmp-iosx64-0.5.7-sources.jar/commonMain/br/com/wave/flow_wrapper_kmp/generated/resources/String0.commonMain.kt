@file:OptIn(InternalResourceApi::class)

package br.com.wave.flow_wrapper_kmp.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/br.com.wave.flow_wrapper_kmp.generated.resources/"

@delegate:ResourceContentHash(-747_396_985)
internal val Res.string.flow_wrapper_back: StringResource by lazy {
      StringResource("string:flow_wrapper_back", "flow_wrapper_back", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 33),
      ))
    }

@delegate:ResourceContentHash(694_458_754)
internal val Res.string.flow_wrapper_error_flow_id_not_implemented: StringResource by lazy {
      StringResource("string:flow_wrapper_error_flow_id_not_implemented", "flow_wrapper_error_flow_id_not_implemented", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 44, 122),
      ))
    }

@delegate:ResourceContentHash(-1_784_467_426)
internal val Res.string.flow_wrapper_error_missing_entry_point: StringResource by lazy {
      StringResource("string:flow_wrapper_error_missing_entry_point", "flow_wrapper_error_missing_entry_point", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 167, 106),
      ))
    }

@delegate:ResourceContentHash(917_318_384)
internal val Res.string.flow_wrapper_error_navigation_policy: StringResource by lazy {
      StringResource("string:flow_wrapper_error_navigation_policy", "flow_wrapper_error_navigation_policy", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 274, 76),
      ))
    }

@delegate:ResourceContentHash(361_150_457)
internal val Res.string.flow_wrapper_fallback_flow_id_not_implemented: StringResource by lazy {
      StringResource("string:flow_wrapper_fallback_flow_id_not_implemented", "flow_wrapper_fallback_flow_id_not_implemented", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 351, 117),
      ))
    }

@delegate:ResourceContentHash(101_783_977)
internal val Res.string.flow_wrapper_fallback_missing_entry_point: StringResource by lazy {
      StringResource("string:flow_wrapper_fallback_missing_entry_point", "flow_wrapper_fallback_missing_entry_point", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 469, 117),
      ))
    }

@delegate:ResourceContentHash(1_108_879_827)
internal val Res.string.flow_wrapper_fullscreen_title_default: StringResource by lazy {
      StringResource("string:flow_wrapper_fullscreen_title_default", "flow_wrapper_fullscreen_title_default", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 587, 69),
      ))
    }

@delegate:ResourceContentHash(217_843_203)
internal val Res.string.flow_wrapper_title_default: StringResource by lazy {
      StringResource("string:flow_wrapper_title_default", "flow_wrapper_title_default", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 657, 46),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("flow_wrapper_back", Res.string.flow_wrapper_back)
  map.put("flow_wrapper_error_flow_id_not_implemented", Res.string.flow_wrapper_error_flow_id_not_implemented)
  map.put("flow_wrapper_error_missing_entry_point", Res.string.flow_wrapper_error_missing_entry_point)
  map.put("flow_wrapper_error_navigation_policy", Res.string.flow_wrapper_error_navigation_policy)
  map.put("flow_wrapper_fallback_flow_id_not_implemented", Res.string.flow_wrapper_fallback_flow_id_not_implemented)
  map.put("flow_wrapper_fallback_missing_entry_point", Res.string.flow_wrapper_fallback_missing_entry_point)
  map.put("flow_wrapper_fullscreen_title_default", Res.string.flow_wrapper_fullscreen_title_default)
  map.put("flow_wrapper_title_default", Res.string.flow_wrapper_title_default)
}
