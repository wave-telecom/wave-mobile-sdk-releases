package br.com.wave.flow_wrapper_kmp

internal data class RuntimeConfig(
    val msisdn: String,
    val apiKey: String,
    val environment: FlowWrapperEnvironment,
    val flowWrapperConfig: FlowWrapperConfig,
)

object FlowWrapper {
    private var runtimeConfig: RuntimeConfig? = null

    internal fun resetForTests() {
        runtimeConfig = null
    }

    fun start(apiKey: String, msisdn: String, config: FlowWrapperConfig = FlowWrapperConfig()) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        val decoded = ApiKeyDecoder.decode(sanitizedApiKey)

        runtimeConfig = RuntimeConfig(
            msisdn = sanitizedMsisdn,
            apiKey = sanitizedApiKey,
            environment = decoded.environment,
            flowWrapperConfig = config,
        )
    }

    private fun requireConfig(): RuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentConfig(): RuntimeConfig = requireConfig()
}
