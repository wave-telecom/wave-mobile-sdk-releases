package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator
import com.multiplatform.webview.web.defaultWebViewFactory
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.readBytes
import platform.Foundation.NSData
import platform.Foundation.NSJSONSerialization
import platform.WebKit.WKScriptMessage
import platform.WebKit.WKScriptMessageHandlerProtocol
import platform.WebKit.WKUserContentController
import platform.darwin.NSObject

// Primary handler name: matches window.webkit.messageHandlers.NativeHandler (case-sensitive)
private const val IOS_SCRIPT_MESSAGE_HANDLER_NAME = "NativeHandler"

// Legacy handler name: kept for backward compatibility during transition
private const val IOS_SCRIPT_MESSAGE_HANDLER_NAME_LEGACY = "nativeHandler"

@OptIn(ExperimentalForeignApi::class)
private fun NSData.toUtf8String(): String? {
    val length = this.length.toInt()
    if (length == 0) return null
    return this.bytes?.readBytes(length)?.decodeToString()
}

private class NativeHandlerScriptMessageHandler(
    private val onDataReceived: (String) -> Unit,
) : NSObject(), WKScriptMessageHandlerProtocol {

    @OptIn(ExperimentalForeignApi::class)
    override fun userContentController(
        userContentController: WKUserContentController,
        didReceiveScriptMessage: WKScriptMessage,
    ) {
        val body = didReceiveScriptMessage.body
        val payload: String? = when (body) {
            is String -> body
            else -> {
                if (body != null) {
                    val jsonData = NSJSONSerialization.dataWithJSONObject(body, options = 0u, error = null)
                    jsonData?.toUtf8String()
                } else null
            }
        }
        if (payload != null) {
            onDataReceived(payload)
        }
    }
}

actual fun platform() = "iOS"

internal actual fun platformLogDebug(tag: String, message: String) {
    println("[$tag] $message")
}

@Composable
internal actual fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
): PlatformWebViewParams? {
    navigator
    onNativeBridgeMessage
    return null
}

@Composable
internal actual fun rememberNativeHandlerWebViewFactory(
    onNativeBridgeMessage: (String) -> Unit,
): ((WebViewFactoryParam) -> NativeWebView)? {
    val currentCallback = rememberUpdatedState(onNativeBridgeMessage)
    val messageHandler = remember {
        NativeHandlerScriptMessageHandler { data -> currentCallback.value(data) }
    }
    return remember(messageHandler) {
        { param: WebViewFactoryParam ->
            val config = param.config
            config.userContentController.addScriptMessageHandler(
                scriptMessageHandler = messageHandler,
                name = IOS_SCRIPT_MESSAGE_HANDLER_NAME,
            )
            // Backward compatibility: also register legacy lowercase name during transition
            config.userContentController.addScriptMessageHandler(
                scriptMessageHandler = messageHandler,
                name = IOS_SCRIPT_MESSAGE_HANDLER_NAME_LEGACY,
            )
            defaultWebViewFactory(param)
        }
    }
}
