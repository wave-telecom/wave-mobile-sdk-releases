package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT.1"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-19T17:54:21.889215-03:00"
    const val GIT_SHA: String = "b2f3251"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT.1@2026-06-19T17:54:21.889215-03:00#b2f3251"
}