package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT-79-gb2f3251"
    const val COMPILED_AT_BRT: String = "2026-06-19T17:54:07.444876-03:00"
    const val GIT_SHA: String = "b2f3251"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT-79-gb2f3251@2026-06-19T17:54:07.444876-03:00#b2f3251"
}