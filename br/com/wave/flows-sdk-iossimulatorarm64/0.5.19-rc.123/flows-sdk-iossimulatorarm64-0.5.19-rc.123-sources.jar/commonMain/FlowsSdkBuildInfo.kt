package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.19-SNAPSHOT-4-g823a1ec"
    const val COMPILED_AT_BRT: String = "2026-07-02T17:36:13.29223-03:00"
    const val GIT_SHA: String = "823a1ec"
    const val GIT_BRANCH: String = "release/0.5.19"
    const val DESCRIPTION: String = "0.5.19-SNAPSHOT-4-g823a1ec@2026-07-02T17:36:13.29223-03:00#823a1ec"
}