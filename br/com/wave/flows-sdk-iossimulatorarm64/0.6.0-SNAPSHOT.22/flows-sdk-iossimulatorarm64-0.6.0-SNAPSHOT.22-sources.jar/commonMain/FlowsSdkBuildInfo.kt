package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.20-0-g7f76412"
    const val COMPILED_AT_BRT: String = "2026-05-22T16:26:05.80908-03:00"
    const val GIT_SHA: String = "7f76412"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.20-0-g7f76412@2026-05-22T16:26:05.80908-03:00#7f76412"
}