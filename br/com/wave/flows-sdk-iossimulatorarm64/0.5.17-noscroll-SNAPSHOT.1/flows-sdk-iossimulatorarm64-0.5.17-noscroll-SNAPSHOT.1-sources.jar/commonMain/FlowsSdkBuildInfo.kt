package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-2-g49be4a0"
    const val COMPILED_AT_BRT: String = "2026-07-02T13:34:28.634501-03:00"
    const val GIT_SHA: String = "49be4a0"
    const val GIT_BRANCH: String = "chore/disable-scroll-callback-snapshot"
    const val DESCRIPTION: String = "0.5.17-2-g49be4a0@2026-07-02T13:34:28.634501-03:00#49be4a0"
}