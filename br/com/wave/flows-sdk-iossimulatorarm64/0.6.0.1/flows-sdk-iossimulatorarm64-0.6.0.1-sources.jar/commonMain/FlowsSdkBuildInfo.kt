package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-6-g70e34657"
    const val COMPILED_AT_BRT: String = "2026-08-14T14:18:11.014097-03:00"
    const val GIT_SHA: String = "70e34657"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.6.0-6-g70e34657@2026-08-14T14:18:11.014097-03:00#70e34657"
}