package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT.1-2-gf8eb1a3"
    const val COMPILED_AT_BRT: String = "2026-06-22T11:19:44.689008-03:00"
    const val GIT_SHA: String = "f8eb1a3"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT.1-2-gf8eb1a3@2026-06-22T11:19:44.689008-03:00#f8eb1a3"
}