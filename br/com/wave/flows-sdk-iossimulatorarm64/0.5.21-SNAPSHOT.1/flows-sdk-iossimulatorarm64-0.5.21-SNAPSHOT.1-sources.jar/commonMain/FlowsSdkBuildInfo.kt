package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-2-gbacb8b1"
    const val COMPILED_AT_BRT: String = "2026-07-07T12:18:57.606169-03:00"
    const val GIT_SHA: String = "bacb8b1"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-2-gbacb8b1@2026-07-07T12:18:57.606169-03:00#bacb8b1"
}