package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-SNAPSHOT-25-g7663246"
    const val COMPILED_AT_BRT: String = "2026-06-29T12:05:42.709373-03:00"
    const val GIT_SHA: String = "7663246"
    const val GIT_BRANCH: String = "release/0.5.17"
    const val DESCRIPTION: String = "0.5.17-SNAPSHOT-25-g7663246@2026-06-29T12:05:42.709373-03:00#7663246"
}