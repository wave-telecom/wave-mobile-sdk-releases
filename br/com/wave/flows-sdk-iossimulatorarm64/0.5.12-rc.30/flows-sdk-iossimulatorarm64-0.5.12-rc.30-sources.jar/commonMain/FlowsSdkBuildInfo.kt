package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.12-SNAPSHOT.2-1-g7e7048e"
    const val COMPILED_AT_BRT: String = "2026-06-02T14:57:20.872838-03:00"
    const val GIT_SHA: String = "7e7048e"
    const val GIT_BRANCH: String = "release/0.5.12"
    const val DESCRIPTION: String = "0.5.12-SNAPSHOT.2-1-g7e7048e@2026-06-02T14:57:20.872838-03:00#7e7048e"
}