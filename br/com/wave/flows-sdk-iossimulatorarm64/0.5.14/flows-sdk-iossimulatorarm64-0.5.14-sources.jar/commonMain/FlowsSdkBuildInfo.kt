package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.13-3-g36793c4"
    const val COMPILED_AT_BRT: String = "2026-06-12T16:56:03.056916-03:00"
    const val GIT_SHA: String = "36793c4"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.13-3-g36793c4@2026-06-12T16:56:03.056916-03:00#36793c4"
}