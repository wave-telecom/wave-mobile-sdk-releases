package br.com.wave.flows.kmp

import coil3.PlatformContext

internal actual fun platformImageLoaderContext(): PlatformContext {
    return PlatformContext.INSTANCE
}
