package br.com.wave.flows.kmp

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.toKString
import platform.Foundation.NSBundle
import platform.UIKit.UIDevice
import platform.UIKit.UIUserInterfaceIdiomPad
import platform.UIKit.UIUserInterfaceIdiomPhone
import platform.posix.uname
import platform.posix.utsname

internal actual object PlatformDeviceInfoProvider {

    // iOS reads everything from UIDevice/NSBundle globals — no host context needed.
    actual fun setHostContext(context: Any?) = Unit

    @OptIn(ExperimentalForeignApi::class)
    actual fun collect(): PlatformDeviceInfo {
        val device = UIDevice.currentDevice
        val bundle = NSBundle.mainBundle
        val appVersion =
            bundle.objectForInfoDictionaryKey("CFBundleShortVersionString") as? String
        val appBuild =
            bundle.objectForInfoDictionaryKey("CFBundleVersion") as? String
        val hardwareModel = memScoped {
            val systemInfo = alloc<utsname>()
            uname(systemInfo.ptr)
            systemInfo.machine.toKString()
        }
        val deviceType = when (device.userInterfaceIdiom) {
            UIUserInterfaceIdiomPad -> "TABLET"
            UIUserInterfaceIdiomPhone -> "PHONE"
            else -> null
        }
        return PlatformDeviceInfo(
            sdkChannel = "MOBILE_IOS_KMP",
            dispositivo = hardwareModel,
            deviceType = deviceType,
            so = device.systemName(),
            soVersion = device.systemVersion(),
            appVersion = appVersion,
            appVersionCode = appBuild,
        )
    }
}
