package br.com.wave.flows.kmp

import kotlinx.cinterop.ExperimentalForeignApi
import platform.darwin.dispatch_async
import platform.darwin.dispatch_get_main_queue

@OptIn(ExperimentalForeignApi::class)
internal actual fun runOnUiThread(block: () -> Unit) {
    dispatch_async(dispatch_get_main_queue()) {
        block()
    }
}
