package br.com.wave.flows.kmp

import br.com.wave.flows.kmp.runtime.RuntimeLogger
import platform.Foundation.NSLog

private const val SDK_LOG_TAG = "WaveFlowsSDK"

internal actual fun platformRuntimeLogger(): RuntimeLogger = IosRuntimeLogger

private object IosRuntimeLogger : RuntimeLogger {
    override fun debug(message: String) {
        NSLog("[$SDK_LOG_TAG][DEBUG] %s", message)
    }

    override fun info(message: String) {
        NSLog("[$SDK_LOG_TAG][INFO] %s", message)
    }

    override fun warn(message: String) {
        NSLog("[$SDK_LOG_TAG][WARN] %s", message)
    }

    override fun error(message: String, throwable: Throwable?) {
        NSLog("[$SDK_LOG_TAG][ERROR] %s", message)
    }
}
