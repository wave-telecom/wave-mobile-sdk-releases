package br.com.wave.flows.kmp

import platform.Foundation.NSTemporaryDirectory

internal actual fun platformWarmupCacheDir(): String? {
    val tempDir = NSTemporaryDirectory().trim()
    if (tempDir.isEmpty()) return null
    return "$tempDir/wave-flows-warmup"
}
