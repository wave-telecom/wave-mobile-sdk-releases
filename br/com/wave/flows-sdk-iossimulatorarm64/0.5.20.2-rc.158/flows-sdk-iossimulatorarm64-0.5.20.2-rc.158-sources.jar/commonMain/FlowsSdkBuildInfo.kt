package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.1-2-g263596f"
    const val COMPILED_AT_BRT: String = "2026-07-22T09:56:02.608123-03:00"
    const val GIT_SHA: String = "263596f"
    const val GIT_BRANCH: String = "release/0.5.20.2"
    const val DESCRIPTION: String = "0.5.20.1-2-g263596f@2026-07-22T09:56:02.608123-03:00#263596f"
}