package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import br.com.wave.flows.kmp.composeblocks.RenderBlockImageContent
import coil3.compose.AsyncImage

internal val FlowRenderBlockImageContent: RenderBlockImageContent =
    { model, contentDescription, modifier, contentScale, colorFilter ->
        val imageLoader = FlowWrapper.requireConfig().imageLoader
        AsyncImage(
            model = model,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
            colorFilter = colorFilter,
            imageLoader = imageLoader,
        )
    }
