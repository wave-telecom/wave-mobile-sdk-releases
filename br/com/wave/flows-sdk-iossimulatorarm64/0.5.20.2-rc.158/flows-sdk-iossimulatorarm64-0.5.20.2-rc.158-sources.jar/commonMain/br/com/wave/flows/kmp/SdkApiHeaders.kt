package br.com.wave.flows.kmp

import io.ktor.client.plugins.api.createClientPlugin
import kotlin.concurrent.Volatile

// Headers attached to every BFF request for the session. Held as an immutable
// map behind a [Volatile] ref so the warmup coroutine and the caller thread
// need no lock — writes swap the whole map atomically.
internal object SdkApiHeaderStore {

    @Volatile
    private var headers: Map<String, String> = emptyMap()

    fun configure(values: Map<String, String>) {
        headers = values
            .filterKeys { it.isNotBlank() }
            .filterValues { it.isNotBlank() }
            .toMap()
    }

    fun current(): Map<String, String> = headers

    fun clear() {
        headers = emptyMap()
    }
}

// Applies the stored headers; never overwrites one already on the request, so
// a per-call header wins over the session default. Installed on the BFF client.
internal val SdkApiHeaders = createClientPlugin("SdkApiHeaders") {
    onRequest { request, _ ->
        SdkApiHeaderStore.current().forEach { (name, value) ->
            if (!request.headers.contains(name)) {
                request.headers[name] = value
            }
        }
    }
}

internal fun configureSdkApiHeaders(headers: Map<String, String>) {
    SdkApiHeaderStore.configure(headers)
}

// All Wave headers share the `X-Wave-` prefix and are hyphenated, so nginx
// (which drops underscored header names by default) never strips them. Values
// stay neutral — no tenant CDR codes in the SDK; the backend maps them.
private const val HEADER_SDK = "X-Wave-SDK"
private const val HEADER_DEVICE = "X-Wave-Device"
private const val HEADER_DEVICE_TYPE = "X-Wave-Device-Type"
private const val HEADER_OS = "X-Wave-OS"
private const val HEADER_OS_VERSION = "X-Wave-OS-Version"
private const val HEADER_APP_VERSION = "X-Wave-App-Version"
private const val HEADER_APP_VERSION_CODE = "X-Wave-App-Version-Code"
private const val HEADER_USER_AGENT = "User-Agent"

// Minimal UA overriding the engine default. BFF-only — the image client keeps
// its default UA, which Telcel's WAF accepts (commit 76b01d2). Structured data
// goes in the dedicated X-Wave-* headers, not crammed into the UA string.
internal fun buildSdkUserAgent(): String = "WaveFlowsSDK/${FlowsSdkBuildInfo.VERSION_LABEL}"

// Pure mapping, split from collection so it is unit-testable without a device.
// Optional fields are omitted when unavailable (e.g. Android with no Context).
internal fun buildDeviceHeaders(info: PlatformDeviceInfo): Map<String, String> = buildMap {
    put(HEADER_USER_AGENT, buildSdkUserAgent())
    put(HEADER_SDK, info.sdkChannel)
    put(HEADER_DEVICE, info.dispositivo)
    info.deviceType?.let { put(HEADER_DEVICE_TYPE, it) }
    put(HEADER_OS, info.so)
    put(HEADER_OS_VERSION, info.soVersion)
    info.appVersion?.let { put(HEADER_APP_VERSION, it) }
    info.appVersionCode?.let { put(HEADER_APP_VERSION_CODE, it) }
}

/** Collects the current platform device info and builds the session headers. */
internal fun buildDeviceHeaders(): Map<String, String> =
    buildDeviceHeaders(PlatformDeviceInfoProvider.collect())
