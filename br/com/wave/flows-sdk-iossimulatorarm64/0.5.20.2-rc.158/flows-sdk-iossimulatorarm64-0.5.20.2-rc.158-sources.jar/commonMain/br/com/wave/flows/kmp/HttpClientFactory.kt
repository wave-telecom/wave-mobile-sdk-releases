package br.com.wave.flows.kmp

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.plugins.UserAgent
import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.client.plugins.defaultRequest
import io.ktor.http.HttpHeaders

/**
 * Creates the platform [HttpClient] used for **all** BFF API calls, applying
 * the given [config] on top of the platform engine (OkHttp on Android, Darwin
 * on iOS).
 */
internal expect fun newPlatformHttpClient(config: HttpClientConfig<*>.() -> Unit = {}): HttpClient

/**
 * The single [HttpClient] through which every BFF API call flows. The
 * [SdkApiHeaders] plugin attaches session-wide device headers (configured at
 * init via [configureSdkApiHeaders]); [SdkAuthHeaders] mints a fresh BTF auth
 * token per request. Both run on every call, so no BFF request can leave the
 * SDK unauthenticated.
 */
fun createPlatformHttpClient(): HttpClient = newPlatformHttpClient {
    install(SdkApiHeaders)
    install(SdkAuthHeaders)
}

/**
 * Dedicated client for image fetches.
 *
 * Kept as a separate factory (rather than reusing [createPlatformHttpClient])
 * so the image transport can evolve independently if the BFF/CDN ever
 * demands different handling. The carousel currently depends on a WebView-like
 * transport header bundle, so the image client restores that behavior without
 * affecting the regular BFF API client.
 */
fun createPlatformImageHttpClient(): HttpClient = HttpClient {
    install(UserAgent) {
        agent = IMAGE_USER_AGENT
    }
    install(SameOriginReferer)

    defaultRequest {
        headers.append(HttpHeaders.AcceptLanguage, "es-MX,es;q=0.9")
        headers.append("Sec-Fetch-Site", "cross-site")
    }
}

private val SameOriginReferer = createClientPlugin("SameOriginReferer") {
    onRequest { request, _ ->
        val host = request.url.host
        if (host.isNotBlank() && !request.headers.contains(HttpHeaders.Referrer)) {
            request.headers[HttpHeaders.Referrer] = "${request.url.protocol.name}://$host/"
        }
    }
}

private const val IMAGE_USER_AGENT =
    "Mozilla/5.0 (Linux; Android 14; sdk_gphone64_x86_64 Build/UE1A.230829.050; wv) " +
        "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.136 " +
        "Mobile Safari/537.36"
