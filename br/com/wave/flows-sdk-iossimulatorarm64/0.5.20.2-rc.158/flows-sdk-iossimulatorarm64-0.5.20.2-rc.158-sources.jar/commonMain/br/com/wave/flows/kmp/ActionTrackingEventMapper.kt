package br.com.wave.flows.kmp

import br.com.wave.flows.kmp.core.host.ActionData
import kotlin.time.Instant

internal const val ACTION_TRACK_TYPE_CLICK = "click"

internal fun ActionData.toSdkActionTracked(origin: String): SDKEvent.ActionTracked =
    SDKEvent.ActionTracked(
        type = ACTION_TRACK_TYPE_CLICK,
        payload = payload,
        timestamp = timestamp.toIsoTimestamp(),
        origin = origin,
    )

private fun String.toIsoTimestamp(): String {
    val epochMillis = toLongOrNull() ?: return this
    return Instant.fromEpochMilliseconds(epochMillis).toString()
}
