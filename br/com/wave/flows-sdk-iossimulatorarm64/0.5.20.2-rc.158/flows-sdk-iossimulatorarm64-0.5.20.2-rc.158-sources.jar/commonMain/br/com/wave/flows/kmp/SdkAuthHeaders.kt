package br.com.wave.flows.kmp

import io.ktor.client.plugins.api.createClientPlugin
import kotlin.concurrent.Volatile

// BTF auth header names. Hyphenated X-BTF-* so nginx (which drops underscored
// names by default) never strips them, matching the X-Wave-* device headers.
internal const val HEADER_BTF_TOKEN = "X-BTF-Token"
internal const val HEADER_BTF_TENANT_ID = "X-BTF-Tenant-Id"

// Session credentials needed to mint a per-request BTF token. Held behind a
// Volatile ref so the request pipeline reads them without a lock; start() swaps
// the whole object atomically and clear() drops it on session reset.
internal data class SdkAuthCredentials(
    val msisdn: String,
    val apiKeyJwt: String,
)

internal object SdkAuthStore {

    @Volatile
    private var credentials: SdkAuthCredentials? = null

    fun configure(msisdn: String, apiKeyJwt: String) {
        credentials = SdkAuthCredentials(msisdn = msisdn, apiKeyJwt = apiKeyJwt)
    }

    fun current(): SdkAuthCredentials? = credentials

    fun clear() {
        credentials = null
    }
}

// Single point that authenticates EVERY BFF request. The encrypted token is
// regenerated per call (fresh IV + iat), so two requests never carry the same
// X-BTF-Token; the tenant id is decoded from the API Key JWT. With no session
// credentials — or with a LEGACY key that lacks the new-format payload — the
// request goes out without BTF headers (the pre-BTF wire behavior) and the
// BFF's own enforcement decides. A token-generation failure propagates out of
// the pipeline and surfaces through the contract provider's error path — it is
// never logged and never crashes the host (the API Key JWT and msisdn are
// never emitted, here or on failure).
internal val SdkAuthHeaders = createClientPlugin("SdkAuthHeaders") {
    onRequest { request, _ ->
        val credentials = SdkAuthStore.current() ?: return@onRequest
        val payload = decodeJwtPayloadOrNull(credentials.apiKeyJwt) ?: return@onRequest
        request.headers[HEADER_BTF_TOKEN] =
            generateEncryptedToken(credentials.msisdn, credentials.apiKeyJwt)
        request.headers[HEADER_BTF_TENANT_ID] = payload.tenantId
    }
}
