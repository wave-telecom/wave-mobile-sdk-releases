package br.com.wave.flows.kmp

import coil3.PlatformContext

internal expect fun platformImageLoaderContext(): PlatformContext
