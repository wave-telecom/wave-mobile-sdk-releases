package br.com.wave.flows.kmp

/**
 * Mints the encrypted BTF token to hand to the WebView (passed as the `token`
 * query param, alongside `externalCode`). It mirrors exactly how [SdkAuthHeaders]
 * authenticates the SDK's own native BFF requests — the same per-call encrypted
 * token, minted from the session's msisdn + API Key JWT.
 *
 * Returns `null` — and the WebView then loads with only `externalCode`, the
 * pre-BTF wire behavior — when [apiKey] is a LEGACY key that lacks the new-format
 * BTF payload, or when token generation fails for any reason. The failure is
 * swallowed (never thrown, never logged, and the API Key JWT / msisdn are never
 * emitted) so a crypto error can never break the WebView load, exactly as the
 * request-pipeline plugin degrades.
 *
 * Each call mints a fresh token (new IV + `iat`); the token carries a short TTL
 * ([DEFAULT_TOKEN_TTL_SECONDS]), so it is generated per WebView load rather than
 * cached for the whole session.
 */
fun generateWebViewAuthToken(msisdn: String, apiKey: String): String? {
    decodeJwtPayloadOrNull(apiKey) ?: return null
    return try {
        generateEncryptedToken(msisdn, apiKey)
    } catch (_: Throwable) {
        null
    }
}
