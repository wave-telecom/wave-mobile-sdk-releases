package br.com.wave.flows.kmp

// Device/app metadata for the CDR headers. Nullable fields are omitted from
// the headers when unavailable (the call still succeeds).
internal data class PlatformDeviceInfo(
    val sdkChannel: String,
    val dispositivo: String,
    // Neutral form factor (PHONE/TABLET), not a tenant code — the backend maps it.
    val deviceType: String?,
    val so: String,
    val soVersion: String,
    val appVersion: String?,
    val appVersionCode: String?,
)

// Android needs the host Context (for PackageManager + screen size); iOS reads
// everything from UIDevice/NSBundle globals, so setHostContext is a no-op there.
internal expect object PlatformDeviceInfoProvider {
    fun setHostContext(context: Any?)

    fun collect(): PlatformDeviceInfo
}
