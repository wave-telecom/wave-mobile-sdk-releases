package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import br.com.wave.flows.kmp.composeblocks.RenderBlockFontResolver
import br.com.wave.flows_sdk.generated.resources.*
import org.jetbrains.compose.resources.Font

@Composable
internal fun rememberFlowRenderBlockFontResolver(): RenderBlockFontResolver {
    // Contracts lean heavily on weight 500 (Medium), so the Medium face is bundled
    // explicitly — without it, 500 falls back to Regular (400) and looks too light.
    // TelcelType still has no SemiBold face; SemiBold (600) requests resolve to the
    // nearest available weight (Bold, 700) automatically.
    val telcelTypeFamily = FontFamily(
        Font(Res.font.telceltype_regular, weight = FontWeight.Normal),
        Font(Res.font.telceltype_medium, weight = FontWeight.Medium),
        Font(Res.font.telceltype_bold, weight = FontWeight.Bold),
        Font(Res.font.telceltype_italic, weight = FontWeight.Normal, style = FontStyle.Italic),
    )

    return remember(telcelTypeFamily) {
        RenderBlockFontResolver { fontFamily ->
            when (fontFamily?.trim()?.lowercase()) {
                // "source sans pro" / "sourcesanspro" kept as aliases so existing
                // contracts (and backend-driven content) render in TelcelType.
                "telceltype", "telcel type", "source sans pro", "sourcesanspro" -> telcelTypeFamily
                else -> null
            }
        }
    }
}
