package br.com.wave.flows.kmp

import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.time.Clock
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okio.ByteString.Companion.toByteString

@Serializable
internal data class TokenPayload(
    val msisdn: String,
    val ttl: Long,
    val baseUrl: String,
    val iat: Long,
)

internal const val DEFAULT_TOKEN_TTL_SECONDS: Long = 900

@OptIn(ExperimentalEncodingApi::class)
private val tokenBase64UrlNoPadding = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT)

@OptIn(ExperimentalEncodingApi::class)
internal fun generateEncryptedToken(msisdn: String, apiKeyJwt: String): String {
    val baseUrl = decodeJwtPayload(apiKeyJwt).baseUrl
    val payload = TokenPayload(msisdn, DEFAULT_TOKEN_TTL_SECONDS, baseUrl, Clock.System.now().epochSeconds)
    val plaintext = Json.encodeToString(payload).encodeToByteArray()
    val key = deriveTokenKey(apiKeyJwt)
    val iv = generateSecureRandomBytes(12)
    val (ciphertext, authTag) = aesGcmEncrypt(plaintext, key, iv)
    return tokenBase64UrlNoPadding.encode(iv + authTag + ciphertext)
}

internal fun deriveTokenKey(apiKeyJwt: String): ByteArray =
    apiKeyJwt.encodeToByteArray().toByteString().sha256().toByteArray()
