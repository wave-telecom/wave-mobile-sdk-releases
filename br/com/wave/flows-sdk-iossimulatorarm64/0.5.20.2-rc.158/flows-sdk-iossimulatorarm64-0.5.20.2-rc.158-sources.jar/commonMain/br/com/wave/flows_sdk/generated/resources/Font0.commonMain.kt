@file:OptIn(InternalResourceApi::class)

package br.com.wave.flows_sdk.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.FontResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/br.com.wave.flows_sdk.generated.resources/"

@delegate:ResourceContentHash(741_032_736)
internal val Res.font.telceltype_bold: FontResource by lazy {
      FontResource("font:telceltype_bold", setOf(
        ResourceItem(setOf(), "${MD}font/telceltype_bold.otf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_327_686_179)
internal val Res.font.telceltype_italic: FontResource by lazy {
      FontResource("font:telceltype_italic", setOf(
        ResourceItem(setOf(), "${MD}font/telceltype_italic.otf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-216_771_860)
internal val Res.font.telceltype_medium: FontResource by lazy {
      FontResource("font:telceltype_medium", setOf(
        ResourceItem(setOf(), "${MD}font/telceltype_medium.otf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_895_304_775)
internal val Res.font.telceltype_regular: FontResource by lazy {
      FontResource("font:telceltype_regular", setOf(
        ResourceItem(setOf(), "${MD}font/telceltype_regular.otf", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainFont0Resources(map: MutableMap<String, FontResource>) {
  map.put("telceltype_bold", Res.font.telceltype_bold)
  map.put("telceltype_italic", Res.font.telceltype_italic)
  map.put("telceltype_medium", Res.font.telceltype_medium)
  map.put("telceltype_regular", Res.font.telceltype_regular)
}
