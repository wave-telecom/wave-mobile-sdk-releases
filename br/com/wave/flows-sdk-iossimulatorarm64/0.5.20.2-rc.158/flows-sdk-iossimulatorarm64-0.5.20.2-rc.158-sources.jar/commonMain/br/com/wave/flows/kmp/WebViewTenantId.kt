package br.com.wave.flows.kmp

/**
 * Resolves the tenant id to hand to the WebView (passed as the `tenantId` query
 * param). It is decoded from the API Key JWT payload — the same source
 * [SdkAuthHeaders] uses for the X-BTF-Tenant-Id header on native BFF requests.
 *
 * Returns `null` for a LEGACY key without the new-format payload, in which case
 * the WebView loads without the param (pre-BTF wire behavior).
 */
fun webViewTenantId(apiKey: String): String? =
    decodeJwtPayloadOrNull(apiKey)?.tenantId?.takeIf(String::isNotBlank)
