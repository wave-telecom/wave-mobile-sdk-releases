package br.com.wave.flows.kmp

/**
 * Host-selected theme mode. Mirrors the hibrido wrapper's `FlowThemeMode` so this
 * native-only SDK exposes the same theme contract — [System] follows the OS, [Light]
 * and [Dark] pin the palette.
 */
enum class FlowThemeMode { System, Light, Dark }
