package br.com.wave.flows.kmp

/**
 * Public scroll snapshot emitted by [RenderBlock].
 *
 * Kept in the SDK package so hosts depend only on the published SDK surface,
 * not on internal implementation modules such as `:core`.
 */
data class ScrollInfo(
    val offsetPx: Int,
    val firstVisibleItemIndex: Int,
    val isScrollingDown: Boolean,
)

internal fun br.com.wave.flows.kmp.core.ScrollInfo.toPublicScrollInfo(): ScrollInfo =
    ScrollInfo(
        offsetPx = offsetPx,
        firstVisibleItemIndex = firstVisibleItemIndex,
        isScrollingDown = isScrollingDown,
    )
