package br.com.wave.flows.kmp

internal expect fun platformWarmupCacheDir(): String?
