package br.com.wave.flows.kmp

import dev.whyoleg.cryptography.CryptographyProvider
import dev.whyoleg.cryptography.DelicateCryptographyApi
import dev.whyoleg.cryptography.algorithms.AES
import dev.whyoleg.cryptography.random.CryptographyRandom

internal data class AesGcmResult(
    val ciphertext: ByteArray,
    val authTag: ByteArray,
)

@OptIn(DelicateCryptographyApi::class)
internal fun aesGcmEncrypt(
    plaintext: ByteArray,
    key: ByteArray,
    iv: ByteArray,
): AesGcmResult {
    require(key.size == 32) { "AES-256-GCM key must be 32 bytes, was ${key.size}" }
    require(iv.size == 12) { "AES-GCM IV must be 12 bytes, was ${iv.size}" }

    val gcm = CryptographyProvider.Default.get(AES.GCM)
    val aesKey = gcm.keyDecoder().decodeFromByteArrayBlocking(AES.Key.Format.RAW, key)
    // encryptWithIvBlocking returns ciphertext || 16-byte auth tag (IV not prepended —
    // it is caller-supplied). The NIST KAT in AesGcmTest anchors this layout empirically.
    val combined = aesKey.cipher().encryptWithIvBlocking(iv, plaintext)
    val tagOffset = combined.size - 16
    return AesGcmResult(
        ciphertext = combined.copyOfRange(0, tagOffset),
        authTag = combined.copyOfRange(tagOffset, combined.size),
    )
}

internal fun generateSecureRandomBytes(size: Int): ByteArray =
    CryptographyRandom.Default.nextBytes(size)
