package br.com.wave.flows.kmp

import br.com.wave.flows.kmp.runtime.RuntimeLogger

/**
 * Produces the platform sink for [RuntimeLogger]. A dumb level+message
 * forwarder — it carries zero tenant/BFF knowledge, only the already-scrubbed
 * strings the runtime passes in.
 */
internal expect fun platformRuntimeLogger(): RuntimeLogger
