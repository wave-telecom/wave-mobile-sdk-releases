package br.com.wave.flows.kmp

internal expect fun runOnUiThread(block: () -> Unit)
