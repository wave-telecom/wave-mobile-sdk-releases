package br.com.wave.flows.kmp.core.errors

open class RenderBlockError(
    val code: String,
    override val message: String,
) : RuntimeException(message)

class RendererNotFoundError(rendererType: String) :
    RenderBlockError(
        code = "RENDERER_NOT_FOUND",
        message = "Renderer \"$rendererType\" not found",
    )

class UnsupportedBlockTypeError(
    blockId: String,
    blockType: String?,
) : RenderBlockError(
    code = "UNSUPPORTED_BLOCK_TYPE",
    message = "Block \"$blockId\" uses unsupported type \"${blockType ?: "<missing-type>"}\"",
)

class UnsupportedActionTargetError(
    blockId: String,
    actionTarget: String?,
) : RenderBlockError(
    code = "UNSUPPORTED_ACTION_TARGET",
    message = "Block \"$blockId\" uses unsupported action target \"${actionTarget ?: "<missing-action>"}\"",
)

class InternalError :
    RenderBlockError(
        code = "INTERNAL_ERROR",
        message = "An internal render-block error occurred",
    )
