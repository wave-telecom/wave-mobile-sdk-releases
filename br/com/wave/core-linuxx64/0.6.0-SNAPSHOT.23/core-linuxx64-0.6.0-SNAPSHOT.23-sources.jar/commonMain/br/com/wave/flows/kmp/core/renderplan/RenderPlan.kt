package br.com.wave.flows.kmp.core.renderplan

import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.registry.RegistryResolution
import br.com.wave.flows.kmp.core.registry.resolveRegistryEntry
import br.com.wave.flows.kmp.core.visibility.VisibilityState
import br.com.wave.flows.kmp.core.visibility.isBlockVisible

data class ResolvedRenderNode(
    val block: BlockNode,
    val rendererType: String,
    val children: List<ResolvedRenderNode>,
)

data class RenderPlanResult(
    val node: ResolvedRenderNode?,
    val errors: List<RenderBlockError>,
)

fun createRenderPlan(
    block: BlockNode,
    rendererRegistry: Set<String>,
    visibility: VisibilityState,
): RenderPlanResult {
    val blockErrors = block.contractErrors
    if (!isBlockVisible(visibility, block.id)) {
        return RenderPlanResult(node = null, errors = blockErrors)
    }

    return when (val resolution = resolveRegistryEntry(rendererRegistry, block.type.name)) {
        is RegistryResolution.Failure -> RenderPlanResult(node = null, errors = blockErrors + resolution.error)
        RegistryResolution.Found -> {
            val childNodes = mutableListOf<ResolvedRenderNode>()
            val childErrors = blockErrors.toMutableList()

            for (child in block.children) {
                val childResult = createRenderPlan(child, rendererRegistry, visibility)
                childResult.node?.let(childNodes::add)
                childErrors += childResult.errors
            }

            RenderPlanResult(
                node = ResolvedRenderNode(
                    block = block,
                    rendererType = block.type.name,
                    children = childNodes,
                ),
                errors = childErrors,
            )
        }
    }
}
