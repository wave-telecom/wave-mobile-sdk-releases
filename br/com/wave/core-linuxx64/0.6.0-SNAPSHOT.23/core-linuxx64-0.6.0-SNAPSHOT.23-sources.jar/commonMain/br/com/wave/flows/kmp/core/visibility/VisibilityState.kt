package br.com.wave.flows.kmp.core.visibility

typealias VisibilityState = Map<String, Boolean>

fun isBlockVisible(state: VisibilityState, blockId: String): Boolean {
    return state[blockId] != false
}

fun setBlockVisibility(
    state: VisibilityState,
    blockId: String,
    value: Boolean,
): VisibilityState {
    return state + (blockId to value)
}

fun toggleBlockVisibility(
    state: VisibilityState,
    blockId: String,
): VisibilityState {
    return setBlockVisibility(state, blockId, state[blockId] != true)
}
