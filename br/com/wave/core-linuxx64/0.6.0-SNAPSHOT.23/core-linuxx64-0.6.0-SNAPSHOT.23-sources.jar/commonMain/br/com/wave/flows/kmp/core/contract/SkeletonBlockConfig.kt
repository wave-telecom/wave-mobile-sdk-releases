package br.com.wave.flows.kmp.core.contract

data class SkeletonBlockConfig(
    val width: String? = null,
    val height: String? = null,
    val align: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig
