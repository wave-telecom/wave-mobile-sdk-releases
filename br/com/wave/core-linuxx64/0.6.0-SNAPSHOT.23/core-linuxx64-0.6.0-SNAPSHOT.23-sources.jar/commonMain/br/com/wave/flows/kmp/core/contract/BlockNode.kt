package br.com.wave.flows.kmp.core.contract

import br.com.wave.flows.kmp.core.errors.RenderBlockError

data class BlockNode(
    val id: String,
    val type: BlockType,
    val config: BlockConfig,
    val children: List<BlockNode> = emptyList(),
    val action: BlockAction? = null,
    val contractErrors: List<RenderBlockError> = emptyList(),
)

data class ScreenContract(
    val id: String,
    val type: String,
    val root: BlockNode,
)
