package br.com.wave.flows.kmp.core.contract

fun interface ScreenContractProvider {
    suspend fun getScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract

    suspend fun getCachedScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? = null

    fun peekCachedScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? = null
}
