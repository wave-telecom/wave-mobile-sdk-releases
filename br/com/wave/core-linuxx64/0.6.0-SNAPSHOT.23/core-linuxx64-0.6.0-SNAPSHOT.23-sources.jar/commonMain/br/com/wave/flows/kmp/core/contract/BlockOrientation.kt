package br.com.wave.flows.kmp.core.contract

enum class BlockOrientation {
    HORIZONTAL,
    VERTICAL,
}
