package br.com.wave.flows.kmp.core.contract

import kotlin.jvm.JvmInline
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonEncoder
import kotlinx.serialization.json.JsonObject

/**
 * Opaque JSON that flows verbatim into [br.com.wave.flows.kmp.SDKEvent.Callback.payload].
 *
 * The SDK MUST NOT decompose, re-serialize, rebuild, or otherwise alter the contents
 * carried by this type. Anything received from the BFF inside a field typed as
 * `VerbatimHostCallbackJson` is part of the contract between BFF and the host app —
 * the SDK is only a transparent pipe.
 *
 * If a new field is needed by the SDK itself, extract it locally without mutating
 * the underlying [element]; the field that reaches the host must remain byte-equivalent
 * to what the BFF emitted.
 */
@JvmInline
@Serializable(with = VerbatimHostCallbackJsonSerializer::class)
value class VerbatimHostCallbackJson(val element: JsonObject) {
    override fun toString(): String = element.toString()
}

internal object VerbatimHostCallbackJsonSerializer : KSerializer<VerbatimHostCallbackJson> {
    private val delegate = JsonObject.serializer()

    override val descriptor: SerialDescriptor = delegate.descriptor

    override fun serialize(encoder: Encoder, value: VerbatimHostCallbackJson) {
        require(encoder is JsonEncoder) { "VerbatimHostCallbackJson requires a JSON encoder" }
        encoder.encodeJsonElement(value.element)
    }

    override fun deserialize(decoder: Decoder): VerbatimHostCallbackJson {
        require(decoder is JsonDecoder) { "VerbatimHostCallbackJson requires a JSON decoder" }
        val element = decoder.decodeJsonElement()
        require(element is JsonObject) {
            "VerbatimHostCallbackJson must wrap a JSON object, got ${element::class.simpleName}"
        }
        return VerbatimHostCallbackJson(element)
    }
}
