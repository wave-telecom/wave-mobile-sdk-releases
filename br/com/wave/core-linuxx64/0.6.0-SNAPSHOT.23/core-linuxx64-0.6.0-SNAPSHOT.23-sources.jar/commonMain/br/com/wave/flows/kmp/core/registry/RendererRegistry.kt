package br.com.wave.flows.kmp.core.registry

import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.errors.RendererNotFoundError

sealed interface RegistryResolution {
    data object Found : RegistryResolution
    data class Failure(val error: RenderBlockError) : RegistryResolution
}

fun resolveRegistryEntry(
    registry: Set<String>,
    rendererType: String,
): RegistryResolution {
    return if (registry.contains(rendererType)) {
        RegistryResolution.Found
    } else {
        RegistryResolution.Failure(RendererNotFoundError(rendererType))
    }
}
