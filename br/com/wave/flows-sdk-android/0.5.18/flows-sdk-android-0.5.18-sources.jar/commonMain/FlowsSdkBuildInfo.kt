package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.18-rc.116-1-g82eaed0"
    const val COMPILED_AT_BRT: String = "2026-07-01T15:18:31.555444-03:00"
    const val GIT_SHA: String = "82eaed0"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.18-rc.116-1-g82eaed0@2026-07-01T15:18:31.555444-03:00#82eaed0"
}