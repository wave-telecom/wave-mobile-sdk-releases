package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-rc.170-13-ge740aa92"
    const val COMPILED_AT_BRT: String = "2026-08-10T11:08:56.809026-03:00"
    const val GIT_SHA: String = "e740aa92"
    const val GIT_BRANCH: String = "release/0.6.0"
    const val DESCRIPTION: String = "0.6.0-rc.170-13-ge740aa92@2026-08-10T11:08:56.809026-03:00#e740aa92"
}