package br.com.wave.flows.kmp

import android.util.Log
import br.com.wave.flows.kmp.runtime.RuntimeLogger

private const val SDK_LOG_TAG = "WaveFlowsSDK"

internal actual fun platformRuntimeLogger(): RuntimeLogger = AndroidRuntimeLogger

private object AndroidRuntimeLogger : RuntimeLogger {
    override fun debug(message: String) {
        runCatching { Log.d(SDK_LOG_TAG, message) }
    }

    override fun info(message: String) {
        runCatching { Log.i(SDK_LOG_TAG, message) }
    }

    override fun warn(message: String) {
        runCatching { Log.w(SDK_LOG_TAG, message) }
    }

    override fun error(message: String, throwable: Throwable?) {
        runCatching { Log.e(SDK_LOG_TAG, message) }
    }
}
