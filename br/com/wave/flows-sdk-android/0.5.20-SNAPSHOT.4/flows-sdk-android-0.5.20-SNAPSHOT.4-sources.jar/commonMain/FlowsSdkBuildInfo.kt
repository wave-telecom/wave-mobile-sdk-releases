package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.3-5-gdefd231"
    const val COMPILED_AT_BRT: String = "2026-07-03T19:52:24.092305-03:00"
    const val GIT_SHA: String = "defd231"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.3-5-gdefd231@2026-07-03T19:52:24.092305-03:00#defd231"
}