package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockImageContent
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockFontResolver
import br.com.wave.flows.kmp.composeblocks.RenderBlockRoute
import br.com.wave.flows.kmp.composeblocks.clearRefreshCooldowns
import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.composeblocks.theme.ProvideFlowTheme
import br.com.wave.flows.kmp.composeblocks.theme.flowThemeSurfaceColor
import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemeMode
import br.com.wave.flows.kmp.runtime.contract.theme.ThemeParser
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.runtime.DEFAULT_BFF_BASE_URL
import br.com.wave.flows.kmp.runtime.DEFAULT_COMPONENT_ID
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_ACTION
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_BACK
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_NAVIGATE
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_OPEN_URL
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_REFRESH
import br.com.wave.flows.kmp.runtime.ORIGIN_NATIVE_RENDER_BLOCK
import br.com.wave.flows.kmp.runtime.api.BffApiFactory
import br.com.wave.flows.kmp.runtime.api.BffApi
import br.com.wave.flows.kmp.runtime.api.clearBffScreenContractCache
import br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider
import br.com.wave.flows.kmp.runtime.api.RefreshSignalRegistry
import br.com.wave.flows.kmp.runtime.warmup.WarmupCoordinator
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore
import br.com.wave.flows.kmp.runtime.warmup.WarmupEntry
import br.com.wave.flows.kmp.runtime.resolveEntry
import io.ktor.client.HttpClient
import coil3.ImageLoader
import coil3.annotation.ExperimentalCoilApi
import coil3.network.ktor3.KtorNetworkFetcherFactory
import coil3.svg.SvgDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okio.Path.Companion.toPath

internal data class FlowWrapperRuntimeConfig(
    val contractProvider: ScreenContractProvider,
    val defaultComponentId: String = DEFAULT_COMPONENT_ID,
    val httpClient: HttpClient,
    val imageHttpClient: HttpClient,
    val imageLoader: ImageLoader,
    val api: BffApi,
    val externalCode: String,
    val diskCache: WarmupDiskCacheStore?,
)

enum class WarmTargetType {
    FLOW,
    COMPONENT,
}

enum class WarmTargetMode {
    FULL,
    SKELETON,
}

data class WarmTarget(
    val slug: String,
    val type: WarmTargetType,
    val mode: WarmTargetMode = WarmTargetMode.FULL,
)

private const val WARM_MODE_FULL = "full"
private const val WARM_MODE_SKELETON = "skeleton"

sealed class SDKEvent {
    data class Error(
        val componentId: String,
        val code: String,
        val message: String,
    ) : SDKEvent()

    data class ComponentLoaded(
        val componentId: String,
    ) : SDKEvent()

    data class Callback(
        val type: String,
        val payload: String,
        val origin: String,
    ) : SDKEvent()

    data class ActionTracked(
        val type: String,
        val payload: Map<String, String>,
        val timestamp: String,
        val origin: String,
    ) : SDKEvent()
}

object FlowWrapper {
    private var runtimeConfig: FlowWrapperRuntimeConfig? = null
    private val sdkScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var warmupJob: Job? = null
    private var renderSessionToken by mutableIntStateOf(0)

    /**
     * Switch the host-selected theme mode — system / light / dark, mirroring the
     * hibrido wrapper's contract so this SDK is a native-only drop-in. [FlowThemeMode.System]
     * follows the OS; [FlowThemeMode.Light]/[FlowThemeMode.Dark] pin the palette. Takes effect
     * immediately — any mounted `RenderBlock` re-resolves `@{token}` references in place.
     */
    fun setThemeMode(mode: FlowThemeMode) {
        FlowThemeStore.setMode(
            when (mode) {
                FlowThemeMode.System -> ThemeMode.Auto
                FlowThemeMode.Light -> ThemeMode.Explicit(ThemeId.Light)
                FlowThemeMode.Dark -> ThemeMode.Explicit(ThemeId.Dark)
            },
        )
    }

    /**
     * [context] feeds the device-metadata CDR headers (FLW-1104): on Android
     * pass an `android.content.Context`; on iOS it is unused (pass `null`).
     */
    fun start(
        context: Any?,
        apiKey: String,
        msisdn: String,
        onReady: (() -> Unit)? = null,
    ) {
        PlatformDeviceInfoProvider.setHostContext(context)
        start(apiKey, msisdn, onReady)
    }

    // Retained for backward compatibility; emits no device-metadata headers.
    fun start(
        apiKey: String,
        msisdn: String,
        onReady: (() -> Unit)? = null,
    ) {
        setMsisdn(apiKey = apiKey, msisdn = msisdn)

        // "Fake init": parse the bundled theme JSON and seed the catalog so
        // the host can show a theme selector before any screen loads.
        // TECH DEBT: replace bundled JSON with a real BFF init payload once
        // the backend exposes one.
        val catalog = loadBundledThemeCatalog()
        FlowThemeStore.setCatalog(catalog)

        warmDefaultEntries { onReady?.invoke() }
    }

    fun setMsisdn(
        apiKey: String,
        msisdn: String,
    ) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        // Fail-fast auth check, once at start: a malformed API key must fail here
        // — clearly as an auth/config error — instead of later, mis-attributed as
        // a per-request content-load failure. Runs before any session teardown so
        // a bad re-init never tears down a working session.
        validateStartCredentials(apiKey = sanitizedApiKey, msisdn = sanitizedMsisdn)

        warmupJob?.cancel()
        runtimeConfig?.imageLoader?.shutdown()
        runtimeConfig?.imageHttpClient?.close()
        runtimeConfig?.httpClient?.close()
        renderSessionToken += 1
        clearBffScreenContractCache()
        RefreshSignalRegistry.reset()
        clearRefreshCooldowns()
        SdkApiHeaderStore.clear()
        SdkAuthStore.clear()

        val externalCode = sanitizedMsisdn.filter(Char::isDigit)

        // Must run before the client is built and any BFF call fires.
        configureSdkApiHeaders(buildDeviceHeaders())
        SdkAuthStore.configure(msisdn = sanitizedMsisdn, apiKeyJwt = sanitizedApiKey)

        val httpClient = createPlatformHttpClient()
        val imageHttpClient = createPlatformImageHttpClient()
        val imageLoader = createFlowImageLoader(imageHttpClient)
        val warmupCacheDir = platformWarmupCacheDir()
        val diskCache =
            warmupCacheDir
                ?.takeIf { it.isNotBlank() }
                ?.toPath()
                ?.let(::WarmupDiskCacheStore)
        val api = BffApiFactory.create(
            client = httpClient,
            baseUrl = DEFAULT_BFF_BASE_URL,
        )
        val contractProvider =
            BffScreenContractProvider(
                baseUrl = DEFAULT_BFF_BASE_URL,
                externalCode = externalCode,
                diskCache = diskCache,
                api = api,
            )

        runtimeConfig =
            FlowWrapperRuntimeConfig(
                contractProvider = contractProvider,
                httpClient = httpClient,
                imageHttpClient = imageHttpClient,
                imageLoader = imageLoader,
                api = api,
                externalCode = externalCode,
                diskCache = diskCache,
            )
    }

    fun warm(
        targets: List<WarmTarget>,
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                    ).warm(
                        targets.map { target ->
                            WarmupEntry(
                                slug = target.slug,
                                type = when (target.type) {
                                    WarmTargetType.FLOW -> "flow"
                                    WarmTargetType.COMPONENT -> "component"
                                },
                                mode = when (target.mode) {
                                    WarmTargetMode.FULL -> WARM_MODE_FULL
                                    WarmTargetMode.SKELETON -> WARM_MODE_SKELETON
                                },
                            )
                        },
                    )
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    /**
     * Hybrid native init: fetch `/api/init` and hand the raw body to [onInitJson]
     * (where the wrapper installs the render-routing policy), then signal [onReady].
     * Unlike [start]/[warmDefaultEntries] it does NOT warm the init's declared
     * entries — native warm targets come from the routing policy.
     */
    fun warmFromInit(
        onInitJson: suspend (String) -> Unit,
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                    ).fetchInit(onInitJson)
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Best-effort: on failure the wrapper keeps the seed policy.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    fun hasCachedComponent(componentId: String): Boolean {
        val normalizedComponentId = componentId.trim()
        if (normalizedComponentId.isEmpty()) return false
        val config = runtimeConfig ?: return false
        return config.contractProvider.peekCachedScreenContract(
            componentId = normalizedComponentId,
            externalCode = config.externalCode,
        ) != null
    }

    private fun warmDefaultEntries(
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        // "Fake init": parse the bundled theme JSON and seed the catalog so
        // the host can show a theme selector before any screen loads.
        // TECH DEBT: replace bundled JSON with a real BFF init payload once
        // the backend exposes one.
        val catalog = loadBundledThemeCatalog()
        FlowThemeStore.setCatalog(catalog)

        if (config.diskCache == null) {
            runOnUiThread { onReady?.invoke() }
            return
        }

        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                    ).warmup()
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    private val themeJsonParser = Json { ignoreUnknownKeys = true; isLenient = true }

    /**
     * Parses [BUNDLED_THEME_JSON] into a [FlowThemeCatalog]. Failures degrade
     * to [FlowThemeCatalog.empty] — the SDK then renders legacy literal-hex
     * blocks unchanged (back-compat).
     */
    private fun loadBundledThemeCatalog(): FlowThemeCatalog {
        return runCatching {
            val root = themeJsonParser.parseToJsonElement(
                br.com.wave.flows.kmp.theme.BUNDLED_THEME_JSON,
            ) as? JsonObject ?: return FlowThemeCatalog.empty()
            ThemeParser.parse(root)
        }.getOrElse { FlowThemeCatalog.empty() }
    }

    internal fun requireConfig(): FlowWrapperRuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentRenderSessionToken(): Int = renderSessionToken

    /**
     * Clears the process-wide theme state so an instrumented suite starts
     * from the same blank slate `start()` would seed. Without this, a prior
     * test that rendered a themed screen leaves a populated [FlowThemeStore]
     * catalog behind, which then masks any defect that depends on the catalog
     * actually being carried by the contract under test. Consumed by the
     * wrapper's `resetForTests`, mirroring the other integration entry points
     * this module exposes to it.
     */
    fun resetThemeForTests() {
        FlowThemeStore.setCatalog(FlowThemeCatalog.empty())
        FlowThemeStore.setMode(ThemeMode.Auto)
    }

    /**
     * Invalidates the cached contract for [componentId] and triggers an
     * internal re-fetch of the mounted [RenderBlock] for that component.
     * The mounted route observes a per-component signal counter; this call
     * increments it, re-running produceState and fetching fresh content from
     * the BFF — no host-side token or re-mount is required.
     *
     * Safe to call without an active session — does nothing if
     * `start()` was never called.
     */
    fun refresh(flowId: String, externalCode: String? = null) {
        val provider = runtimeConfig?.contractProvider as? BffScreenContractProvider ?: return
        provider.invalidate(componentId = flowId, externalCode = externalCode)
        RefreshSignalRegistry.bump(flowId, externalCode)
    }
}

/**
 * One-time start-of-session validation of the API key.
 *
 * A key whose payload does NOT decode to the new BTF format ([ApiKeyPayload])
 * is a LEGACY key: it is accepted without validation and the session runs
 * without BTF authentication, exactly as the SDK behaved before the BTF scheme
 * existed ([SdkAuthHeaders] skips the BTF headers for the same keys). Rejecting
 * legacy keys here silently degraded every production render to the WebView
 * fallback for hosts still on the old credential.
 *
 * A new-format key additionally proves the full crypto path works in this
 * runtime by minting one token ([generateEncryptedToken]) and discarding it —
 * each real request still mints its own fresh token. On crypto failure it
 * throws [IllegalArgumentException] — the same mechanism the non-blank
 * `apiKey`/`msisdn` checks in [FlowWrapper.setMsisdn] already use. The message
 * is a fixed auth/config string and the underlying cause is deliberately NOT
 * chained, so no fragment of the API key JWT or the msisdn can leak through an
 * underlying base64/JSON error.
 */
internal fun validateStartCredentials(apiKey: String, msisdn: String) {
    decodeJwtPayloadOrNull(apiKey) ?: return
    try {
        generateEncryptedToken(msisdn, apiKey)
    } catch (_: Exception) {
        throw IllegalArgumentException(
            "FlowWrapper.start received an invalid apiKey: it could not be validated for BFF authentication.",
        )
    }
}

/**
 * Default interval between scroll-callback emissions, in milliseconds; pass `0`
 * to disable throttling. Re-exported for facade consumers, which cannot see the
 * renderer module that owns the value (single source of truth).
 */
const val DEFAULT_SCROLL_THROTTLE_MS: Long =
    br.com.wave.flows.kmp.composeblocks.DEFAULT_SCROLL_THROTTLE_MS

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    onScroll: ((ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
    modifier: Modifier = Modifier,
) {
    val config = FlowWrapper.requireConfig()
    val resolvedComponentId = resolveEntry(componentId, flowId, config.defaultComponentId)
    val renderSessionToken = FlowWrapper.currentRenderSessionToken()
    // Prefer a font resolver supplied by the host (so an app can ship the
    // fonts in its own resource bundle and resolve them) and fall back to the
    // SDK's bundled TelcelType resolver. Needed because library `composeResources`
    // are not packaged into the consuming app by the KMP library plugin, so the
    // SDK's own fonts may not be present at runtime.
    val fontResolver = LocalRenderBlockFontResolver.current ?: rememberFlowRenderBlockFontResolver()

    CompositionLocalProvider(
        LocalRenderBlockImageContent provides FlowRenderBlockImageContent,
        LocalRenderBlockFontResolver provides fontResolver,
    ) {
        ProvideFlowTheme {
            RenderBlockRouteWrapper(
                resolvedComponentId = resolvedComponentId,
                renderSessionToken = renderSessionToken,
                onEvent = onEvent,
                scroll = scroll,
                pullToRefreshEnabled = pullToRefreshEnabled,
                onScroll = onScroll,
                scrollThrottleMs = scrollThrottleMs,
                modifier = modifier,
                config = config,
            )
        }
    }
}

/**
 * The active Flow theme's surface colour, for host chrome that PRESENTS a
 * [RenderBlock] but is composed OUTSIDE it — e.g. a host-owned bottom-sheet
 * shell whose background would otherwise be a hardcoded constant and ignore
 * dark mode. Mode-aware: a near-white surface in light, a dark surface in
 * dark. Returns [fallback] when no theme is configured (legacy back-compat).
 */
@Composable
fun rememberFlowThemeSurfaceColor(fallback: Color): Color =
    flowThemeSurfaceColor(fallback)

@Composable
private fun RenderBlockRouteWrapper(
    resolvedComponentId: String,
    renderSessionToken: Int,
    onEvent: ((SDKEvent) -> Unit)?,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    onScroll: ((ScrollInfo) -> Unit)?,
    scrollThrottleMs: Long,
    modifier: Modifier,
    config: FlowWrapperRuntimeConfig,
) {
    val effectivePullToRefresh = pullToRefreshEnabled && scroll
    // The force-network refresh + skeleton peek live only on the concrete
    // runtime provider. Casting here (the same `as? BffScreenContractProvider`
    // already used by `FlowWrapper.refresh`) keeps `:composeblocks` free of any
    // runtime coupling — it receives only the injected lambdas.
    val bffProvider = config.contractProvider as? BffScreenContractProvider
    val selfContainedRefresh = effectivePullToRefresh && bffProvider != null
    RenderBlockRoute(
            componentId = resolvedComponentId,
            contractProvider = config.contractProvider,
            sessionToken = renderSessionToken,
            hostEventHandler = FlowWrapperHostEventHandler(
                componentId = resolvedComponentId,
                onEvent = onEvent,
            ),
            onContractLoaded = { contract ->
                onEvent?.invoke(SDKEvent.ComponentLoaded(contract.id))
            },
            scroll = scroll,
            pullToRefreshEnabled = effectivePullToRefresh,
            onFetchFresh = if (selfContainedRefresh) {
                { id, ext -> bffProvider.getFreshScreenContract(id, ext) }
            } else {
                null
            },
            onPeekSkeleton = if (selfContainedRefresh) {
                { id, ext -> bffProvider.getCachedSkeletonContract(id, ext) }
            } else {
                null
            },
            onScroll = onScroll?.let { handler -> { info -> handler(info.toPublicScrollInfo()) } },
            scrollThrottleMs = scrollThrottleMs,
            modifier = modifier,
        )
}

@OptIn(ExperimentalCoilApi::class)
private fun createFlowImageLoader(httpClient: HttpClient): ImageLoader {
    val context = platformImageLoaderContext()
    return ImageLoader.Builder(context)
        .components {
            add(KtorNetworkFetcherFactory(httpClient))
            add(SvgDecoder.Factory())
        }
        .build()
}

private class FlowWrapperHostEventHandler(
    private val componentId: String,
    private val onEvent: ((SDKEvent) -> Unit)?,
) : HostEventHandler {
    override fun onHostEvent(event: HostEvent) {
        onEvent?.invoke(event.toSdkEvent(componentId))
    }
}

private fun HostEvent.toSdkEvent(componentId: String): SDKEvent {
    return when (this) {
        is HostEvent.Error -> SDKEvent.Error(
            componentId = componentId,
            code = error.code,
            message = error.message,
        )

        is HostEvent.ActionTracked -> event.toSdkActionTracked(origin = ORIGIN_NATIVE_RENDER_BLOCK)

        is HostEvent.DelegatedHostAction -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_ACTION,
            payload = rawJson,
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        HostEvent.Refresh -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_REFRESH,
            payload = buildJsonObject {
                put("componentId", JsonPrimitive(componentId))
            }.toString(),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        is HostEvent.Navigation -> SDKEvent.Callback(
            type = navigationType(event),
            payload = navigationPayload(event),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )
    }
}

private fun navigationType(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> EVENT_RENDER_BLOCK_NAVIGATE
        NavigationEvent.Back -> EVENT_RENDER_BLOCK_BACK
        is NavigationEvent.External -> EVENT_RENDER_BLOCK_OPEN_URL
    }
}

private fun navigationPayload(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> event.verbatim.toString()

        NavigationEvent.Back -> "{}"

        is NavigationEvent.External -> buildJsonObject {
            put("url", JsonPrimitive(event.url))
        }.toString()
    }
}
