package br.com.wave.flows.kmp

import java.io.File

internal actual fun platformWarmupCacheDir(): String? {
    val application = runCatching {
        val activityThreadClass = Class.forName("android.app.ActivityThread")
        activityThreadClass.getMethod("currentApplication").invoke(null)
    }.getOrNull() ?: runCatching {
        val appGlobalsClass = Class.forName("android.app.AppGlobals")
        appGlobalsClass.getMethod("getInitialApplication").invoke(null)
    }.getOrNull()

    val context = application as? android.content.Context ?: return null
    return File(context.cacheDir, "warmup_cache").absolutePath
}
