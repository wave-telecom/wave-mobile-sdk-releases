package br.com.wave.flows.kmp

import android.os.Handler
import android.os.Looper

internal actual fun runOnUiThread(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
        block()
        return
    }

    Handler(Looper.getMainLooper()).post(block)
}
