package br.com.wave.flows.kmp

import coil3.PlatformContext

internal actual fun platformImageLoaderContext(): PlatformContext {
    val application = runCatching {
        val activityThreadClass = Class.forName("android.app.ActivityThread")
        activityThreadClass.getMethod("currentApplication").invoke(null)
    }.getOrNull() ?: runCatching {
        val appGlobalsClass = Class.forName("android.app.AppGlobals")
        appGlobalsClass.getMethod("getInitialApplication").invoke(null)
    }.getOrNull()

    return requireNotNull(application as? PlatformContext) {
        "Unable to resolve application context for Coil image loader."
    }
}
