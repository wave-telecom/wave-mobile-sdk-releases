package br.com.wave.flows.kmp

import android.content.Context
import android.os.Build
import kotlin.concurrent.Volatile

private const val TABLET_SMALLEST_WIDTH_DP = 600

internal actual object PlatformDeviceInfoProvider {

    @Volatile
    private var appContext: Context? = null

    actual fun setHostContext(context: Any?) {
        (context as? Context)?.let { appContext = it.applicationContext }
    }

    actual fun collect(): PlatformDeviceInfo {
        val context = appContext
        val packageInfo = context?.let {
            runCatching {
                it.packageManager.getPackageInfo(it.packageName, 0)
            }.getOrNull()
        }
        val versionCode = packageInfo?.let { info ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.longVersionCode.toString()
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toString()
            }
        }
        // Phone vs tablet is a screen-size fact the OS itself decides; the
        // model name doesn't carry it. ≥ 600dp smallest width = tablet.
        val deviceType = context?.resources?.configuration?.let { config ->
            if (config.smallestScreenWidthDp >= TABLET_SMALLEST_WIDTH_DP) "TABLET" else "PHONE"
        }
        return PlatformDeviceInfo(
            sdkChannel = "MOBILE_ANDROID_KMP",
            dispositivo = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            deviceType = deviceType,
            so = "Android",
            soVersion = Build.VERSION.RELEASE.orEmpty(),
            appVersion = packageInfo?.versionName,
            appVersionCode = versionCode,
        )
    }
}
