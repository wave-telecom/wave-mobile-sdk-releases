package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-2-g1ca54a2"
    const val COMPILED_AT_BRT: String = "2026-06-28T10:02:12.403595-03:00"
    const val GIT_SHA: String = "1ca54a2"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.16-2-g1ca54a2@2026-06-28T10:02:12.403595-03:00#1ca54a2"
}