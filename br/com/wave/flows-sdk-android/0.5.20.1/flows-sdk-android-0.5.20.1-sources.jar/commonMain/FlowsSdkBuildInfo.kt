package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-4-ge49ba11"
    const val COMPILED_AT_BRT: String = "2026-07-09T20:56:26.473526-03:00"
    const val GIT_SHA: String = "e49ba11"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20-4-ge49ba11@2026-07-09T20:56:26.473526-03:00#e49ba11"
}