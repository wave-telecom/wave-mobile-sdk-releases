package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-3-g8ab9fc9"
    const val COMPILED_AT_BRT: String = "2026-06-29T12:37:44.802745-03:00"
    const val GIT_SHA: String = "8ab9fc9"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.17-3-g8ab9fc9@2026-06-29T12:37:44.802745-03:00#8ab9fc9"
}