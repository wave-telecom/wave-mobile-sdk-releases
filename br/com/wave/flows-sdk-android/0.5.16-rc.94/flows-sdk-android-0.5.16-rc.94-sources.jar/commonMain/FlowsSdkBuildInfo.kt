package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-SNAPSHOT-67-ge86e263"
    const val COMPILED_AT_BRT: String = "2026-06-26T19:15:16.107563-03:00"
    const val GIT_SHA: String = "e86e263"
    const val GIT_BRANCH: String = "release/0.5.16"
    const val DESCRIPTION: String = "0.5.16-SNAPSHOT-67-ge86e263@2026-06-26T19:15:16.107563-03:00#e86e263"
}