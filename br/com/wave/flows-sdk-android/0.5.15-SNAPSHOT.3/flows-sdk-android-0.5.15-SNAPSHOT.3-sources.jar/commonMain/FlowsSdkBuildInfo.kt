package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT.2-4-g1838e72"
    const val COMPILED_AT_BRT: String = "2026-06-23T12:36:08.439294-03:00"
    const val GIT_SHA: String = "1838e72"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT.2-4-g1838e72@2026-06-23T12:36:08.439294-03:00#1838e72"
}