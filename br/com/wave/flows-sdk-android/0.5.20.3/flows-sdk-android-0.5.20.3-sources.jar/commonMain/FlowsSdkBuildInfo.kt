package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.3-rc.160-1-g1ce0262"
    const val COMPILED_AT_BRT: String = "2026-07-22T11:03:31.773344-03:00"
    const val GIT_SHA: String = "1ce0262"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20.3-rc.160-1-g1ce0262@2026-07-22T11:03:31.773344-03:00#1ce0262"
}