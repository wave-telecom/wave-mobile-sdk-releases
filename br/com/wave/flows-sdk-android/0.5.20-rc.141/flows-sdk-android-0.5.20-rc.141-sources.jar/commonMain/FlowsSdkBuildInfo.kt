package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-rc.140-1-ga7e1f5d"
    const val COMPILED_AT_BRT: String = "2026-07-07T11:54:27.76364-03:00"
    const val GIT_SHA: String = "a7e1f5d"
    const val GIT_BRANCH: String = "release/0.5.20"
    const val DESCRIPTION: String = "0.5.20-rc.140-1-ga7e1f5d@2026-07-07T11:54:27.76364-03:00#a7e1f5d"
}