package br.com.wave.flows.kmp

import io.ktor.client.HttpClient

expect fun createPlatformHttpClient(): HttpClient
