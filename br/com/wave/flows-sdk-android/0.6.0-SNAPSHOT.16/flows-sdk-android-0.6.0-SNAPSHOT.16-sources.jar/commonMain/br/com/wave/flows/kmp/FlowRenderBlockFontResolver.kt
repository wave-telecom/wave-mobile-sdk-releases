package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import br.com.wave.flows.kmp.composeblocks.RenderBlockFontResolver
import br.com.wave.flows_sdk.generated.resources.*
import org.jetbrains.compose.resources.Font

@Composable
internal fun rememberFlowRenderBlockFontResolver(): RenderBlockFontResolver {
    val sourceSansProFamily = FontFamily(
        Font(Res.font.sourcesanspro_regular, weight = FontWeight.Normal),
        Font(Res.font.sourcesanspro_semibold, weight = FontWeight.SemiBold),
        Font(Res.font.sourcesanspro_bold, weight = FontWeight.Bold),
        Font(Res.font.sourcesanspro_italic, weight = FontWeight.Normal, style = FontStyle.Italic),
    )

    return remember(sourceSansProFamily) {
        RenderBlockFontResolver { fontFamily ->
            when (fontFamily?.trim()?.lowercase()) {
                "source sans pro", "sourcesanspro" -> sourceSansProFamily
                else -> null
            }
        }
    }
}
