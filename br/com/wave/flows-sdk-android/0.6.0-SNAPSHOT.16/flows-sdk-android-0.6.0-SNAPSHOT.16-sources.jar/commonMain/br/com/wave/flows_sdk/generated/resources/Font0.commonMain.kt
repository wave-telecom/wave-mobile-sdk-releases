@file:OptIn(InternalResourceApi::class)

package br.com.wave.flows_sdk.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.FontResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/br.com.wave.flows_sdk.generated.resources/"

@delegate:ResourceContentHash(1_577_256_034)
internal val Res.font.sourcesanspro_bold: FontResource by lazy {
      FontResource("font:sourcesanspro_bold", setOf(
        ResourceItem(setOf(), "${MD}font/sourcesanspro_bold.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_344_778_983)
internal val Res.font.sourcesanspro_italic: FontResource by lazy {
      FontResource("font:sourcesanspro_italic", setOf(
        ResourceItem(setOf(), "${MD}font/sourcesanspro_italic.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_894_406_966)
internal val Res.font.sourcesanspro_regular: FontResource by lazy {
      FontResource("font:sourcesanspro_regular", setOf(
        ResourceItem(setOf(), "${MD}font/sourcesanspro_regular.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-828_416_480)
internal val Res.font.sourcesanspro_semibold: FontResource by lazy {
      FontResource("font:sourcesanspro_semibold", setOf(
        ResourceItem(setOf(), "${MD}font/sourcesanspro_semibold.ttf", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainFont0Resources(map: MutableMap<String, FontResource>) {
  map.put("sourcesanspro_bold", Res.font.sourcesanspro_bold)
  map.put("sourcesanspro_italic", Res.font.sourcesanspro_italic)
  map.put("sourcesanspro_regular", Res.font.sourcesanspro_regular)
  map.put("sourcesanspro_semibold", Res.font.sourcesanspro_semibold)
}
