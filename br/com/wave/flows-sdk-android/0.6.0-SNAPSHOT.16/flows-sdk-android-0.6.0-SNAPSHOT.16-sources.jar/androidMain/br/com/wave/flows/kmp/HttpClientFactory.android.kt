package br.com.wave.flows.kmp

import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO

actual fun createPlatformHttpClient(): HttpClient {
    return HttpClient(CIO)
}
