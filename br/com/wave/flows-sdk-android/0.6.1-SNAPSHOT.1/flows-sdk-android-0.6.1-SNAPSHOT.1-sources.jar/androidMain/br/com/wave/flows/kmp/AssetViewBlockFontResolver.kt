package br.com.wave.flows.kmp

import android.content.res.AssetManager
import android.graphics.Typeface
import br.com.wave.flows.kmp.viewblocks.ViewBlockFontResolver

// The KMP compose-resources plugin merges :flows-sdk's `composeResources/font`
// assets under this path in the consuming app (confirmed against the merged
// assets tree; same path the sample app's own composeResources font merges to).
private const val TELCELTYPE_FONT_ASSET_DIR =
    "composeResources/br.com.wave.flows_sdk.generated.resources/font"

private val TELCELTYPE_FAMILY_ALIASES = setOf(
    "telceltype", "telcel type", "source sans pro", "sourcesanspro",
)

/**
 * Real TelcelType faces for the View renderer, mirroring
 * `rememberFlowRenderBlockFontResolver`'s family/weight mapping
 * (FlowRenderBlockFontResolver.kt:26-33) exactly: a `TextView` needs one
 * concrete [Typeface] up front (unlike Compose's `FontFamily`, which bundles
 * every face and resolves at draw time), so the weight/style pick happens
 * here instead. `null` for any unrecognized family lets the caller fall back
 * to the platform default typeface, matching the Compose resolver's contract.
 */
internal class AssetViewBlockFontResolver(
    private val assets: AssetManager,
) : ViewBlockFontResolver {
    private val cache = mutableMapOf<String, Typeface?>()

    override fun resolve(fontFamily: String?, fontWeight: Int?, italic: Boolean): Typeface? {
        if (fontFamily?.trim()?.lowercase() !in TELCELTYPE_FAMILY_ALIASES) return null

        // TelcelType has no dedicated SemiBold (600) face; nearest available
        // weight is Bold (700), same fallback the Compose FontFamily makes.
        val faceFileName = when {
            italic -> "telceltype_italic.otf"
            fontWeight == 500 -> "telceltype_medium.otf"
            fontWeight != null && fontWeight >= 600 -> "telceltype_bold.otf"
            else -> "telceltype_regular.otf"
        }

        return cache.getOrPut(faceFileName) {
            runCatching {
                Typeface.createFromAsset(assets, "$TELCELTYPE_FONT_ASSET_DIR/$faceFileName")
            }.onFailure { error ->
                // The merged asset path is a build-tool convention, not a guaranteed API — if a
                // future plugin/resource-repackage moves it, fail loudly in the log but still
                // degrade to the platform default typeface, exactly like an unrecognized family.
                platformRuntimeLogger().warn(
                    "AssetViewBlockFontResolver: failed to load $TELCELTYPE_FONT_ASSET_DIR/$faceFileName " +
                        "(${error.message}); falling back to the platform default typeface.",
                )
            }.getOrNull()
        }
    }
}
