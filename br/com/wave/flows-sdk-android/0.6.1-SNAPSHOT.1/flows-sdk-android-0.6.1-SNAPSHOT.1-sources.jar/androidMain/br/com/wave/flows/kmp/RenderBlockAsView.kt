package br.com.wave.flows.kmp

import android.app.Dialog
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.widget.NestedScrollView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import br.com.wave.flows.kmp.composeblocks.DEFAULT_SCROLL_THROTTLE_MS
import br.com.wave.flows.kmp.composeblocks.LocalRenderRouteStateKey
import br.com.wave.flows.kmp.composeblocks.scrollInfoFor
import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.SubComponentBlockConfig
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.visibility.VisibilityState
import br.com.wave.flows.kmp.core.visibility.buildInitialVisibilityState
import br.com.wave.flows.kmp.core.visibility.setBlockVisibility
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache
import br.com.wave.flows.kmp.viewblocks.ViewBlockFontResolver
import br.com.wave.flows.kmp.viewblocks.ViewBlockImageContent
import br.com.wave.flows.kmp.viewblocks.ViewBlockInteractionContext
import br.com.wave.flows.kmp.viewblocks.ViewBlockRefreshCooldownStore
import br.com.wave.flows.kmp.viewblocks.ViewBlockRenderer
import kotlinx.coroutines.delay

/**
 * Mounts `:viewblocks`' View tree as [RenderBlockRoute]'s leaf renderer,
 * inheriting its fetch/loading/error/PTR machinery unchanged (the caller,
 * [RenderBlockRouteWrapper] via [platformViewRenderContract]) — this composable
 * only builds and re-builds the rendered [contract].
 *
 * Owns the interaction state (plan step 7) — a View-side mirror of
 * `RenderBlockScreen`'s `visibilityState`/`RenderBlockRenderContext`: a tab tap
 * or a `show`/`hide` action rebuilds the tree (re-render is parent-owned,
 * Amendment A1.4). Non-root `BOTTOM_SHEET` nodes are never rendered inline —
 * they are excluded from the main tree and, when their visibility flips true,
 * presented as a bottom-anchored [Dialog] overlay instead (mirrors the
 * reference's nested `ModalBottomSheet` path).
 *
 * PTR (behavior-parity plan G13, `pullToRefreshEnabled`/[isRefreshing]/
 * [onPtrRefresh]) wraps the scroll host in a [SwipeRefreshLayout] — see
 * [buildViewRenderHost].
 */
@Composable
internal fun RenderBlockAsView(
    contract: ScreenContract,
    config: FlowWrapperRuntimeConfig,
    hostEventHandler: HostEventHandler,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    isRefreshing: Boolean,
    onPtrRefresh: () -> Unit,
    onScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
) {
    val context = LocalContext.current
    val imageContent = remember(config.imageLoader) { CoilViewBlockImageContent(context, config.imageLoader) }
    val fontResolver = remember(context) { AssetViewBlockFontResolver(context.assets) }
    val routeStateKey = LocalRenderRouteStateKey.current

    // Mirrors `ProvideFlowTheme`'s resolution (`LocalFlowTheme.kt:54-60`), but
    // fed `contract.themeCatalog` directly rather than `FlowThemeStore.catalog`
    // — the View path has no `LaunchedEffect(themeCatalog)` equivalent to keep
    // the store's catalog authoritative, and `resolveActive` only needs the
    // catalog + mode + systemDark to pick a palette.
    val themeMode by FlowThemeStore.mode.collectAsState()
    val systemDark = isSystemInDarkTheme()
    val themeId = FlowThemeStore.resolveActive(contract.themeCatalog, themeMode, systemDark)?.id ?: ThemeId.Light

    // G2 (behavior-parity plan): recompose (and rebuild `AndroidView`) the
    // instant a refresh cooldown locks/releases, mirroring the reference's
    // snapshot-backed `RefreshCooldownStore` reads (`RenderBlockScreen.kt:554,563`).
    var cooldownTick by remember { mutableStateOf(0) }
    DisposableEffect(Unit) {
        ViewBlockRefreshCooldownStore.onChange = { cooldownTick++ }
        onDispose { ViewBlockRefreshCooldownStore.onChange = null }
    }

    // Mirrors `RenderBlockScreen.kt:247-256`: seeded from the cache when a prior
    // interaction on this route already recorded one, else the same
    // `buildInitialVisibilityState` the reference seeds from; the root is
    // always visible, overriding its own inherited hidden state (relevant when
    // a bottom-sheet is promoted to root elsewhere).
    val visibilityState = remember(contract.id) {
        mutableStateMapOf<String, Boolean>().apply {
            putAll(RenderBlockInteractionCache.getVisibility(routeStateKey) ?: buildInitialVisibilityState(contract.root))
            put(contract.root.id, true)
        }
    }

    val interaction = remember(contract.id, routeStateKey) {
        ViewBlockInteractionContext(
            onHostEvent = hostEventHandler::onHostEvent,
            currentVisibility = { visibilityState.toMap() },
            onVisibilityChange = { next ->
                visibilityState.putAll(next)
                if (routeStateKey.isNotBlank()) {
                    RenderBlockInteractionCache.putVisibility(routeStateKey, visibilityState.toMap())
                }
            },
            routeStateKey = routeStateKey,
            rootNode = contract.root,
        )
    }

    // Re-enable once the nearest active deadline elapses, re-arming on every
    // tick/route change for the *remaining* time from that absolute deadline
    // — mirrors the reference's per-cooldown `LaunchedEffect`
    // (`RenderBlockScreen.kt:560-564`), collapsed to one timer for whichever
    // deadline on this route is nearest (only one `RenderBlockAsView` host
    // renders per session, see `ViewBlockRefreshCooldownStore`'s kdoc).
    LaunchedEffect(cooldownTick, routeStateKey) {
        val nearest = ViewBlockRefreshCooldownStore.earliestActiveDeadline(routeStateKey, interaction.clock.nowMillis())
        if (nearest != null) {
            val (key, deadline) = nearest
            val remaining = deadline - interaction.clock.nowMillis()
            if (remaining > 0) delay(remaining)
            ViewBlockRefreshCooldownStore.release(key)
        }
    }

    // G7 (behavior-parity plan S2, step 10): `sub-component` needs an async
    // `contractProvider` fetch, impossible inside `:viewblocks`' synchronous
    // `render()` — pre-resolved here (the interactive host, which already
    // holds `config.contractProvider`/`config.externalCode`) and threaded down
    // as `embeddedContracts`. Seeded synchronously from the sync cache peek
    // (instant swap when warm, no placeholder flash), then refreshed by the
    // suspend fetch; a cache miss/fetch failure leaves the placeholder up,
    // mirroring the reference's `produceState` (`RenderBlockSubComponentRenderer.kt:45-50`).
    val subComponentTargets = remember(contract.root) { collectSubComponentTargetIds(contract.root) }
    val embedded = remember(contract.id) {
        mutableStateMapOf<String, ScreenContract>().apply {
            subComponentTargets.forEach { id ->
                config.contractProvider.peekCachedScreenContract(id, config.externalCode)?.let { put(id, it) }
            }
        }
    }
    LaunchedEffect(contract.id, subComponentTargets) {
        subComponentTargets.forEach { id ->
            runCatching { config.contractProvider.getScreenContract(id, config.externalCode) }
                .getOrNull()
                ?.let { embedded[id] = it }
        }
    }

    val visibilitySnapshot = visibilityState.toMap()
    val nonRootSheetIds = remember(contract.root) { collectNonRootBottomSheetIds(contract.root) }
    // Non-root bottom-sheets are never part of the inline tree, regardless of
    // their toggled state — a visible one is presented as a modal below instead.
    val mainTreeOverrides: VisibilityState = if (nonRootSheetIds.isEmpty()) {
        visibilitySnapshot
    } else {
        visibilitySnapshot + nonRootSheetIds.associateWith { false }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            buildViewRenderHost(
                context = ctx,
                scroll = scroll,
                pullToRefreshEnabled = pullToRefreshEnabled,
                onScroll = onScroll,
                scrollThrottleMs = scrollThrottleMs,
                onPtrRefresh = onPtrRefresh,
            )
        },
        update = { host ->
            // Rebuilt on every recomposition of a new/refreshed `contract` or a
            // visibility change (a tab tap, a `show`/`hide` action, a cooldown
            // lock/release). When PTR is wrapping, the content host is the
            // [NestedScrollView] inside the SwipeRefreshLayout — resolved by
            // type, never by index: SwipeRefreshLayout's constructor adds its
            // own spinner view as a child (plan step 8).
            val contentHost = (host as? SwipeRefreshLayout)?.let { srl ->
                (0 until srl.childCount).asSequence().map(srl::getChildAt).filterIsInstance<NestedScrollView>().first()
            } ?: host
            // Preserve the outer scroll offset across the rebuild — a naive
            // `removeAllViews`/`addView` would otherwise jump back to top.
            val savedScrollY = contentHost.scrollY
            contentHost.removeAllViews()
            val rendered = ViewBlockRenderer.render(
                context = contentHost.context,
                contract = contract,
                imageContent = imageContent,
                fontResolver = fontResolver,
                animationsEnabled = true,
                interaction = interaction,
                visibilityOverrides = mainTreeOverrides,
                embeddedContracts = embedded.toMap(),
                themeId = themeId,
            )
            rendered.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            )
            contentHost.addView(rendered)
            contentHost.post { contentHost.scrollY = savedScrollY }
            (host as? SwipeRefreshLayout)?.isRefreshing = isRefreshing
        },
    )

    val visibleSheetId = nonRootSheetIds.firstOrNull { visibilitySnapshot[it] == true }
    if (visibleSheetId != null) {
        val sheetNode = remember(contract.root, visibleSheetId) { findNode(contract.root, visibleSheetId) }
        if (sheetNode != null) {
            BottomSheetOverlay(
                context = context,
                contract = contract,
                sheetNode = sheetNode,
                imageContent = imageContent,
                fontResolver = fontResolver,
                interaction = interaction,
                visibilityOverrides = visibilitySnapshot,
                embeddedContracts = embedded.toMap(),
                themeId = themeId,
                onDismiss = {
                    interaction.onVisibilityChange(
                        setBlockVisibility(interaction.currentVisibility(), visibleSheetId, false),
                    )
                },
            )
        }
    }
}

/**
 * Presents [sheetNode]'s rendered subtree as a plain bottom-anchored [Dialog]
 * (no Material dependency, per the strategist's ruling): bottom gravity,
 * `WRAP_CONTENT` height, a dim scrim, and a slide-up entrance. Dismiss (back
 * press or a scrim tap, both native `Dialog` behaviour) calls [onDismiss],
 * which flips the sheet's visibility back to `false` through the SAME
 * interaction seam a tab tap uses. Full drag-to-dismiss / partial-expand
 * parity with the reference's `ModalBottomSheet` is enumerated debt — the
 * acceptance bar here is "the sheet opens and dismisses".
 */
@Composable
private fun BottomSheetOverlay(
    context: Context,
    contract: ScreenContract,
    sheetNode: BlockNode,
    imageContent: ViewBlockImageContent,
    fontResolver: ViewBlockFontResolver,
    interaction: ViewBlockInteractionContext,
    visibilityOverrides: Map<String, Boolean>,
    embeddedContracts: Map<String, ScreenContract>,
    themeId: ThemeId,
    onDismiss: () -> Unit,
) {
    DisposableEffect(sheetNode.id) {
        val dialog = Dialog(context).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setCancelable(true)
            setCanceledOnTouchOutside(true)
            setOnDismissListener { onDismiss() }
        }
        val sheetContract = ScreenContract(
            id = sheetNode.id,
            type = "runtime-bottom-sheet",
            root = sheetNode,
            themeCatalog = contract.themeCatalog,
        )
        val content = ViewBlockRenderer.render(
            context = context,
            contract = sheetContract,
            imageContent = imageContent,
            fontResolver = fontResolver,
            animationsEnabled = true,
            interaction = interaction,
            visibilityOverrides = visibilityOverrides,
            embeddedContracts = embeddedContracts,
            themeId = themeId,
        )
        dialog.setContentView(
            FrameLayout(context).apply {
                addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            },
        )
        dialog.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.4f)
            setBackgroundDrawableResource(android.R.color.transparent)
        }
        dialog.show()
        content.translationY = content.height.toFloat().coerceAtLeast(300f)
        content.animate().translationY(0f).setDuration(SHEET_SLIDE_DURATION_MS).start()
        onDispose { dialog.dismiss() }
    }
}

private const val SHEET_SLIDE_DURATION_MS = 220L

/** Every `BOTTOM_SHEET` node NOT at the tree's own root (plan step 5/7). */
private fun collectNonRootBottomSheetIds(root: BlockNode): Set<String> {
    val ids = mutableSetOf<String>()
    fun walk(node: BlockNode, isRoot: Boolean) {
        if (!isRoot && node.type == BlockType.BOTTOM_SHEET) ids += node.id
        node.children.forEach { walk(it, isRoot = false) }
    }
    walk(root, isRoot = true)
    return ids
}

/**
 * Every `sub-component` target id (`config.componentId ?: config.flowId`,
 * mirroring `RenderBlockSubComponentRenderer.kt:33-34`) reachable from [root] —
 * the set of ids [RenderBlockAsView] pre-resolves via [FlowWrapperRuntimeConfig.contractProvider]
 * (plan step 10) into `embeddedContracts`.
 */
private fun collectSubComponentTargetIds(root: BlockNode): Set<String> {
    val ids = mutableSetOf<String>()
    fun walk(node: BlockNode) {
        if (node.type == BlockType.SUB_COMPONENT) {
            val config = node.config as? SubComponentBlockConfig
            (config?.componentId?.takeIf { it.isNotBlank() } ?: config?.flowId?.takeIf { it.isNotBlank() })
                ?.let { ids += it }
        }
        node.children.forEach(::walk)
    }
    walk(root)
    return ids
}

private fun findNode(root: BlockNode, id: String): BlockNode? {
    if (root.id == id) return root
    for (child in root.children) {
        findNode(child, id)?.let { return it }
    }
    return null
}

/**
 * `scroll == true` mirrors `rootListLayoutFor(scroll) == LAZY` — the SDK owns
 * scrolling, here via a [NestedScrollView] (non-recycling; acceptable for a
 * home-sized L&F review, not a LazyColumn-equivalent) so it still participates
 * in Android nested-scroll with a host. `scroll == false` mirrors WRAP_CONTENT
 * — the host owns the outer scroll — via a plain, non-scrolling [FrameLayout].
 *
 * `pullToRefreshEnabled` (implies `scroll`, per `effectivePullToRefresh`) wraps
 * the [NestedScrollView] in a [SwipeRefreshLayout], mirroring the reference's
 * `PullToRefreshBox` (`RenderBlockScreen.kt:501-507`) — the content
 * [NestedScrollView] sits NEXT TO SwipeRefreshLayout's own spinner child, so
 * consumers resolve it by type (see the `AndroidView.update` `contentHost`
 * resolution above).
 *
 * Non-composable and testable without composition (behavior-parity plan's
 * SRP note): `flowsSampleApp`'s `ScrollReportParityTest`/`PtrGestureParityTest`
 * (a separate Gradle module, no `friendPaths`) drive this directly — not
 * `internal`, same cross-module-visibility reason as `LocalRenderRouteStateKey`.
 */
fun buildViewRenderHost(
    context: Context,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    onScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)?,
    scrollThrottleMs: Long,
    onPtrRefresh: () -> Unit,
): ViewGroup {
    val matchParent = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    if (!scroll) {
        return FrameLayout(context).apply { layoutParams = matchParent }
    }
    val scrollView = NestedScrollView(context).apply {
        isFillViewport = true
        layoutParams = matchParent
    }
    if (onScroll != null) attachScrollReporter(scrollView, onScroll, scrollThrottleMs)
    if (!pullToRefreshEnabled) return scrollView
    return SwipeRefreshLayout(context).apply {
        layoutParams = matchParent
        addView(scrollView, matchParent)
        setOnRefreshListener { onPtrRefresh() }
    }
}

/**
 * Rate-limits [onScroll] emissions to [scrollThrottleMs], mirroring
 * `throttleScrollPositions` (`RenderBlockScreen.kt:416-426`): the first
 * position in a window is emitted immediately (leading edge); any further
 * position while that window is open replaces a single pending trailing
 * emission, delivered at the window's end with the latest (resting) value.
 * `scrollThrottleMs <= 0` disables throttling (raw per-frame emission).
 */
private fun attachScrollReporter(
    scrollView: NestedScrollView,
    onScroll: (br.com.wave.flows.kmp.core.ScrollInfo) -> Unit,
    scrollThrottleMs: Long,
) {
    val handler = Handler(Looper.getMainLooper())
    var lastEmitUptimeMs = 0L
    var lastOffset = 0
    var pendingEmit: Runnable? = null

    fun emit(scrollY: Int) {
        onScroll(scrollInfoFor(offset = scrollY, index = 0, lastOffset = lastOffset, lastIndex = 0))
        lastOffset = scrollY
    }

    scrollView.setOnScrollChangeListener { _, _, scrollY, _, _ ->
        if (scrollThrottleMs <= 0L) {
            emit(scrollY)
            return@setOnScrollChangeListener
        }
        val now = SystemClock.uptimeMillis()
        pendingEmit?.let(handler::removeCallbacks)
        if (now - lastEmitUptimeMs >= scrollThrottleMs) {
            pendingEmit = null
            lastEmitUptimeMs = now
            emit(scrollY)
        } else {
            val runnable = Runnable {
                lastEmitUptimeMs = SystemClock.uptimeMillis()
                emit(scrollY)
            }
            pendingEmit = runnable
            handler.postDelayed(runnable, lastEmitUptimeMs + scrollThrottleMs - now)
        }
    }
}
