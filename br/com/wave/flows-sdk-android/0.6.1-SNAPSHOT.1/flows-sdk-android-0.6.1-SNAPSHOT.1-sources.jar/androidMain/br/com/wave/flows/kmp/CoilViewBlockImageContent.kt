package br.com.wave.flows.kmp

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View
import br.com.wave.flows.kmp.viewblocks.ViewBlockImageContent
import coil3.ImageLoader
import coil3.asDrawable
import coil3.request.ImageRequest

/**
 * Forwards every [Drawable] call to a swappable delegate, so [resolve] can
 * return a real, non-null [Drawable] synchronously (never falling to the
 * renderer's empty-`View` fallback) while the actual bytes load async. Until a
 * delegate lands, [getIntrinsicWidth]/[getIntrinsicHeight] report -1 (no
 * size), same as a plain Coil placeholder. [setDelegate] then forwards the
 * delegate's real intrinsic size AND requests a re-measure of the host
 * `ImageView` (via its registered [Drawable.Callback], set by
 * `ImageView.setImageDrawable`): a single-dimension image (`adjustViewBounds`
 * + `WRAP_CONTENT` on the other axis, e.g. a full-width banner) is sized from
 * intrinsic aspect ratio at initial measure, when it is still -1, and would
 * otherwise stay collapsed forever once the real bytes arrive. `invalidateSelf`
 * alone only repaints in place — Compose's `AsyncImage` gets an equivalent
 * relayout for free from recomposition on load; this is the View-side
 * equivalent.
 *
 * `internal`, not `private`: `ForwardingDrawableReMeasureInstrumentedTest`
 * (androidDeviceTest) constructs this directly to isolate the re-measure
 * mechanism from Coil's async fetch.
 */
internal class ForwardingDrawable : Drawable() {
    private var delegate: Drawable? = null

    fun setDelegate(newDelegate: Drawable) {
        newDelegate.bounds = bounds
        delegate = newDelegate
        (callback as? View)?.requestLayout()
        invalidateSelf()
    }

    override fun getIntrinsicWidth(): Int = delegate?.intrinsicWidth ?: -1

    override fun getIntrinsicHeight(): Int = delegate?.intrinsicHeight ?: -1

    override fun onBoundsChange(bounds: Rect) {
        delegate?.bounds = bounds
    }

    override fun draw(canvas: Canvas) {
        delegate?.draw(canvas)
    }

    override fun setAlpha(alpha: Int) {
        delegate?.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        delegate?.colorFilter = colorFilter
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * Real network images through the same WAF-safe [imageLoader] the Compose
 * path uses (`FlowWrapper.createFlowImageLoader`, browser UA/Referer/
 * Accept-Language + `SvgDecoder`) — without widening `:viewblocks`'
 * synchronous [ViewBlockImageContent] contract.
 */
internal class CoilViewBlockImageContent(
    private val context: Context,
    private val imageLoader: ImageLoader,
) : ViewBlockImageContent {
    override fun resolve(url: String): Drawable {
        val forwarding = ForwardingDrawable()
        val request = ImageRequest.Builder(context)
            .data(url)
            .target(onSuccess = { image -> forwarding.setDelegate(image.asDrawable(context.resources)) })
            .build()
        imageLoader.enqueue(request)
        return forwarding
    }
}
