package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.viewblocks.ViewBlockRefreshCooldownStore

internal actual val platformSupportsViewEngine: Boolean = true

@Composable
internal actual fun platformViewRenderContract(
    config: FlowWrapperRuntimeConfig,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    onScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)?,
    scrollThrottleMs: Long,
): (@Composable (ScreenContract, HostEventHandler, Boolean, () -> Unit) -> Unit)? {
    if (FlowWrapper.renderEngine != RenderEngine.VIEW) return null
    return { contract, hostEventHandler, isRefreshing, onPtrRefresh ->
        RenderBlockAsView(
            contract = contract,
            config = config,
            hostEventHandler = hostEventHandler,
            scroll = scroll,
            pullToRefreshEnabled = pullToRefreshEnabled,
            isRefreshing = isRefreshing,
            onPtrRefresh = onPtrRefresh,
            onScroll = onScroll,
            scrollThrottleMs = scrollThrottleMs,
        )
    }
}

internal actual fun clearPlatformViewCooldowns() {
    ViewBlockRefreshCooldownStore.clear()
}
