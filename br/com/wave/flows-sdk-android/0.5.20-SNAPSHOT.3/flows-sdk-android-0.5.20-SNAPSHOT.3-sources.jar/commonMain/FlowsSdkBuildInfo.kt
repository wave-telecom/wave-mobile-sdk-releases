package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.3-1-gbc332f7"
    const val COMPILED_AT_BRT: String = "2026-07-03T19:33:48.32266-03:00"
    const val GIT_SHA: String = "bc332f7"
    const val GIT_BRANCH: String = "fix/core-analytics-proguard-keep"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.3-1-gbc332f7@2026-07-03T19:33:48.32266-03:00#bc332f7"
}