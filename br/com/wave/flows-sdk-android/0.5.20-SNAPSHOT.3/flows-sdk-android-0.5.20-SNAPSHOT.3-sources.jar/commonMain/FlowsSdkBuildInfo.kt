package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.2-5-gedba225"
    const val COMPILED_AT_BRT: String = "2026-07-03T18:48:32.991703-03:00"
    const val GIT_SHA: String = "edba225"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.2-5-gedba225@2026-07-03T18:48:32.991703-03:00#edba225"
}