package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.12-7-g71d8049"
    const val COMPILED_AT_BRT: String = "2026-06-12T11:06:42.527719-03:00"
    const val GIT_SHA: String = "71d8049"
    const val GIT_BRANCH: String = "release/0.5.13"
    const val DESCRIPTION: String = "0.5.12-7-g71d8049@2026-06-12T11:06:42.527719-03:00#71d8049"
}