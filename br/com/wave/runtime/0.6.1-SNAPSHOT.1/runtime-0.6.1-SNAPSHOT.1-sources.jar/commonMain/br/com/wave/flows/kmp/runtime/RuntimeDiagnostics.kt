package br.com.wave.flows.kmp.runtime

/**
 * Seam for opt-in verbose diagnostics for the contract fetch/parse pipeline.
 *
 * The verbose formatting (decoder messages, JSON paths, contract meta) lives
 * only in the `sdkBuildType=debug` source set of this module and is installed
 * via [br.com.wave.flows.kmp.runtime.ContractDiagnosticsBootstrap]. In a
 * published (release) build that source set is compiled out entirely: the
 * hook below stays null and the forwarders emit nothing, so verbose payload
 * detail can never reach an integrator regardless of the HOST app's own
 * debug/release build type.
 */
internal object RuntimeDiagnostics {
    internal var contractDiagnostics: ContractDiagnostics? = null
}

/**
 * Verbose contract diagnostics delegate. The only implementation lives in the
 * debug source set; release builds never have a concrete instance to install.
 */
internal interface ContractDiagnostics {
    fun logParseFailureDetail(logger: RuntimeLogger, context: String, error: Throwable)
    fun logPayloadMeta(logger: RuntimeLogger, context: String, rawJson: String)
}

/**
 * Detail line for a contract failure. No-op when no delegate is installed
 * (release builds, or diagnostics off).
 */
internal fun RuntimeLogger.debugContractDetail(context: String, error: Throwable) {
    RuntimeDiagnostics.contractDiagnostics?.logParseFailureDetail(this, context, error)
}

/**
 * `meta` descriptor (contract version + correlationId) of a fetched payload,
 * for correlating client-side failures with BFF deploys. Same seam as
 * [debugContractDetail].
 */
internal fun RuntimeLogger.debugContractMeta(context: String, rawJson: String) {
    RuntimeDiagnostics.contractDiagnostics?.logPayloadMeta(this, context, rawJson)
}
