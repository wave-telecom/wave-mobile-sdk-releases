package br.com.wave.flows.kmp.runtime.warmup

import br.com.wave.flows.kmp.runtime.api.BffApi
import br.com.wave.flows.kmp.runtime.api.BffScreenContractCache
import br.com.wave.flows.kmp.runtime.api.sources.ContractMode
import br.com.wave.flows.kmp.runtime.api.sources.ContractQuery
import br.com.wave.flows.kmp.runtime.api.sources.LiveBlockIndex
import br.com.wave.flows.kmp.runtime.api.init.InitEntryDto
import br.com.wave.flows.kmp.runtime.api.init.InitResponseParser
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.runtime.contract.parseScreenContract
import br.com.wave.flows.kmp.runtime.DefaultRuntimeDispatchers
import br.com.wave.flows.kmp.runtime.NoOpRuntimeLogger
import br.com.wave.flows.kmp.runtime.debugContractDetail
import br.com.wave.flows.kmp.runtime.debugContractMeta
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.RuntimeDispatchers
import br.com.wave.flows.kmp.runtime.RuntimeLogger
import br.com.wave.flows.kmp.runtime.SystemRuntimeClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

const val WARMUP_DEFAULT_TTL_MS = 10L * 60 * 1000
private const val WARMUP_MAX_CONCURRENCY = 4

data class WarmupEntry(
    val slug: String,
    val type: String,
    val mode: String,
)

class WarmupCoordinator(
    baseUrl: String,
    private val externalCode: String,
    private val api: BffApi,
    private val diskCache: WarmupDiskCacheStore?,
    private val onScreenContractCached: suspend (ScreenContract) -> Unit = {},
    private val dispatchers: RuntimeDispatchers = DefaultRuntimeDispatchers,
    private val clock: RuntimeClock = SystemRuntimeClock,
    private val logger: RuntimeLogger = NoOpRuntimeLogger,
) {
    private val normalizedBaseUrl = baseUrl.trimEnd('/')

    /** Fetch the raw `/api/init` body and hand it to [onInitJson]; unlike [warmup]
     *  it does NOT warm the declared entries (native warm targets come from the
     *  render-routing policy the caller derives from this body). */
    suspend fun fetchInit(onInitJson: suspend (String) -> Unit) {
        val initJson = fetchInitJson() ?: return
        onInitJson(initJson)
    }

    private suspend fun fetchInitJson(): String? =
        try {
            withContext(dispatchers.io) {
                logger.info("Init request started")
                val response = api.getInit(externalCode)
                check(response.isSuccessful) {
                    "Init request failed (HTTP ${response.code})"
                }
                response.body ?: error("Init response body is empty")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logger.warn("Init request failed (reason=${e::class.simpleName})")
            null
        }

    suspend fun warmup() {
        logger.info("Warm-up started")

        val initJson = fetchInitJson() ?: return

        logger.info("Init request succeeded")

        val initResponse = try {
            InitResponseParser.parse(initJson)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logger.warn("Init response parsing failed (reason=${e::class.simpleName})")
            return
        }

        logger.info(
            "Init declared ${initResponse.preloadable.size} preloadable, " +
                "${initResponse.cacheable.size} cacheable entries",
        )

        warm(
            initResponse.preloadable.map { entry ->
                WarmupEntry(slug = entry.slug, type = entry.type, mode = ContractMode.SKELETON.wireValue)
            } + initResponse.cacheable.map { entry ->
                WarmupEntry(slug = entry.slug, type = entry.type, mode = ContractMode.FULL.wireValue)
            },
        )

        logger.info("Warm-up completed")
    }

    suspend fun warm(entries: List<WarmupEntry>) {
        if (entries.isEmpty()) return

        val requestLimiter = Semaphore(WARMUP_MAX_CONCURRENCY)
        coroutineScope {
            entries.map { entry ->
                async {
                    requestLimiter.withPermit {
                        fetchAndCache(
                            entry = InitEntryDto(slug = entry.slug, type = entry.type),
                            mode = entry.mode,
                        )
                    }
                }
            }.awaitAll()
        }
    }

    private suspend fun fetchAndCache(entry: InitEntryDto, mode: String) {
        val cacheKey = WarmupCacheKey(
            baseUrl = normalizedBaseUrl,
            externalCode = externalCode,
            entryType = entry.type,
            slug = entry.slug,
            mode = mode,
        )

        logger.info("Fetching ${entry.slug} (type=${entry.type}, mode=$mode)")

        try {
            val json = withContext(dispatchers.io) {
                val response = when {
                    entry.type == "flow" && mode == "skeleton" ->
                        api.getFlowContractSkeleton(entry.slug, externalCode, "skeleton")
                    entry.type == "flow" ->
                        api.getFlowContract(entry.slug, externalCode)
                    else ->
                        api.getComponentContract(entry.slug, externalCode)
                }
                check(response.isSuccessful) {
                    "Fetch failed for ${entry.slug} (HTTP ${response.code})"
                }
                response.body ?: error("Empty response for ${entry.slug}")
            }

            logger.debugContractMeta("Fetched ${entry.slug} (type=${entry.type}, mode=$mode)", json)
            val ttlMs = ResponseMetadataExtractor.extractExpiresInMs(json) ?: WARMUP_DEFAULT_TTL_MS
            diskCache?.write(cacheKey, json, ttlMs)
            val contract = parseScreenContract(
                json = json,
                reporter = RuntimeContractAnomalyReporter(logger),
            )
            BffScreenContractCache.put(
                baseUrl = normalizedBaseUrl,
                externalCode = externalCode,
                componentId = entry.slug,
                contract = contract,
                mode = mode,
            )
            LiveBlockIndex.register(
                contractQuery = ContractQuery(
                    baseUrl = normalizedBaseUrl,
                    externalCode = externalCode,
                    componentId = entry.slug,
                    mode = when (mode) {
                        ContractMode.SKELETON.wireValue -> ContractMode.SKELETON
                        else -> ContractMode.FULL
                    },
                ),
                contract = contract,
            )
            runCatching {
                onScreenContractCached(contract)
            }.onFailure { error ->
                logger.warn("Image preload failed for ${entry.slug} (type=${entry.type}, mode=$mode, reason=${error::class.simpleName})")
            }
            logger.info("Cached ${entry.slug} (type=${entry.type}, mode=$mode, ttlMs=$ttlMs)")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            logger.warn("Failed to fetch ${entry.slug} (type=${entry.type}, mode=$mode, reason=${e::class.simpleName})")
            logger.debugContractDetail("Failed to fetch ${entry.slug} (type=${entry.type}, mode=$mode)", e)
        }
    }
}
