package br.com.wave.flows.kmp.runtime.contract.dto.block

import br.com.wave.flows.kmp.runtime.contract.mapping.support.TransportValueCoercions
import br.com.wave.flows.kmp.runtime.contract.dto.action.ActionDto
import kotlinx.serialization.DeserializationStrategy
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import kotlinx.serialization.json.JsonContentPolymorphicSerializer
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

@Serializable(with = BlockDtoSerializer::class)
internal sealed interface BlockDto {
    val id: String?
    val type: String?
    val children: List<BlockDto>?
    val action: ActionDto?
}

internal object BlockDtoSerializer : JsonContentPolymorphicSerializer<BlockDto>(BlockDto::class) {
    override fun selectDeserializer(element: JsonElement): DeserializationStrategy<BlockDto> {
        val obj = element as? JsonObject
        val rawType = (obj?.get("type") as? JsonPrimitive)?.contentOrNull
        return when (TransportValueCoercions.normalizeEnumValue(rawType)) {
            "text" -> TextBlockDto.serializer()
            "rich-text" -> RichTextBlockDto.serializer()
            "button" -> ButtonBlockDto.serializer()
            "card" -> CardBlockDto.serializer()
            "container" -> ContainerBlockDto.serializer()
            "list" -> ListBlockDto.serializer()
            "divider" -> DividerBlockDto.serializer()
            "grid" -> GridBlockDto.serializer()
            "image", "icon" -> ImageBlockDto.serializer()
            "carousel" -> CarouselBlockDto.serializer()
            "chart" -> ChartBlockDto.serializer()
            "radio-group" -> RadioGroupBlockDto.serializer()
            "skeleton" -> SkeletonBlockDto.serializer()
            "sub-component" -> SubComponentBlockDto.serializer()
            "spacer" -> SpacerBlockDto.serializer()
            "toolbar" -> ToolbarBlockDto.serializer()
            "tabs" -> TabsBlockDto.serializer()
            "tabs-plans" -> TabsPlansBlockDto.serializer()
            "bottom-sheet" -> BottomSheetBlockDto.serializer()
            "accordion" -> AccordionBlockDto.serializer()
            else -> UnknownBlockDto.serializer()
        }
    }
}

internal interface BaseStyleDto {
    val margin: Int?
    val marginTop: Int?
    val marginBottom: Int?
    val marginLeft: Int?
    val marginRight: Int?
    val padding: Int?
    val paddingTop: Int?
    val paddingBottom: Int?
    val paddingLeft: Int?
    val paddingRight: Int?
    val borderRadius: Int?
    val borderRadiusTop: Int?
    val borderRadiusBottom: Int?
    val borderRadiusLeft: Int?
    val borderRadiusRight: Int?
    val borderWidth: Int?
    val borderColor: String?
    val borderStyle: String?
    val backgroundColor: String?
    val color: String?
    val visibility: Boolean?
}

internal interface SizedStyleDto : BaseStyleDto {
    val width: Int?
    val height: Int?
}

internal interface ResponsiveSizeDto {
    val maxWidth: Int?
    val fullWidth: Boolean?
}

internal interface PositioningStyleDto {
    val position: String?
    val top: Int?
    val right: Int?
    val bottom: Int?
    val left: Int?
    val zIndex: Int?
}

@Serializable
internal data class BlockVariantSelectedDto(
    val color: String? = null,
    val backgroundColor: String? = null,
    val borderRadius: Int? = null,
)

@Serializable
internal data class BlockVariantDisabledDto(
    val color: String? = null,
    val backgroundColor: String? = null,
)

@Serializable
internal data class BlockVariantsDto(
    val selected: BlockVariantSelectedDto? = null,
    val disabled: BlockVariantDisabledDto? = null,
)

@Serializable
internal data class TextBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: TextBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class RichTextBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: RichTextBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class ButtonBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: ButtonBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class CardBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: CardBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class ContainerBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: ContainerBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class ListBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: ListBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class DividerBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: DividerBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class GridBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: GridBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class ImageBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: ImageBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class CarouselBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: CarouselBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class ChartBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: ChartBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class RadioGroupBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: RadioGroupBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class SkeletonBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: SkeletonBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class SubComponentBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: SubComponentBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class SpacerBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: SpacerBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class ToolbarBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: ToolbarBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class TabsBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: TabsBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class BottomSheetBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: BottomSheetBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class AccordionBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: AccordionBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class UnknownBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: JsonObject? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class TabsPlansBlockConfigDto(
    val data: List<TabsPlansGroupDto>? = null,
    val visibility: Boolean? = null,
)

@Serializable
internal data class TabsPlansBlockDto(
    override val id: String? = null,
    override val type: String? = null,
    val config: TabsPlansBlockConfigDto? = null,
    override val children: List<BlockDto>? = null,
    override val action: ActionDto? = null,
) : BlockDto

@Serializable
internal data class TabsPlansGroupDto(
    val title: String? = null,
    val options: List<TabsPlansOptionDto>? = null,
    val categories: List<TabsPlansCategoryDto>? = null,
    val p: Int? = null,
)

@Serializable
internal data class TabsPlansOptionDto(
    val label: String? = null,
    val value: String? = null,
    val p: Int? = null,
)

@Serializable
internal data class TabsPlansCategoryDto(
    val category: String? = null,
    val referenceId: String? = null,
    val plans: List<TabsPlansPlanDto>? = null,
    val p: Int? = null,
)

@Serializable
internal data class TabsPlansUsageDataPointDto(
    val key: String? = null,
    val fill: String? = null,
    val value: Int? = null,
    val updatedAt: String? = null,
)

@Serializable
internal data class TabsPlansExtrasDto(
    val facebook: Boolean? = null,
    val x: Boolean? = null,
    val snapchat: Boolean? = null,
    val whatsapp: Boolean? = null,
    val instagram: Boolean? = null,
    val uber: Boolean? = null,
    val calls: Boolean? = null,
    val sms: Boolean? = null,
    val messenger: Boolean? = null,
    val data: Boolean? = null,
)

@Serializable
internal data class TabsPlansLimitedDto(
    val data: Int? = null,
)

@Serializable
internal data class TabsPlansBorderlessServicesDto(
    val sms: Boolean? = null,
    val data: Boolean? = null,
    val voice: Boolean? = null,
    val whatsapp: Boolean? = null,
    val social: Boolean? = null,
)

@Serializable
internal data class TabsPlansMetadataDto(
    val priority: Int? = null,
    val category: String? = null,
    val label: String? = null,
)

@Serializable
internal data class TabsPlansPlanDto(
    val id: String? = null,
    val name: String? = null,
    val category: String? = null,
    val price: Int? = null,
    val createdAt: String? = null,
    val startDate: String? = null,
    val endDate: String? = null,
    val totalData: Int? = null,
    val usedData: Int? = null,
    val availableData: Int? = null,
    val unlimited: Boolean? = null,
    val limited: TabsPlansLimitedDto? = null,
    val extras: TabsPlansExtrasDto? = null,
    val extra: TabsPlansExtrasDto? = null,
    val period: String? = null,
    val borderlessServices: TabsPlansBorderlessServicesDto? = null,
    val usageData: List<TabsPlansUsageDataPointDto>? = null,
    val cutoffMessage: JsonElement? = null,
    val showGetMoreData: Boolean? = null,
    val freeNumbers: Int? = null,
    val frequentNumbers: Int? = null,
    val includedServices: List<String>? = null,
    val metadata: TabsPlansMetadataDto? = null,
    @SerialName("_kind") val kind: String? = null,
    val p: Int? = null,
)

@Serializable
internal data class TextBlockConfigDto(
    val value: String? = null,
    val fontSize: Int? = null,
    val lineHeight: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val align: String? = null,
    val strikethrough: Boolean? = null,
    val truncate: Boolean? = null,
    val variants: BlockVariantsDto? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class RichTextSegmentDto(
    val text: String? = null,
    val fontSize: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val color: String? = null,
    val strikethrough: Boolean? = null,
    val underline: Boolean? = null,
)

@Serializable
internal data class RichTextBlockConfigDto(
    val segments: List<RichTextSegmentDto>? = null,
    val fontSize: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val align: String? = null,
    val strikethrough: Boolean? = null,
    val truncate: Boolean? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class ButtonBlockConfigDto(
    val value: String? = null,
    val text: String? = null,
    val ariaLabel: String? = null,
    val textColor: String? = null,
    val fontSize: Int? = null,
    val lineHeight: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val align: String? = null,
    val variants: BlockVariantsDto? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val maxWidth: Int? = null,
    override val fullWidth: Boolean? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto, ResponsiveSizeDto

@Serializable
internal data class CardBlockConfigDto(
    val elevation: Int? = null,
    val variants: BlockVariantsDto? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val maxWidth: Int? = null,
    override val fullWidth: Boolean? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto, ResponsiveSizeDto

@Serializable
internal data class ContainerBlockConfigDto(
    override val position: String? = null,
    val variants: BlockVariantsDto? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class ListBlockConfigDto(
    val spacing: Int? = null,
    val orientation: String? = null,
    val align: String? = null,
    val verticalAlign: String? = null,
    val horizontalAlign: String? = null,
    val expand: Boolean? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val maxWidth: Int? = null,
    override val fullWidth: Boolean? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto, ResponsiveSizeDto

@Serializable
internal data class DividerBlockConfigDto(
    val orientation: String? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class ImageBlockConfigDto(
    val url: String? = null,
    val altText: String? = null,
    val aspectRatio: String? = null,
    val align: String? = null,
    val variants: BlockVariantsDto? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class CarouselBlockConfigDto(
    val itemWidth: Int? = null,
    val showIndicators: Boolean? = null,
    val showButtons: Boolean? = null,
    val spacing: Int? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class GridBlockConfigDto(
    val columns: Int? = null,
    val gap: Int? = null,
    val maxColumnSize: Int? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class ChartDataPointDto(
    val key: String? = null,
    val value: Int? = null,
    val fill: String? = null,
)

@Serializable
internal data class ChartBlockConfigDto(
    val type: String? = null,
    val data: List<ChartDataPointDto>? = null,
    val size: Int? = null,
    val fontSize: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val lineHeight: Int? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class RadioGroupVariantDto(
    val color: String? = null,
    val backgroundColor: String? = null,
)

@Serializable
internal data class RadioGroupVariantsDto(
    val selected: RadioGroupVariantDto? = null,
)

@Serializable
internal data class RadioGroupBlockConfigDto(
    val orientation: String? = null,
    val activeIndex: Int? = null,
    val activeColor: String? = null,
    val activeBackgroundColor: String? = null,
    val spacing: Int? = null,
    val variants: RadioGroupVariantsDto? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class SkeletonBlockConfigDto(
    val width: String? = null,
    val height: String? = null,
    val align: String? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : BaseStyleDto, PositioningStyleDto

@Serializable
internal data class SubComponentBlockConfigDto(
    val componentId: String? = null,
    val flowId: String? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : BaseStyleDto, PositioningStyleDto

@Serializable
internal data class SpacerBlockConfigDto(
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class ToolbarBlockConfigDto(
    val title: String? = null,
    val align: String? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class TabOptionDto(
    val id: String? = null,
    val label: String? = null,
    val contentReferenceId: String? = null,
)

@Serializable
internal data class TabsBlockConfigDto(
    val options: List<TabOptionDto>? = null,
    val gap: Int? = null,
    val activeColor: String? = null,
    val activeBackgroundColor: String? = null,
    val inactiveColor: String? = null,
    val inactiveBackgroundColor: String? = null,
    val variants: BlockVariantsDto? = null,
    val fontSize: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class BottomSheetBlockConfigDto(
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto

@Serializable
internal data class AccordionBlockConfigDto(
    val title: String? = null,
    val defaultOpen: Boolean? = null,
    val iconColor: String? = null,
    val iconUrl: String? = null,
    val iconWidth: Int? = null,
    val iconHeight: Int? = null,
    val wrapContent: Boolean? = null,
    val fullWidth: Boolean? = null,
    val fontSize: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    override val width: Int? = null,
    override val height: Int? = null,
    override val margin: Int? = null,
    override val marginTop: Int? = null,
    override val marginBottom: Int? = null,
    override val marginLeft: Int? = null,
    override val marginRight: Int? = null,
    override val padding: Int? = null,
    override val paddingTop: Int? = null,
    override val paddingBottom: Int? = null,
    override val paddingLeft: Int? = null,
    override val paddingRight: Int? = null,
    override val borderRadius: Int? = null,
    override val borderRadiusTop: Int? = null,
    override val borderRadiusBottom: Int? = null,
    override val borderRadiusLeft: Int? = null,
    override val borderRadiusRight: Int? = null,
    override val borderWidth: Int? = null,
    override val borderColor: String? = null,
    override val borderStyle: String? = null,
    override val backgroundColor: String? = null,
    override val color: String? = null,
    override val visibility: Boolean? = null,
    override val position: String? = null,
    override val top: Int? = null,
    override val right: Int? = null,
    override val bottom: Int? = null,
    override val left: Int? = null,
    override val zIndex: Int? = null,
) : SizedStyleDto, PositioningStyleDto
