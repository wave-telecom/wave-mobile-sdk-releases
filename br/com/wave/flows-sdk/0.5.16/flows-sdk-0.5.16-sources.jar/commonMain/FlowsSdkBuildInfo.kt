package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-rc.94-1-g47dadd2"
    const val COMPILED_AT_BRT: String = "2026-06-26T19:29:23.64133-03:00"
    const val GIT_SHA: String = "47dadd2"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.16-rc.94-1-g47dadd2@2026-06-26T19:29:23.64133-03:00#47dadd2"
}