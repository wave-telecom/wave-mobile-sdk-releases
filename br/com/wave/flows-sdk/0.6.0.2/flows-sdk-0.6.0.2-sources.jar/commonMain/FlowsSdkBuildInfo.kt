package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0.1-9-gc43f72b9"
    const val COMPILED_AT_BRT: String = "2026-09-01T16:28:02.012121-03:00"
    const val GIT_SHA: String = "c43f72b9"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.6.0.1-9-gc43f72b9@2026-09-01T16:28:02.012121-03:00#c43f72b9"
}