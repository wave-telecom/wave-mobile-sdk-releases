package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.2-rc.158-1-gef10177"
    const val COMPILED_AT_BRT: String = "2026-07-22T10:28:26.694767-03:00"
    const val GIT_SHA: String = "ef10177"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20.2-rc.158-1-gef10177@2026-07-22T10:28:26.694767-03:00#ef10177"
}