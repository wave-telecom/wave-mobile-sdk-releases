package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.12-rc.30-1-g8993cd6"
    const val COMPILED_AT_BRT: String = "2026-06-02T16:05:48.228719-03:00"
    const val GIT_SHA: String = "8993cd6"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.12-rc.30-1-g8993cd6@2026-06-02T16:05:48.228719-03:00#8993cd6"
}