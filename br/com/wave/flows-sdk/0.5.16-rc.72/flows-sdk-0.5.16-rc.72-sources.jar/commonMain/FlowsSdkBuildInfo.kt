package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-SNAPSHOT-11-gbb19257"
    const val COMPILED_AT_BRT: String = "2026-06-26T09:58:23.580739-03:00"
    const val GIT_SHA: String = "bb19257"
    const val GIT_BRANCH: String = "release/0.5.16"
    const val DESCRIPTION: String = "0.5.16-SNAPSHOT-11-gbb19257@2026-06-26T09:58:23.580739-03:00#bb19257"
}