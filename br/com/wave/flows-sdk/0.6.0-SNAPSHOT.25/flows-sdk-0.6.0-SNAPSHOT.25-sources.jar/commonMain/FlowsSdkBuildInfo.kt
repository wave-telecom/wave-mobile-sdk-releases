package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.23-7-g776f68c"
    const val COMPILED_AT_BRT: String = "2026-05-25T13:37:42.611613-03:00"
    const val GIT_SHA: String = "776f68c"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.23-7-g776f68c@2026-05-25T13:37:42.611613-03:00#776f68c"
}