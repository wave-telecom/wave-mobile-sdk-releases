package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockImageContent
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockFontResolver
import br.com.wave.flows.kmp.composeblocks.RenderBlockRoute
import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.host.ActionData
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.runtime.DEFAULT_BFF_BASE_URL
import br.com.wave.flows.kmp.runtime.DEFAULT_COMPONENT_ID
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_ACTION
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_BACK
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_NAVIGATE
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_OPEN_URL
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_REFRESH
import br.com.wave.flows.kmp.runtime.ORIGIN_NATIVE_RENDER_BLOCK
import br.com.wave.flows.kmp.runtime.api.BffApiFactory
import br.com.wave.flows.kmp.runtime.api.clearBffScreenContractCache
import br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider
import br.com.wave.flows.kmp.runtime.warmup.WarmupCoordinator
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore
import br.com.wave.flows.kmp.runtime.resolveEntry
import io.ktor.client.HttpClient
import coil3.SingletonImageLoader
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.svg.SvgDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okio.Path.Companion.toPath

private const val DEFAULT_IMAGE_CDN_BASE_URL =
    "https://telcel-dev-wave-journeys-web.vercel.app"

internal data class FlowWrapperRuntimeConfig(
    val contractProvider: ScreenContractProvider,
    val defaultComponentId: String = DEFAULT_COMPONENT_ID,
    val httpClient: HttpClient,
    val imageUrlResolver: FlowImageUrlResolver = FlowImageUrlResolver(DEFAULT_IMAGE_CDN_BASE_URL),
)

sealed class SDKEvent {
    data class Error(
        val componentId: String,
        val code: String,
        val message: String,
    ) : SDKEvent()

    data class ComponentLoaded(
        val componentId: String,
    ) : SDKEvent()

    data class Callback(
        val type: String,
        val payload: String,
        val origin: String,
    ) : SDKEvent()
}

object FlowWrapper {
    private var runtimeConfig: FlowWrapperRuntimeConfig? = null
    private val sdkScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var warmupJob: Job? = null
    private var renderSessionToken by mutableIntStateOf(0)

    fun start(
        apiKey: String,
        msisdn: String,
        onReady: (() -> Unit)? = null,
    ) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        warmupJob?.cancel()
        runtimeConfig?.httpClient?.close()
        renderSessionToken += 1
        clearBffScreenContractCache()
        configureFlowImageLoaderFactory()
        clearFlowImageLoaderMemoryCache()

        val externalCode = sanitizedMsisdn.filter(Char::isDigit)
        val httpClient = createPlatformHttpClient()
        val warmupCacheDir = platformWarmupCacheDir()
        val diskCache =
            warmupCacheDir
                ?.takeIf { it.isNotBlank() }
                ?.toPath()
                ?.let(::WarmupDiskCacheStore)
        val contractProvider =
            BffScreenContractProvider(
                baseUrl = DEFAULT_BFF_BASE_URL,
                externalCode = externalCode,
                diskCache = diskCache,
                api = BffApiFactory.create(
                    client = httpClient,
                    baseUrl = DEFAULT_BFF_BASE_URL,
                ),
            )

        runtimeConfig =
            FlowWrapperRuntimeConfig(
                contractProvider = contractProvider,
                httpClient = httpClient,
                imageUrlResolver = FlowImageUrlResolver(DEFAULT_IMAGE_CDN_BASE_URL),
            )

        if (diskCache == null) {
            runOnUiThread { onReady?.invoke() }
            return
        }

        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = DEFAULT_BFF_BASE_URL,
                        externalCode = externalCode,
                        api = BffApiFactory.create(
                            client = httpClient,
                            baseUrl = DEFAULT_BFF_BASE_URL,
                        ),
                        diskCache = diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                    ).warmup()
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    internal fun requireConfig(): FlowWrapperRuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentRenderSessionToken(): Int = renderSessionToken

    internal fun resolveImageUrl(url: String): String {
        return runtimeConfig?.imageUrlResolver?.resolve(url) ?: url
    }

    /**
     * Drops the cached `full` contract for [componentId] so the next
     * lookup goes through the chain and reaches the BFF again. The
     * companion `skeleton` entry is preserved, so a re-mounted
     * `RenderBlock` can still surface the cached skeleton while the
     * fresh fetch is in flight.
     *
     * **This call alone does not trigger a re-fetch.** It only clears
     * the cache. The host is responsible for re-mounting the relevant
     * `RenderBlock` — typically by bumping a per-component
     * `refreshToken` and passing it as the `refreshToken` parameter of
     * the composable. Splitting these two concerns lets the host
     * refresh a single component without disturbing siblings (e.g. the
     * navbar) and without resetting global state.
     *
     * Safe to call without an active session — does nothing if
     * `start()` was never called.
     */
    fun refresh(componentId: String, externalCode: String? = null) {
        val provider = runtimeConfig?.contractProvider as? BffScreenContractProvider ?: return
        provider.invalidate(componentId = componentId, externalCode = externalCode)
    }
}

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    refreshToken: Int = 0,
    modifier: Modifier = Modifier,
) {
    val config = FlowWrapper.requireConfig()
    val resolvedComponentId = resolveEntry(componentId, flowId, config.defaultComponentId)
    val renderSessionToken = FlowWrapper.currentRenderSessionToken()
    val fontResolver = rememberFlowRenderBlockFontResolver()

    CompositionLocalProvider(
        LocalRenderBlockImageContent provides FlowRenderBlockImageContent,
        LocalRenderBlockFontResolver provides fontResolver,
    ) {
        RenderBlockRoute(
            componentId = resolvedComponentId,
            contractProvider = config.contractProvider,
            sessionToken = renderSessionToken,
            refreshToken = refreshToken,
            hostEventHandler = FlowWrapperHostEventHandler(
                componentId = resolvedComponentId,
                onEvent = onEvent,
            ),
            onContractLoaded = { contract ->
                onEvent?.invoke(SDKEvent.ComponentLoaded(contract.id))
            },
            modifier = modifier,
        )
    }
}

private fun configureFlowImageLoaderFactory() {
    SingletonImageLoader.setSafe { context ->
        createFlowImageLoader(context)
    }
}

private fun clearFlowImageLoaderMemoryCache() {
    runCatching {
        val imageLoader = SingletonImageLoader.get(platformImageLoaderContext())
        imageLoader.memoryCache?.clear()
    }
}

private fun createFlowImageLoader(context: PlatformContext): ImageLoader {
    return ImageLoader.Builder(context)
        .components {
            add(SvgDecoder.Factory())
        }
        .build()
}

private class FlowWrapperHostEventHandler(
    private val componentId: String,
    private val onEvent: ((SDKEvent) -> Unit)?,
) : HostEventHandler {
    override fun onHostEvent(event: HostEvent) {
        onEvent?.invoke(event.toSdkEvent(componentId))
    }
}

private fun HostEvent.toSdkEvent(componentId: String): SDKEvent {
    return when (this) {
        is HostEvent.Error -> SDKEvent.Error(
            componentId = componentId,
            code = error.code,
            message = error.message,
        )

        is HostEvent.ActionTracked -> SDKEvent.Callback(
            type = event.type,
            payload = buildActionPayload(event),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        is HostEvent.DelegatedHostAction -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_ACTION,
            payload = rawJson,
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        HostEvent.Refresh -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_REFRESH,
            payload = buildJsonObject {
                put("componentId", JsonPrimitive(componentId))
            }.toString(),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        is HostEvent.Navigation -> SDKEvent.Callback(
            type = navigationType(event),
            payload = navigationPayload(event),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )
    }
}

private fun buildActionPayload(actionData: ActionData): String {
    return buildJsonObject {
        put("type", JsonPrimitive(actionData.type))
        put(
            "payload",
            buildJsonObject {
                actionData.payload.forEach { (key, value) ->
                    put(key, JsonPrimitive(value))
                }
            },
        )
        put("timestamp", JsonPrimitive(actionData.timestamp))
    }.toString()
}

private fun navigationType(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> EVENT_RENDER_BLOCK_NAVIGATE
        NavigationEvent.Back -> EVENT_RENDER_BLOCK_BACK
        is NavigationEvent.External -> EVENT_RENDER_BLOCK_OPEN_URL
    }
}

private fun navigationPayload(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> event.verbatim.toString()

        NavigationEvent.Back -> "{}"

        is NavigationEvent.External -> buildJsonObject {
            put("url", JsonPrimitive(event.url))
        }.toString()
    }
}
