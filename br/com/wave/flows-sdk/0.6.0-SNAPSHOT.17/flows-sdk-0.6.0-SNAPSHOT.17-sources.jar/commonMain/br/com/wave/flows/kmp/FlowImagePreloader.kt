package br.com.wave.flows.kmp

import br.com.wave.flows.kmp.core.contract.AccordionBlockConfig
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.ImageBlockConfig
import br.com.wave.flows.kmp.core.contract.ScreenContract
import coil3.SingletonImageLoader
import coil3.request.ImageRequest
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

internal suspend fun preloadContractImages(
    contract: ScreenContract,
) {
    val targets = contract.collectImageUrls()
    if (targets.isEmpty()) return

    val context = platformImageLoaderContext()
    val imageLoader = SingletonImageLoader.get(context)

    coroutineScope {
        targets.map { url ->
            async {
                runCatching {
                    imageLoader.execute(
                        ImageRequest.Builder(context)
                            .data(FlowWrapper.resolveImageUrl(url))
                            .build(),
                    )
                }
            }
        }.awaitAll()
    }
}

internal fun ScreenContract.collectImageUrls(): List<String> {
    val seen = linkedSetOf<String>()
    root.collectImageUrlsInto(seen)
    return seen.toList()
}

private fun BlockNode.collectImageUrlsInto(seen: MutableSet<String>) {
    when (val config = config) {
        is ImageBlockConfig -> collectRemoteImageUrl(config.url, seen)
        is AccordionBlockConfig -> collectRemoteImageUrl(config.iconUrl, seen)
        else -> Unit
    }

    children.forEach { child ->
        child.collectImageUrlsInto(seen)
    }
}

private fun collectRemoteImageUrl(
    url: String?,
    seen: MutableSet<String>,
) {
    val normalized = url?.trim().orEmpty()
    if (!normalized.startsWith("http://", ignoreCase = true) &&
        !normalized.startsWith("https://", ignoreCase = true)
    ) {
        return
    }

    seen += normalized
}
