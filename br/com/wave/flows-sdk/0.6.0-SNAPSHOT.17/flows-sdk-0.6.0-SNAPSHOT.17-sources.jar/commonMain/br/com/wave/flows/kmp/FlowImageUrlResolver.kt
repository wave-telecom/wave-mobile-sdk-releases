package br.com.wave.flows.kmp

import io.ktor.http.Url
import io.ktor.http.encodeURLParameter

internal class FlowImageUrlResolver(
    imageCdnBaseUrl: String?,
) {
    private val imageCdnBaseUrl = imageCdnBaseUrl?.trim()?.trimEnd('/')?.takeIf { it.isNotEmpty() }

    fun resolve(rawUrl: String): String {
        val normalized = rawUrl.trim()
        val cdnBaseUrl = imageCdnBaseUrl ?: return rawUrl
        if (normalized.isEmpty()) return rawUrl
        if (!normalized.startsWith("http://", ignoreCase = true) &&
            !normalized.startsWith("https://", ignoreCase = true)
        ) {
            return rawUrl
        }

        val source = runCatching { Url(normalized) }.getOrNull() ?: return rawUrl
        val cdn = runCatching { Url(cdnBaseUrl) }.getOrNull() ?: return rawUrl

        if (source.host.equals(cdn.host, ignoreCase = true)) return normalized
        if (source.encodedPath.startsWith("/_next/image")) return normalized
        if (source.encodedPath.endsWith(".svg", ignoreCase = true)) return normalized
        if (!source.isRasterImageCandidate()) return normalized

        return "$cdnBaseUrl/_next/image?url=${normalized.encodeURLParameter()}&w=384&q=75"
    }
}

private fun Url.isRasterImageCandidate(): Boolean {
    val lowerPath = encodedPath.lowercase()
    return lowerPath.startsWith("/medias/") ||
        lowerPath.endsWith(".jpg") ||
        lowerPath.endsWith(".jpeg") ||
        lowerPath.endsWith(".png") ||
        lowerPath.endsWith(".webp") ||
        lowerPath.endsWith(".gif") ||
        lowerPath.endsWith(".avif")
}
