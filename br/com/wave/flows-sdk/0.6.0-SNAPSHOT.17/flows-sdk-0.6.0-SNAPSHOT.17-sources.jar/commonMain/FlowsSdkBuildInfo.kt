package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.16-1-g3993514"
    const val COMPILED_AT_BRT: String = "2026-05-22T16:13:29.19991-03:00"
    const val GIT_SHA: String = "3993514"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.16-1-g3993514@2026-05-22T16:13:29.19991-03:00#3993514"
}