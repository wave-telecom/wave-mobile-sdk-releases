package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-rc.141-1-g5619eef"
    const val COMPILED_AT_BRT: String = "2026-07-07T12:13:14.917535-03:00"
    const val GIT_SHA: String = "5619eef"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.20-rc.141-1-g5619eef@2026-07-07T12:13:14.917535-03:00#5619eef"
}