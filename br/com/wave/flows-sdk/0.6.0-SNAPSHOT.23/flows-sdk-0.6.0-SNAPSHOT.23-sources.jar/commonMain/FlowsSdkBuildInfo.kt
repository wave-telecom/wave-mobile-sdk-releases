package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.22-2-g914215d"
    const val COMPILED_AT_BRT: String = "2026-05-23T15:22:50.520829-03:00"
    const val GIT_SHA: String = "914215d"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.22-2-g914215d@2026-05-23T15:22:50.520829-03:00#914215d"
}