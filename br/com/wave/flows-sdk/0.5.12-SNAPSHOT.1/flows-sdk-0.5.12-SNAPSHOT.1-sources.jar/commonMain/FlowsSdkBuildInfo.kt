package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.26-23-gf8dbbff"
    const val COMPILED_AT_BRT: String = "2026-06-01T22:36:08.178534-03:00"
    const val GIT_SHA: String = "f8dbbff"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.26-23-gf8dbbff@2026-06-01T22:36:08.178534-03:00#f8dbbff"
}