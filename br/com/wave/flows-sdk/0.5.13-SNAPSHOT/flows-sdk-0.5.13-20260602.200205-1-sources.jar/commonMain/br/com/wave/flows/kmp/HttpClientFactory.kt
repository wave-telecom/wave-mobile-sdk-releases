package br.com.wave.flows.kmp

import io.ktor.client.HttpClient

expect fun createPlatformHttpClient(): HttpClient

/**
 * Dedicated client for image fetches.
 *
 * Kept as a separate factory (rather than reusing [createPlatformHttpClient])
 * so the image transport can evolve independently if the BFF/CDN ever
 * demands different handling — but right now the default engine
 * configuration (OkHttp on Android, Darwin on iOS) is sufficient against
 * the production hosts. No tenant-specific headers, no User-Agent override,
 * no Referer injection.
 */
fun createPlatformImageHttpClient(): HttpClient = HttpClient()
