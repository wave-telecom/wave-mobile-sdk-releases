package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.12-rc.30-1-ga50e295"
    const val COMPILED_AT_BRT: String = "2026-06-02T17:03:08.914273-03:00"
    const val GIT_SHA: String = "a50e295"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.12-rc.30-1-ga50e295@2026-06-02T17:03:08.914273-03:00#a50e295"
}