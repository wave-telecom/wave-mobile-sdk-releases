package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.2-12-gc70d966"
    const val COMPILED_AT_BRT: String = "2026-07-22T10:40:15.425707-03:00"
    const val GIT_SHA: String = "c70d966"
    const val GIT_BRANCH: String = "release/0.5.20.3"
    const val DESCRIPTION: String = "0.5.20.2-12-gc70d966@2026-07-22T10:40:15.425707-03:00#c70d966"
}