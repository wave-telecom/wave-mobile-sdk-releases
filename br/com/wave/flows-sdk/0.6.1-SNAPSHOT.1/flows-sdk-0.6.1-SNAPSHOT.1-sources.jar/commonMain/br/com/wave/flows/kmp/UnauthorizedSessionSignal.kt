package br.com.wave.flows.kmp

import kotlin.concurrent.Volatile

/**
 * Fans out the session-dying signal from [SdkAuthHeaders] — the single point that
 * attaches the outbound credential, and so the single point that sees the BFF reject
 * it — to every currently mounted `RenderBlock`. There is no per-request caller to
 * hand the 401 back to (it can arrive off a warm-up or a background refresh), so this
 * is a plain broadcast rather than a request-scoped return value.
 *
 * The SDK does not retry on its own: that mechanism was deliberately removed, and
 * reintroducing it here (e.g. re-attempting the request after a listener "handles"
 * the signal) would bring it back through the back door.
 */
internal object UnauthorizedSessionSignal {
    /**
     * Copy-on-write: [notifyUnauthorized] runs on the HTTP client's thread while
     * subscriptions come and go on the UI thread as blocks mount and unmount. A
     * mutable collection iterated on one thread and edited on another throws; an
     * immutable snapshot swapped behind `@Volatile` cannot.
     */
    @Volatile
    private var listeners: List<() -> Unit> = emptyList()

    fun subscribe(listener: () -> Unit) {
        listeners = listeners + listener
    }

    fun unsubscribe(listener: () -> Unit) {
        listeners = listeners.filterNot { it === listener }
    }

    /** Notifies every subscriber once. Safe to call from any thread. */
    fun notifyUnauthorized() {
        listeners.forEach { it() }
    }
}
