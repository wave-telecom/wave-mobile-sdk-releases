package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockImageContent
import br.com.wave.flows.kmp.composeblocks.LocalRenderBlockFontResolver
import br.com.wave.flows.kmp.composeblocks.RenderBlockRoute
import br.com.wave.flows.kmp.composeblocks.clearRefreshCooldowns
import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.composeblocks.theme.ProvideFlowTheme
import br.com.wave.flows.kmp.composeblocks.theme.flowThemeIsDark
import br.com.wave.flows.kmp.composeblocks.theme.flowThemeSurfaceColor
import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemeMode
import br.com.wave.flows.kmp.runtime.contract.theme.ThemeParser
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.runtime.ContractDiagnosticsBootstrap
import br.com.wave.flows.kmp.runtime.DEFAULT_COMPONENT_ID
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_ACTION
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_BACK
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_NAVIGATE
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_OPEN_URL
import br.com.wave.flows.kmp.runtime.EVENT_RENDER_BLOCK_REFRESH
import br.com.wave.flows.kmp.runtime.ORIGIN_NATIVE_RENDER_BLOCK
import br.com.wave.flows.kmp.runtime.api.BffApiFactory
import br.com.wave.flows.kmp.runtime.api.BffApi
import br.com.wave.flows.kmp.runtime.api.clearBffScreenContractCache
import br.com.wave.flows.kmp.runtime.api.BffScreenContractProvider
import br.com.wave.flows.kmp.runtime.api.RefreshSignalRegistry
import br.com.wave.flows.kmp.runtime.warmup.WarmupCoordinator
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore
import br.com.wave.flows.kmp.runtime.warmup.WarmupEntry
import br.com.wave.flows.kmp.runtime.resolveEntry
import io.ktor.client.HttpClient
import coil3.ImageLoader
import coil3.annotation.ExperimentalCoilApi
import coil3.network.ktor3.KtorNetworkFetcherFactory
import coil3.svg.SvgDecoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okio.Path.Companion.toPath

internal data class FlowWrapperRuntimeConfig(
    val contractProvider: ScreenContractProvider,
    val defaultComponentId: String = DEFAULT_COMPONENT_ID,
    val httpClient: HttpClient,
    val imageHttpClient: HttpClient,
    val imageLoader: ImageLoader,
    val api: BffApi,
    val externalCode: String,
    val diskCache: WarmupDiskCacheStore?,
)

enum class WarmTargetType {
    FLOW,
    COMPONENT,
}

enum class WarmTargetMode {
    FULL,
    SKELETON,
}

data class WarmTarget(
    val slug: String,
    val type: WarmTargetType,
    val mode: WarmTargetMode = WarmTargetMode.FULL,
)

private const val WARM_MODE_FULL = "full"
private const val WARM_MODE_SKELETON = "skeleton"

/**
 * Which leaf renderer mounts a resolved [ScreenContract]: the default Compose
 * tree ([COMPOSE], `RenderBlockScreen`), or the Android View tree ([VIEW],
 * `:viewblocks`' `ViewBlockRenderer` — Android-only; every other platform stays
 * on [COMPOSE] regardless of this setting).
 */
enum class RenderEngine {
    COMPOSE,
    VIEW,
}

sealed class SDKEvent {
    data class Error(
        val componentId: String,
        val code: String,
        val message: String,
    ) : SDKEvent()

    data class ComponentLoaded(
        val componentId: String,
    ) : SDKEvent()

    data class Callback(
        val type: String,
        val payload: String,
        val origin: String,
    ) : SDKEvent()

    data class ActionTracked(
        val type: String,
        val payload: Map<String, String>,
        val timestamp: String,
        val origin: String,
    ) : SDKEvent()

    /**
     * The session's credential was rejected by the BFF (401). The SDK does not retry
     * on its own — the host owns credential acquisition and must open a new session
     * with a fresh [FlowWrapper.start]/[FlowWrapper.openSession].
     */
    data object Unauthorized : SDKEvent()
}

object FlowWrapper {
    private var runtimeConfig: FlowWrapperRuntimeConfig? = null
    private val sdkScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var warmupJob: Job? = null
    private var renderSessionToken by mutableIntStateOf(0)
    private val runtimeLogger by lazy { platformRuntimeLogger() }

    private val renderEngineState = mutableStateOf(RenderEngine.COMPOSE)

    /**
     * Process-wide leaf-renderer selection (mirrors this object's other
     * process-wide config state, e.g. `renderSessionToken`): backed by
     * snapshot state so a live toggle (e.g. the debug selector) recomposes
     * [platformViewRenderContract] directly, instead of relying on some other,
     * unrelated recomposition to pick up the new value. `COMPOSE` is the
     * default and today's behavior on every platform.
     */
    var renderEngine: RenderEngine
        get() = renderEngineState.value
        set(value) {
            renderEngineState.value = value
        }

    /**
     * Whether [renderEngine] is currently mounting the View leaf — i.e. [RenderEngine.VIEW]
     * AND the current platform actually supports it ([platformSupportsViewEngine]; iOS never
     * activates VIEW regardless of the flag). Debug/host indicators should read this instead
     * of [renderEngine] directly, so they never claim a leaf switch that never happens.
     */
    fun isViewEngineActive(): Boolean = renderEngine == RenderEngine.VIEW && platformSupportsViewEngine

    /**
     * Which BFF this session talks to: the `base_url` the wave token carries.
     * [WaveTokenStore.openSession] already rejects a token with no `base_url`, so by
     * the time [openSession]/[warm]/[warmFromInit]/[warmDefaultEntries] call this — all
     * of them after the session opened — a value is always present.
     */
    private fun effectiveBffBaseUrl(): String =
        requireNotNull(WaveTokenStore.currentBaseUrl()) {
            "FlowWrapper: no session base_url available; start()/openSession() must open a session first."
        }

    /**
     * Switch the host-selected theme mode — system / light / dark, mirroring the
     * hibrido wrapper's contract so this SDK is a native-only drop-in. [FlowThemeMode.System]
     * follows the OS; [FlowThemeMode.Light]/[FlowThemeMode.Dark] pin the palette. Takes effect
     * immediately — any mounted `RenderBlock` re-resolves `@{token}` references in place.
     */
    fun setThemeMode(mode: FlowThemeMode) {
        FlowThemeStore.setMode(
            when (mode) {
                FlowThemeMode.System -> ThemeMode.Auto
                FlowThemeMode.Light -> ThemeMode.Explicit(ThemeId.Light)
                FlowThemeMode.Dark -> ThemeMode.Explicit(ThemeId.Dark)
            },
        )
    }

    /**
     * Registers the host [context] without any other init side effect, so wrappers can
     * seed it before [openSession] builds the device-metadata CDR headers (FLW-1104). On
     * Android pass an `android.content.Context`; on iOS it is unused (pass `null`).
     */
    fun setHostContext(context: Any?) {
        PlatformDeviceInfoProvider.setHostContext(context)
    }

    /**
     * [context] feeds the device-metadata CDR headers (FLW-1104): on Android
     * pass an `android.content.Context`; on iOS it is unused (pass `null`).
     *
     * [waveToken] is the credential the integrator's own backend issued — required:
     * the SDK holds it in memory for the life of the process and never persists it,
     * so every session starts from a token the host hands over. The subscriber
     * identifier is read from its `externalCode` claim, not a separate parameter.
     *
     * [onUnauthorized], when given, is subscribed for the life of THIS session — from
     * this call until the next `start`/`openSession` or [clearWaveToken] — so a 401
     * reaches the host even when no `RenderBlock` is mounted (warm-up, or a WebView-only
     * host where no native block ever composes).
     */
    fun start(
        context: Any?,
        waveToken: String,
        onReady: (() -> Unit)? = null,
        onUnauthorized: (() -> Unit)? = null,
    ) {
        setHostContext(context)
        openSession(waveToken, onUnauthorized)

        // "Fake init": parse the bundled theme JSON and seed the catalog so
        // the host can show a theme selector before any screen loads.
        // TECH DEBT: replace bundled JSON with a real BFF init payload once
        // the backend exposes one.
        val catalog = loadBundledThemeCatalog()
        FlowThemeStore.setCatalog(catalog)

        warmDefaultEntries { onReady?.invoke() }
    }

    fun openSession(waveToken: String, onUnauthorized: (() -> Unit)? = null) {
        val sanitizedToken = waveToken.trim()

        require(sanitizedToken.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank waveToken."
        }
        // Fail-fast on the credential BEFORE any session teardown, so a bad re-init
        // never drops a working session.
        validateWaveToken(sanitizedToken)

        warmupJob?.cancel()
        runtimeConfig?.imageLoader?.shutdown()
        runtimeConfig?.imageHttpClient?.close()
        runtimeConfig?.httpClient?.close()
        renderSessionToken += 1
        clearBffScreenContractCache()
        RefreshSignalRegistry.reset()
        clearRefreshCooldowns()
        clearPlatformViewCooldowns()
        SdkApiHeaderStore.clear()

        // Must run before the client is built and any BFF call fires. Debug
        // builds of this SDK install the verbose contract-diagnostics
        // delegate; release builds compile ContractDiagnosticsBootstrap.install()
        // as a no-op, so no per-host toggle can ever turn it on in production.
        ContractDiagnosticsBootstrap.install()

        configureSdkApiHeaders(buildDeviceHeaders())
        // The credential (and onUnauthorized's subscription) land before the client is
        // built, so the very first warmup request already carries the token and already
        // has a listener for its response.
        WaveTokenStore.openSession(sanitizedToken, onUnauthorized)
        // validateWaveToken above already guarantees a non-blank externalCode claim.
        val externalCode = requireNotNull(WaveTokenStore.currentExternalCode()) {
            "FlowWrapper: session token carries no externalCode."
        }

        val httpClient = createPlatformHttpClient()
        val imageHttpClient = createPlatformImageHttpClient()
        val imageLoader = createFlowImageLoader(imageHttpClient)
        val warmupCacheDir = platformWarmupCacheDir()
        val diskCache =
            warmupCacheDir
                ?.takeIf { it.isNotBlank() }
                ?.toPath()
                ?.let(::WarmupDiskCacheStore)
        val api = BffApiFactory.create(
            client = httpClient,
            baseUrl = effectiveBffBaseUrl(),
        )
        val contractProvider =
            BffScreenContractProvider(
                baseUrl = effectiveBffBaseUrl(),
                externalCode = externalCode,
                diskCache = diskCache,
                api = api,
                logger = runtimeLogger,
            )

        runtimeConfig =
            FlowWrapperRuntimeConfig(
                contractProvider = contractProvider,
                httpClient = httpClient,
                imageHttpClient = imageHttpClient,
                imageLoader = imageLoader,
                api = api,
                externalCode = externalCode,
                diskCache = diskCache,
            )
    }

    /**
     * Fail-fast check that [waveToken] is a credential this SDK can open a session
     * with: a readable JWT whose payload carries a non-blank `baseUrl`. Throws
     * [IllegalArgumentException] otherwise, with a fixed message that never echoes any
     * part of the token.
     *
     * [start]/[openSession] run this themselves — it is public for callers that must
     * fail before the session is touched. The hybrid wrapper needs exactly that: its
     * native bridge wraps session setup in a `runCatching` (so a warm-up failure never
     * takes down the host), which would otherwise swallow a config error the
     * integrator is meant to see.
     */
    fun validateWaveToken(waveToken: String) {
        requireWaveTokenPayload(waveToken)
    }

    /**
     * Drops the wave token and every trace of the session it opened — logout. The
     * session keeps running (a mounted `RenderBlock` is not torn down), but every
     * subsequent request goes out unauthenticated until the next [start].
     *
     * The credential itself only ever lived in memory, but the session it opened
     * left plain-text BFF contract bodies on disk (the warm-up cache, keyed by this
     * subscriber's `externalCode`) plus in-memory contract/interaction/live-block
     * caches and request headers — all of it readable by whoever uses the device
     * next unless dropped here too. Safe with no open session, no cache directory,
     * a locked/unreadable cache file, or a second call: every clear below is
     * best-effort and none of them throw.
     *
     * This clear is a plain [WaveTokenStore] write, not Compose state: it wakes
     * nothing, so it cannot itself trigger a recomposition that then reads the
     * `runtimeConfig` a caller (e.g. the hybrid wrapper's own `logout()`) may clear
     * around this same call. A mounted `RenderBlock`/WebView simply keeps showing
     * the logged-out subscriber's last frame until the host unmounts it.
     */
    fun clearWaveToken() {
        WaveTokenStore.clear()
        SdkApiHeaderStore.clear()
        clearBffScreenContractCache()
        RefreshSignalRegistry.reset()
        clearRefreshCooldowns()
        runtimeConfig?.diskCache?.clearAll()
    }

    /**
     * Seeds only the session token store — no HTTP client, no image loader, no BFF
     * client — for `flow-wrapper-kmp` tests that need [waveTokenForWebView]/
     * [waveTokenEnvironment] resolved without a full [openSession] (which needs a
     * platform `Context` to build a Coil loader). Not a production entry point: real
     * sessions always go through [start]/[openSession].
     *
     * TECH DEBT (docs/tech-debt-inventory.md TD-5): test-only method on production
     * code, kept because removing it needs a cross-module test-fixture seam that
     * does not exist yet — do not add a sixth one of these without reading TD-5 first.
     */
    fun seedWaveTokenForTests(waveToken: String) {
        WaveTokenStore.openSession(waveToken.trim())
    }

    fun warm(
        targets: List<WarmTarget>,
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = effectiveBffBaseUrl(),
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                        logger = runtimeLogger,
                    ).warm(
                        targets.map { target ->
                            WarmupEntry(
                                slug = target.slug,
                                type = when (target.type) {
                                    WarmTargetType.FLOW -> "flow"
                                    WarmTargetType.COMPONENT -> "component"
                                },
                                mode = when (target.mode) {
                                    WarmTargetMode.FULL -> WARM_MODE_FULL
                                    WarmTargetMode.SKELETON -> WARM_MODE_SKELETON
                                },
                            )
                        },
                    )
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    /**
     * Hybrid native init: fetch `/api/init` and hand the raw body to [onInitJson]
     * (where the wrapper installs the render-routing policy), then signal [onReady].
     * Unlike [start]/[warmDefaultEntries] it does NOT warm the init's declared
     * entries — native warm targets come from the routing policy.
     */
    fun warmFromInit(
        onInitJson: suspend (String) -> Unit,
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = effectiveBffBaseUrl(),
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        logger = runtimeLogger,
                    ).fetchInit(onInitJson)
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Best-effort: on failure the wrapper keeps the seed policy.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    fun hasCachedComponent(componentId: String): Boolean {
        val normalizedComponentId = componentId.trim()
        if (normalizedComponentId.isEmpty()) return false
        val config = runtimeConfig ?: return false
        return config.contractProvider.peekCachedScreenContract(
            componentId = normalizedComponentId,
            externalCode = config.externalCode,
        ) != null
    }

    private fun warmDefaultEntries(
        onReady: (() -> Unit)? = null,
    ) {
        val config = requireConfig()
        // "Fake init": parse the bundled theme JSON and seed the catalog so
        // the host can show a theme selector before any screen loads.
        // TECH DEBT: replace bundled JSON with a real BFF init payload once
        // the backend exposes one.
        val catalog = loadBundledThemeCatalog()
        FlowThemeStore.setCatalog(catalog)

        if (config.diskCache == null) {
            runOnUiThread { onReady?.invoke() }
            return
        }

        warmupJob =
            sdkScope.launch {
                try {
                    WarmupCoordinator(
                        baseUrl = effectiveBffBaseUrl(),
                        externalCode = config.externalCode,
                        api = config.api,
                        diskCache = config.diskCache,
                        onScreenContractCached = { contract ->
                            preloadContractImages(contract)
                        },
                        logger = runtimeLogger,
                    ).warmup()
                } catch (e: CancellationException) {
                    return@launch
                } catch (_: Throwable) {
                    // Warmup is a best-effort optimization. The SDK still becomes usable.
                }

                runOnUiThread {
                    onReady?.invoke()
                }
            }
    }

    private val themeJsonParser = Json { ignoreUnknownKeys = true; isLenient = true }

    /**
     * Parses [BUNDLED_THEME_JSON] into a [FlowThemeCatalog]. Failures degrade
     * to [FlowThemeCatalog.empty] — the SDK then renders legacy literal-hex
     * blocks unchanged (back-compat).
     */
    private fun loadBundledThemeCatalog(): FlowThemeCatalog {
        return runCatching {
            val root = themeJsonParser.parseToJsonElement(
                br.com.wave.flows.kmp.theme.BUNDLED_THEME_JSON,
            ) as? JsonObject ?: return FlowThemeCatalog.empty()
            ThemeParser.parse(root)
        }.getOrElse { FlowThemeCatalog.empty() }
    }

    internal fun requireConfig(): FlowWrapperRuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(context, waveToken) must be called before RenderBlock()."
        }
    }

    internal fun currentRenderSessionToken(): Int = renderSessionToken

    /**
     * Clears the process-wide theme state so an instrumented suite starts
     * from the same blank slate `start()` would seed. Without this, a prior
     * test that rendered a themed screen leaves a populated [FlowThemeStore]
     * catalog behind, which then masks any defect that depends on the catalog
     * actually being carried by the contract under test. Consumed by the
     * wrapper's `resetForTests`, mirroring the other integration entry points
     * this module exposes to it.
     */
    fun resetThemeForTests() {
        FlowThemeStore.setCatalog(FlowThemeCatalog.empty())
        FlowThemeStore.setMode(ThemeMode.Auto)
    }

    /**
     * Invalidates the cached contract for [componentId] and triggers an
     * internal re-fetch of the mounted [RenderBlock] for that component.
     * The mounted route observes a per-component signal counter; this call
     * increments it, re-running produceState and fetching fresh content from
     * the BFF — no host-side token or re-mount is required.
     *
     * Safe to call without an active session — does nothing if
     * `start()` was never called.
     */
    fun refresh(flowId: String, externalCode: String? = null) {
        val provider = runtimeConfig?.contractProvider as? BffScreenContractProvider ?: return
        provider.invalidate(componentId = flowId, externalCode = externalCode)
        RefreshSignalRegistry.bump(flowId, externalCode)
    }

    /**
     * Authed, parsed contract for [componentId] via the SAME provider (and its cache) the
     * native leaf uses — no new client, no auth mutation, no new network path. `internal`:
     * inert in a release build (nothing in a release source set references it), exactly like
     * [renderEngine] sits inert until `FlowDebug` drives it. Surfaced to debug tooling only via
     * `flows-sdk`'s own `debugBackdoor` source set (`FlowsSdkDebug`), never as published ABI.
     */
    internal suspend fun requireScreenContract(componentId: String, externalCode: String? = null): ScreenContract {
        val config = requireConfig()
        return config.contractProvider.getScreenContract(componentId, externalCode ?: config.externalCode)
    }
}

/**
 * Default interval between scroll-callback emissions, in milliseconds; pass `0`
 * to disable throttling. Re-exported for facade consumers, which cannot see the
 * renderer module that owns the value (single source of truth).
 */
const val DEFAULT_SCROLL_THROTTLE_MS: Long =
    br.com.wave.flows.kmp.composeblocks.DEFAULT_SCROLL_THROTTLE_MS

/**
 * Platform seam for [RenderEngine.VIEW]: `null` unless the View engine is
 * active AND the current platform actually has a View renderer (Android only
 * — the iOS `actual` returns `null` unconditionally, keeping that platform
 * byte-identical to the Compose path regardless of [FlowWrapper.renderEngine]).
 */
@Composable
internal expect fun platformViewRenderContract(
    config: FlowWrapperRuntimeConfig,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    onScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)?,
    scrollThrottleMs: Long,
): (@Composable (ScreenContract, HostEventHandler, Boolean, () -> Unit) -> Unit)?

/** Whether the current platform has a View renderer at all (Android only; see [platformViewRenderContract]). */
internal expect val platformSupportsViewEngine: Boolean

/**
 * Drops the View engine's process-wide refresh-cooldown ledger (Android only;
 * a no-op elsewhere) on the SAME session-reset path that already clears
 * [clearRefreshCooldowns] (`:235`) — session-reset parity for the View path's
 * `ViewBlockRefreshCooldownStore`, which this commonMain module cannot
 * reference directly (Android-only type).
 */
internal expect fun clearPlatformViewCooldowns()

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    onScroll: ((ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
    modifier: Modifier = Modifier,
) {
    val config = FlowWrapper.requireConfig()
    val resolvedComponentId = resolveEntry(componentId, flowId, config.defaultComponentId)
    val renderSessionToken = FlowWrapper.currentRenderSessionToken()
    // Prefer a font resolver supplied by the host (so an app can ship the
    // fonts in its own resource bundle and resolve them) and fall back to the
    // SDK's bundled TelcelType resolver. Needed because library `composeResources`
    // are not packaged into the consuming app by the KMP library plugin, so the
    // SDK's own fonts may not be present at runtime.
    val fontResolver = LocalRenderBlockFontResolver.current ?: rememberFlowRenderBlockFontResolver()

    CompositionLocalProvider(
        LocalRenderBlockImageContent provides FlowRenderBlockImageContent,
        LocalRenderBlockFontResolver provides fontResolver,
    ) {
        ProvideFlowTheme {
            RenderBlockRouteWrapper(
                resolvedComponentId = resolvedComponentId,
                renderSessionToken = renderSessionToken,
                onEvent = onEvent,
                scroll = scroll,
                pullToRefreshEnabled = pullToRefreshEnabled,
                onScroll = onScroll,
                scrollThrottleMs = scrollThrottleMs,
                modifier = modifier,
                config = config,
            )
        }
    }
}

/**
 * The active Flow theme's surface colour, for host chrome that PRESENTS a
 * [RenderBlock] but is composed OUTSIDE it — e.g. a host-owned bottom-sheet
 * shell whose background would otherwise be a hardcoded constant and ignore
 * dark mode. Mode-aware: a near-white surface in light, a dark surface in
 * dark. Returns [fallback] when no theme is configured (legacy back-compat).
 */
@Composable
fun rememberFlowThemeSurfaceColor(fallback: Color): Color =
    flowThemeSurfaceColor(fallback)

/**
 * Whether the active Flow theme mode currently resolves to dark — for host chrome/render
 * paths outside a `RenderBlock` that need a plain boolean (e.g. to pick a `ThemeId` for a
 * render path with no theme resolution of its own) instead of a resolved [Color]. Reads the
 * same process-wide [FlowThemeStore] every native `RenderBlock` already reacts to via
 * [setThemeMode], so it stays in lockstep instead of tracking a second, disjoint theme state.
 */
@Composable
fun rememberFlowThemeIsDark(): Boolean = flowThemeIsDark()

@Composable
private fun RenderBlockRouteWrapper(
    resolvedComponentId: String,
    renderSessionToken: Int,
    onEvent: ((SDKEvent) -> Unit)?,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    onScroll: ((ScrollInfo) -> Unit)?,
    scrollThrottleMs: Long,
    modifier: Modifier,
    config: FlowWrapperRuntimeConfig,
) {
    // The 401 seam: SdkAuthHeaders is the single point that attaches the outbound
    // credential, so it is also the single point that notices the BFF reject it. It
    // has no componentId to target, so every mounted RenderBlock reports the session
    // dying on its own onEvent — the host already expects one callback per block.
    val currentOnEvent = rememberUpdatedState(onEvent)
    DisposableEffect(Unit) {
        val listener: () -> Unit = { currentOnEvent.value?.invoke(SDKEvent.Unauthorized) }
        UnauthorizedSessionSignal.subscribe(listener)
        onDispose { UnauthorizedSessionSignal.unsubscribe(listener) }
    }

    val effectivePullToRefresh = pullToRefreshEnabled && scroll
    // The force-network refresh + skeleton peek live only on the concrete
    // runtime provider. Casting here (the same `as? BffScreenContractProvider`
    // already used by `FlowWrapper.refresh`) keeps `:composeblocks` free of any
    // runtime coupling — it receives only the injected lambdas.
    val bffProvider = config.contractProvider as? BffScreenContractProvider
    val selfContainedRefresh = effectivePullToRefresh && bffProvider != null
    // Hoisted so the SAME core-domain adapter feeds both the View engine
    // (`platformViewRenderContract`, behavior-parity plan step 6) and the
    // Compose reference (`RenderBlockRoute.onScroll` below) — one seam, not
    // two independently-drifting ones.
    val coreOnScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)? =
        onScroll?.let { handler -> { info -> handler(info.toPublicScrollInfo()) } }
    val viewContent = platformViewRenderContract(config, scroll, effectivePullToRefresh, coreOnScroll, scrollThrottleMs)
    RenderBlockRoute(
            componentId = resolvedComponentId,
            contractProvider = config.contractProvider,
            sessionToken = renderSessionToken,
            hostEventHandler = FlowWrapperHostEventHandler(
                componentId = resolvedComponentId,
                onEvent = onEvent,
            ),
            onContractLoaded = { contract ->
                onEvent?.invoke(SDKEvent.ComponentLoaded(contract.id))
            },
            scroll = scroll,
            pullToRefreshEnabled = effectivePullToRefresh,
            onFetchFresh = if (selfContainedRefresh) {
                { id, ext -> bffProvider.getFreshScreenContract(id, ext) }
            } else {
                null
            },
            onPeekSkeleton = if (selfContainedRefresh) {
                { id, ext -> bffProvider.getCachedSkeletonContract(id, ext) }
            } else {
                null
            },
            onScroll = coreOnScroll,
            scrollThrottleMs = scrollThrottleMs,
            modifier = modifier,
            renderContract = viewContent,
        )
}

@OptIn(ExperimentalCoilApi::class)
private fun createFlowImageLoader(httpClient: HttpClient): ImageLoader {
    val context = platformImageLoaderContext()
    return ImageLoader.Builder(context)
        .components {
            add(KtorNetworkFetcherFactory(httpClient))
            add(SvgDecoder.Factory())
        }
        .build()
}

private class FlowWrapperHostEventHandler(
    private val componentId: String,
    private val onEvent: ((SDKEvent) -> Unit)?,
) : HostEventHandler {
    override fun onHostEvent(event: HostEvent) {
        onEvent?.invoke(event.toSdkEvent(componentId))
    }
}

private fun HostEvent.toSdkEvent(componentId: String): SDKEvent {
    return when (this) {
        is HostEvent.Error -> SDKEvent.Error(
            componentId = componentId,
            code = error.code,
            message = error.message,
        )

        is HostEvent.ActionTracked -> event.toSdkActionTracked(origin = ORIGIN_NATIVE_RENDER_BLOCK)

        is HostEvent.DelegatedHostAction -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_ACTION,
            payload = rawJson,
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        HostEvent.Refresh -> SDKEvent.Callback(
            type = EVENT_RENDER_BLOCK_REFRESH,
            payload = buildJsonObject {
                put("componentId", JsonPrimitive(componentId))
            }.toString(),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )

        is HostEvent.Navigation -> SDKEvent.Callback(
            type = navigationType(event),
            payload = navigationPayload(event),
            origin = ORIGIN_NATIVE_RENDER_BLOCK,
        )
    }
}

private fun navigationType(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> EVENT_RENDER_BLOCK_NAVIGATE
        NavigationEvent.Back -> EVENT_RENDER_BLOCK_BACK
        is NavigationEvent.External -> EVENT_RENDER_BLOCK_OPEN_URL
    }
}

private fun navigationPayload(event: NavigationEvent): String {
    return when (event) {
        is NavigationEvent.Navigate -> event.verbatim.toString()

        NavigationEvent.Back -> "{}"

        is NavigationEvent.External -> buildJsonObject {
            put("url", JsonPrimitive(event.url))
        }.toString()
    }
}
