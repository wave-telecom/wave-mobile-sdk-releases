package br.com.wave.flows.kmp

/**
 * The session's wave token, for the hybrid wrapper to hand to the WebView (passed
 * as the `token` query param, alongside `externalCode`). It is the SAME value
 * [SdkAuthHeaders] puts on the SDK's own native BFF requests — one credential, read
 * from one place, so the two engines can never authenticate as different callers.
 *
 * Returns `null` when the session has no token (no session open yet, or after
 * [FlowWrapper.clearWaveToken]), in which case the WebView loads with only
 * `externalCode` and the backend's enforcement decides — the same degrade the
 * native path takes.
 *
 * Unlike the scheme this replaces, no token is minted here: there is no TTL to
 * outrun and no reason to regenerate per load. The value does not change within a
 * session — a host that needs a fresh credential starts a new session — so callers
 * may read it once per WebView mount.
 */
fun waveTokenForWebView(): String? = WaveTokenStore.current()

/**
 * The session token's `environment` claim (e.g. `DEV`, `PRD`), or `null` when the
 * session has no token or the token omits it.
 *
 * Exists for the hybrid wrapper, which picks the journeys WebView host from it — the
 * same job the API Key JWT's claim of the same name used to do. This module returns
 * the raw string rather than an enum on purpose: which environments exist, and what
 * to do when the claim is missing, are the wrapper's concerns, not this SDK's.
 */
fun waveTokenEnvironment(): String? = WaveTokenStore.currentEnvironment()
