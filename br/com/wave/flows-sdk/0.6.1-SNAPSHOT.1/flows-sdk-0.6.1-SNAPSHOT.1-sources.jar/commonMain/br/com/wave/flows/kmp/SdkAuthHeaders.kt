package br.com.wave.flows.kmp

import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode

private const val BEARER_PREFIX = "Bearer "

/** `Authorization: Bearer <wave token>` — the standard scheme, no custom header. */
internal fun bearerHeaderValue(token: String): String = BEARER_PREFIX + token

/**
 * Single point that authenticates EVERY BFF request — and, since it is the one place
 * the credential is attached, the single point that notices the BFF reject it.
 *
 * The SDK no longer mints anything: it forwards the wave token the host's backend
 * issued, verbatim, as a bearer credential. The tenant is the BFF's to resolve from
 * the token — there is no second header to keep in sync, and no key material in the
 * app.
 *
 * With no token in [WaveTokenStore] the request goes out unauthenticated and the
 * BFF's own enforcement decides. That is deliberate: an integrator who has not
 * supplied a token yet gets a clean 401 from the backend instead of an SDK-level
 * crash on a code path (warmup) that runs before any screen is mounted.
 *
 * A 401 response reports [UnauthorizedSessionSignal] and nothing else — the SDK does
 * NOT ask the host for a token and retry by itself (that mechanism was deliberately
 * removed); the host owns credential acquisition and must open a new session.
 */
internal val SdkAuthHeaders = createClientPlugin("SdkAuthHeaders") {
    onRequest { request, _ ->
        val token = WaveTokenStore.current() ?: return@onRequest
        request.headers[HttpHeaders.Authorization] = bearerHeaderValue(token)
    }
    onResponse { response ->
        if (response.status == HttpStatusCode.Unauthorized) {
            UnauthorizedSessionSignal.notifyUnauthorized()
        }
    }
}
