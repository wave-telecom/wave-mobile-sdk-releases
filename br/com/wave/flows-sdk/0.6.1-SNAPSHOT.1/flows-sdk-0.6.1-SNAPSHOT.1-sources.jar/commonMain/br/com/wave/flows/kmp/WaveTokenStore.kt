package br.com.wave.flows.kmp

import kotlin.concurrent.Volatile

/**
 * The session's wave token: received from the host, held here, and read by
 * [SdkAuthHeaders] on every BFF request and by [waveTokenForWebView] on every
 * WebView load. The SDK does not mint it — it only decodes the payload for the
 * `baseUrl` it must talk to and the `environment` the WebView loads from.
 *
 * **In memory only, for the life of the process.** The host issues the credential
 * and hands it over on every `start`, so persisting it would write a secret to disk
 * that nothing ever reads back — while adding an at-rest exposure window, a
 * cross-subscriber replay hazard, and a stale-format failure mode. Navigation,
 * unmounting a `RenderBlock` and popping the back stack do not touch this object;
 * only a new session or [clear] does.
 *
 * A plain [Volatile] ref, not Compose state: `start`/`logout` are the SDK's only two
 * transitions (no in-session rotation — a host that needs a fresh credential starts a
 * new session), so nothing needs to be woken on a write. Compose state here once fed
 * a WebView re-injection push (a rotation reaching an already-mounted page without
 * recreating it); with rotation gone, that reader can own its own observable state
 * instead of this layer importing a UI runtime.
 */
internal object WaveTokenStore {

    @Volatile
    private var token: String? = null

    // Decoded once per token rather than per read: `currentBaseUrl` is consulted every
    // time a BFF client, warmup coordinator or contract provider is built.
    @Volatile
    private var payload: WaveTokenPayload? = null

    // The listener actually registered with UnauthorizedSessionSignal for the
    // currently open session, kept so the NEXT openSession/clear unsubscribes exactly
    // it — never a second one left dangling on the broadcast set.
    private var unauthorizedListener: (() -> Unit)? = null

    /**
     * Opens a session with [waveToken], which must be a readable JWT carrying a
     * `baseUrl`. Throws [IllegalArgumentException] otherwise: a credential the SDK
     * cannot read a BFF out of is a config error the integrator can fix, and it
     * should surface at start rather than as a mystery load failure on every screen.
     *
     * Validates before mutating anything, so a bad re-init never tears down a session
     * that is currently working.
     *
     * [onUnauthorized], when given, is subscribed to [UnauthorizedSessionSignal] for
     * the life of this session — from here until the next [openSession] or [clear] —
     * so a 401 reaches the host on its own, independently of whether any composable
     * happens to be mounted when the BFF rejects the credential (this is where the
     * session's lifetime actually lives; a mounted `RenderBlock` is a shorter-lived,
     * additional subscriber, not the only one).
     */
    fun openSession(waveToken: String, onUnauthorized: (() -> Unit)? = null) {
        val decoded = requireWaveTokenPayload(waveToken.trim())
        token = waveToken.trim()
        payload = decoded
        unauthorizedListener?.let(UnauthorizedSessionSignal::unsubscribe)
        unauthorizedListener = onUnauthorized
        onUnauthorized?.let(UnauthorizedSessionSignal::subscribe)
    }

    fun current(): String? = token

    /**
     * The BFF this session talks to, from the token's `base_url` claim — normalized
     * here, once, at the point it enters the SDK: the real claim value ends with a
     * trailing slash. Every `FlowWrapper` call site that builds a client off this
     * value reads it already clean. `null` before a session is open.
     */
    fun currentBaseUrl(): String? = payload?.baseUrl?.trim()?.trimEnd('/')?.takeIf(String::isNotEmpty)

    /** The token's `env` claim, for the hybrid wrapper's WebView host. */
    fun currentEnvironment(): String? = payload?.environment?.trim()?.takeIf(String::isNotEmpty)

    /** The open session's subscriber identifier, off the token's `externalCode` claim. */
    fun currentExternalCode(): String? = payload?.externalCode?.trim()?.takeIf(String::isNotEmpty)

    /** Drops the credential — logout, or a test resetting process-wide state. */
    fun clear() {
        token = null
        payload = null
        unauthorizedListener?.let(UnauthorizedSessionSignal::unsubscribe)
        unauthorizedListener = null
    }
}
