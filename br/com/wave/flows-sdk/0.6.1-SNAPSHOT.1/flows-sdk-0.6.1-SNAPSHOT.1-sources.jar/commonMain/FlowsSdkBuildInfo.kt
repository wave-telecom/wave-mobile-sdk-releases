package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-219-gc073e3f3"
    const val COMPILED_AT_BRT: String = "2026-08-11T16:51:32.15075-03:00"
    const val GIT_SHA: String = "c073e3f3"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-219-gc073e3f3@2026-08-11T16:51:32.15075-03:00#c073e3f3"
}