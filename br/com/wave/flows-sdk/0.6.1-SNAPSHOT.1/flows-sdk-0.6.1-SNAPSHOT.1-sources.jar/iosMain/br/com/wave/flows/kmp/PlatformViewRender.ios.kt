package br.com.wave.flows.kmp

import androidx.compose.runtime.Composable
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.host.HostEventHandler

// No View renderer on iOS; the Compose path (RenderBlockScreen) is the only
// renderer regardless of FlowWrapper.renderEngine.
internal actual val platformSupportsViewEngine: Boolean = false

@Composable
internal actual fun platformViewRenderContract(
    config: FlowWrapperRuntimeConfig,
    scroll: Boolean,
    pullToRefreshEnabled: Boolean,
    onScroll: ((br.com.wave.flows.kmp.core.ScrollInfo) -> Unit)?,
    scrollThrottleMs: Long,
): (@Composable (ScreenContract, HostEventHandler, Boolean, () -> Unit) -> Unit)? = null

internal actual fun clearPlatformViewCooldowns() {
    // No View renderer on iOS (see platformSupportsViewEngine); nothing to clear.
}
