package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.5-14-gda9bdff"
    const val COMPILED_AT_BRT: String = "2026-07-07T10:19:45.116228-03:00"
    const val GIT_SHA: String = "da9bdff"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.5-14-gda9bdff@2026-07-07T10:19:45.116228-03:00#da9bdff"
}