package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.14-6-g4fc1035"
    const val COMPILED_AT_BRT: String = "2026-05-22T14:22:22.222347-03:00"
    const val GIT_SHA: String = "4fc1035"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.14-6-g4fc1035@2026-05-22T14:22:22.222347-03:00#4fc1035"
}