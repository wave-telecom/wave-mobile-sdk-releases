package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-9-gdc43783"
    const val COMPILED_AT_BRT: String = "2026-06-26T19:51:17.474523-03:00"
    const val GIT_SHA: String = "dc43783"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.16-9-gdc43783@2026-06-26T19:51:17.474523-03:00#dc43783"
}