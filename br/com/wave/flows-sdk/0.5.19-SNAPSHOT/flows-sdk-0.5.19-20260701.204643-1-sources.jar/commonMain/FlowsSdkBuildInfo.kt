package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.18-3-gaa9af9f"
    const val COMPILED_AT_BRT: String = "2026-07-01T17:47:51.61649-03:00"
    const val GIT_SHA: String = "aa9af9f"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.18-3-gaa9af9f@2026-07-01T17:47:51.61649-03:00#aa9af9f"
}