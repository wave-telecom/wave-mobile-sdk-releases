package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT.2"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-22T11:20:09.463175-03:00"
    const val GIT_SHA: String = "f8eb1a3"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT.2@2026-06-22T11:20:09.463175-03:00#f8eb1a3"
}