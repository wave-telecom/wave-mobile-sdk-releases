package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.19-rc.123"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-02T17:36:36.844273-03:00"
    const val GIT_SHA: String = "823a1ec"
    const val GIT_BRANCH: String = "release/0.5.19"
    const val DESCRIPTION: String = "0.5.19-rc.123@2026-07-02T17:36:36.844273-03:00#823a1ec"
}