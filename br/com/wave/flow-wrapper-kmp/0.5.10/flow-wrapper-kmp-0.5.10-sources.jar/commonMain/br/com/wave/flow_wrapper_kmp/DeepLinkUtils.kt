package br.com.wave.flow_wrapper_kmp

internal data class NativeCallbackMessage(
    val type: String,
    val payload: String,
)

internal fun nativeCallbackMessageFromPayload(payload: String): NativeCallbackMessage {
    val type = extractTypeFieldFromJson(payload) ?: "UNKNOWN"
    return NativeCallbackMessage(type = type, payload = payload)
}

internal fun extractStringFieldFromJson(
    json: String,
    fieldName: String,
): String? {
    return JsonStringFieldExtractor(json).firstStringField(fieldName)?.takeIf { it.isNotBlank() }
}

private fun extractTypeFieldFromJson(json: String): String? {
    return TopLevelJsonFieldExtractor(json).stringField("type")?.takeIf { it.isNotBlank() }
}

internal class TopLevelJsonFieldExtractor(
    private val json: String,
) {
    private var index: Int = 0

    fun stringField(fieldName: String): String? {
        skipWhitespace()
        if (!consumeChar('{')) return null
        skipWhitespace()

        if (consumeChar('}')) return null

        while (index < json.length) {
            val key = parseJsonString() ?: return null
            skipWhitespace()
            if (!consumeChar(':')) return null
            skipWhitespace()

            val value =
                if (json.getOrNull(index) == '"') {
                    parseJsonString()
                } else {
                    skipJsonValue()
                    null
                }

            if (key == fieldName && !value.isNullOrBlank()) {
                return value
            }

            skipWhitespace()
            when {
                consumeChar(',') -> {
                    skipWhitespace()
                }
                consumeChar('}') -> return null
                else -> return null
            }
        }

        return null
    }

    private fun parseJsonString(): String? {
        if (!consumeChar('"')) return null
        val result = StringBuilder()

        while (index < json.length) {
            when (val char = json[index++]) {
                '"' -> return result.toString()
                '\\' -> {
                    if (index >= json.length) return null
                    when (val escaped = json[index++]) {
                        '"', '\\', '/' -> result.append(escaped)
                        'b' -> result.append('\b')
                        'f' -> result.append('\u000C')
                        'n' -> result.append('\n')
                        'r' -> result.append('\r')
                        't' -> result.append('\t')
                        'u' -> {
                            if (index + 4 > json.length) return null
                            val hex = json.substring(index, index + 4)
                            val codePoint = hex.toIntOrNull(16) ?: return null
                            result.append(codePoint.toChar())
                            index += 4
                        }
                        else -> return null
                    }
                }
                else -> result.append(char)
            }
        }

        return null
    }

    private fun skipJsonValue() {
        when (json.getOrNull(index)) {
            '{' -> skipEnclosed('{', '}')
            '[' -> skipEnclosed('[', ']')
            '"' -> parseJsonString()
            else -> skipPrimitive()
        }
    }

    private fun skipEnclosed(openChar: Char, closeChar: Char) {
        if (!consumeChar(openChar)) return
        var depth = 1
        var inString = false
        var escaped = false

        while (index < json.length && depth > 0) {
            val char = json[index++]
            if (inString) {
                when {
                    escaped -> escaped = false
                    char == '\\' -> escaped = true
                    char == '"' -> inString = false
                }
                continue
            }

            when (char) {
                '"' -> inString = true
                openChar -> depth++
                closeChar -> depth--
            }
        }
    }

    private fun skipPrimitive() {
        while (index < json.length) {
            when (json[index]) {
                ',', '}', ']', ' ', '\n', '\r', '\t' -> return
                else -> index++
            }
        }
    }

    private fun skipWhitespace() {
        while (index < json.length && json[index].isWhitespace()) {
            index++
        }
    }

    private fun consumeChar(expected: Char): Boolean {
        if (json.getOrNull(index) != expected) return false
        index++
        return true
    }
}

internal class JsonStringFieldExtractor(
    private val json: String,
) {
    private var index: Int = 0

    fun firstStringField(fieldName: String): String? {
        skipWhitespace()
        return findInValue(fieldName)
    }

    private fun findInValue(fieldName: String): String? {
        skipWhitespace()
        return when (json.getOrNull(index)) {
            '{' -> findInObject(fieldName)
            '[' -> findInArray(fieldName)
            '"' -> {
                parseJsonString()
                null
            }
            null -> null
            else -> {
                skipPrimitive()
                null
            }
        }
    }

    private fun findInObject(fieldName: String): String? {
        if (!consumeChar('{')) return null
        skipWhitespace()

        if (consumeChar('}')) return null

        while (index < json.length) {
            val key = parseJsonString() ?: return null
            skipWhitespace()
            if (!consumeChar(':')) return null
            skipWhitespace()

            if (key == fieldName && json.getOrNull(index) == '"') {
                return parseJsonString()
            }

            findInValue(fieldName)?.let { return it }

            skipWhitespace()
            when {
                consumeChar(',') -> skipWhitespace()
                consumeChar('}') -> return null
                else -> return null
            }
        }

        return null
    }

    private fun findInArray(fieldName: String): String? {
        if (!consumeChar('[')) return null
        skipWhitespace()

        if (consumeChar(']')) return null

        while (index < json.length) {
            findInValue(fieldName)?.let { return it }

            skipWhitespace()
            when {
                consumeChar(',') -> skipWhitespace()
                consumeChar(']') -> return null
                else -> return null
            }
        }

        return null
    }

    private fun parseJsonString(): String? {
        if (!consumeChar('"')) return null
        val result = StringBuilder()

        while (index < json.length) {
            when (val char = json[index++]) {
                '"' -> return result.toString()
                '\\' -> {
                    if (index >= json.length) return null
                    when (val escaped = json[index++]) {
                        '"', '\\', '/' -> result.append(escaped)
                        'b' -> result.append('\b')
                        'f' -> result.append('\u000C')
                        'n' -> result.append('\n')
                        'r' -> result.append('\r')
                        't' -> result.append('\t')
                        'u' -> {
                            if (index + 4 > json.length) return null
                            val hex = json.substring(index, index + 4)
                            val codePoint = hex.toIntOrNull(16) ?: return null
                            result.append(codePoint.toChar())
                            index += 4
                        }
                        else -> return null
                    }
                }
                else -> result.append(char)
            }
        }

        return null
    }

    private fun skipPrimitive() {
        while (index < json.length) {
            when (json[index]) {
                ',', '}', ']', ' ', '\n', '\r', '\t' -> return
                else -> index++
            }
        }
    }

    private fun skipWhitespace() {
        while (index < json.length && json[index].isWhitespace()) {
            index++
        }
    }

    private fun consumeChar(expected: Char): Boolean {
        if (json.getOrNull(index) != expected) return false
        index++
        return true
    }
}
