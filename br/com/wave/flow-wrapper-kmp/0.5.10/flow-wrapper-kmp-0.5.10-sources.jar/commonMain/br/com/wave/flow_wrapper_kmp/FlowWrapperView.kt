package br.com.wave.flow_wrapper_kmp

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.multiplatform.webview.web.LoadingState
import com.multiplatform.webview.web.WebView
import com.multiplatform.webview.web.rememberWebViewNavigator
import com.multiplatform.webview.web.rememberWebViewState
import br.com.wave.flow_wrapper_kmp.generated.resources.Res
import br.com.wave.flow_wrapper_kmp.generated.resources.flow_wrapper_error_missing_entry_point
import br.com.wave.flow_wrapper_kmp.generated.resources.flow_wrapper_fallback_missing_entry_point
import org.jetbrains.compose.resources.stringResource

private const val DEFAULT_COMPONENT_ID = "balance-summary-1"
private const val PATH_PREFIX_FLOWS = "/flows/"
private const val PATH_PREFIX_COMPONENTS = "/components/"
private const val ORIGIN_NATIVE_HANDLER_BRIDGE = "native_handler_bridge"
private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"

private enum class FlowWrapperErrorCode(val value: String) {
    MissingEntryPoint("MISSING_ENTRY_POINT"),
}

internal sealed interface FlowWrapperEntry {
    data class Component(val componentId: String) : FlowWrapperEntry

    data class Flow(val flowId: String) : FlowWrapperEntry

    data object Missing : FlowWrapperEntry
}

internal fun resolveFlowWrapperEntry(componentId: String?, flowId: String?): FlowWrapperEntry {
    if (!componentId.isNullOrBlank()) return FlowWrapperEntry.Component(componentId)
    if (!flowId.isNullOrBlank()) return FlowWrapperEntry.Flow(flowId)
    return FlowWrapperEntry.Missing
}

internal fun FlowWrapperEntry.path(): String = when (this) {
    is FlowWrapperEntry.Component -> "$PATH_PREFIX_COMPONENTS$componentId"
    is FlowWrapperEntry.Flow -> "$PATH_PREFIX_FLOWS$flowId"
    FlowWrapperEntry.Missing -> ""
}

internal fun FlowWrapperEntry.id(): String = when (this) {
    is FlowWrapperEntry.Component -> componentId
    is FlowWrapperEntry.Flow -> flowId
    FlowWrapperEntry.Missing -> DEFAULT_COMPONENT_ID
}

@Composable
fun RenderBlock(
    componentId: String? = null,
    flowId: String? = null,
    onEvent: ((SDKEvent) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val errorMissingEntryPoint = stringResource(Res.string.flow_wrapper_error_missing_entry_point)
    val fallbackMissingEntryPoint = stringResource(Res.string.flow_wrapper_fallback_missing_entry_point)

    when (val entry = resolveFlowWrapperEntry(componentId = componentId, flowId = flowId)) {
        is FlowWrapperEntry.Component, is FlowWrapperEntry.Flow -> {
            FlowWrapperViewInternal(
                modifier = modifier,
                entryPath = entry.path(),
                entryId = entry.id(),
                onEvent = onEvent,
            )
        }
        FlowWrapperEntry.Missing -> {
            onEvent?.invoke(
                SDKEvent.Error(
                    componentId = DEFAULT_COMPONENT_ID,
                    code = FlowWrapperErrorCode.MissingEntryPoint.value,
                    message = errorMissingEntryPoint,
                )
            )
            FlowWrapperFallback(
                modifier = modifier,
                message = fallbackMissingEntryPoint,
            )
        }
    }
}

internal fun handleNativeBridgeMessage(
    params: String,
    onCallbackReceived: (NativeCallbackMessage) -> Unit,
): String {
    parseNativeBridgeParams(params)?.let(onCallbackReceived)
    return "{}"
}

internal fun parseNativeBridgeParams(params: String): NativeCallbackMessage? {
    if (params.isBlank()) return null
    return nativeCallbackMessageFromPayload(params)
}

private fun emitCallbackEvent(
    onEvent: ((SDKEvent) -> Unit)?,
    callbackMessage: NativeCallbackMessage,
    origin: String,
) {
    platformLogDebug(
        FLOW_WRAPPER_LOG_TAG,
        "callback origin=$origin type=${callbackMessage.type} payload=${callbackMessage.payload.asLogPayload()}",
    )
    onEvent?.invoke(
        SDKEvent.Callback(
            type = callbackMessage.type,
            payload = callbackMessage.payload,
            origin = origin,
        )
    )
}

private fun String.asLogPayload(maxLength: Int = 320): String {
    return if (length <= maxLength) this else take(maxLength) + "..."
}

@Composable
private fun FlowWrapperFallback(modifier: Modifier, message: String) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = message, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
internal fun FlowWrapperViewInternal(
    entryPath: String,
    entryId: String,
    modifier: Modifier = Modifier,
    onEvent: ((SDKEvent) -> Unit)? = null,
) {
    val currentOnEventState = rememberUpdatedState(onEvent)
    val config = FlowWrapper.currentConfig()
    val flowWrapperConfig = config.flowWrapperConfig
    val resolvedEntryPath = remember(entryPath) { FlowWrapper.resolveEntryPathForRendering(entryPath) }

    val entryUrl =
        remember(
            config.msisdn,
            config.environment,
            resolvedEntryPath,
            flowWrapperConfig.entryUrlProvider,
        ) {
            flowWrapperConfig.entryUrlProvider.urlFor(
                EntryUrlContext(
                    msisdn = config.msisdn,
                    environment = config.environment,
                    path = resolvedEntryPath,
                )
            )
        }

    val navigator = rememberWebViewNavigator()
    val state = rememberWebViewState(entryUrl)
    state.webSettings.androidWebSettings.domStorageEnabled = true

    LaunchedEffect(state.loadingState) {
        if (state.loadingState is LoadingState.Finished) {
            currentOnEventState.value?.invoke(SDKEvent.ComponentLoaded(componentId = entryId))
        }
    }

    val onNativeBridgeMessage: (String) -> Unit = { data ->
        handleNativeBridgeMessage(data) { callbackMessage ->
            FlowWrapper.updateRuntimeStateFromCallback(
                entryPath = entryPath,
                callbackMessage = callbackMessage,
            )
            emitCallbackEvent(
                onEvent = currentOnEventState.value,
                callbackMessage = callbackMessage,
                origin = ORIGIN_NATIVE_HANDLER_BRIDGE,
            )
        }
    }

    val platformWebViewParams = rememberFlowWrapperPlatformWebViewParams(
        navigator = navigator,
        onNativeBridgeMessage = onNativeBridgeMessage,
    )

    val webViewFactory = rememberNativeHandlerWebViewFactory(
        onNativeBridgeMessage = onNativeBridgeMessage,
    )

    Box(modifier = modifier.fillMaxSize()) {
        WebView(
            state = state,
            navigator = navigator,
            platformWebViewParams = platformWebViewParams,
            factory = webViewFactory,
            modifier = Modifier
                .padding()
                .fillMaxSize(),
        )
    }
}
