package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-rc.67"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-23T13:32:35.61514-03:00"
    const val GIT_SHA: String = "697c652"
    const val GIT_BRANCH: String = "release/0.5.15"
    const val DESCRIPTION: String = "0.5.15-rc.67@2026-06-23T13:32:35.61514-03:00#697c652"
}