package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.16-rc.72"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-26T09:58:37.943996-03:00"
    const val GIT_SHA: String = "bb19257"
    const val GIT_BRANCH: String = "release/0.5.16"
    const val DESCRIPTION: String = "0.5.16-rc.72@2026-06-26T09:58:37.943996-03:00#bb19257"
}