package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-SNAPSHOT"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-26T19:51:55.045465-03:00"
    const val GIT_SHA: String = "dc43783"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.17-SNAPSHOT@2026-06-26T19:51:55.045465-03:00#dc43783"
}