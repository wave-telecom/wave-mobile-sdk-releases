package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.3-rc.160"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-22T10:40:55.406584-03:00"
    const val GIT_SHA: String = "c70d966"
    const val GIT_BRANCH: String = "release/0.5.20.3"
    const val DESCRIPTION: String = "0.5.20.3-rc.160@2026-07-22T10:40:55.406584-03:00#c70d966"
}