package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT.3"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-23T12:36:41.774276-03:00"
    const val GIT_SHA: String = "1838e72"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT.3@2026-06-23T12:36:41.774276-03:00#1838e72"
}