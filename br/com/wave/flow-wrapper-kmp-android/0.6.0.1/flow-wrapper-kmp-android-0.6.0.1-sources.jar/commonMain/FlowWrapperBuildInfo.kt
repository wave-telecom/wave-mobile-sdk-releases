package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.6.0.1"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-08-14T14:18:30.920225-03:00"
    const val GIT_SHA: String = "70e34657"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.6.0.1@2026-08-14T14:18:30.920225-03:00#70e34657"
}