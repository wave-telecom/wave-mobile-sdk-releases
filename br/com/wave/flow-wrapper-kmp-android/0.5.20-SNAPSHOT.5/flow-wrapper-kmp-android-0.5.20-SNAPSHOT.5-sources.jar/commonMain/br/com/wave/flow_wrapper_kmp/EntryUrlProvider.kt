package br.com.wave.flow_wrapper_kmp

private const val BASE_URL_DEV = "https://telcel-dev-wave-journeys-web.vercel.app"
private const val BASE_URL_PRD = "https://telcel-prd-wave-journeys-web.vercel.app"

data class EntryUrlContext(
    val msisdn: String,
    val environment: FlowWrapperEnvironment,
    val path: String,
    val themeMode: String? = null,
    val refresh: Boolean = false,
)

fun interface EntryUrlProvider {
    fun urlFor(context: EntryUrlContext): String
}

object DefaultEntryUrlProvider : EntryUrlProvider {
    override fun urlFor(context: EntryUrlContext): String {
        val baseUrl = when (context.environment) {
            FlowWrapperEnvironment.DEV -> BASE_URL_DEV
            FlowWrapperEnvironment.PRD -> BASE_URL_PRD
        }
        val externalCode = context.msisdn.filter(Char::isDigit)
        var url = "$baseUrl${context.path}${context.path.querySeparator()}externalCode=$externalCode"
        context.themeMode?.let { url += "&themeMode=$it" }
        if (context.refresh) url += "&refresh=true"
        return url
    }
}

private fun String.querySeparator(): Char = if ('?' in this) '&' else '?'
