package br.com.wave.flow_wrapper_kmp

import android.annotation.SuppressLint
import android.app.Application
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.SafeBrowsingResponse
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import com.multiplatform.webview.web.AccompanistWebViewClient
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator
import com.multiplatform.webview.web.defaultWebViewFactory

private const val NATIVE_HANDLER_BRIDGE_NAME = "NativeHandler"
private const val NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP = "sendDataToApp"
private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"
private const val ORIGIN_NATIVE_HANDLER_BRIDGE = "native_handler_bridge"
private const val INTERNAL_ERROR_BASE_URL = "https://wave.local/error"

private class NativeHandlerJavascriptInterface(
    private val onCallbackPayload: (String) -> Unit,
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun sendDataToApp(payload: String?) {
        if (payload.isNullOrBlank()) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "callback origin=$ORIGIN_NATIVE_HANDLER_BRIDGE type=UNKNOWN payload=<blank>",
            )
            return
        }
        val payloadPreview = if (payload.length <= 320) payload else payload.take(320) + "..."
        platformLogDebug(FLOW_WRAPPER_LOG_TAG, "android_js_interface sendDataToApp payload=$payloadPreview")
        mainHandler.post { onCallbackPayload(payload) }
    }

    @JavascriptInterface
    fun callNative(
        methodName: String?,
        params: String?,
        @Suppress("UNUSED_PARAMETER") callbackId: String?,
    ) {
        if (methodName != NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "unsupported_native_handler_method method=${methodName ?: "<null>"}",
            )
            return
        }
        sendDataToApp(params)
    }
}

private class FlowWrapperWebViewClient(
    private val onProcessGone: () -> Boolean,
) : AccompanistWebViewClient() {
    private var didRenderErrorPageForCurrentNavigation = false

    override fun onPageStarted(
        view: WebView,
        url: String?,
        favicon: Bitmap?,
    ) {
        // Skip Accompanist's viewport JS injection; SDK contract uses native bridge only.
        state.errorsForCurrentRequest.clear()
        didRenderErrorPageForCurrentNavigation = false
    }

    override fun onReceivedError(
        view: WebView,
        request: WebResourceRequest?,
        error: WebResourceError?,
    ) {
        super.onReceivedError(view, request, error)
        if (request?.isForMainFrame != true) return
        renderCustomErrorPage(view = view, state = FlowWrapperWebViewErrorState.Network)
    }

    @Suppress("DEPRECATION")
    override fun onReceivedError(
        view: WebView,
        errorCode: Int,
        description: String?,
        failingUrl: String?,
    ) {
        super.onReceivedError(view, errorCode, description, failingUrl)
        renderCustomErrorPage(view = view, state = FlowWrapperWebViewErrorState.Network)
    }

    override fun onReceivedHttpError(
        view: WebView,
        request: WebResourceRequest?,
        errorResponse: WebResourceResponse,
    ) {
        super.onReceivedHttpError(view, request, errorResponse)
        if (request?.isForMainFrame != true) return
        if (errorResponse.statusCode in 400..599) {
            renderCustomErrorPage(view = view, state = FlowWrapperWebViewErrorState.Http)
        }
    }

    override fun onReceivedSslError(
        view: WebView,
        handler: SslErrorHandler,
        error: SslError,
    ) {
        super.onReceivedSslError(view, handler, error)
        handler.cancel()
        renderCustomErrorPage(view = view, state = FlowWrapperWebViewErrorState.Ssl)
    }

    override fun onRenderProcessGone(
        view: WebView,
        detail: RenderProcessGoneDetail,
    ): Boolean {
        // didCrash == false means the SYSTEM killed the renderer to reclaim memory (the
        // background-then-reopen case), not a genuine page crash. Recover by recreating the
        // WebView and reloading; only paint the static error page on a real crash or once the
        // recovery budget is spent. Return true either way so the framework does not kill the app.
        if (!detail.didCrash() && onProcessGone()) {
            // Recovery rebuilds a fresh WebView via recomposition; this defunct instance stays
            // registered with the shared renderer process if left alive, so it keeps receiving
            // render-process callbacks on later kills and silently drains the recovery budget.
            (view.parent as? android.view.ViewGroup)?.removeView(view)
            view.destroy()
            return true
        }
        renderCustomErrorPage(view = view, state = FlowWrapperWebViewErrorState.Process)
        return true
    }

    override fun onSafeBrowsingHit(
        view: WebView,
        request: WebResourceRequest,
        threatType: Int,
        callback: SafeBrowsingResponse,
    ) {
        callback.backToSafety(true)
        renderCustomErrorPage(view = view, state = FlowWrapperWebViewErrorState.SafeBrowsing)
    }

    private fun renderCustomErrorPage(
        view: WebView,
        state: FlowWrapperWebViewErrorState,
    ) {
        if (didRenderErrorPageForCurrentNavigation) return
        didRenderErrorPageForCurrentNavigation = true
        platformLogDebug(FLOW_WRAPPER_LOG_TAG, flowWrapperWebViewErrorLogMessage(state))
        view.loadDataWithBaseURL(
            INTERNAL_ERROR_BASE_URL,
            flowWrapperWebViewErrorHtml(state),
            "text/html",
            "utf-8",
            null,
        )
    }

    override fun onPageFinished(view: WebView, url: String?) {
        super.onPageFinished(view, url)
        view.evaluateJavascript(PAGE_HEIGHT_OBSERVER_JS, null)
    }
}

private class FlowWrapperWarmupWebViewClient(
) : WebViewClient() {
    override fun onPageFinished(
        view: WebView,
        url: String?,
    ) {
        super.onPageFinished(view, url)
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "warmup_page_finished",
        )
    }
}

private class AndroidFlowWrapperWarmupHandle(
    private val application: Application,
    private val entryUrl: String,
    private val onCallbackPayload: (String) -> Unit,
    private val onTimeout: () -> Unit,
    private val timeoutMs: Long,
) : FlowWrapperWarmupHandle {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private var isClosed = false
    private val timeoutRunnable =
        Runnable {
            if (!isClosed) {
                onTimeout()
            }
        }

    init {
        mainHandler.postDelayed(timeoutRunnable, timeoutMs)
        mainHandler.post { createAndLoadWebView() }
    }

    override fun cancel() {
        mainHandler.removeCallbacks(timeoutRunnable)
        mainHandler.post { close() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createAndLoadWebView() {
        if (isClosed) return

        val nativeHandlerBridge =
            NativeHandlerJavascriptInterface { payload ->
                if (!isClosed) {
                    onCallbackPayload(payload)
                }
            }

        webView =
            WebView(application).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                }
                webViewClient = FlowWrapperWarmupWebViewClient()
                removeJavascriptInterface(NATIVE_HANDLER_BRIDGE_NAME)
                addJavascriptInterface(nativeHandlerBridge, NATIVE_HANDLER_BRIDGE_NAME)
                platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "warmup_load_started",
                )
                loadUrl(entryUrl)
            }
    }

    private fun close() {
        if (isClosed) return
        isClosed = true
        webView?.apply {
            stopLoading()
            webViewClient = WebViewClient()
            removeJavascriptInterface(NATIVE_HANDLER_BRIDGE_NAME)
            destroy()
        }
        webView = null
    }
}

private fun resolveApplicationContext(): Application? {
    (HostContextHolder.applicationContext as? Application)?.let { return it }
    return runCatching {
        val activityThreadClass = Class.forName("android.app.ActivityThread")
        activityThreadClass.getMethod("currentApplication").invoke(null) as? Application
    }.getOrNull() ?: runCatching {
        val appGlobalsClass = Class.forName("android.app.AppGlobals")
        appGlobalsClass.getMethod("getInitialApplication").invoke(null) as? Application
    }.getOrNull()
}

actual fun platform() = "Android"

internal actual fun platformLogDebug(tag: String, message: String) {
    runCatching {
        Log.d(tag, message)
    }
}

@Composable
internal actual fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
    onWebViewProcessGone: () -> Boolean,
): PlatformWebViewParams? {
    navigator
    onNativeBridgeMessage
    // Keep the recovery callback current without recreating the (remembered) client.
    val currentProcessGone = rememberUpdatedState(onWebViewProcessGone)
    val client = remember { FlowWrapperWebViewClient(onProcessGone = { currentProcessGone.value() }) }
    return remember(client) { PlatformWebViewParams(client = client) }
}

@Composable
internal actual fun rememberNativeHandlerWebViewFactory(
    onNativeBridgeMessage: (String) -> Unit,
    onWebViewProcessGone: () -> Boolean,
): ((WebViewFactoryParam) -> NativeWebView)? {
    // Android handles render-process-gone recovery in FlowWrapperWebViewClient (installed via
    // rememberFlowWrapperPlatformWebViewParams), so the factory does not need this callback.
    onWebViewProcessGone
    val currentCallback = rememberUpdatedState(onNativeBridgeMessage)
    val nativeHandlerBridge =
        remember {
            NativeHandlerJavascriptInterface { payload -> currentCallback.value(payload) }
        }

    return remember(nativeHandlerBridge) {
        { param: WebViewFactoryParam ->
            val webView = defaultWebViewFactory(param)
            webView.settings.apply {
                domStorageEnabled = true
            }
            webView.removeJavascriptInterface(NATIVE_HANDLER_BRIDGE_NAME)
            webView.addJavascriptInterface(nativeHandlerBridge, NATIVE_HANDLER_BRIDGE_NAME)
            webView
        }
    }
}

internal actual object PlatformFlowWrapperWarmupLauncher {
    actual fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle? {
        val application = resolveApplicationContext()
        if (application == null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "warmup_context_unavailable",
            )
            return null
        }
        return AndroidFlowWrapperWarmupHandle(
            application = application,
            entryUrl = entryUrl,
            onCallbackPayload = onCallbackPayload,
            onTimeout = onTimeout,
            timeoutMs = timeoutMs,
        )
    }
}
