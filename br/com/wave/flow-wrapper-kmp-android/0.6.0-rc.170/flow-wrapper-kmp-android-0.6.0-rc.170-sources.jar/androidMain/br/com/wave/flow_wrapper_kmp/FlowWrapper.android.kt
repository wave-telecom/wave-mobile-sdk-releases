package br.com.wave.flow_wrapper_kmp

import android.content.Context

internal object HostContextHolder {
    @Volatile
    var applicationContext: Context? = null
        private set

    fun set(context: Context) {
        applicationContext = context.applicationContext
    }
}

/**
 * Android entry point that registers the host [context] before SDK init, so the
 * device-metadata CDR headers (FLW-1104) reach BFF calls and platform lookups
 * (warmup WebView, image loader, warmup cache dir) stop depending on the
 * reflection fallback. Android-only source set: the iOS framework surface is
 * unchanged — iOS keeps calling the common [FlowWrapper.start].
 */
fun FlowWrapper.start(
    context: Context,
    apiKey: String,
    msisdn: String,
    config: FlowWrapperConfig = FlowWrapperConfig(),
    onReady: (() -> Unit)? = null,
) {
    HostContextHolder.set(context)
    br.com.wave.flows.kmp.FlowWrapper.setHostContext(context)
    start(apiKey = apiKey, msisdn = msisdn, config = config, onReady = onReady)
}
