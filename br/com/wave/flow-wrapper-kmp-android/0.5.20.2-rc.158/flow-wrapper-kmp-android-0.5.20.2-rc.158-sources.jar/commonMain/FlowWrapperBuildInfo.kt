package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20.2-rc.158"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-22T09:56:40.848002-03:00"
    const val GIT_SHA: String = "263596f"
    const val GIT_BRANCH: String = "release/0.5.20.2"
    const val DESCRIPTION: String = "0.5.20.2-rc.158@2026-07-22T09:56:40.848002-03:00#263596f"
}