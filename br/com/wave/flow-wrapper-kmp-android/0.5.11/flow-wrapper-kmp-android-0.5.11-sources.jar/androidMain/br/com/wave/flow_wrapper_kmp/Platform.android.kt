package br.com.wave.flow_wrapper_kmp

import android.annotation.SuppressLint
import android.app.Application
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebViewClient
import android.webkit.WebView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import com.multiplatform.webview.web.AccompanistWebViewClient
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator
import com.multiplatform.webview.web.defaultWebViewFactory

private const val NATIVE_HANDLER_BRIDGE_NAME = "NativeHandler"
private const val NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP = "sendDataToApp"
private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"
private const val ORIGIN_NATIVE_HANDLER_BRIDGE = "native_handler_bridge"

private class NativeHandlerJavascriptInterface(
    private val onCallbackPayload: (String) -> Unit,
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun sendDataToApp(payload: String?) {
        if (payload.isNullOrBlank()) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "callback origin=$ORIGIN_NATIVE_HANDLER_BRIDGE type=UNKNOWN payload=<blank>",
            )
            return
        }
        val payloadPreview = if (payload.length <= 320) payload else payload.take(320) + "..."
        platformLogDebug(FLOW_WRAPPER_LOG_TAG, "android_js_interface sendDataToApp payload=$payloadPreview")
        mainHandler.post { onCallbackPayload(payload) }
    }

    @JavascriptInterface
    fun callNative(
        methodName: String?,
        params: String?,
        @Suppress("UNUSED_PARAMETER") callbackId: String?,
    ) {
        if (methodName != NATIVE_HANDLER_METHOD_SEND_DATA_TO_APP) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "unsupported_native_handler_method method=${methodName ?: "<null>"}",
            )
            return
        }
        sendDataToApp(params)
    }
}

private class FlowWrapperWebViewClient(
) : AccompanistWebViewClient() {
    override fun onPageStarted(
        view: WebView,
        url: String?,
        favicon: Bitmap?,
    ) {
        // Skip Accompanist's viewport JS injection; SDK contract uses native bridge only.
        state.errorsForCurrentRequest.clear()
    }
}

private class FlowWrapperWarmupWebViewClient(
    private val entryUrl: String,
) : WebViewClient() {
    override fun onPageFinished(
        view: WebView,
        url: String?,
    ) {
        super.onPageFinished(view, url)
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "warmup_page_finished entryUrl=$entryUrl loadedUrl=${url ?: "<null>"}",
        )
    }
}

private class AndroidFlowWrapperWarmupHandle(
    private val application: Application,
    private val entryUrl: String,
    private val onCallbackPayload: (String) -> Unit,
    private val onTimeout: () -> Unit,
    private val timeoutMs: Long,
) : FlowWrapperWarmupHandle {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private var isClosed = false
    private val timeoutRunnable =
        Runnable {
            if (!isClosed) {
                onTimeout()
            }
        }

    init {
        mainHandler.postDelayed(timeoutRunnable, timeoutMs)
        mainHandler.post { createAndLoadWebView() }
    }

    override fun cancel() {
        mainHandler.removeCallbacks(timeoutRunnable)
        mainHandler.post { close() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createAndLoadWebView() {
        if (isClosed) return

        val nativeHandlerBridge =
            NativeHandlerJavascriptInterface { payload ->
                if (!isClosed) {
                    onCallbackPayload(payload)
                }
            }

        webView =
            WebView(application).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                }
                webViewClient = FlowWrapperWarmupWebViewClient(entryUrl = entryUrl)
                removeJavascriptInterface(NATIVE_HANDLER_BRIDGE_NAME)
                addJavascriptInterface(nativeHandlerBridge, NATIVE_HANDLER_BRIDGE_NAME)
                platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "warmup_load_started entryUrl=$entryUrl",
                )
                loadUrl(entryUrl)
            }
    }

    private fun close() {
        if (isClosed) return
        isClosed = true
        webView?.apply {
            stopLoading()
            webViewClient = WebViewClient()
            removeJavascriptInterface(NATIVE_HANDLER_BRIDGE_NAME)
            destroy()
        }
        webView = null
    }
}

private fun resolveApplicationContext(): Application? {
    return runCatching {
        val activityThreadClass = Class.forName("android.app.ActivityThread")
        activityThreadClass.getMethod("currentApplication").invoke(null) as? Application
    }.getOrNull() ?: runCatching {
        val appGlobalsClass = Class.forName("android.app.AppGlobals")
        appGlobalsClass.getMethod("getInitialApplication").invoke(null) as? Application
    }.getOrNull()
}

actual fun platform() = "Android"

internal actual fun platformLogDebug(tag: String, message: String) {
    runCatching {
        Log.d(tag, message)
    }
}

@Composable
internal actual fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
): PlatformWebViewParams? {
    navigator
    onNativeBridgeMessage
    val client = remember { FlowWrapperWebViewClient() }
    return remember(client) { PlatformWebViewParams(client = client) }
}

@Composable
internal actual fun rememberNativeHandlerWebViewFactory(
    onNativeBridgeMessage: (String) -> Unit,
): ((WebViewFactoryParam) -> NativeWebView)? {
    val currentCallback = rememberUpdatedState(onNativeBridgeMessage)
    val nativeHandlerBridge =
        remember {
            NativeHandlerJavascriptInterface { payload -> currentCallback.value(payload) }
        }

    return remember(nativeHandlerBridge) {
        { param: WebViewFactoryParam ->
            val webView = defaultWebViewFactory(param)
            webView.settings.apply {
                domStorageEnabled = true
            }
            webView.removeJavascriptInterface(NATIVE_HANDLER_BRIDGE_NAME)
            webView.addJavascriptInterface(nativeHandlerBridge, NATIVE_HANDLER_BRIDGE_NAME)
            webView
        }
    }
}

internal actual object PlatformFlowWrapperWarmupLauncher {
    actual fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle? {
        val application = resolveApplicationContext()
        if (application == null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "warmup_context_unavailable entryUrl=$entryUrl",
            )
            return null
        }
        return AndroidFlowWrapperWarmupHandle(
            application = application,
            entryUrl = entryUrl,
            onCallbackPayload = onCallbackPayload,
            onTimeout = onTimeout,
            timeoutMs = timeoutMs,
        )
    }
}
