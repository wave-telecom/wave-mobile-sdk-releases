package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderListNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as ListBlockConfig
    val compactHorizontalItem = LocalCompactHorizontalItem.current
    val chartOverlayContent = LocalChartOverlayContent.current
    if (config.orientation == BlockOrientation.VERTICAL) {
        CompositionLocalProvider(LocalCompactHorizontalItem provides false) {
            Column(
                modifier = modifier
                    .then(
                        if (shouldFillWidth(config.style, parentOrientation) && !compactHorizontalItem) {
                            Modifier.fillMaxWidth()
                        } else {
                            Modifier
                        },
                    )
                    .applyBlockStyle(config.style)
                    .padding(
                        if (compactHorizontalItem) {
                            config.style.toVerticalPaddingValues()
                        } else {
                            config.style.toPaddingValues()
                        },
                    ),
                verticalArrangement = Arrangement.spacedBy(config.spacing.dp),
                horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
            ) {
                node.children.forEach { child ->
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.VERTICAL,
                    )
                }
            }
        }
    } else {
        val centerUnalignedChartOverlayRow = chartOverlayContent && config.horizontalAlign == null
        val expandLastItem = node.children.lastOrNull()?.containsDivider() == true
        val expandIndexes = node.children.mapIndexedNotNull { index, child ->
            val childConfig = child.block.config
            if (childConfig is ListBlockConfig && childConfig.expand) index else null
        }.toSet()
        AdaptiveHorizontalListLayout(
            modifier = modifier
                .then(
                    if (shouldFillWidth(config.style, parentOrientation) && !centerUnalignedChartOverlayRow) {
                        Modifier.fillMaxWidth()
                    } else {
                        Modifier
                    },
                )
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            spacing = config.spacing,
            horizontalAlign = if (centerUnalignedChartOverlayRow) "center" else config.horizontalAlign,
            verticalAlign = config.verticalAlign,
            expandIndexes = expandIndexes,
            expandLastItem = expandLastItem,
        ) {
            node.children.forEach { child ->
                CompositionLocalProvider(LocalCompactHorizontalItem provides true) {
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                    )
                }
            }
        }
    }
}

private fun ResolvedRenderNode.containsDivider(): Boolean {
    return block.type == BlockType.DIVIDER || children.any { it.containsDivider() }
}
