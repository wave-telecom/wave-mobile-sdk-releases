package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderButtonNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as ButtonBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    val background = config.style.backgroundColorHex?.toComposeColorOrNull()
    val textColor = radioGroupOverride.colorOverride
        ?: config.style.colorHex?.toComposeColorOrNull()
    val isLink = background == null || background == Color.Transparent
    val contentColor = textColor ?: ButtonDefaults.buttonColors().contentColor

    if (isLink) {
        // Render as an inline text link — contracts use transparent buttons as
        // anchor-style affordances (e.g. "Mostrar detalles" on the home screen).
        Row(
            modifier = modifier
                .clickable { renderContext.dispatchNodeAction(node) }
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = config.value,
                color = textColor ?: Color.Unspecified,
                fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
                fontWeight = config.fontWeight?.toComposeFontWeight(),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        return
    }

    val buttonModifier = if (shouldFillWidth(config.style, parentOrientation = null)) {
        modifier.fillMaxWidth()
    } else {
        modifier
    }.applyBlockStyle(config.style)

    Button(
        onClick = {
            renderContext.dispatchNodeAction(node)
        },
        modifier = buttonModifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = background ?: ButtonDefaults.buttonColors().containerColor,
            contentColor = contentColor,
        ),
        shape = config.style.toRoundedCornerShape(),
        contentPadding = ButtonDefaults.ContentPadding,
    ) {
        Text(
            text = config.value,
            fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
            fontWeight = config.fontWeight?.toComposeFontWeight(),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
