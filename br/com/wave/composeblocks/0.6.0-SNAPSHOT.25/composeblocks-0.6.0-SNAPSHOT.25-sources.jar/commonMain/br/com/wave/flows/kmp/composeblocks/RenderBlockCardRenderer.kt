package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.CardBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderCardNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as CardBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    val containerColor = radioGroupOverride.backgroundColorOverride
        ?: config.style.backgroundColorHex?.toComposeColorOrNull()
        ?: MaterialTheme.colorScheme.surface
    val elevationDp = (config.elevation ?: 0).dp
    val isTransparentWrapper = containerColor == Color.Transparent && elevationDp == 0.dp
    val isBorderedContentChip = config.style.width == null &&
        config.style.borderWidth != null &&
        elevationDp == 0.dp &&
        config.style.backgroundColorHex == null
    Card(
        modifier = modifier
            .then(if (shouldFillWidth(config.style, parentOrientation) && !isBorderedContentChip) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style, includeBackground = false),
        shape = config.style.toRoundedCornerShape(),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = elevationDp),
    ) {
        Column(modifier = Modifier.padding(config.style.toPaddingValues(defaultPadding = if (isTransparentWrapper) 0 else 12))) {
            node.children.forEach { child ->
                RenderResolvedNode(
                    node = child,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.VERTICAL,
                )
            }
        }
    }
}
