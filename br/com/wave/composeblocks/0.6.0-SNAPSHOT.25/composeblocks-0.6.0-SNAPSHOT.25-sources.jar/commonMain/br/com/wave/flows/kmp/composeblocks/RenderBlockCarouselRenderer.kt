package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.CarouselBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun renderCarouselNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as CarouselBlockConfig
    val children = node.children
    val itemWidth = if (config.itemWidth > 0) config.itemWidth else 200
    val spacing = config.spacing

    val pagerState = rememberPagerState(pageCount = { children.size })

    Column(
        modifier = modifier
            .then(if (config.style.width == null) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (children.isEmpty()) return@Column

        HorizontalPager(
            state = pagerState,
            pageSize = PageSize.Fixed(itemWidth.dp),
            pageSpacing = spacing.dp,
            contentPadding = PaddingValues(horizontal = 16.dp),
            modifier = Modifier.fillMaxWidth(),
        ) { page ->
            Box(modifier = Modifier.width(itemWidth.dp)) {
                CompositionLocalProvider {
                    RenderResolvedNode(
                        node = children[page],
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                    )
                }
            }
        }

        if (config.showIndicators && children.size > 1) {
            Row(
                modifier = Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            ) {
                repeat(children.size) { index ->
                    val isActive = pagerState.currentPage == index
                    Box(
                        modifier = Modifier
                            .size(if (isActive) 8.dp else 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (isActive) Color(0xFF0071D1) else Color(0xFFCBD5E1),
                                CircleShape,
                            ),
                    )
                }
            }
        }
    }
}

@Composable
private fun CompositionLocalProvider(content: @Composable () -> Unit) {
    // Tiny wrapper kept so future locals (compact-horizontal, etc.) can be provided per slide.
    content()
}
