package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.registry.ComposeRendererRegistry
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.runtime.buildRenderPlan
import br.com.wave.flows.kmp.core.visibility.buildInitialVisibilityState
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache

@Composable
fun RenderBlockRoute(
    componentId: String,
    contractProvider: ScreenContractProvider,
    hostEventHandler: HostEventHandler,
    externalCode: String? = null,
    sessionToken: Int = 0,
    refreshToken: Int = 0,
    onContractLoaded: (ScreenContract) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val routeStateKey = remember(componentId, externalCode, sessionToken) {
        "$sessionToken|${externalCode.orEmpty()}|$componentId"
    }
    val initialCachedContract = remember(componentId, externalCode, refreshToken) {
        contractProvider.peekCachedScreenContract(componentId, externalCode)
    }
    val contract by produceState<ScreenContract?>(
        initialValue = initialCachedContract,
        componentId,
        externalCode,
        refreshToken,
    ) {
        val cached = initialCachedContract ?: contractProvider.getCachedScreenContract(componentId, externalCode)
        // Always publish the cache result — including `null` — so a refresh
        // with no skeleton available drives the route through the loading
        // state (spinner) instead of silently freezing on the previous
        // contract during the network round-trip. Without this, the
        // `MutableState` inside `produceState` keeps the stale value and
        // the user sees no feedback that a refresh is in flight.
        value = cached
        try {
            value = contractProvider.getScreenContract(componentId, externalCode)
        } catch (error: Throwable) {
            // The BFF (or any source in the chain) failed. Try to recover
            // via the cache; if there is nothing to fall back to, surface
            // the error to the host instead of crashing the main thread.
            val fallback = contractProvider.getCachedScreenContract(componentId, externalCode)
            if (fallback != null) {
                value = fallback
                return@produceState
            }
            val errorCode = if (cached == null) "CONTRACT_LOAD_FAILED" else "CONTRACT_REFRESH_FAILED"
            hostEventHandler.onHostEvent(
                HostEvent.Error(
                    RenderBlockError(
                        code = errorCode,
                        message = "Failed to resolve contract \"$componentId\": ${error.message ?: "unknown error"}",
                    ),
                ),
            )
        }
    }

    // Snapshot the produced state into a local value. Without this, a
    // `LaunchedEffect` whose body still dereferences `contract!!` can race
    // with a refresh that resets the state to `null` between composition
    // and the effect being dispatched — producing an NPE in the middle of
    // an in-flight animation (chart, etc.).
    val resolvedContract = contract
    if (resolvedContract == null) {
        // Material3 circular spinner centred in the slot. Host themes it
        // via MaterialTheme.colorScheme.primary — no Telcel-specific color
        // is hardcoded in the SDK.
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(modifier = Modifier.size(40.dp))
        }
        return
    }

    LaunchedEffect(resolvedContract.id, refreshToken) {
        onContractLoaded(resolvedContract)
    }

    CompositionLocalProvider(
        LocalRenderRouteStateKey provides routeStateKey,
    ) {
        RenderBlockScreen(
            contract = resolvedContract,
            refreshToken = refreshToken,
            hostEventHandler = hostEventHandler,
            modifier = modifier,
        )
    }
}

@Composable
fun RenderBlockScreen(
    contract: ScreenContract,
    refreshToken: Int = 0,
    hostEventHandler: HostEventHandler,
    modifier: Modifier = Modifier,
) {
    val routeStateKey = LocalRenderRouteStateKey.current
    val cachedVisibility = remember(routeStateKey) {
        RenderBlockInteractionCache.getVisibility(routeStateKey)
    }
    val visibilityState = remember(contract.id, refreshToken) {
        mutableStateMapOf<String, Boolean>().apply {
            putAll(cachedVisibility ?: buildInitialVisibilityState(contract.root))
            // The root of any contract is always visible: hidden-by-default
            // only makes sense for nested blocks whose siblings toggle them.
            // When a block (e.g. a bottom-sheet) is promoted to root via the
            // LiveBlockIndex, its inherited hidden state would prune the plan.
            put(contract.root.id, true)
        }
    }
    val visibilitySnapshot = visibilityState.toMap()
    val plan = remember(contract.root, visibilitySnapshot) {
        buildRenderPlan(
            block = contract.root,
            rendererRegistry = ComposeRendererRegistry.supportedRendererTypes,
            visibility = visibilitySnapshot,
        )
    }

    plan.errors.forEach { hostEventHandler.onHostEvent(HostEvent.Error(it)) }

    val rootNode = plan.node ?: return
    val rootModifier = modifier
        .fillMaxSize()
        .background(contract.root.config.style.backgroundColorHex?.toComposeColorOrNull() ?: Color.Transparent)
    val renderContext = RenderBlockRenderContext(
        hostEventHandler = hostEventHandler,
        currentVisibility = { visibilityState.toMap() },
        onVisibilityChange = {
            visibilityState.putAll(it)
            if (routeStateKey.isNotBlank()) {
                RenderBlockInteractionCache.putVisibility(
                    routeId = routeStateKey,
                    visibility = visibilityState.toMap(),
                )
            }
        },
    )

    // `LocalIsRootBlock` is `true` only for this root dispatch so renderers
    // that need to know whether they're the topmost node of a host-driven
    // RenderBlock invocation (currently only `renderBottomSheetNode`) can
    // pick a different code path. Children must reset it to `false` to
    // avoid leaking the flag down the tree.
    CompositionLocalProvider(LocalIsRootBlock provides true) {
        if (rootNode.block.contractErrors.isEmpty() &&
            rootNode.block.type == BlockType.LIST &&
            (rootNode.block.config as? ListBlockConfig)?.orientation == BlockOrientation.VERTICAL
        ) {
            RenderLazyRootListNode(
                node = rootNode,
                renderContext = renderContext,
                modifier = rootModifier,
            )
        } else {
            RenderResolvedNode(
                node = rootNode,
                renderContext = renderContext,
                modifier = rootModifier,
                parentOrientation = null,
            )
        }
    }
}

@Composable
private fun RenderLazyRootListNode(
    node: ResolvedRenderNode,
    renderContext: RenderBlockRenderContext,
    modifier: Modifier = Modifier,
) {
    val config = node.block.config as ListBlockConfig

    LazyColumn(
        modifier = modifier
            .then(if (shouldFillWidth(config.style, parentOrientation = null)) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style),
        verticalArrangement = Arrangement.spacedBy(config.spacing.dp),
        horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
        contentPadding = config.style.toPaddingValues(),
    ) {
        items(
            items = node.children,
            key = { child -> child.block.id },
            contentType = { child -> child.block.type.name },
        ) { child ->
            RenderResolvedNode(
                node = child,
                renderContext = renderContext,
                parentOrientation = BlockOrientation.VERTICAL,
            )
        }
    }
}

@Composable
internal fun RenderResolvedNode(
    node: ResolvedRenderNode,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
    modifier: Modifier = Modifier,
    wrapActionClick: Boolean = true,
) {
    val clickModifier = if (wrapActionClick && node.block.action != null) {
        modifier.clickable {
            renderContext.dispatchNodeAction(node)
        }
    } else {
        modifier
    }

    if (node.block.contractErrors.isNotEmpty()) {
        renderFallbackNode(
            node = node,
            modifier = clickModifier,
            renderContext = renderContext,
        )
        return
    }

    // Capture the "I'm the root of this RenderBlock call" signal *before*
    // dispatching, then reset it for the rest of the subtree. Only the
    // current node may see itself as root; every descendant is, by
    // definition, nested. This avoids the flag leaking through long
    // renderer chains (list → card → bottom-sheet etc.).
    val isRoot = LocalIsRootBlock.current
    CompositionLocalProvider(LocalIsRootBlock provides false) {
        when (node.block.type) {
            BlockType.TEXT -> renderTextNode(node, clickModifier)
            BlockType.RICH_TEXT -> renderRichTextNode(node, clickModifier)
            BlockType.BUTTON -> renderButtonNode(node, clickModifier, renderContext)
            BlockType.CARD -> renderCardNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.CAROUSEL -> renderCarouselNode(node, clickModifier, renderContext)
            BlockType.CHART -> renderChartNode(node, clickModifier, renderContext)
            BlockType.CONTAINER -> renderContainerNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.DIVIDER -> renderDividerNode(node, clickModifier)
            BlockType.IMAGE -> renderImageNode(node, clickModifier)
            BlockType.LIST -> renderListNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.RADIO_GROUP -> renderRadioGroupNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.SKELETON -> renderSkeletonNode(node, clickModifier)
            BlockType.SPACER -> renderSpacerNode(node, clickModifier)
            BlockType.TOOLBAR -> renderToolbarNode(node, clickModifier, renderContext)
            BlockType.TABS -> renderTabsNode(node, clickModifier, renderContext)
            BlockType.BOTTOM_SHEET -> renderBottomSheetNode(node, clickModifier, renderContext, isRoot = isRoot)
            BlockType.ACCORDION -> renderAccordionNode(node, clickModifier, renderContext, parentOrientation)
            BlockType.UNKNOWN -> renderFallbackNode(node, clickModifier, renderContext)
        }
    }
}
