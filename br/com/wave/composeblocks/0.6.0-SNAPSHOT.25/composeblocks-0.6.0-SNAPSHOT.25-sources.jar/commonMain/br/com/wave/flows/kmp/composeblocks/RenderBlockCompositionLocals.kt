package br.com.wave.flows.kmp.composeblocks

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

internal data class RadioGroupStyleOverride(
    val active: Boolean = false,
    val colorOverride: Color? = null,
    val backgroundColorOverride: Color? = null,
    val inGroup: Boolean = false,
    val fontScaleOverride: Float = 1f,
)

internal val LocalRadioGroupStyleOverride = compositionLocalOf { RadioGroupStyleOverride() }
internal val LocalCompactHorizontalItem = compositionLocalOf { false }
internal val LocalChartOverlayContent = compositionLocalOf { false }
internal val LocalRenderRouteStateKey = compositionLocalOf { "" }
