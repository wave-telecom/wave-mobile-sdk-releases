package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockStyle

internal fun Modifier.applyBlockStyle(style: BlockStyle): Modifier {
    var next = this

    style.width?.let { next = next.width(it.dp) }
    style.height?.let { next = next.height(it.dp) }
    if (style.hasMargins()) {
        next = next.padding(style.toMarginValues())
    }
    style.toBorderStroke()?.let { border ->
        next = next.border(border, style.toRoundedCornerShape())
    }
    style.zIndex?.let { next = next.zIndex(it.toFloat()) }
    val backgroundColor = style.backgroundColorHex?.toComposeColorOrNull()
    if (backgroundColor != null) {
        val shape = style.toRoundedCornerShape()
        next = next
            .clip(shape)
            .background(backgroundColor, shape)
    }

    return next
}

internal fun Modifier.applyBlockStyle(
    style: BlockStyle,
    includeBackground: Boolean,
): Modifier {
    var next = this

    style.width?.let { next = next.width(it.dp) }
    style.height?.let { next = next.height(it.dp) }
    if (style.hasMargins()) {
        next = next.padding(style.toMarginValues())
    }
    style.toBorderStroke()?.let { border ->
        next = next.border(border, style.toRoundedCornerShape())
    }
    style.zIndex?.let { next = next.zIndex(it.toFloat()) }
    val backgroundColor = style.backgroundColorHex?.toComposeColorOrNull()
    if (includeBackground && backgroundColor != null) {
        val shape = style.toRoundedCornerShape()
        next = next
            .clip(shape)
            .background(backgroundColor, shape)
    }

    return next
}

internal fun shouldFillWidth(
    style: BlockStyle,
    parentOrientation: BlockOrientation?,
): Boolean {
    return style.width == null && parentOrientation != BlockOrientation.HORIZONTAL
}

internal fun BlockStyle.toRoundedCornerShape(): RoundedCornerShape {
    return RoundedCornerShape(
        topStart = (borderRadiusTop ?: borderRadius ?: 0).dp,
        topEnd = (borderRadiusRight ?: borderRadius ?: 0).dp,
        bottomStart = (borderRadiusLeft ?: borderRadius ?: 0).dp,
        bottomEnd = (borderRadiusBottom ?: borderRadius ?: 0).dp,
    )
}

internal fun BlockStyle.toBorderStroke(): androidx.compose.foundation.BorderStroke? {
    val width = borderWidth ?: return null
    val color = borderColorHex?.toComposeColorOrNull() ?: return null
    if (width <= 0) return null
    if (borderStyle?.equals("solid", ignoreCase = true) == false) return null
    return androidx.compose.foundation.BorderStroke(width.dp, color)
}

internal fun BlockStyle.toPaddingValues(defaultPadding: Int = 0): PaddingValues {
    val top = paddingTop ?: padding ?: defaultPadding
    val bottom = paddingBottom ?: padding ?: defaultPadding
    val left = paddingLeft ?: padding ?: defaultPadding
    val right = paddingRight ?: padding ?: defaultPadding
    return PaddingValues(start = left.dp, top = top.dp, end = right.dp, bottom = bottom.dp)
}

internal fun BlockStyle.toVerticalPaddingValues(defaultPadding: Int = 0): PaddingValues {
    val top = paddingTop ?: padding ?: defaultPadding
    val bottom = paddingBottom ?: padding ?: defaultPadding
    return PaddingValues(top = top.dp, bottom = bottom.dp)
}

internal fun BlockStyle.toMarginValues(): PaddingValues {
    val top = marginTop ?: margin ?: 0
    val bottom = marginBottom ?: margin ?: 0
    val left = marginLeft ?: margin ?: 0
    val right = marginRight ?: margin ?: 0
    return PaddingValues(start = left.dp, top = top.dp, end = right.dp, bottom = bottom.dp)
}

internal fun BlockStyle.hasMargins(): Boolean {
    return margin != null || marginTop != null || marginBottom != null || marginLeft != null || marginRight != null
}

internal fun Int.toComposeFontWeight(): FontWeight {
    return when {
        this >= 700 -> FontWeight.Bold
        this >= 600 -> FontWeight.SemiBold
        this >= 500 -> FontWeight.Medium
        else -> FontWeight.Normal
    }
}

internal fun String?.toComposeTextAlign(): TextAlign? {
    return when (this?.lowercase()) {
        "center" -> TextAlign.Center
        "end", "right" -> TextAlign.End
        "start", "left" -> TextAlign.Start
        else -> null
    }
}

internal fun String?.toHorizontalAlignment(): Alignment.Horizontal {
    return when (this?.lowercase()) {
        "center" -> Alignment.CenterHorizontally
        "end", "right" -> Alignment.End
        else -> Alignment.Start
    }
}

internal fun String?.toVerticalAlignment(): Alignment.Vertical {
    return when (this?.lowercase()) {
        "center" -> Alignment.CenterVertically
        "end", "bottom" -> Alignment.Bottom
        else -> Alignment.Top
    }
}

internal fun String?.toContentScale(): ContentScale {
    return when (this?.lowercase()) {
        "fill" -> ContentScale.FillBounds
        "crop" -> ContentScale.Crop
        else -> ContentScale.Fit
    }
}

internal fun BlockStyle.isAbsolutePosition(): Boolean {
    return position?.equals("absolute", ignoreCase = true) == true
}

internal fun BlockStyle.isRelativePosition(): Boolean {
    return position?.equals("relative", ignoreCase = true) == true
}

internal fun BlockStyle.toAbsoluteAlignment(): Alignment {
    val hasTop = top != null
    val hasBottom = bottom != null
    val hasLeft = left != null
    val hasRight = right != null
    return when {
        hasTop && hasRight -> Alignment.TopEnd
        hasTop && hasLeft -> Alignment.TopStart
        hasBottom && hasRight -> Alignment.BottomEnd
        hasBottom && hasLeft -> Alignment.BottomStart
        hasRight -> Alignment.TopEnd
        hasLeft -> Alignment.TopStart
        hasBottom -> Alignment.BottomStart
        else -> Alignment.TopStart
    }
}

internal fun BlockStyle.toAbsoluteOffsetX(): androidx.compose.ui.unit.Dp {
    val leftValue = left
    val rightValue = right
    return when {
        leftValue != null -> leftValue.dp
        rightValue != null -> (-rightValue).dp
        else -> 0.dp
    }
}

internal fun BlockStyle.toAbsoluteOffsetY(): androidx.compose.ui.unit.Dp {
    val topValue = top
    val bottomValue = bottom
    return when {
        topValue != null -> topValue.dp
        bottomValue != null -> (-bottomValue).dp
        else -> 0.dp
    }
}
