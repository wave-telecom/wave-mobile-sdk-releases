package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ToolbarBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderToolbarNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as ToolbarBlockConfig
    val leftChild = node.children.firstOrNull()
    val rightChild = node.children.getOrNull(1)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues(defaultPadding = 12)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Box(
            modifier = Modifier.size(32.dp),
            contentAlignment = Alignment.Center,
        ) {
            leftChild?.let {
                RenderResolvedNode(
                    node = it,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.HORIZONTAL,
                    modifier = Modifier.size(24.dp),
                )
            }
        }

        Text(
            text = config.title,
            modifier = Modifier.weight(1f),
            textAlign = config.align.toComposeTextAlign() ?: TextAlign.Center,
            style = TextStyle(
                color = config.style.colorHex?.toComposeColorOrNull() ?: Color.Unspecified,
                fontWeight = FontWeight.SemiBold,
            ),
        )

        Box(
            modifier = Modifier.size(32.dp),
            contentAlignment = Alignment.Center,
        ) {
            rightChild?.let {
                RenderResolvedNode(
                    node = it,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.HORIZONTAL,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
    }
}
