package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ChartBlockConfig
import br.com.wave.flows.kmp.core.contract.ChartDataPoint
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private const val GAUGE_SEGMENT_COUNT = 25
private const val SEMI_CIRCLE_TOTAL_SWEEP = 180f
private const val SEMI_CIRCLE_START_ANGLE = 180f
private const val SEMI_CIRCLE_GAP_ANGLE = 3.9f
private const val SEMI_CIRCLE_VISUAL_SCALE = 1.2f

@Composable
internal fun renderChartNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as ChartBlockConfig
    val chartSize = (if (config.size > 0) config.size else 160).dp
    val semiCircleVisualSize = chartSize * SEMI_CIRCLE_VISUAL_SCALE
    val isSemiCircle = !config.type.equals("donut", ignoreCase = true) &&
        !config.type.equals("circle", ignoreCase = true)
    val revealProgressState = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        delay(400L)
        animate(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = 1500,
                easing = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1.0f),
            ),
        ) { value, _ -> revealProgressState.value = value }
    }

    Box(
        modifier = modifier
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        contentAlignment = Alignment.Center,
    ) {
        if (isSemiCircle) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .width(semiCircleVisualSize)
                        .height(semiCircleVisualSize * 0.58f),
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(semiCircleVisualSize / 2)
                            .align(Alignment.TopCenter),
                    ) {
                        drawSemiCircleGauge(
                            points = config.data,
                            revealProgress = revealProgressState.value,
                        )
                    }
                    if (node.children.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .width(semiCircleVisualSize * 0.56f)
                                .height(semiCircleVisualSize / 2)
                                .padding(bottom = semiCircleVisualSize * 0.012f),
                            verticalArrangement = Arrangement.Bottom,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            CompositionLocalProvider(LocalChartOverlayContent provides true) {
                                node.children.forEach { child ->
                                    RenderResolvedNode(
                                        node = child,
                                        renderContext = renderContext,
                                        parentOrientation = BlockOrientation.VERTICAL,
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .width(semiCircleVisualSize * 0.94f)
                            .padding(bottom = 0.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = "0%",
                            fontSize = 12.sp,
                            color = Color(0xFF222222),
                        )
                        Text(
                            text = "100%",
                            fontSize = 12.sp,
                            color = Color(0xFF222222),
                        )
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier.width(chartSize).height(chartSize),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(modifier = Modifier.fillMaxWidth().height(chartSize)) {
                    drawDonutChart(config.data, revealProgressState.value)
                }
                if (node.children.isNotEmpty()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        node.children.forEach { child ->
                            RenderResolvedNode(
                                node = child,
                                renderContext = renderContext,
                                parentOrientation = BlockOrientation.VERTICAL,
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawSemiCircleGauge(
    points: List<ChartDataPoint>,
    revealProgress: Float,
) {
    val total = points.sumOf { it.value.toLong() }.coerceAtLeast(1L).toFloat()
    val segmentSpan = SEMI_CIRCLE_TOTAL_SWEEP / GAUGE_SEGMENT_COUNT
    val segmentCenterSpan = if (GAUGE_SEGMENT_COUNT > 1) {
        SEMI_CIRCLE_TOTAL_SWEEP / (GAUGE_SEGMENT_COUNT - 1)
    } else {
        0f
    }
    val segmentSweep = segmentSpan - SEMI_CIRCLE_GAP_ANGLE
    val segmentThickness = (size.width * 0.082f).coerceAtLeast(13f)
    val outerRadius = (size.width / 2f) - (segmentThickness / 2f)
    val trackRadius = outerRadius - (segmentThickness / 2f)
    val availableSegmentCount = points.toGaugeSegmentCount(total)
    val usedSegmentCount = points.toUsedSegmentCount(total)

    for (segmentIndex in 0 until GAUGE_SEGMENT_COUNT) {
        // Fan opening: segments start bunched at 180° and spread to final positions as progress increases
        val centerAngle = SEMI_CIRCLE_START_ANGLE + (segmentIndex * segmentCenterSpan * revealProgress)
        val radians = (centerAngle * PI / 180f).toFloat()
        val center = Offset(
            x = size.width / 2f + (trackRadius * cos(radians)),
            y = size.height + (trackRadius * sin(radians)),
        )
        val segmentLength = ((trackRadius * (segmentSweep * PI.toFloat() / 180f)) * 0.94f) *
            revealProgress
        val color = if (segmentIndex < availableSegmentCount) {
            points.availableColor()
        } else if (segmentIndex < availableSegmentCount + usedSegmentCount) {
            points.usedColor()
        } else {
            Color.Transparent
        }

        if (color == Color.Transparent || segmentLength <= 0f) continue

        rotate(
            degrees = centerAngle - 90f,
            pivot = center,
        ) {
            drawRoundRect(
                color = color,
                topLeft = Offset(
                    x = center.x - (segmentLength / 2f),
                    y = center.y - (segmentThickness / 2f),
                ),
                size = Size(width = segmentLength, height = segmentThickness),
                cornerRadius = CornerRadius(1f, 1f),
            )
        }
    }
}

private fun List<ChartDataPoint>.toGaugeSegmentCount(total: Float): Int {
    val availableValue = firstOrNull { it.key.equals("available", ignoreCase = true) }?.value ?: 0
    return ((availableValue / total) * GAUGE_SEGMENT_COUNT)
        .roundToInt()
        .coerceIn(0, GAUGE_SEGMENT_COUNT)
}

private fun List<ChartDataPoint>.toUsedSegmentCount(total: Float): Int {
    val usedValue = firstOrNull { it.key.equals("used", ignoreCase = true) }?.value ?: 0
    return ((usedValue / total) * GAUGE_SEGMENT_COUNT)
        .roundToInt()
        .coerceIn(0, GAUGE_SEGMENT_COUNT)
}

private fun List<ChartDataPoint>.usedColor(): Color =
    firstOrNull { it.key.equals("used", ignoreCase = true) }
        ?.fill
        ?.toComposeColorOrNull()
        ?: Color(0xFFE5E7EB)

private fun List<ChartDataPoint>.availableColor(): Color =
    firstOrNull { it.key.equals("available", ignoreCase = true) }
        ?.fill
        ?.toComposeColorOrNull()
        ?: Color(0xFF8BC34A)

private fun DrawScope.drawDonutChart(points: List<ChartDataPoint>, revealProgress: Float) {
    val total = points.sumOf { it.value.toLong() }.coerceAtLeast(1L).toFloat()
    val stroke = size.minDimension * 0.14f
    val topLeft = Offset(stroke / 2f, stroke / 2f)
    val arcSize = Size(size.width - stroke, size.height - stroke)

    val totalSweep = 360f * revealProgress
    var start = -90f
    var drawn = 0f
    for (point in points) {
        if (drawn >= totalSweep) break
        val fullSweep = (point.value / total) * 360f
        val sweep = (totalSweep - drawn).coerceAtMost(fullSweep)
        drawArc(
            color = point.fill.toComposeColorOrNull() ?: Color(0xFFE5E7EB),
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Butt),
        )
        start += fullSweep
        drawn += fullSweep
    }
}
