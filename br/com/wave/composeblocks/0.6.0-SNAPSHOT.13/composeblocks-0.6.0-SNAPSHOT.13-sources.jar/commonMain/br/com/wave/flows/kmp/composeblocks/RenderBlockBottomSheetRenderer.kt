package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BottomSheetBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.visibility.setBlockVisibility

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun renderBottomSheetNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    // By the time this composable is invoked, the render plan has already
    // checked visibility; still, guard against stale state toggling mid-frame.
    val config = node.block.config as BottomSheetBlockConfig
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)

    LaunchedEffect(node.block.id) {
        sheetState.show()
    }

    ModalBottomSheet(
        onDismissRequest = {
            renderContext.onVisibilityChange(
                setBlockVisibility(
                    state = renderContext.currentVisibility(),
                    blockId = node.block.id,
                    value = false,
                ),
            )
        },
        sheetState = sheetState,
        containerColor = config.style.backgroundColorHex?.toComposeColorOrNull()
            ?: Color.White,
        shape = config.style.toRoundedCornerShape(),
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(config.style.toPaddingValues(defaultPadding = 16)),
        ) {
            node.children.forEach { child ->
                RenderResolvedNode(
                    node = child,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.VERTICAL,
                )
            }
        }
    }
}
