package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.registry.ComposeRendererRegistry
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.runtime.buildRenderPlan
import br.com.wave.flows.kmp.core.visibility.buildInitialVisibilityState
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache

@Composable
fun RenderBlockRoute(
    componentId: String,
    contractProvider: ScreenContractProvider,
    hostEventHandler: HostEventHandler,
    externalCode: String? = null,
    sessionToken: Int = 0,
    refreshToken: Int = 0,
    onContractLoaded: (ScreenContract) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val routeStateKey = remember(componentId, externalCode, sessionToken) {
        "$sessionToken|${externalCode.orEmpty()}|$componentId"
    }
    val initialCachedContract = remember(componentId, externalCode, refreshToken) {
        contractProvider.peekCachedScreenContract(componentId, externalCode)
    }
    val contract by produceState<ScreenContract?>(
        initialValue = initialCachedContract,
        componentId,
        externalCode,
        refreshToken,
    ) {
        val cached = initialCachedContract ?: contractProvider.getCachedScreenContract(componentId, externalCode)
        cached?.let {
            value = cached
        }
        try {
            value = contractProvider.getScreenContract(componentId, externalCode)
        } catch (error: Throwable) {
            if (cached == null) throw error
            val fallback = contractProvider.getCachedScreenContract(componentId, externalCode)
            if (fallback != null) {
                value = fallback
                return@produceState
            }
            hostEventHandler.onHostEvent(
                HostEvent.Error(
                    RenderBlockError(
                        code = "CONTRACT_REFRESH_FAILED",
                        message = "Failed to refresh cached contract \"$componentId\": ${error.message ?: "unknown error"}",
                    ),
                ),
            )
        }
    }

    if (contract == null) {
        Text(
            text = "Loading blocks...",
            modifier = modifier.padding(16.dp),
        )
        return
    }

    LaunchedEffect(contract!!.id, refreshToken) {
        onContractLoaded(contract!!)
    }

    CompositionLocalProvider(
        LocalRenderRouteStateKey provides routeStateKey,
    ) {
        RenderBlockScreen(
            contract = contract!!,
            refreshToken = refreshToken,
            hostEventHandler = hostEventHandler,
            modifier = modifier,
        )
    }
}

@Composable
fun RenderBlockScreen(
    contract: ScreenContract,
    refreshToken: Int = 0,
    hostEventHandler: HostEventHandler,
    modifier: Modifier = Modifier,
) {
    val routeStateKey = LocalRenderRouteStateKey.current
    val cachedVisibility = remember(routeStateKey) {
        RenderBlockInteractionCache.getVisibility(routeStateKey)
    }
    val visibilityState = remember(contract.id, refreshToken) {
        mutableStateMapOf<String, Boolean>().apply {
            putAll(cachedVisibility ?: buildInitialVisibilityState(contract.root))
        }
    }
    val visibilitySnapshot = visibilityState.toMap()
    val plan = remember(contract.root, visibilitySnapshot) {
        buildRenderPlan(
            block = contract.root,
            rendererRegistry = ComposeRendererRegistry.supportedRendererTypes,
            visibility = visibilitySnapshot,
        )
    }

    plan.errors.forEach { hostEventHandler.onHostEvent(HostEvent.Error(it)) }

    val rootNode = plan.node ?: return
    val rootModifier = modifier
        .fillMaxSize()
        .background(contract.root.config.style.backgroundColorHex?.toComposeColorOrNull() ?: Color.Transparent)
    val renderContext = RenderBlockRenderContext(
        hostEventHandler = hostEventHandler,
        currentVisibility = { visibilityState.toMap() },
        onVisibilityChange = {
            visibilityState.putAll(it)
            if (routeStateKey.isNotBlank()) {
                RenderBlockInteractionCache.putVisibility(
                    routeId = routeStateKey,
                    visibility = visibilityState.toMap(),
                )
            }
        },
    )

    if (rootNode.block.contractErrors.isEmpty() &&
        rootNode.block.type == BlockType.LIST &&
        (rootNode.block.config as? ListBlockConfig)?.orientation == BlockOrientation.VERTICAL
    ) {
        RenderLazyRootListNode(
            node = rootNode,
            renderContext = renderContext,
            modifier = rootModifier,
        )
    } else {
        RenderResolvedNode(
            node = rootNode,
            renderContext = renderContext,
            modifier = rootModifier,
            parentOrientation = null,
        )
    }
}

@Composable
private fun RenderLazyRootListNode(
    node: ResolvedRenderNode,
    renderContext: RenderBlockRenderContext,
    modifier: Modifier = Modifier,
) {
    val config = node.block.config as ListBlockConfig

    LazyColumn(
        modifier = modifier
            .then(if (shouldFillWidth(config.style, parentOrientation = null)) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style),
        verticalArrangement = Arrangement.spacedBy(config.spacing.dp),
        horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
        contentPadding = config.style.toPaddingValues(),
    ) {
        items(
            items = node.children,
            key = { child -> child.block.id },
            contentType = { child -> child.block.type.name },
        ) { child ->
            RenderResolvedNode(
                node = child,
                renderContext = renderContext,
                parentOrientation = BlockOrientation.VERTICAL,
            )
        }
    }
}

@Composable
internal fun RenderResolvedNode(
    node: ResolvedRenderNode,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
    modifier: Modifier = Modifier,
    wrapActionClick: Boolean = true,
) {
    val clickModifier = if (wrapActionClick && node.block.action != null) {
        modifier.clickable {
            renderContext.dispatchNodeAction(node)
        }
    } else {
        modifier
    }

    if (node.block.contractErrors.isNotEmpty()) {
        renderFallbackNode(
            node = node,
            modifier = clickModifier,
            renderContext = renderContext,
        )
        return
    }

    when (node.block.type) {
        BlockType.TEXT -> renderTextNode(node, clickModifier)
        BlockType.BUTTON -> renderButtonNode(node, clickModifier, renderContext)
        BlockType.CARD -> renderCardNode(node, clickModifier, renderContext, parentOrientation)
        BlockType.CAROUSEL -> renderCarouselNode(node, clickModifier, renderContext)
        BlockType.CHART -> renderChartNode(node, clickModifier, renderContext)
        BlockType.CONTAINER -> renderContainerNode(node, clickModifier, renderContext, parentOrientation)
        BlockType.DIVIDER -> renderDividerNode(node, clickModifier)
        BlockType.IMAGE -> renderImageNode(node, clickModifier)
        BlockType.LIST -> renderListNode(node, clickModifier, renderContext, parentOrientation)
        BlockType.RADIO_GROUP -> renderRadioGroupNode(node, clickModifier, renderContext, parentOrientation)
        BlockType.SKELETON -> renderSkeletonNode(node, clickModifier)
        BlockType.SPACER -> renderSpacerNode(node, clickModifier)
        BlockType.TOOLBAR -> renderToolbarNode(node, clickModifier, renderContext)
        BlockType.TABS -> renderTabsNode(node, clickModifier, renderContext)
        BlockType.BOTTOM_SHEET -> renderBottomSheetNode(node, clickModifier, renderContext)
        BlockType.ACCORDION -> renderAccordionNode(node, clickModifier, renderContext, parentOrientation)
        BlockType.UNKNOWN -> renderFallbackNode(node, clickModifier, renderContext)
    }
}
