package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.material3.Text
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ChartBlockConfig
import br.com.wave.flows.kmp.core.contract.ChartDataPoint
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private const val CHART_REVEAL_ROUTE_ID = "chart.reveal"

private const val GAUGE_SEGMENT_COUNT = 25
private const val SEMI_CIRCLE_TOTAL_SWEEP = 180f
private const val SEMI_CIRCLE_START_ANGLE = 180f
private const val SEMI_CIRCLE_GAP_ANGLE = 3.28f
// Scales the gauge relative to the contract `size`. Tuned to ~0.95 for parity
// with the previous web rendering; values > 1 inflate the gauge beyond the
// contract and overflow narrow cards.
private const val SEMI_CIRCLE_VISUAL_SCALE = 0.95f

@Composable
internal fun renderChartNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as ChartBlockConfig
    val chartSize = (if (config.size > 0) config.size else 160).dp
    val semiCircleVisualSize = chartSize * SEMI_CIRCLE_VISUAL_SCALE
    val isSemiCircle = !config.type.equals("donut", ignoreCase = true) &&
        !config.type.equals("circle", ignoreCase = true)
    val markerBlockId = node.block.id
    val alreadyRevealed = remember(markerBlockId) {
        RenderBlockInteractionCache.getToggle(
            routeId = CHART_REVEAL_ROUTE_ID,
            blockId = markerBlockId,
            slot = "chart.revealAnimated",
        ) ?: false
    }
    val shouldAnimate = !alreadyRevealed
    val revealProgressState = remember(markerBlockId) {
        mutableStateOf(if (shouldAnimate) 0f else 1f)
    }
    LaunchedEffect(markerBlockId) {
        if (!shouldAnimate) return@LaunchedEffect
        RenderBlockInteractionCache.putToggle(
            routeId = CHART_REVEAL_ROUTE_ID,
            blockId = markerBlockId,
            value = true,
            slot = "chart.revealAnimated",
        )
        delay(400L)
        animate(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = 1500,
                easing = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1.0f),
            ),
        ) { value, _ -> revealProgressState.value = value }
    }

    // Pre-resolve chart palette in composable scope so the DrawScope helpers
    // below (which can't call @Composable) work with plain Colors. The
    // toThemedComposeColorOrNull call observes LocalFlowTheme, so a theme
    // switch recomposes this lambda and the draw runs against the new
    // palette.
    val usedColor: Color = config.data
        .firstOrNull { it.key.equals("used", ignoreCase = true) }
        ?.fill
        ?.toThemedComposeColorOrNull()
        ?: Color(0xFF8BC34A)
    val availableColor: Color = config.data
        .firstOrNull { it.key.equals("available", ignoreCase = true) }
        ?.fill
        ?.toThemedComposeColorOrNull()
        ?: Color(0xFFE5E7EB)
    val pointColors: List<Color> = config.data.map {
        it.fill?.toThemedComposeColorOrNull() ?: Color(0xFFE5E7EB)
    }
    val labelColor: Color = config.style.colorHex
        ?.toThemedComposeColorOrNull()
        ?: Color.Unspecified
    val labelFontSize = config.fontSizeSp?.sp ?: TextUnit.Unspecified
    val labelLineHeight = config.lineHeightSp?.sp ?: TextUnit.Unspecified
    val labelFontFamily = config.fontFamily.toComposeFontFamilyOrNull()
    val labelFontWeight = config.fontWeight?.toComposeFontWeight()
    val labelFontStyle = config.fontStyle.toComposeFontStyleOrNull()

    Box(
        modifier = modifier
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        contentAlignment = Alignment.Center,
    ) {
        if (isSemiCircle) {
          BoxWithConstraints {
            // Clamp the gauge to the width the parent actually offers. The
            // contract `size` (scaled by SEMI_CIRCLE_VISUAL_SCALE) is the
            // desired width, but on narrow cards 264dp overflows the container
            // padding. Shrinking to fit keeps the wide-screen look unchanged
            // (maxWidth >= desired) while preventing overflow on small screens.
            val gaugeSize = semiCircleVisualSize.coerceAtMost(maxWidth)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .width(gaugeSize)
                        .height(gaugeSize / 2),
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(gaugeSize / 2),
                    ) {
                        drawSemiCircleGauge(
                            points = config.data,
                            revealProgress = revealProgressState.value,
                            usedColor = usedColor,
                            availableColor = availableColor,
                        )
                    }
                    if (node.children.isNotEmpty()) {
                        // Overlay ("Te quedan" + value) anchored to the flat base of
                        // the gauge. No bottom nudge here on purpose: a prior
                        // proportional padding (~gaugeSize * 0.012f ≈ 2.5dp) pushed the
                        // text visibly above the design and was removed. The central
                        // label carries lineHeight from the contract, so it renders via
                        // LineHeightStyle(Trim.None, Center) (see RenderBlockTextRenderer):
                        // the line box is symmetric, so BottomCenter alignment keeps it
                        // centered across font sizes/system scales without a magic offset.
                        // If vertical drift ever shows up at extreme scales, reintroduce a
                        // small FIXED dp offset (not proportional), so it doesn't grow with
                        // the gauge.
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .width(gaugeSize * 0.56f),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            CompositionLocalProvider(LocalChartOverlayContent provides true) {
                                node.children.forEach { child ->
                                    RenderResolvedNode(
                                        node = child,
                                        renderContext = renderContext,
                                        parentOrientation = BlockOrientation.VERTICAL,
                                    )
                                }
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .width(gaugeSize)
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    val labelSlot = gaugeSize * 0.094f
                    Box(
                        modifier = Modifier.width(labelSlot),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "0%",
                            modifier = Modifier.wrapContentSize(unbounded = true),
                            color = labelColor,
                            fontSize = labelFontSize,
                            fontFamily = labelFontFamily,
                            fontWeight = labelFontWeight,
                            fontStyle = labelFontStyle,
                            lineHeight = labelLineHeight,
                        )
                    }
                    Box(
                        modifier = Modifier.width(labelSlot),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "100%",
                            modifier = Modifier.wrapContentSize(unbounded = true),
                            color = labelColor,
                            fontSize = labelFontSize,
                            fontFamily = labelFontFamily,
                            fontWeight = labelFontWeight,
                            fontStyle = labelFontStyle,
                            lineHeight = labelLineHeight,
                        )
                    }
                }
            }
          }
        } else {
            Box(
                modifier = Modifier.width(chartSize).height(chartSize),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(modifier = Modifier.fillMaxWidth().height(chartSize)) {
                    drawDonutChart(config.data, pointColors, revealProgressState.value)
                }
                if (node.children.isNotEmpty()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        node.children.forEach { child ->
                            RenderResolvedNode(
                                node = child,
                                renderContext = renderContext,
                                parentOrientation = BlockOrientation.VERTICAL,
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawSemiCircleGauge(
    points: List<ChartDataPoint>,
    revealProgress: Float,
    usedColor: Color,
    availableColor: Color,
) {
    val total = points.sumOf { it.value.toLong() }.coerceAtLeast(1L).toFloat()
    val segmentSpan = SEMI_CIRCLE_TOTAL_SWEEP / GAUGE_SEGMENT_COUNT
    val segmentCenterSpan = if (GAUGE_SEGMENT_COUNT > 1) {
        SEMI_CIRCLE_TOTAL_SWEEP / (GAUGE_SEGMENT_COUNT - 1)
    } else {
        0f
    }
    val segmentSweep = segmentSpan - SEMI_CIRCLE_GAP_ANGLE
    val segmentThickness = (size.width * 0.094f).coerceAtLeast(13f)
    val trackRadius = (size.width / 2f) - (segmentThickness / 2f)
    val availableSegmentCount = points.toGaugeSegmentCount(total)
    val usedSegmentCount = points.toUsedSegmentCount(total)

    for (segmentIndex in 0 until GAUGE_SEGMENT_COUNT) {
        // Fan opening: segments start bunched at 180° and spread to final positions as progress increases
        val centerAngle = SEMI_CIRCLE_START_ANGLE + (segmentIndex * segmentCenterSpan * revealProgress)
        val radians = (centerAngle * PI / 180f).toFloat()
        val center = Offset(
            x = size.width / 2f + (trackRadius * cos(radians)),
            y = size.height + (trackRadius * sin(radians)),
        )
        val segmentLength = trackRadius * (segmentSweep * PI.toFloat() / 180f) * revealProgress
        val color = if (segmentIndex < availableSegmentCount) {
            availableColor
        } else if (segmentIndex < availableSegmentCount + usedSegmentCount) {
            usedColor
        } else {
            Color.Transparent
        }

        if (color == Color.Transparent || segmentLength <= 0f) continue

        rotate(
            degrees = centerAngle - 90f,
            pivot = center,
        ) {
            drawRoundRect(
                color = color,
                topLeft = Offset(
                    x = center.x - (segmentLength / 2f),
                    y = center.y - (segmentThickness / 2f),
                ),
                size = Size(width = segmentLength, height = segmentThickness),
                cornerRadius = CornerRadius(1f, 1f),
            )
        }
    }
}

private fun List<ChartDataPoint>.toGaugeSegmentCount(total: Float): Int {
    val availableValue = firstOrNull { it.key.equals("available", ignoreCase = true) }?.value ?: 0
    return ((availableValue / total) * GAUGE_SEGMENT_COUNT)
        .roundToInt()
        .coerceIn(0, GAUGE_SEGMENT_COUNT)
}

private fun List<ChartDataPoint>.toUsedSegmentCount(total: Float): Int {
    val usedValue = firstOrNull { it.key.equals("used", ignoreCase = true) }?.value ?: 0
    return ((usedValue / total) * GAUGE_SEGMENT_COUNT)
        .roundToInt()
        .coerceIn(0, GAUGE_SEGMENT_COUNT)
}

private fun DrawScope.drawDonutChart(
    points: List<ChartDataPoint>,
    pointColors: List<Color>,
    revealProgress: Float,
) {
    val total = points.sumOf { it.value.toLong() }.coerceAtLeast(1L).toFloat()
    val stroke = size.minDimension * 0.14f
    val topLeft = Offset(stroke / 2f, stroke / 2f)
    val arcSize = Size(size.width - stroke, size.height - stroke)

    val totalSweep = 360f * revealProgress
    var start = -90f
    var drawn = 0f
    for ((idx, point) in points.withIndex()) {
        if (drawn >= totalSweep) break
        val fullSweep = (point.value / total) * 360f
        val sweep = (totalSweep - drawn).coerceAtMost(fullSweep)
        drawArc(
            color = pointColors.getOrNull(idx) ?: Color(0xFFE5E7EB),
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Butt),
        )
        start += fullSweep
        drawn += fullSweep
    }
}

private fun String?.toComposeFontStyleOrNull(): FontStyle? = when (this?.lowercase()) {
    "italic", "oblique" -> FontStyle.Italic
    "normal" -> FontStyle.Normal
    else -> null
}
