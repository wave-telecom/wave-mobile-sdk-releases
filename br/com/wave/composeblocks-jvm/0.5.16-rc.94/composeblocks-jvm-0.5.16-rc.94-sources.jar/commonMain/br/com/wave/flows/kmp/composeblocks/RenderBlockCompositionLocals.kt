package br.com.wave.flows.kmp.composeblocks

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.Color

internal data class RadioGroupStyleOverride(
    val active: Boolean = false,
    val colorOverride: Color? = null,
    val backgroundColorOverride: Color? = null,
    val inGroup: Boolean = false,
    val fontScaleOverride: Float = 1f,
)

internal val LocalRadioGroupStyleOverride = compositionLocalOf { RadioGroupStyleOverride() }
internal val LocalContentColorOverride = compositionLocalOf<Color?> { null }

/**
 * Ids of the components/flows currently being embedded by ancestor `sub-component`
 * blocks. A `sub-component` whose target is already in this stack renders its
 * placeholder children instead of fetching again — a guard against embed cycles.
 */
internal val LocalSubComponentStack = compositionLocalOf<List<String>> { emptyList() }

/**
 * Carries the `variants.disabled` palette for a card that is currently in its
 * disabled cooldown (a `refresh`-action card locks itself for [REFRESH_DISABLE_MILLIS]
 * after being tapped). When [active], the card paints [backgroundColorHex] and forces
 * [contentColorHex] onto its text/icon children, overriding the base style.
 */
internal data class DisabledVariantOverride(
    val active: Boolean = false,
    val contentColorHex: String? = null,
    val backgroundColorHex: String? = null,
)

internal val LocalDisabledVariant = compositionLocalOf { DisabledVariantOverride() }

/** Cooldown a `refresh`-action card stays disabled for after being tapped. */
internal const val REFRESH_DISABLE_MILLIS = 30_000L
internal val LocalCompactHorizontalItem = compositionLocalOf { false }
internal val LocalChartOverlayContent = compositionLocalOf { false }
internal val LocalRenderRouteStateKey = compositionLocalOf { "" }

/**
 * Maps each tab content block id to its page index within its tab group. Built
 * once per screen (from every `tabs` block's options) and used by the content
 * container to animate tab switches with a directional slide.
 */
internal val LocalTabContentOrder = compositionLocalOf<Map<String, Int>> { emptyMap() }

/**
 * Bridges a `tabs` block to its content container, which is rendered as a
 * *sibling* (not a child) of the tabs block in the contract. The tabs renderer
 * registers a swipe handler keyed by each tab's `contentReferenceId`; the
 * content container looks it up and calls it with `+1` (next) or `-1`
 * (previous) when the user swipes horizontally over the content — including
 * over the chart, since the chart's `Canvas` does not consume pointer events.
 *
 * Screen-scoped (provided once at the root), so siblings can share it.
 */
internal class TabSwipeRegistry {
    // Snapshot-backed so a content container that reads `handlerFor` during
    // composition recomposes the moment a tab registers its handler — without
    // this, the very first swipe could see a stale/null handler (the tabs
    // block registers in an effect that runs *after* the sibling list has
    // already composed). Registration must be one-shot (DisposableEffect),
    // never per-recomposition, or the state write would loop.
    private val handlers = mutableStateMapOf<String, (Int) -> Unit>()

    fun register(contentReferenceId: String, onSwipe: (Int) -> Unit) {
        handlers[contentReferenceId] = onSwipe
    }

    fun unregister(contentReferenceId: String) {
        handlers.remove(contentReferenceId)
    }

    fun handlerFor(contentReferenceId: String): ((Int) -> Unit)? = handlers[contentReferenceId]
}

internal val LocalTabSwipeRegistry = compositionLocalOf<TabSwipeRegistry?> { null }
