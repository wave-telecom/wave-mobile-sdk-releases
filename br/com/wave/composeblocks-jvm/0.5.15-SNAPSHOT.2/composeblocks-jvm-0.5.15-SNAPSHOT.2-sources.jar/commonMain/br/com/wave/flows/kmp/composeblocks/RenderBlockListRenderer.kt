package br.com.wave.flows.kmp.composeblocks

import kotlin.math.abs
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderListNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as ListBlockConfig
    val compactHorizontalItem = LocalCompactHorizontalItem.current
    val chartOverlayContent = LocalChartOverlayContent.current
    if (config.orientation == BlockOrientation.VERTICAL) {
        val tabOrder = LocalTabContentOrder.current
        val tabContentChild = node.children.firstOrNull { it.block.id in tabOrder }
        // When this list hosts a tab's content, let a horizontal swipe anywhere
        // over it (including the chart) switch tabs. The handler is registered
        // by the sibling `tabs` block via the screen-scoped swipe registry.
        val swipeHandler = tabContentChild?.let { LocalTabSwipeRegistry.current?.handlerFor(it.block.id) }
        val swipeModifier = if (swipeHandler != null) Modifier.tabSwipeGesture(swipeHandler) else Modifier
        CompositionLocalProvider(LocalCompactHorizontalItem provides false) {
            Column(
                modifier = modifier
                    .then(
                        if (shouldFillWidth(config.style, parentOrientation) && !compactHorizontalItem) {
                            Modifier.fillMaxWidth()
                        } else {
                            Modifier
                        },
                    )
                    // `expand` lists fill the parent's height (a no-op when the
                    // parent is wrap-content), giving space-* arrangements room to
                    // distribute — e.g. pinning a card's button to the bottom.
                    // Skip it inside a horizontal row: there `expand` means "share
                    // the width", and forcing fillMaxHeight on every column makes
                    // the row collapse vertically (no child supplies an intrinsic
                    // height), which drops table rows entirely.
                    .then(
                        if (config.expand && parentOrientation != BlockOrientation.HORIZONTAL) {
                            Modifier.fillMaxHeight()
                        } else {
                            Modifier
                        },
                    )
                    .applyBlockStyle(config.style)
                    .padding(
                        if (compactHorizontalItem) {
                            config.style.toVerticalPaddingValues()
                        } else {
                            config.style.toPaddingValues()
                        },
                    )
                    .then(swipeModifier),
                verticalArrangement = config.verticalAlign.toVerticalArrangement(config.spacing),
                horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
            ) {
                if (tabContentChild != null) {
                    // This list hosts a tab's content: animate a tab switch with a
                    // directional horizontal slide — right→left when moving to a
                    // later tab, left→right when going back to an earlier one.
                    AnimatedContent(
                        targetState = tabContentChild,
                        transitionSpec = {
                            val from = tabOrder[initialState.block.id] ?: 0
                            val to = tabOrder[targetState.block.id] ?: 0
                            if (to >= from) {
                                (slideInHorizontally { w -> w } + fadeIn()) togetherWith
                                    (slideOutHorizontally { w -> -w } + fadeOut())
                            } else {
                                (slideInHorizontally { w -> -w } + fadeIn()) togetherWith
                                    (slideOutHorizontally { w -> w } + fadeOut())
                            }
                        },
                        label = "tabContent",
                    ) { child ->
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.VERTICAL,
                        )
                    }
                } else {
                    node.children.forEach { child ->
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.VERTICAL,
                        )
                    }
                }
            }
        }
    } else {
        val centerUnalignedChartOverlayRow = chartOverlayContent && config.horizontalAlign == null
        val expandLastItem = node.children.lastOrNull()?.containsDivider() == true
        val expandIndexes = node.children.mapIndexedNotNull { index, child ->
            val childConfig = child.block.config
            if (childConfig is ListBlockConfig && childConfig.expand) index else null
        }.toSet()
        AdaptiveHorizontalListLayout(
            modifier = modifier
                .then(
                    if (shouldFillWidth(config.style, parentOrientation) && !centerUnalignedChartOverlayRow) {
                        Modifier.fillMaxWidth()
                    } else {
                        Modifier
                    },
                )
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            spacing = config.spacing,
            horizontalAlign = if (centerUnalignedChartOverlayRow) "center" else config.horizontalAlign,
            verticalAlign = config.verticalAlign,
            expandIndexes = expandIndexes,
            expandLastItem = expandLastItem,
        ) {
            node.children.forEach { child ->
                CompositionLocalProvider(LocalCompactHorizontalItem provides true) {
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                    )
                }
            }
        }
    }
}

private fun ResolvedRenderNode.containsDivider(): Boolean {
    return block.type == BlockType.DIVIDER || children.any { it.containsDivider() }
}

/**
 * Detects a horizontal swipe over a tab's content and commits a tab change on
 * release: drag left → next tab (`+1`), drag right → previous (`-1`). Only
 * horizontal-dominant drags are consumed, so the vertical scroll of the screen
 * keeps working. The threshold avoids accidental switches on small drags.
 */
private fun Modifier.tabSwipeGesture(onSwipe: (Int) -> Unit): Modifier =
    this.pointerInput(onSwipe) {
        val thresholdPx = 56.dp.toPx()
        var totalDrag = 0f
        detectHorizontalDragGestures(
            onDragStart = { totalDrag = 0f },
            onDragEnd = {
                when {
                    totalDrag <= -thresholdPx -> onSwipe(1)
                    totalDrag >= thresholdPx -> onSwipe(-1)
                }
            },
        ) { change, dragAmount ->
            totalDrag += dragAmount
            // Only claim the drag once it's a deliberate tab swipe (past the
            // threshold). Before that, leave it unconsumed so a horizontally
            // scrollable child inside the tab content (e.g. a carousel) still
            // receives it instead of being starved.
            if (abs(totalDrag) >= thresholdPx) change.consume()
        }
    }
