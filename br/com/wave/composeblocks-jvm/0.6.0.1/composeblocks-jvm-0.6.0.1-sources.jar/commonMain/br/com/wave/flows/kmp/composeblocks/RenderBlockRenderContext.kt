package br.com.wave.flows.kmp.composeblocks

import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.core.analytics.buildStatisticItemPayload
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.runtime.InternalSdkEffect
import br.com.wave.flows.kmp.core.runtime.dispatchBlockAction
import br.com.wave.flows.kmp.core.visibility.VisibilityState
import br.com.wave.flows.kmp.runtime.MonotonicRuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.SystemRuntimeClock

internal data class RenderBlockRenderContext(
    val hostEventHandler: HostEventHandler,
    val currentVisibility: () -> VisibilityState,
    val onVisibilityChange: (VisibilityState) -> Unit,
    // Wall-clock: used for the action-tracking timestamp (epoch). Keep it wall.
    val clock: RuntimeClock = SystemRuntimeClock,
    // Monotonic: drives the refresh cooldown window so a device clock change can't
    // shorten/extend/break it. Injectable so tests can advance it deterministically.
    val cooldownClock: RuntimeClock = MonotonicRuntimeClock,
    // Source used by `sub-component` blocks to fetch the embedded component/flow's
    // tree. Null when the screen was rendered without a provider (e.g. a static
    // contract passed straight to RenderBlockScreen) — sub-components then just
    // render their placeholder children.
    val contractProvider: ScreenContractProvider? = null,
    val externalCode: String? = null,
    // Resolved root of the screen being dispatched from — the only source with
    // enough tree shape (parent/index) to derive StatisticItem position/ubication.
    // Null only if a caller reconstructs this context without a rendered tree.
    val rootNode: ResolvedRenderNode? = null,
)

internal fun RenderBlockRenderContext.dispatchNodeAction(node: ResolvedRenderNode) {
    val action = node.block.action ?: return
    val payload = rootNode?.let { buildStatisticItemPayload(it, node) } ?: mapOf("blockId" to node.block.id)
    val result = dispatchBlockAction(
        action = action,
        blockId = node.block.id,
        visibility = currentVisibility(),
        timestamp = clock.nowMillis().toString(),
        payload = payload,
    )

    result.hostEvents.forEach(hostEventHandler::onHostEvent)
    onVisibilityChange(result.visibility)
    result.internalEffects.forEach { effect ->
        when (effect) {
            InternalSdkEffect.ToggleThemeMode -> FlowThemeStore.toggle()
        }
    }
}
