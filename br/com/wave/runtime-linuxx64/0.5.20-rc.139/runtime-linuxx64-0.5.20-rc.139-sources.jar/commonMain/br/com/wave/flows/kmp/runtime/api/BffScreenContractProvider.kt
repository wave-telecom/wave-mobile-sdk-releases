package br.com.wave.flows.kmp.runtime.api

import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.runtime.DefaultRuntimeDispatchers
import br.com.wave.flows.kmp.runtime.NoOpRuntimeLogger
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeContractAnomalyReporter
import br.com.wave.flows.kmp.runtime.RuntimeDispatchers
import br.com.wave.flows.kmp.runtime.RuntimeLogger
import br.com.wave.flows.kmp.runtime.SystemRuntimeClock
import br.com.wave.flows.kmp.runtime.api.sources.BffNetworkSource
import br.com.wave.flows.kmp.runtime.api.sources.ContractMode
import br.com.wave.flows.kmp.runtime.api.sources.ContractQuery
import br.com.wave.flows.kmp.runtime.api.sources.ContractSource
import br.com.wave.flows.kmp.runtime.api.sources.DiskWarmupSource
import br.com.wave.flows.kmp.runtime.api.sources.InMemoryRamSource
import br.com.wave.flows.kmp.runtime.api.sources.LiveBlockIndex
import br.com.wave.flows.kmp.runtime.api.sources.LiveBlockIndexSource
import br.com.wave.flows.kmp.runtime.warmup.WarmupCacheKey
import br.com.wave.flows.kmp.runtime.warmup.WarmupDiskCacheStore
import kotlinx.coroutines.withContext

class BffScreenContractProvider(
    baseUrl: String,
    private val externalCode: String,
    private val diskCache: WarmupDiskCacheStore? = null,
    api: BffApi,
    private val dispatchers: RuntimeDispatchers = DefaultRuntimeDispatchers,
    clock: RuntimeClock = SystemRuntimeClock,
    private val logger: RuntimeLogger = NoOpRuntimeLogger,
) : ScreenContractProvider {

    private val normalizedBaseUrl = baseUrl.trimEnd('/')
    private val reporter = RuntimeContractAnomalyReporter(logger)

    private val liveBlockSource: ContractSource = LiveBlockIndexSource()
    private val ramSource: ContractSource = InMemoryRamSource()

    private val diskSource: ContractSource? = diskCache?.let { store ->
        DiskWarmupSource(
            store = store,
            reporter = reporter,
            logger = logger,
            onHit = ::onContractMaterialized,
        )
    }

    private val networkSource: ContractSource = BffNetworkSource(
        api = api,
        reporter = reporter,
        logger = logger,
        clock = clock,
        onSuccess = ::onContractMaterialized,
    )

    /**
     * Ordered list of sources, fastest first.
     *
     * `LiveBlockIndex` sits at the top so requests for in-tree sub-blocks
     * (e.g. a `bottom-sheet` that is already part of an in-memory
     * contract) resolve without going through RAM/disk/network — the BFF
     * does not expose those ids as standalone endpoints. Each source is
     * independent; new ones can be inserted without modifying peers.
     */
    private val fullChain: List<ContractSource> =
        listOfNotNull(liveBlockSource, ramSource, diskSource, networkSource)

    /** Cache-only chain — used by callers that must not hit the network. */
    private val cacheOnlyChain: List<ContractSource> =
        listOfNotNull(liveBlockSource, ramSource, diskSource)

    /**
     * Network-only chain for the pull-to-refresh fetch. It deliberately
     * excludes `liveBlockSource`/`ramSource`/`diskSource` so a refresh
     * ALWAYS hits the BFF instead of being short-circuited by the stale
     * full synthetic the `LiveBlockIndex` keeps at the top of [fullChain].
     * A successful fetch re-warms RAM + `LiveBlockIndex` through
     * [onContractMaterialized], so ordinary caching is restored on success.
     */
    private val networkOnlyChain: List<ContractSource> = listOfNotNull(networkSource)

    /**
     * Skeleton-only cache chain — RAM + disk, `liveBlockSource` excluded.
     * The index answers FULL for an already-materialised component, so it
     * would mask the skeleton; this chain queries [ContractMode.SKELETON]
     * directly to surface the warmup skeleton as the refresh interim value.
     */
    private val skeletonCacheChain: List<ContractSource> = listOfNotNull(ramSource, diskSource)

    override suspend fun getScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract {
        val query = buildQuery(componentId, externalCode, ContractMode.FULL)
        return withContext(dispatchers.io) {
            fullChain.firstNotNullOfOrNull { it.tryGet(query) }
                ?: error("No source could resolve componentId=${query.componentId} externalCode=${query.externalCode}")
        }
    }

    override suspend fun getCachedScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? {
        return withContext(dispatchers.io) {
            resolveFromChain(cacheOnlyChain, componentId, externalCode) { src, q -> src.tryGet(q) }
        }
    }

    /**
     * Force-fetches the FULL contract from the BFF, bypassing every cache
     * layer (RAM, disk, and the `LiveBlockIndex`). Used by the native
     * pull-to-refresh path, which must guarantee a fresh network fetch even
     * when the component is still warm. A successful fetch re-warms RAM +
     * `LiveBlockIndex` via [onContractMaterialized], so a later non-refresh
     * mount serves the fresh contract from cache. Errors the same way as
     * [getScreenContract] when the BFF declines, so a refresh against a dead
     * BFF surfaces a failure instead of silently serving stale content.
     */
    suspend fun getFreshScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract {
        val query = buildQuery(componentId, externalCode, ContractMode.FULL)
        return withContext(dispatchers.io) {
            networkOnlyChain.firstNotNullOfOrNull { it.tryGet(query) }
                ?: error("No source could resolve componentId=${query.componentId} externalCode=${query.externalCode}")
        }
    }

    /**
     * Resolves the SKELETON variant from the cache only ([skeletonCacheChain]:
     * RAM + disk, `LiveBlockIndex` excluded), returning `null` when no skeleton
     * was warmup-seeded. Used as the pull-to-refresh interim value so the route
     * shows the skeleton while the fresh fetch is in flight, never the stale
     * full synthetic the index would otherwise return.
     */
    suspend fun getCachedSkeletonContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? {
        val query = buildQuery(componentId, externalCode, ContractMode.SKELETON)
        return withContext(dispatchers.io) {
            skeletonCacheChain.firstNotNullOfOrNull { it.tryGet(query) }
        }
    }

    override fun peekCachedScreenContract(
        componentId: String,
        externalCode: String?,
    ): ScreenContract? = resolveFromChain(cacheOnlyChain, componentId, externalCode) { src, q -> src.trySync(q) }

    /**
     * Walk the chain trying [ContractMode.FULL] first, then falling back to
     * [ContractMode.SKELETON]. Each step is opaque to the caller — sources
     * choose whether they can answer.
     */
    private inline fun resolveFromChain(
        chain: List<ContractSource>,
        componentId: String,
        externalCode: String?,
        lookup: (ContractSource, ContractQuery) -> ScreenContract?,
    ): ScreenContract? {
        val full = buildQuery(componentId, externalCode, ContractMode.FULL)
        chain.firstNotNullOfOrNull { lookup(it, full) }?.let { return it }
        val skeleton = buildQuery(componentId, externalCode, ContractMode.SKELETON)
        return chain.firstNotNullOfOrNull { lookup(it, skeleton) }
    }

    private fun buildQuery(
        componentId: String,
        externalCode: String?,
        mode: ContractMode,
    ): ContractQuery = ContractQuery(
        baseUrl = normalizedBaseUrl,
        externalCode = externalCode ?: this.externalCode,
        componentId = componentId,
        mode = mode,
    )

    /**
     * Called whenever a downstream source materialises a contract. Updates
     * the RAM contract cache *and* indexes every block in the tree so the
     * top-of-chain `LiveBlockIndex` can answer subsequent sub-block
     * lookups without round-tripping the BFF.
     */
    private fun onContractMaterialized(query: ContractQuery, contract: ScreenContract) {
        BffScreenContractCache.put(
            baseUrl = query.baseUrl,
            externalCode = query.externalCode,
            componentId = query.componentId,
            contract = contract,
            mode = query.mode.wireValue,
        )
        LiveBlockIndex.register(query, contract)
    }

    fun clearCache() {
        BffScreenContractCache.clearSession(
            baseUrl = normalizedBaseUrl,
            externalCode = externalCode,
        )
        LiveBlockIndex.clearSession(
            baseUrl = normalizedBaseUrl,
            externalCode = externalCode,
        )
    }

    /**
     * Drops the cached contract for [componentId] in [mode] so the next
     * lookup goes through the chain again — typically reaching the BFF.
     * The companion `skeleton` (or `full`) entry for the same component
     * is preserved, so a host that re-mounts the `RenderBlock` right
     * after calling this still sees the cached fallback while the fresh
     * fetch is in flight.
     *
     * Defaults to `ContractMode.FULL` because that is the entry the BFF's
     * `render_block_refresh` callback is asking the host to re-fetch.
     */
    fun invalidate(
        componentId: String,
        mode: String = ContractMode.FULL.wireValue,
        externalCode: String? = null,
    ) {
        val resolvedExternalCode = externalCode ?: this.externalCode
        BffScreenContractCache.remove(
            baseUrl = normalizedBaseUrl,
            externalCode = resolvedExternalCode,
            componentId = componentId,
            mode = mode,
        )
        // The warmup disk layer stores a contract under both "flow" and "component" entry
        // types; evict both so the post-invalidate re-fetch can't be served a stale disk entry.
        diskCache?.let { store ->
            for (entryType in listOf("flow", "component")) {
                store.remove(
                    WarmupCacheKey(
                        baseUrl = normalizedBaseUrl,
                        externalCode = resolvedExternalCode,
                        entryType = entryType,
                        slug = componentId,
                        mode = mode,
                    ),
                )
            }
        }
    }
}
