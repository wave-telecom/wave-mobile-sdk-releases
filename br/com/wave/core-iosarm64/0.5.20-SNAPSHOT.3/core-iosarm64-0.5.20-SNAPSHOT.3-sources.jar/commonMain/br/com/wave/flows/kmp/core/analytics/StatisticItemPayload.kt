package br.com.wave.flows.kmp.core.analytics

import br.com.wave.flows.kmp.core.contract.AccordionBlockConfig
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.contract.ToolbarBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

/**
 * Payload keys mirroring the client's Adobe Analytics `StatisticItem` vocabulary
 * (name/type/position/ubication/category/subcategory), so the host can fill its
 * model 1:1 without the SDK depending on any analytics vendor type.
 */
object StatisticPayloadKeys {
    const val BLOCK_ID = "blockId"
    const val NAME = "name"
    const val TYPE = "type"
    const val POSITION = "position"
    const val UBICATION = "ubication"
    const val CATEGORY = "category"
    const val SUBCATEGORY = "subcategory"
}

// Doc-stated fold set only: accented Latin vowels + ñ/Ñ, plus comma removal.
// commonMain has no java.text.Normalizer, so this is a literal lookup instead.
private val ACCENT_FOLD_MAP = mapOf(
    'á' to 'a', 'é' to 'e', 'í' to 'i', 'ó' to 'o', 'ú' to 'u',
    'Á' to 'A', 'É' to 'E', 'Í' to 'I', 'Ó' to 'O', 'Ú' to 'U',
    'ñ' to 'n', 'Ñ' to 'N',
)

fun sanitizeStatisticName(raw: String): String =
    raw
        .map { ACCENT_FOLD_MAP[it] ?: it }
        .joinToString("")
        .replace(",", "")
        .trim()

fun mapComponentType(type: BlockType): String = when (type) {
    BlockType.CAROUSEL -> "Carrusel"
    BlockType.LIST -> "Lista"
    BlockType.GRID -> "Mosaico"
    else -> "Único"
}

fun deriveComponentName(block: BlockNode): String {
    val ownName = when (val config = block.config) {
        is TextBlockConfig -> config.value
        is ButtonBlockConfig -> config.value
        is ToolbarBlockConfig -> config.title
        is AccordionBlockConfig -> config.title ?: ""
        is RichTextBlockConfig -> config.segments.joinToString(" ") { it.text }
        else -> ""
    }
    if (ownName.isNotBlank()) return ownName

    for (child in block.children) {
        val childName = deriveComponentName(child)
        if (childName.isNotBlank()) return childName
    }
    return ""
}

fun ubicationFor(topLevelIndex: Int, topLevelCount: Int): String = when {
    topLevelCount <= 1 || topLevelIndex == 0 -> "Principal"
    topLevelIndex == topLevelCount - 1 -> "Inferior"
    else -> "Medio"
}

internal data class StatisticLocation(
    val positionInParent: Int,
    val topLevelIndex: Int,
    val topLevelCount: Int,
    val parentType: BlockType? = null,
)

internal fun locateStatistic(root: ResolvedRenderNode, targetId: String): StatisticLocation? {
    val topLevelCount = root.children.size

    fun findWithin(
        node: ResolvedRenderNode,
        targetId: String,
        parentType: BlockType?,
    ): StatisticLocation? {
        node.children.forEachIndexed { index, child ->
            if (child.block.id == targetId) {
                return StatisticLocation(
                    positionInParent = index + 1,
                    topLevelIndex = -1,
                    topLevelCount = topLevelCount,
                    parentType = parentType,
                )
            }
            findWithin(child, targetId, node.block.type)?.let { return it }
        }
        return null
    }

    root.children.forEachIndexed { topLevelIndex, topLevelChild ->
        if (topLevelChild.block.id == targetId) {
            return StatisticLocation(
                positionInParent = topLevelIndex + 1,
                topLevelIndex = topLevelIndex,
                topLevelCount = topLevelCount,
                parentType = root.block.type,
            )
        }
        val found = findWithin(topLevelChild, targetId, topLevelChild.block.type)
        if (found != null) {
            return found.copy(topLevelIndex = topLevelIndex)
        }
    }
    return null
}

fun buildStatisticItemPayload(root: ResolvedRenderNode, target: ResolvedRenderNode): Map<String, String> {
    val location = locateStatistic(root, target.block.id)
    val type = location?.parentType?.let(::mapComponentType) ?: mapComponentType(target.block.type)
    return mapOf(
        StatisticPayloadKeys.BLOCK_ID to target.block.id,
        StatisticPayloadKeys.NAME to sanitizeStatisticName(deriveComponentName(target.block)),
        StatisticPayloadKeys.TYPE to type,
        StatisticPayloadKeys.POSITION to (location?.positionInParent?.toString() ?: "1"),
        StatisticPayloadKeys.UBICATION to (
            location?.let { ubicationFor(it.topLevelIndex, it.topLevelCount) } ?: "Principal"
            ),
        StatisticPayloadKeys.CATEGORY to "N/A",
        StatisticPayloadKeys.SUBCATEGORY to "N/A",
    )
}
