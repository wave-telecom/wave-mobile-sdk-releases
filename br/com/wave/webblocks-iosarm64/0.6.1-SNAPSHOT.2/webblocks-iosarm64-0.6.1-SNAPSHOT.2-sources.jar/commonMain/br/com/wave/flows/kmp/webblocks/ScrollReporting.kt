package br.com.wave.flows.kmp.webblocks

import br.com.wave.flows.kmp.core.ScrollInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.transform

/**
 * Default interval between scroll-callback emissions, in milliseconds. Mirrors
 * `:composeblocks`' `RenderBlockScreen.kt` constant of the same name and value — the
 * single source of truth for every facade exposing a `scrollThrottleMs` parameter is
 * duplicated here (not depended on) because `:webblocks` does not depend on
 * `:composeblocks`; see the module's technical-debt watchlist for the future `core`/
 * `runtime` hoist. Pass `0` to disable throttling and receive raw per-frame emissions.
 */
const val DEFAULT_SCROLL_THROTTLE_MS: Long = 200L

/**
 * Builds the [ScrollInfo] payload for one scroll frame reported by the WebView harness.
 * Direction is derived by comparing the current offset against the previous frame's —
 * identical rule to `:composeblocks`' `scrollInfoFor`. A WebView has no LazyColumn item
 * index, so [firstVisibleItemIndex] is always `0`; direction is decided from [offset]/
 * [lastOffset] alone (the `index`/`lastIndex` parameters are kept for signature parity
 * with the composeblocks family and are always `0` from this module's only call site).
 */
fun scrollInfoFor(
    offset: Int,
    index: Int,
    lastOffset: Int,
    lastIndex: Int,
): ScrollInfo =
    ScrollInfo(
        offsetPx = offset,
        firstVisibleItemIndex = index,
        isScrollingDown = index > lastIndex || (index == lastIndex && offset > lastOffset),
    )

/**
 * Rate-limits scroll position emissions to the host. `intervalMs <= 0` disables
 * throttling (raw per-frame emission). Otherwise the first position is emitted
 * immediately (leading edge) and at most one emission follows per window; while a
 * window is open, [kotlinx.coroutines.flow.conflate] keeps only the latest position, so
 * the resting value is always delivered within one interval and no work happens while
 * the WebView is idle. Identical semantics to `:composeblocks`' `throttleScrollPositions`.
 */
fun Flow<Pair<Int, Int>>.throttleScrollPositions(
    intervalMs: Long,
): Flow<Pair<Int, Int>> =
    if (intervalMs > 0L) {
        conflate().transform { position ->
            emit(position)
            delay(intervalMs)
        }
    } else {
        this
    }
