package br.com.wave.flows.kmp.webblocks

import kotlinx.serialization.json.JsonObject

/**
 * Builds the exact `window.waveRenderHost.render(...)` call to hand to
 * `WebViewNavigator.evaluateJavaScript`. The real harness's `render(a)` does `JSON.parse(a)`
 * internally, so [payloadJson] must arrive as a JSON **string** argument, never a bare object
 * literal — [payloadJson] is re-encoded as a properly escaped JS string literal so `a` is what
 * `render` actually expects.
 */
internal fun buildRenderInvocation(payloadJson: String): String =
    "window.waveRenderHost.render(${payloadJson.toJsStringLiteral()})"

/** [buildRenderInvocation] overload for callers holding the parsed envelope, not its text. */
internal fun buildRenderInvocation(payload: JsonObject): String = buildRenderInvocation(payload.toString())

/**
 * Builds the `window.waveRenderHost.resolveSubComponent(id, blockJson)` call answering a
 * `fetchSubComponent` request. [id] correlates the response to the request the harness made;
 * [blockJson] is the raw sub-tree JSON `handleFetchSubComponent` resolved, stringified. The
 * harness `JSON.parse`s its second argument (same contract as `render`), so both arguments are
 * escaped as JS string literals via the SAME escaper [buildRenderInvocation] uses — one escaping
 * path, not two.
 */
internal fun buildSubComponentResolution(id: String, blockJson: String): String =
    "window.waveRenderHost.resolveSubComponent(${id.toJsStringLiteral()}, ${blockJson.toJsStringLiteral()})"

/**
 * Escapes [this] into a JS double-quoted string literal. Order matters: backslash first, so
 * escaping the quote/line-separator characters afterward doesn't double-escape the backslash
 * that operation itself introduces. `U+2028`/`U+2029` (LINE/PARAGRAPH SEPARATOR) are escaped
 * because some JS engines still treat them as statement terminators even inside a string
 * literal, which would truncate the call mid-argument.
 */
private fun String.toJsStringLiteral(): String {
    val escaped = this
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    return "\"$escaped\""
}
