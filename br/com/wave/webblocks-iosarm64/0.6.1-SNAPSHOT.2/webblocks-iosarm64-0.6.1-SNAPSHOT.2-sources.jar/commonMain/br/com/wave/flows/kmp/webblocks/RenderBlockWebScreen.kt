package br.com.wave.flows.kmp.webblocks

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.ScrollInfo
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.theme.ThemeId
import com.multiplatform.webview.jsbridge.IJsMessageHandler
import com.multiplatform.webview.jsbridge.JsMessage
import com.multiplatform.webview.jsbridge.rememberWebViewJsBridge
import com.multiplatform.webview.web.WebView
import com.multiplatform.webview.web.WebViewNavigator
import com.multiplatform.webview.web.rememberWebViewNavigator
import com.multiplatform.webview.web.rememberWebViewState
import com.multiplatform.webview.setting.WebSettings
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.putJsonObject
import kotlin.math.roundToInt
import kotlin.time.Clock

/** Envelope version pushed to `window.waveRenderHost.render`. */
private const val PUSH_ENVELOPE_VERSION = 2

/**
 * The `render` push envelope for [contractJson]/[themeMode]/[refreshInFlight]. Extracted as a
 * pure function so the additive `refreshing` field is asserted without a Compose/WebView
 * harness — `v`/`data`/`theme` stay untouched, older pages ignore the unknown key.
 */
internal fun buildPushRenderEnvelope(
    contractJson: JsonElement,
    themeMode: ThemeId,
    refreshInFlight: Boolean,
) = buildJsonObject {
    put("v", JsonPrimitive(PUSH_ENVELOPE_VERSION))
    put("data", contractJson)
    putJsonObject("theme") { put("mode", JsonPrimitive(themeMode.value)) }
    put("refreshing", JsonPrimitive(refreshInFlight))
}

/**
 * Resolves the raw BFF envelope for a `fetchSubComponent` target — ALWAYS a round trip through
 * this provider, never a slice of the already-rendered tree. Returns the whole envelope
 * (`{id, blocks, meta, …}`); [handleFetchSubComponent] unwraps `.blocks` before answering the
 * harness. `null` when no provider is installed or the id can't be answered — the request stays
 * unresolved, matching native's own "no provider" behavior.
 */
fun interface RawSubComponentProvider {
    suspend fun getRawSubComponent(componentId: String, externalCode: String?): String?
}

private const val METHOD_READY = "ready"
private const val METHOD_RENDERED = "rendered"
private const val METHOD_HEIGHT = "height"
private const val METHOD_EVENT = "event"
private const val METHOD_SCROLL = "scroll"
private const val METHOD_FETCH_SUB_COMPONENT = "fetchSubComponent"
private const val READY_TIMEOUT_MS = 8_000L
// Bounds the `ready` -> `rendered` window so a silent stall — no exception, just nothing ever
// resolving — surfaces a visible error instead of an indefinite loading overlay.
private const val RENDERED_TIMEOUT_MS = 10_000L

/**
 * Mirrors the legacy flow-wrapper-kmp host's `WebSettings.applyFlowWrapperDefaults`
 * so both engines render the same content under the same effective viewport/zoom behavior.
 * Duplicated rather than shared because webblocks must not depend on flow-wrapper-kmp.
 */
internal fun WebSettings.applyRenderBlockWebDefaults() {
    androidWebSettings.domStorageEnabled = true
    supportZoom = false
}

private sealed interface Phase {
    data object Booting : Phase
    data object AwaitingRender : Phase
    data object Rendered : Phase
    data class Failed(val code: String, val diagnostic: String) : Phase
}

/**
 * Renders [contractJson] — the raw BFF envelope, pushed byte-for-byte — through the web
 * render-block SDK running inside a WebView loaded from [url]. The module owns no adapter and no
 * typed contract: it is a dumb transport between whatever supplies raw BFF JSON and the two JS
 * interfaces on the injection path — `window.waveRenderHost.render`/`resolveSubComponent`
 * (native -> web push, this file) and the `kmpJsBridge` callback chain (web -> native,
 * `ready`/`rendered`/`height`/`event`/`scroll`/`fetchSubComponent`, handled below). Shape-
 * compatible with the native renderer family: [loading] overlays the WebView until the page
 * reports `rendered`, and again whenever [refreshInFlight] is true; [error] replaces it on a
 * missing `ready` handshake or a fatal error, and
 * carries a [RenderBlockWebFailure] with a retry seam — its cause text is diagnostic only and
 * must never be rendered, because an integrator's end user is the most external audience there is.
 */
@Composable
fun RenderBlockWebScreen(
    // The remote render-only route URL. The module is URL-source-agnostic — where it comes from
    // is the caller's concern.
    url: String,
    contractJson: JsonElement,
    // True while the caller's own contract refetch is in flight (set even for a same-value
    // result). Drives both the skeleton cover below and the `refreshing` field pushed to the
    // page, so the page can disable its own refresh control and resolve pull-to-refresh.
    refreshInFlight: Boolean = false,
    hostEventHandler: HostEventHandler,
    themeMode: ThemeId = ThemeId.Light,
    onScroll: ((ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
    rawSubComponentProvider: RawSubComponentProvider? = null,
    externalCode: String? = null,
    loading: @Composable () -> Unit = {},
    error: @Composable (failure: RenderBlockWebFailure) -> Unit = { RenderBlockWebFallbackError(onRetry = it.retry) },
    modifier: Modifier = Modifier,
) {
    val currentHostEventHandler by rememberUpdatedState(hostEventHandler)
    // The jsBridge handlers below are registered once (DisposableEffect keyed on jsBridge
    // only) and captured in a closure that outlives any single recomposition — read the
    // payload through `rememberUpdatedState` so a re-composed value is honored on the NEXT
    // native->JS round trip instead of the stale one from registration time.
    val currentContractJson by rememberUpdatedState(contractJson)
    val currentRefreshInFlight by rememberUpdatedState(refreshInFlight)
    val currentRawSubComponentProvider by rememberUpdatedState(rawSubComponentProvider)
    val currentExternalCode by rememberUpdatedState(externalCode)
    val currentThemeMode by rememberUpdatedState(themeMode)
    val currentOnScroll by rememberUpdatedState(onScroll)

    var phase by remember { mutableStateOf<Phase>(Phase.Booting) }
    // Bumped by retry to force a fresh `rememberWebViewState`/`WebView` under `key(reloadTick)`
    // below — re-pushing the contract into a dead page is a no-op, the page itself must reload.
    var reloadTick by remember { mutableStateOf(0) }
    // A different url/block gets its own recovery episode.
    val recoveryBudget = remember(url) { WebViewRecoveryBudget(nowMs = { Clock.System.now().toEpochMilliseconds() }) }

    val currentDensity by rememberUpdatedState(LocalDensity.current.density)
    val navigator = rememberWebViewNavigator()
    val jsBridge = rememberWebViewJsBridge(navigator)
    val scope = rememberCoroutineScope()
    // Raw `offsetPx` pushed by the `scroll` bridge handler; throttled/collected below.
    val scrollOffsets = remember { MutableStateFlow(0) }

    fun pushRender() {
        val envelope = buildPushRenderEnvelope(currentContractJson, currentThemeMode, currentRefreshInFlight)
        navigator.evaluateJavaScript(buildRenderInvocation(envelope))
    }

    DisposableEffect(jsBridge) {
        val readyHandler = nativeMethodHandler(METHOD_READY) {
            phase = Phase.AwaitingRender
            pushRender()
        }
        val renderedHandler = nativeMethodHandler(METHOD_RENDERED) {
            phase = Phase.Rendered
        }
        // Registered for bridge-contract parity with the page even though the module no
        // longer sizes anything off of it.
        val heightHandler = nativeMethodHandler(METHOD_HEIGHT) {}
        val eventHandler = nativeMethodHandler(METHOD_EVENT) { params ->
            handleEvent(params, currentHostEventHandler) { failureMessage ->
                phase = Phase.Failed(RENDER_BLOCK_WEB_FAILURE_HARNESS_FATAL, failureMessage)
            }
        }
        val scrollHandler = nativeMethodHandler(METHOD_SCROLL) { params ->
            val offsetPx = runCatching { Json.parseToJsonElement(params).jsonObject["offsetPx"]?.jsonPrimitive?.int }
                .getOrNull()
            // The harness reports CSS px; convert to the physical-px unit `ScrollInfo.offsetPx`
            // carries from the native renderer (see `cssPxToPhysicalPx` kdoc).
            if (offsetPx != null) scrollOffsets.value = cssPxToPhysicalPx(offsetPx, currentDensity)
        }
        val fetchSubComponentHandler = nativeMethodHandler(METHOD_FETCH_SUB_COMPONENT) { params ->
            handleFetchSubComponent(
                rawParams = params,
                provider = currentRawSubComponentProvider,
                externalCode = currentExternalCode,
                navigator = navigator,
                scope = scope,
            )
        }

        jsBridge.register(readyHandler)
        jsBridge.register(renderedHandler)
        jsBridge.register(heightHandler)
        jsBridge.register(eventHandler)
        jsBridge.register(scrollHandler)
        jsBridge.register(fetchSubComponentHandler)

        onDispose {
            jsBridge.unregister(readyHandler)
            jsBridge.unregister(renderedHandler)
            jsBridge.unregister(heightHandler)
            jsBridge.unregister(eventHandler)
            jsBridge.unregister(scrollHandler)
            jsBridge.unregister(fetchSubComponentHandler)
        }
    }

    LaunchedEffect(scrollThrottleMs) {
        // A WebView has no LazyColumn item index, so `firstVisibleItemIndex` is always
        // `0` — direction is derived from `offsetPx` deltas alone (see `scrollInfoFor`).
        var lastOffset = 0
        scrollOffsets
            .transform { offset ->
                emit(offset)
                delay(scrollThrottleMs)
            }
            .collect { offset ->
                currentOnScroll?.invoke(
                    scrollInfoFor(offset = offset, index = 0, lastOffset = lastOffset, lastIndex = 0),
                )
                lastOffset = offset
            }
    }

    LaunchedEffect(url, reloadTick) {
        delay(READY_TIMEOUT_MS)
        if (phase == Phase.Booting) {
            phase = Phase.Failed(RENDER_BLOCK_WEB_FAILURE_NOT_READY, "webblocks harness did not signal ready in time")
        }
    }

    // Re-keyed on every `phase` change: entering AwaitingRender starts this bound; leaving it
    // (Rendered, or a Failed from elsewhere) cancels this coroutine before it can fire.
    LaunchedEffect(phase) {
        if (phase != Phase.AwaitingRender) return@LaunchedEffect
        delay(RENDERED_TIMEOUT_MS)
        if (phase == Phase.AwaitingRender) {
            phase = Phase.Failed(RENDER_BLOCK_WEB_FAILURE_NOT_RENDERED, "webblocks harness did not report rendered in time")
        }
    }

    // Reports once per failure transition (guarded on `is Phase.Failed`, keyed on `phase` itself)
    // rather than on every recomposition — the same channel the harness's own fatal already uses.
    LaunchedEffect(phase) {
        val failed = phase as? Phase.Failed ?: return@LaunchedEffect
        currentHostEventHandler.onHostEvent(
            HostEvent.Error(RenderBlockError(code = failed.code, message = failed.diagnostic)),
        )
    }

    // Deliberately does NOT reset `phase` back to `AwaitingRender` on a reload (a `contractJson`
    // param change while already `Rendered`): the WebView stays mounted across `pushRender`, so
    // resetting `phase` would re-arm the ready/render timeouts above and risks a spurious
    // Failed. Visible feedback instead comes from `refreshInFlight` covering the WebView with
    // `loading()` below (mirrors the native arm's refresh skeleton) — `pushRender` also fires on
    // that transition so the page learns a refresh started, not just that it finished.
    LaunchedEffect(contractJson, currentThemeMode, refreshInFlight) {
        if (phase == Phase.Rendered || phase == Phase.AwaitingRender) pushRender()
    }

    Box(modifier = modifier.then(Modifier.fillMaxSize())) {
        // Keyed on `reloadTick` so retry gets a fresh `WebViewState`/`WebView` — the page itself
        // reloads, not just the contract. `navigator`/`jsBridge` stay outside this key so the
        // bridge registration above survives the remount and re-attaches to the new WebView.
        key(reloadTick) {
            val state = rememberWebViewState(url) { applyRenderBlockWebDefaults() }
            // Renderer-process death: on Android an unhandled crash kills the integrator's host
            // process, so this seam's Android actual keeps the app alive unconditionally; whether
            // the block itself auto-recovers or lands on Phase.Failed is the budget's call below.
            val platformWebViewParams = remember(reloadTick) {
                rendererDeathWebViewParams(
                    onRendererGone = {
                        val diagnostic = "webblocks web arm's renderer process terminated"
                        if (recoveryBudget.tryConsume()) {
                            // Not a Phase.Failed transition, so the once-per-transition effect
                            // below never sees this cause — report it here instead, once, so an
                            // auto-recovered crash still reaches the host and the log.
                            currentHostEventHandler.onHostEvent(
                                HostEvent.Error(
                                    RenderBlockError(code = RENDER_BLOCK_WEB_FAILURE_RENDERER_GONE, message = diagnostic),
                                ),
                            )
                            phase = Phase.Booting
                            reloadTick++
                        } else {
                            // Exhausted: the phase transition below reports through the existing
                            // once-per-transition effect — do not report twice.
                            phase = Phase.Failed(RENDER_BLOCK_WEB_FAILURE_RENDERER_GONE, diagnostic)
                        }
                    },
                )
            }
            // Opportunistic fail-fast: a main-frame load error means the `ready` handshake will
            // never arrive, so there is no reason to wait out the full READY_TIMEOUT_MS bound
            // once one is observed. Known gap: other failure causes (a silent hang with no load
            // error) still wait out the full timeout before being reported.
            LaunchedEffect(state) {
                snapshotFlow { state.errorsForCurrentRequest.any { it.isFromMainFrame } }
                    .collect { hasMainFrameError ->
                        if (hasMainFrameError && phase == Phase.Booting) {
                            phase = Phase.Failed(
                                RENDER_BLOCK_WEB_FAILURE_NOT_READY,
                                "webblocks harness did not signal ready in time",
                            )
                        }
                    }
            }
            WebView(
                state = state,
                navigator = navigator,
                webViewJsBridge = jsBridge,
                modifier = Modifier.fillMaxSize(),
                platformWebViewParams = platformWebViewParams,
            )
        }
        when (val currentPhase = phase) {
            is Phase.Failed -> error(
                RenderBlockWebFailure(
                    code = currentPhase.code,
                    diagnostic = currentPhase.diagnostic,
                    retry = {
                        phase = Phase.Booting
                        reloadTick++
                    },
                ),
            )
            // A refetch keeps the WebView mounted (see the LaunchedEffect above), so the cover
            // over it is this flag alone rather than a `phase` reset.
            Phase.Rendered -> if (refreshInFlight) loading()
            Phase.Booting, Phase.AwaitingRender -> loading()
        }
    }
}

private val RENDER_BLOCK_WEB_FALLBACK_ICON_SIZE = 40.dp
private val RENDER_BLOCK_WEB_FALLBACK_ICON_STROKE_WIDTH = 3.dp

/** Accessibility metadata only — never painted as on-screen copy. */
private const val RENDER_BLOCK_WEB_FALLBACK_RETRY_DESCRIPTION = "Retry"

/** Root test tag for [RenderBlockWebFallbackError], for on-device acceptance assertions. */
const val RENDER_BLOCK_WEB_FALLBACK_ERROR_TAG = "render_block_web_fallback_error"

/**
 * The module's last-resort failure floor: an opaque, full-bleed surface so a broken or
 * half-rendered page can never show through, with a single retry affordance and no SDK-authored
 * copy — an integrator's end user is the most external audience there is, in a language and
 * for a tenant the SDK does not know.
 */
@Composable
fun RenderBlockWebFallbackError(onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .testTag(RENDER_BLOCK_WEB_FALLBACK_ERROR_TAG),
        contentAlignment = Alignment.Center,
    ) {
        val iconColor = MaterialTheme.colorScheme.onSurface
        Canvas(
            modifier = Modifier
                .size(RENDER_BLOCK_WEB_FALLBACK_ICON_SIZE)
                .clickable(
                    role = Role.Button,
                    onClickLabel = RENDER_BLOCK_WEB_FALLBACK_RETRY_DESCRIPTION,
                    onClick = onRetry,
                )
                .semantics { contentDescription = RENDER_BLOCK_WEB_FALLBACK_RETRY_DESCRIPTION },
        ) {
            drawArc(
                color = iconColor,
                startAngle = -215f,
                sweepAngle = 250f,
                useCenter = false,
                style = Stroke(width = RENDER_BLOCK_WEB_FALLBACK_ICON_STROKE_WIDTH.toPx(), cap = StrokeCap.Round),
            )
        }
    }
}

/**
 * Handles the `event` envelope. Forwards the decoded [HostEvent] to [hostEventHandler]. A fatal
 * harness error (`kind:"error"` with `payload.fatal:true`) also invokes [onFatal] so the
 * composable surfaces an error state, in addition to (not instead of) informing the host via
 * [hostEventHandler].
 */
private fun handleEvent(
    rawParams: String,
    hostEventHandler: HostEventHandler,
    onFatal: (String) -> Unit,
) {
    val envelope = runCatching { Json.parseToJsonElement(rawParams).jsonObject }.getOrNull() ?: return
    val fatal = envelope["payload"]?.jsonObject?.get("fatal")?.jsonPrimitive?.boolean == true
    val message = envelope["payload"]?.jsonObject?.get("message")?.jsonPrimitive?.contentOrNull

    val decoded = decodeEvent(envelope)
    hostEventHandler.onHostEvent(decoded)
    if (fatal) onFatal(message ?: "webblocks harness reported a fatal error")
}

/**
 * Handles the `fetchSubComponent` bridge request: parses `{id}` — `id` IS the target
 * `componentId`/`flowId`, not a correlation token for a separate `config` — and answers via
 * `navigator.evaluateJavaScript` (main-thread-safe — never the library `callNative` callback
 * arg, per the module's threading rule).
 *
 * ALWAYS round-trips through [provider], never slicing an already-resolved tree. [provider]
 * answers with the raw BFF envelope (`{id, blocks, meta, …}`); `.blocks` is unwrapped here — the
 * one seam where a raw envelope becomes a `fetchSubComponent` answer — before it reaches the
 * harness, which expects a `Block`, not an envelope. No provider / no target / a `blocks`-less
 * envelope leaves the request unanswered — the harness's own promise then stays unresolved,
 * keeping the sub-component's placeholder up, exactly mirroring native's "no provider" /
 * failure behavior.
 */
private fun handleFetchSubComponent(
    rawParams: String,
    provider: RawSubComponentProvider?,
    externalCode: String?,
    navigator: WebViewNavigator,
    scope: CoroutineScope,
) {
    val envelope = runCatching { Json.parseToJsonElement(rawParams).jsonObject }.getOrNull() ?: return
    val targetId = envelope["id"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() } ?: return

    if (provider == null) return
    scope.launch {
        val rawEnvelope = runCatching { provider.getRawSubComponent(targetId, externalCode) }.getOrNull()
            ?: return@launch
        val blocks = runCatching { Json.parseToJsonElement(rawEnvelope).jsonObject["blocks"] }.getOrNull()
            ?: return@launch
        navigator.evaluateJavaScript(buildSubComponentResolution(targetId, blocks.toString()))
    }
}

/**
 * Converts the harness's `scroll.offsetPx` — CSS px (`Math.round(scrollTop)`, the WebView
 * viewport's own coordinate space) — into the same unit [ScrollInfo.offsetPx] carries from
 * `:composeblocks`' native renderer: raw device px (`LazyListState.firstVisibleItemScrollOffset`
 * is measured in Compose's underlying pixel space, not dp). `density` is
 * `LocalDensity.current.density` (pixels per dp); rounds to the nearest px.
 */
internal fun cssPxToPhysicalPx(cssPx: Int, density: Float): Int =
    (cssPx * density).roundToInt()

/**
 * Deliberately never invokes [IJsMessageHandler.handle]'s `callback` — the real harness never
 * registers a callbackId for `ready`/`rendered`/`height`/`event`, so it never awaits or reads a
 * reply. Calling it anyway replies for nothing AND actively breaks production: the library's
 * `WebViewJsBridge.onCallback` runs `evaluateJavaScript` from the JavaBridge thread (not main),
 * which Android's `WebView.evaluateJavascript` rejects, and the thrown exception propagates
 * back into the WebView's JS engine as an uncaught, unattributable error that the harness's own
 * global error listener genuinely (and correctly) reports as a fatal `event` — a spurious,
 * self-inflicted failure on every single tap. Not calling `callback` removes the defect at its
 * source instead of marshalling the reply to the main thread for an ACK nothing reads.
 */
private fun nativeMethodHandler(method: String, onParams: (String) -> Unit): IJsMessageHandler =
    object : IJsMessageHandler {
        override fun methodName(): String = method

        override fun handle(
            message: JsMessage,
            navigator: WebViewNavigator?,
            callback: (String) -> Unit,
        ) {
            // `callback` intentionally unused — see the doc comment above.
            onParams(message.params)
        }
    }
