package br.com.wave.flows.kmp.webblocks

import com.multiplatform.webview.web.PlatformWebViewParams

/**
 * Platform hook for a WebView renderer-process crash. `compose-webview-multiplatform:2.0.3` does
 * not surface this on its own: an unhandled Android `onRenderProcessGone` terminates the
 * integrator's host process, and iOS never calls [onRendererGone] because this dependency version
 * has no seam to observe it (see the `.ios.kt` actual). [onRendererGone] runs the shared recovery
 * policy (budget, phase transition, host report) — this seam contributes detection only.
 */
internal expect fun rendererDeathWebViewParams(onRendererGone: () -> Unit): PlatformWebViewParams?
