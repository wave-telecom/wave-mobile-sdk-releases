package br.com.wave.flows.kmp.webblocks

/**
 * An unbounded automatic recovery would put the block into an endless reload loop in front of the
 * user every time the renderer process dies — this bound is what turns "resurrect the WebView"
 * into a feature instead of a hazard.
 */
internal const val MAX_WEB_VIEW_RECOVERY_ATTEMPTS = 3

/** See [MAX_WEB_VIEW_RECOVERY_ATTEMPTS]; the window an episode of attempts is measured against. */
internal const val WEB_VIEW_RECOVERY_WINDOW_MS = 60_000L

/**
 * Bounds automatic renderer-death recovery to [maxAttempts] within a rolling [windowMs] episode.
 * [nowMs] is a parameter rather than a real clock read so tests can advance time deterministically
 * without a `delay`.
 */
internal class WebViewRecoveryBudget(
    private val maxAttempts: Int = MAX_WEB_VIEW_RECOVERY_ATTEMPTS,
    private val windowMs: Long = WEB_VIEW_RECOVERY_WINDOW_MS,
    private val nowMs: () -> Long,
) {
    private var episodeStartMs: Long? = null
    private var episodeAttempts: Int = 0

    fun tryConsume(): Boolean {
        if (maxAttempts <= 0) return false

        val now = nowMs()
        val episodeStart = episodeStartMs
        if (episodeStart == null || now - episodeStart >= windowMs) {
            episodeStartMs = now
            episodeAttempts = 0
        }

        if (episodeAttempts >= maxAttempts) return false
        episodeAttempts++
        return true
    }
}
