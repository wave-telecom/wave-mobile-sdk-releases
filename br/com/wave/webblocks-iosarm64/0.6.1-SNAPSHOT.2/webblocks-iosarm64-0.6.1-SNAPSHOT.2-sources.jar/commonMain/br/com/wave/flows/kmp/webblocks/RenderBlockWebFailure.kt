package br.com.wave.flows.kmp.webblocks

/**
 * A render failure the module could not resolve on its own. [code] is a stable, machine-readable
 * cause for the host and the log; [diagnostic] is for the log and the host event ONLY and must
 * never be rendered (see the module KDoc); [retry] re-loads the page and returns the block to its
 * loading state.
 */
data class RenderBlockWebFailure(
    val code: String,
    val diagnostic: String,
    val retry: () -> Unit,
)

/** The `ready` handshake never arrived within the module's ready-timeout bound. */
const val RENDER_BLOCK_WEB_FAILURE_NOT_READY = "RENDER_BLOCK_WEB_FAILURE_NOT_READY"

/** The page acknowledged `ready` but never reported `rendered` within the rendered-timeout bound. */
const val RENDER_BLOCK_WEB_FAILURE_NOT_RENDERED = "RENDER_BLOCK_WEB_FAILURE_NOT_RENDERED"

/** The harness itself reported a fatal error over the `event` bridge. */
const val RENDER_BLOCK_WEB_FAILURE_HARNESS_FATAL = "RENDER_BLOCK_WEB_FAILURE_HARNESS_FATAL"

/** The renderer process died and the automatic recovery budget is exhausted for this episode. */
const val RENDER_BLOCK_WEB_FAILURE_RENDERER_GONE = "RENDER_BLOCK_WEB_FAILURE_RENDERER_GONE"
