package br.com.wave.flows.kmp.webblocks

import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.contract.VerbatimHostCallbackJson
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.ActionData
import br.com.wave.flows.kmp.core.host.HostEvent
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

private const val KIND_NAVIGATE = "navigate"
private const val KIND_ACTION_TRACKED = "actionTracked"
private const val KIND_ERROR = "error"
private const val KIND_REFRESH = "refresh"
private const val KIND_HOST_DELEGATED = "hostDelegated"

private const val NAV_TYPE_BACK = "navigationBack"
private const val NAV_TYPE_EXTERNAL = "navigationExternal"
private const val NAV_TYPE_WEBVIEW = "navigationWebView"

/**
 * Decodes the `event` envelope into the SDK's [HostEvent] surface. Unknown `kind`s are reported
 * as a generic [HostEvent.Error] rather than silently ignored — the harness contract is fixed,
 * so an unrecognized kind means a spec/version mismatch, not a variant the caller should shrug
 * off.
 */
internal fun decodeEvent(envelope: JsonObject): HostEvent {
    val kind = envelope["kind"]?.jsonPrimitive?.contentOrNull
    val payload = envelope["payload"]?.jsonObject ?: JsonObject(emptyMap())

    return when (kind) {
        KIND_NAVIGATE -> HostEvent.Navigation(decodeNavigation(payload))
        KIND_ACTION_TRACKED -> HostEvent.ActionTracked(decodeActionData(payload))
        KIND_ERROR -> HostEvent.Error(decodeError(payload))
        KIND_REFRESH -> HostEvent.Refresh
        KIND_HOST_DELEGATED -> HostEvent.DelegatedHostAction(
            payload["rawJson"]?.jsonPrimitive?.contentOrNull.orEmpty(),
        )
        else -> HostEvent.Error(
            object : RenderBlockError(
                code = "WEB_HARNESS_UNKNOWN_EVENT",
                message = "webblocks harness sent an unrecognized event kind: ${kind ?: "<missing>"}",
            ) {},
        )
    }
}

/**
 * The web `navigate` event is the `NavigationEvent` wrapper the harness's `onNavigate`
 * callback receives verbatim (`{type:'navigation', payload: NavigationPayload, extras?}`,
 * `NavigationPayload = {navigationType, navigationId?, nextScreenName?, modalReference?,
 * navigationReference?}`) — the harness re-emits it UNCHANGED as the envelope `payload`, so
 * `navigationEventWrapper` here is that whole `{type,payload,extras?}` object;
 * `navigationType`/`navigationId` live one level deeper, under
 * `navigationEventWrapper["payload"]` — not at this level. `navigationType` selects the
 * [NavigationEvent] shape — `navigationBack` -> [NavigationEvent.Back],
 * `navigationExternal`/`navigationWebView` -> [NavigationEvent.External] (URL carried in
 * `navigationId`), anything else -> [NavigationEvent.Navigate].
 */
private fun decodeNavigation(navigationEventWrapper: JsonObject): NavigationEvent {
    val navigationPayload = navigationEventWrapper["payload"]?.jsonObject ?: JsonObject(emptyMap())
    val navigationType = navigationPayload["navigationType"]?.jsonPrimitive?.contentOrNull
    val navigationId = navigationPayload["navigationId"]?.jsonPrimitive?.contentOrNull.orEmpty()

    return when (navigationType) {
        NAV_TYPE_BACK -> NavigationEvent.Back
        NAV_TYPE_EXTERNAL, NAV_TYPE_WEBVIEW -> NavigationEvent.External(navigationId)
        else -> {
            // `extras.config` (when present) IS the original BFF verbatim the outbound side
            // carries — highest fidelity. Falls back to the typed `navigationPayload` subset
            // for older bundles that don't forward it yet.
            val verbatimConfig = navigationEventWrapper["extras"]?.jsonObject?.get("config")?.jsonObject
            NavigationEvent.Navigate(
                nextComponentId = navigationId,
                verbatim = VerbatimHostCallbackJson(verbatimConfig ?: navigationPayload),
            )
        }
    }
}

private fun decodeActionData(payload: JsonObject): ActionData =
    ActionData(
        type = payload["type"]?.jsonPrimitive?.contentOrNull.orEmpty(),
        payload = (payload["payload"]?.jsonObject ?: JsonObject(emptyMap()))
            .mapValues { (_, v) -> (v as? JsonPrimitive)?.contentOrNull ?: v.toString() },
        timestamp = payload["timestamp"]?.jsonPrimitive?.contentOrNull.orEmpty(),
    )

private fun decodeError(payload: JsonObject): RenderBlockError {
    val code = payload["code"]?.jsonPrimitive?.contentOrNull ?: "WEB_HARNESS_ERROR"
    val message = payload["message"]?.jsonPrimitive?.contentOrNull ?: "webblocks harness reported an error"
    return object : RenderBlockError(code = code, message = message) {}
}
