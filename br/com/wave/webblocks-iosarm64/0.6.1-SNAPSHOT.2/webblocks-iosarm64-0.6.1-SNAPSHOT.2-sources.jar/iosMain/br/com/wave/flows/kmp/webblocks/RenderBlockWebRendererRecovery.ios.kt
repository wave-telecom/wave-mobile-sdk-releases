package br.com.wave.flows.kmp.webblocks

import com.multiplatform.webview.web.PlatformWebViewParams

/**
 * No-op on this dependency version, verified against its exact iOS source
 * (`WebView.ios.kt`/`WKNavigationDelegate.kt` at tag 2.0.3): `PlatformWebViewParams` is an empty
 * class here and `ActualWebView` never reads it; `onCreated` fires before the library assigns its
 * own hardcoded `WKNavigationDelegate` to `navigationDelegate`, and that assignment is
 * unconditional, so nothing installed from `onCreated` survives it. There is no window in this
 * version to intercept `webViewWebContentProcessDidTerminate:`. [onRendererGone] is therefore never
 * called on iOS; the existing ready/rendered timeouts remain the only bound there.
 */
internal actual fun rendererDeathWebViewParams(onRendererGone: () -> Unit): PlatformWebViewParams? = null
