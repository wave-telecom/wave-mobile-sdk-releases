package br.com.wave.flows.kmp.webblocks.adapter.config

import br.com.wave.flows.kmp.core.contract.AccordionBlockConfig
import br.com.wave.flows.kmp.core.contract.BlockConfig
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockStyle
import br.com.wave.flows.kmp.core.contract.BottomSheetBlockConfig
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.contract.CardBlockConfig
import br.com.wave.flows.kmp.core.contract.CarouselBlockConfig
import br.com.wave.flows.kmp.core.contract.ChartBlockConfig
import br.com.wave.flows.kmp.core.contract.ContainerBlockConfig
import br.com.wave.flows.kmp.core.contract.DividerBlockConfig
import br.com.wave.flows.kmp.core.contract.GridBlockConfig
import br.com.wave.flows.kmp.core.contract.ImageBlockConfig
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.RadioGroupBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextSegment
import br.com.wave.flows.kmp.core.contract.SkeletonBlockConfig
import br.com.wave.flows.kmp.core.contract.SpacerBlockConfig
import br.com.wave.flows.kmp.core.contract.SubComponentBlockConfig
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.theme.ThemePalette
import br.com.wave.flows.kmp.webblocks.adapter.resolveColor
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject

/**
 * Type-specific fields on top of [br.com.wave.flows.kmp.webblocks.adapter.encodeStyle] —
 * field names are authoritative in `packages/render-core/src/types/blocks/<type>.ts` (read
 * before mapping each type below; discoveries/gaps noted per branch). Returns the fields to
 * merge into the web `config` object (never `variants`, built separately by
 * [encodeVariants] since it is a cross-cutting concern of the shared `BlockConfig` base, not
 * a per-type one).
 */
internal fun encodeTypeFields(config: BlockConfig, palette: ThemePalette?): Map<String, JsonElement> {
    val out = LinkedHashMap<String, JsonElement>()

    when (config) {
        is TextBlockConfig -> {
            out["value"] = JsonPrimitive(config.value)
            config.fontSizeSp?.let { out["fontSize"] = JsonPrimitive(it) }
            config.lineHeightSp?.let { out["lineHeight"] = JsonPrimitive(it) }
            config.fontFamily?.let { out["fontFamily"] = JsonPrimitive(it) }
            config.fontWeight?.let { out["fontWeight"] = JsonPrimitive(it) }
            config.align?.let { out["align"] = JsonPrimitive(it) }
            out["strikethrough"] = JsonPrimitive(config.strikethrough)
            out["truncate"] = JsonPrimitive(config.truncate)
        }

        // Web `RichTextBlockConfig` has no `disallowSelection` counterpart to native `TextBlockConfig`'s
        // (a text-only field); n/a here since rich-text carries its own shape.
        is RichTextBlockConfig -> {
            out["segments"] = JsonArray(config.segments.map { encodeSegment(it, palette) })
            config.fontSizeSp?.let { out["fontSize"] = JsonPrimitive(it) }
            config.fontFamily?.let { out["fontFamily"] = JsonPrimitive(it) }
            config.fontWeight?.let { out["fontWeight"] = JsonPrimitive(it) }
            config.fontStyle?.let { out["fontStyle"] = JsonPrimitive(it) }
            config.color?.let { out["color"] = JsonPrimitive(resolveColor(it, palette)) }
            config.align?.let { out["align"] = JsonPrimitive(it) }
            out["strikethrough"] = JsonPrimitive(config.strikethrough)
            out["truncate"] = JsonPrimitive(config.truncate)
        }

        // Web `ButtonBlockConfig` has no `align` field (verified button.ts) — dropped, not invented.
        is ButtonBlockConfig -> {
            out["value"] = JsonPrimitive(config.value)
            config.fontSizeSp?.let { out["fontSize"] = JsonPrimitive(it) }
            config.lineHeightSp?.let { out["lineHeight"] = JsonPrimitive(it) }
            config.fontFamily?.let { out["fontFamily"] = JsonPrimitive(it) }
            config.fontWeight?.let { out["fontWeight"] = JsonPrimitive(it) }
            config.style.fullWidth?.let { out["fullWidth"] = JsonPrimitive(it) }
        }

        is CardBlockConfig -> {
            config.elevation?.let { out["elevation"] = JsonPrimitive(it) }
            config.style.maxWidth?.let { out["maxWidth"] = JsonPrimitive(it) }
            config.style.fullWidth?.let { out["fullWidth"] = JsonPrimitive(it) }
        }

        // Web `ContainerBlockConfig` carries position/top/bottom/left/right/zIndex —
        // the one type (with `ImageBlockConfig`) that DOES have a slot for these
        // BlockStyle fields; other types drop them (see the mapping doc).
        is ContainerBlockConfig -> out.putAll(encodePositioning(config.style))

        is GridBlockConfig -> {
            out["columns"] = JsonPrimitive(config.columns)
            out["gap"] = JsonPrimitive(config.gap)
            config.maxColumnSize?.let { out["maxColumnSize"] = JsonPrimitive(it) }
            config.style.fullWidth?.let { out["fullWidth"] = JsonPrimitive(it) }
        }

        // Web `ListBlockConfig` has no plain `align` field (only verticalAlign/horizontalAlign) —
        // native's `align` is dropped, not invented.
        is ListBlockConfig -> {
            out["spacing"] = JsonPrimitive(config.spacing)
            out["orientation"] = JsonPrimitive(config.orientation.wireValue())
            config.verticalAlign?.let { out["verticalAlign"] = JsonPrimitive(it) }
            config.horizontalAlign?.let { out["horizontalAlign"] = JsonPrimitive(it) }
            out["expand"] = JsonPrimitive(config.expand)
            config.style.maxWidth?.let { out["maxWidth"] = JsonPrimitive(it) }
            config.style.fullWidth?.let { out["fullWidth"] = JsonPrimitive(it) }
        }

        is DividerBlockConfig -> out["orientation"] = JsonPrimitive(config.orientation.wireValue())

        // Web `ImageBlockConfig` has no plain `align` field — dropped, not invented.
        is ImageBlockConfig -> {
            out["url"] = JsonPrimitive(config.url)
            config.altText?.let { out["altText"] = JsonPrimitive(it) }
            config.aspectRatio?.let { out["aspectRatio"] = JsonPrimitive(it) }
            config.width?.let { out["width"] = JsonPrimitive(it) }
            config.height?.let { out["height"] = JsonPrimitive(it) }
            out.putAll(encodePositioning(config.style))
        }

        // Web `RadioGroupBlockConfig` has no active*Hex fields at all — folded into the
        // generic `variants.selected` slot by encodeVariants (inferred, not a confirmed
        // contract; see the mapping doc).
        is RadioGroupBlockConfig -> {
            out["orientation"] = JsonPrimitive(config.orientation.wireValue())
            config.activeIndex?.let { out["activeIndex"] = JsonPrimitive(it) }
            out["spacing"] = JsonPrimitive(config.spacing)
        }

        is CarouselBlockConfig -> {
            out["itemWidth"] = JsonPrimitive(config.itemWidth)
            out["showIndicators"] = JsonPrimitive(config.showIndicators)
            config.showButtons?.let { out["showButtons"] = JsonPrimitive(it) }
            out["spacing"] = JsonPrimitive(config.spacing)
        }

        // Web `ChartBlockConfig.data[].updatedAt` is required but we have no source for
        // it — omitted (JSON is not runtime-typechecked; document as a parity gap).
        is ChartBlockConfig -> {
            out["type"] = JsonPrimitive(config.type)
            out["data"] = JsonArray(
                config.data.map { point ->
                    buildJsonObject {
                        put("key", JsonPrimitive(point.key))
                        put("value", JsonPrimitive(point.value))
                        put("fill", JsonPrimitive(point.fill))
                    }
                },
            )
            out["size"] = JsonPrimitive(config.size)
            config.fontSizeSp?.let { out["fontSize"] = JsonPrimitive(it) }
            config.fontFamily?.let { out["fontFamily"] = JsonPrimitive(it) }
            config.fontWeight?.let { out["fontWeight"] = JsonPrimitive(it) }
            config.fontStyle?.let { out["fontStyle"] = JsonPrimitive(it) }
            config.lineHeightSp?.let { out["lineHeight"] = JsonPrimitive(it) }
        }

        is SpacerBlockConfig -> Unit

        // Web `TabsBlockConfig` has no active*/inactive*Hex fields; `active*` folds into
        // the generic `variants.selected` slot (inferred, see encodeVariants). `inactive*`
        // has no web slot at all and stays dropped (documented gap). `chipStyle` is NOT
        // dropped — it reaches the payload via `WebBlockAdapter.styleToEncode` (the un-split
        // bar/chip style feeding `encodeStyle`, not this per-type block), which is where the
        // web `Tabs` component's chip shape (`borderRadius`/`padding`/`backgroundColor`/
        // `border*`) actually comes from.
        is TabsBlockConfig -> {
            out["options"] = JsonArray(
                config.options.map { option ->
                    buildJsonObject {
                        put("id", JsonPrimitive(option.id))
                        put("label", JsonPrimitive(option.label))
                        put("contentReferenceId", JsonPrimitive(option.contentReferenceId))
                    }
                },
            )
            out["gap"] = JsonPrimitive(config.gap)
            config.fontSizeSp?.let { out["fontSize"] = JsonPrimitive(it) }
            config.fontFamily?.let { out["fontFamily"] = JsonPrimitive(it) }
            config.fontWeight?.let { out["fontWeight"] = JsonPrimitive(it) }
            config.lineHeightSp?.let { out["lineHeight"] = JsonPrimitive(it) }
            config.style.fullWidth?.let { out["fullWidth"] = JsonPrimitive(it) }
        }

        is BottomSheetBlockConfig -> Unit

        // Web `AccordionBlockConfig` has no `lineHeight`-backing source field on our side
        // (native has none either) and no `centerHeader` source — both omitted, not invented.
        is AccordionBlockConfig -> {
            config.title?.let { out["title"] = JsonPrimitive(it) }
            out["defaultOpen"] = JsonPrimitive(config.defaultOpen)
            config.iconColorHex?.let { out["iconColor"] = JsonPrimitive(resolveColor(it, palette)) }
            config.iconUrl?.let { out["iconUrl"] = JsonPrimitive(it) }
            config.iconWidth?.let { out["iconWidth"] = JsonPrimitive(it) }
            config.iconHeight?.let { out["iconHeight"] = JsonPrimitive(it) }
            config.wrapContent?.let { out["wrapContent"] = JsonPrimitive(it) }
            config.fullWidth?.let { out["fullWidth"] = JsonPrimitive(it) }
            config.fontSizeSp?.let { out["fontSize"] = JsonPrimitive(it) }
            config.fontFamily?.let { out["fontFamily"] = JsonPrimitive(it) }
            config.fontWeight?.let { out["fontWeight"] = JsonPrimitive(it) }
            config.fontStyle?.let { out["fontStyle"] = JsonPrimitive(it) }
        }

        is SubComponentBlockConfig -> {
            config.componentId?.let { out["componentId"] = JsonPrimitive(it) }
            config.flowId?.let { out["flowId"] = JsonPrimitive(it) }
        }

        // Web `SkeletonBlockConfig` is a bare `BlockConfig` alias (no type-specific fields);
        // our `width`/`height`(String) and `align` have no web slot at all — dropped, documented.
        is SkeletonBlockConfig -> Unit

        // TOOLBAR/UNKNOWN never reach here — `webTypeToken` returns null for both and the
        // caller omits the node before encoding type fields.
        else -> Unit
    }

    return out
}

private fun encodeSegment(segment: RichTextSegment, palette: ThemePalette?): JsonObject =
    buildJsonObject {
        put("text", JsonPrimitive(segment.text))
        segment.fontSizeSp?.let { put("fontSize", JsonPrimitive(it)) }
        segment.fontFamily?.let { put("fontFamily", JsonPrimitive(it)) }
        segment.fontWeight?.let { put("fontWeight", JsonPrimitive(it)) }
        segment.fontStyle?.let { put("fontStyle", JsonPrimitive(it)) }
        segment.color?.let { put("color", JsonPrimitive(resolveColor(it, palette))) }
        put("strikethrough", JsonPrimitive(segment.strikethrough))
        put("underline", JsonPrimitive(segment.underline))
    }

/** `position`/`top`/`right`/`bottom`/`left`/`zIndex` — the `Container`/`Image` web slot. */
private fun encodePositioning(style: BlockStyle): Map<String, JsonElement> {
    val out = LinkedHashMap<String, JsonElement>()
    style.position?.let { out["position"] = JsonPrimitive(it) }
    style.top?.let { out["top"] = JsonPrimitive(it) }
    style.right?.let { out["right"] = JsonPrimitive(it) }
    style.bottom?.let { out["bottom"] = JsonPrimitive(it) }
    style.left?.let { out["left"] = JsonPrimitive(it) }
    style.zIndex?.let { out["zIndex"] = JsonPrimitive(it) }
    return out
}

private fun BlockOrientation.wireValue(): String = name.lowercase()

/**
 * Builds the shared `variants.{selected,disabled}` object (`common.ts:66-73`:
 * `BlockConfig.variants?: {selected?, disabled?}`, both `Partial<BlockStyleConfig>`).
 * Only [CardBlockConfig] has a confirmed web-side variant convention (`selected`
 * background/borderRadius, `disabled` color/background). `RadioGroupBlockConfig` /
 * `TabsBlockConfig`'s native `active*Hex` fields are folded into `variants.selected` as a
 * best-effort inference (there is no dedicated web field for them); their `inactive*Hex`
 * fields have no web variant slot at all (web only models `selected`/`disabled`) and are
 * dropped — documented parity gaps, not invented behavior.
 */
internal fun encodeVariants(config: BlockConfig, palette: ThemePalette?): JsonObject? {
    val selected = LinkedHashMap<String, JsonElement>()
    val disabled = LinkedHashMap<String, JsonElement>()

    when (config) {
        is CardBlockConfig -> {
            config.selectedBackgroundColorHex?.let { selected["backgroundColor"] = JsonPrimitive(resolveColor(it, palette)) }
            config.selectedBorderRadius?.let { selected["borderRadius"] = JsonPrimitive(it) }
            config.disabledColorHex?.let { disabled["color"] = JsonPrimitive(resolveColor(it, palette)) }
            config.disabledBackgroundColorHex?.let { disabled["backgroundColor"] = JsonPrimitive(resolveColor(it, palette)) }
        }

        is RadioGroupBlockConfig -> {
            config.activeColorHex?.let { selected["color"] = JsonPrimitive(resolveColor(it, palette)) }
            config.activeBackgroundColorHex?.let { selected["backgroundColor"] = JsonPrimitive(resolveColor(it, palette)) }
        }

        is TabsBlockConfig -> {
            config.activeColorHex?.let { selected["color"] = JsonPrimitive(resolveColor(it, palette)) }
            config.activeBackgroundColorHex?.let { selected["backgroundColor"] = JsonPrimitive(resolveColor(it, palette)) }
        }

        else -> Unit
    }

    if (selected.isEmpty() && disabled.isEmpty()) return null

    return buildJsonObject {
        if (selected.isNotEmpty()) put("selected", buildJsonObject { selected.forEach { (k, v) -> put(k, v) } })
        if (disabled.isNotEmpty()) put("disabled", buildJsonObject { disabled.forEach { (k, v) -> put(k, v) } })
    }
}
