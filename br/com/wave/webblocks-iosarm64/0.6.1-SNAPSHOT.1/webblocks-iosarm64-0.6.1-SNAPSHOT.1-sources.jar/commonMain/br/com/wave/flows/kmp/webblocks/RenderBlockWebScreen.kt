package br.com.wave.flows.kmp.webblocks

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.ScrollInfo
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.runtime.MonotonicRuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.webblocks.adapter.DecodedEvent
import br.com.wave.flows.kmp.webblocks.adapter.UnmappedNode
import br.com.wave.flows.kmp.webblocks.adapter.WebBlockAdapter
import br.com.wave.flows.kmp.webblocks.adapter.decodeEvent
import com.multiplatform.webview.jsbridge.IJsMessageHandler
import com.multiplatform.webview.jsbridge.JsMessage
import com.multiplatform.webview.jsbridge.rememberWebViewJsBridge
import com.multiplatform.webview.web.WebView
import com.multiplatform.webview.web.WebViewNavigator
import com.multiplatform.webview.web.rememberWebViewNavigator
import com.multiplatform.webview.web.rememberWebViewState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.math.roundToInt

private const val METHOD_READY = "ready"
private const val METHOD_RENDERED = "rendered"
private const val METHOD_HEIGHT = "height"
private const val METHOD_EVENT = "event"
private const val METHOD_SCROLL = "scroll"
private const val METHOD_FETCH_SUB_COMPONENT = "fetchSubComponent"
private const val READY_TIMEOUT_MS = 8_000L
// Host-owned-scroll placeholder height before the first `height` report arrives —
// mirrors the legacy `FlowWrapperViewInternal.HOST_SCROLL_PLACEHOLDER_HEIGHT` (600.dp).
private val HOST_SCROLL_PLACEHOLDER_HEIGHT = 600.dp
// Bounds the `ready` -> `rendered` window (spec §Handshake step 4: React commit + fonts +
// image decode must all settle) so a silent stall — no exception, just nothing ever
// resolving — surfaces a visible error instead of an indefinite loading overlay.
private const val RENDERED_TIMEOUT_MS = 10_000L

private sealed interface Phase {
    data object Booting : Phase
    data object AwaitingRender : Phase
    data object Rendered : Phase
    data class Failed(val message: String) : Phase
}

/**
 * Renders [contract] through the web render-block SDK running inside a WebView loaded from
 * [url] (`bridge-protocol-spec.md`). Shape-compatible with the native renderer family:
 * [loading] overlays the WebView until the page reports `rendered`; [error] replaces it on
 * a missing `ready` handshake or a fatal error — replacing the previous silent white screen.
 *
 * The host-facing surface mirrors `:composeblocks`' `RenderBlockScreen`: [onScroll] rides
 * the page's `scroll` bridge signal (inert until the page emits it — see the
 * technical-debt/C-B notes), [pullToRefreshEnabled] wraps the WebView in a Material3
 * `PullToRefreshBox`, and [onContractLoaded] fires once per contract on the first
 * `rendered`. [visibilityOverrides]/[embeddedContracts] flow through the pure
 * [WebBlockAdapter] rather than any composable-level tree manipulation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RenderBlockWebScreen(
    // The remote render-only route URL (the journeys route; a localhost dev-server URL in
    // the study). The module is URL-source-agnostic — where it comes from is the caller's
    // concern (the clean production seam).
    url: String,
    contract: ScreenContract,
    hostEventHandler: HostEventHandler,
    themeMode: ThemeId = ThemeId.Light,
    scroll: Boolean = true,
    pullToRefreshEnabled: Boolean = false,
    isRefreshing: Boolean = false,
    onPtrRefresh: () -> Unit = {},
    onScroll: ((ScrollInfo) -> Unit)? = null,
    scrollThrottleMs: Long = DEFAULT_SCROLL_THROTTLE_MS,
    onContractLoaded: (ScreenContract) -> Unit = {},
    visibilityOverrides: Map<String, Boolean>? = null,
    embeddedContracts: Map<String, ScreenContract> = emptyMap(),
    // Sub-component fetch (gap 2): resolves the embedded tree for a `sub-component` block's
    // target. `null` (default) = respond "unresolved" = placeholder, matching native's own
    // "no provider" behavior.
    contractProvider: ScreenContractProvider? = null,
    externalCode: String? = null,
    // Monotonic clock driving the PTR cooldown gate. Injectable so tests can advance it
    // deterministically instead of depending on wall-clock delay.
    cooldownClock: RuntimeClock = MonotonicRuntimeClock,
    loading: @Composable () -> Unit = {},
    error: @Composable (message: String) -> Unit = { DefaultRenderBlockWebError(it) },
    modifier: Modifier = Modifier,
) {
    val currentHostEventHandler by rememberUpdatedState(hostEventHandler)
    // The jsBridge handlers below are registered once (DisposableEffect keyed on jsBridge
    // only) and captured in a closure that outlives any single recomposition — read the
    // contract through `rememberUpdatedState` so a re-composed `contract` is honored on
    // the NEXT native->JS round trip instead of the stale one from registration time.
    val currentContract by rememberUpdatedState(contract)
    val currentContractProvider by rememberUpdatedState(contractProvider)
    val currentExternalCode by rememberUpdatedState(externalCode)
    var currentThemeMode by remember { mutableStateOf(themeMode) }
    LaunchedEffect(themeMode) { currentThemeMode = themeMode }

    var phase by remember { mutableStateOf<Phase>(Phase.Booting) }
    var reportedHeightPx by remember { mutableStateOf<Int?>(null) }
    // Fires `onContractLoaded` exactly once per contract id, on the first transition into
    // `Phase.Rendered` — a subsequent `pushRender()` on the SAME id (e.g. a theme toggle)
    // must not re-fire it.
    var loadedContractId by remember { mutableStateOf<String?>(null) }

    val resolvedBaseUrl = url
    val currentDensity by rememberUpdatedState(LocalDensity.current.density)
    val navigator = rememberWebViewNavigator()
    val jsBridge = rememberWebViewJsBridge(navigator)
    val scope = rememberCoroutineScope()
    val cooldownGate = remember(cooldownClock) { RefreshCooldownGate(cooldownClock, PTR_COOLDOWN_MS) }
    // Raw `offsetPx` pushed by the `scroll` bridge handler; throttled/collected below.
    val scrollOffsets = remember { MutableStateFlow(0) }

    fun pushRender() {
        val (payload, unmapped) = WebBlockAdapter.toRenderPayload(
            contract = currentContract,
            mode = currentThemeMode,
            visibilityOverrides = visibilityOverrides,
            embeddedContracts = embeddedContracts,
        )
        reportUnmapped(unmapped, currentHostEventHandler)
        navigator.evaluateJavaScript(buildRenderInvocation(payload))
    }

    DisposableEffect(jsBridge) {
        val readyHandler = nativeMethodHandler(METHOD_READY) {
            phase = Phase.AwaitingRender
            pushRender()
        }
        val renderedHandler = nativeMethodHandler(METHOD_RENDERED) { params ->
            phase = Phase.Rendered
            heightPxFrom(params)?.let { reportedHeightPx = it }
        }
        // Sizes the root Box when the host owns scroll (`scroll == false`): consumes the
        // `heightPx` the harness reports on `rendered` (the ONLY initial height signal —
        // the harness's own `ResizeObserver` swallows its first post-render callback, so a
        // static contract never emits a follow-up `height`), refined by any later `height`
        // report for dynamic content (`bridge-protocol-spec.md` steps 4–5).
        val heightHandler = nativeMethodHandler(METHOD_HEIGHT) { params ->
            heightPxFrom(params)?.let { reportedHeightPx = it }
        }
        val eventHandler = nativeMethodHandler(METHOD_EVENT) { params ->
            when (
                val outcome = handleEvent(params, currentHostEventHandler) { failureMessage ->
                    phase = Phase.Failed(failureMessage)
                }
            ) {
                EventOutcome.Handled -> Unit
                is EventOutcome.ToggleTheme -> {
                    // Adopt the harness's OWN new mode — re-pushing the OLD mode would get
                    // reset right back by the harness's per-render store reset (spec §3).
                    // Falls back to a local flip only if the harness ever omits `payload.mode`.
                    currentThemeMode = outcome.mode
                        ?: currentContract.themeCatalog.toggle(currentThemeMode)?.id
                        ?: currentThemeMode
                    pushRender()
                }
            }
        }
        // Inert until the harness emits `scroll` (C-B interface requirement CB-1); the
        // native side is complete now so the feature lights up the moment it does.
        val scrollHandler = nativeMethodHandler(METHOD_SCROLL) { params ->
            val offsetPx = runCatching { Json.parseToJsonElement(params).jsonObject["offsetPx"]?.jsonPrimitive?.int }
                .getOrNull()
            // The harness reports CSS px; convert to the physical-px unit `ScrollInfo.offsetPx`
            // carries from the native renderer (see `cssPxToPhysicalPx` kdoc).
            if (offsetPx != null) scrollOffsets.value = cssPxToPhysicalPx(offsetPx, currentDensity)
        }
        val fetchSubComponentHandler = nativeMethodHandler(METHOD_FETCH_SUB_COMPONENT) { params ->
            handleFetchSubComponent(
                rawParams = params,
                provider = currentContractProvider,
                externalCode = currentExternalCode,
                mode = currentThemeMode,
                navigator = navigator,
                scope = scope,
                hostEventHandler = currentHostEventHandler,
            )
        }

        jsBridge.register(readyHandler)
        jsBridge.register(renderedHandler)
        jsBridge.register(heightHandler)
        jsBridge.register(eventHandler)
        jsBridge.register(scrollHandler)
        jsBridge.register(fetchSubComponentHandler)

        onDispose {
            jsBridge.unregister(readyHandler)
            jsBridge.unregister(renderedHandler)
            jsBridge.unregister(heightHandler)
            jsBridge.unregister(eventHandler)
            jsBridge.unregister(scrollHandler)
            jsBridge.unregister(fetchSubComponentHandler)
        }
    }

    if (onScroll != null) {
        LaunchedEffect(scrollThrottleMs) {
            // A WebView has no LazyColumn item index, so `firstVisibleItemIndex` is always
            // `0` — direction is derived from `offsetPx` deltas alone (see `scrollInfoFor`).
            var lastOffset = 0
            scrollOffsets
                .map { it to 0 }
                .throttleScrollPositions(scrollThrottleMs)
                .collect { (offset, index) ->
                    onScroll(scrollInfoFor(offset, index, lastOffset, 0))
                    lastOffset = offset
                }
        }
    }

    LaunchedEffect(resolvedBaseUrl) {
        if (resolvedBaseUrl == null) return@LaunchedEffect
        delay(READY_TIMEOUT_MS)
        if (phase == Phase.Booting) {
            phase = Phase.Failed("webblocks harness did not signal ready in time")
        }
    }

    // Re-keyed on every `phase` change: entering AwaitingRender starts this bound; leaving it
    // (Rendered, or a Failed from elsewhere) cancels this coroutine before it can fire.
    LaunchedEffect(phase) {
        if (phase != Phase.AwaitingRender) return@LaunchedEffect
        delay(RENDERED_TIMEOUT_MS)
        if (phase == Phase.AwaitingRender) {
            phase = Phase.Failed("webblocks harness did not report rendered in time")
        }
    }

    LaunchedEffect(phase, contract.id) {
        if (phase == Phase.Rendered && loadedContractId != contract.id) {
            loadedContractId = contract.id
            onContractLoaded(contract)
        }
    }

    // Deliberately does NOT reset `phase` back to `AwaitingRender` on a reload (a `contract`
    // param change while already `Rendered`): the WebView stays mounted across `pushRender`,
    // so the last rendered frame remains visible under no overlay while the new `render`
    // settles, instead of flashing back to `loading()`. This is the webblocks-layer analog
    // of the native route's "don't blank to skeleton on refresh" behavior — `onPeekSkeleton`
    // itself has no equivalent here since this composable receives an already-resolved
    // contract and owns no fetch (that peek-ahead concept belongs to the route/wrapper, C-C).
    LaunchedEffect(contract, currentThemeMode) {
        if (phase == Phase.Rendered || phase == Phase.AwaitingRender) pushRender()
    }

    // `scroll == true` → the WebView owns its own scroll (current behavior); `scroll ==
    // false` → sized to the harness's reported content height so the host's outer scroll
    // container measures it, the exact pattern the legacy WebView uses
    // (`FlowWrapperView.kt` `measuredHeightPx` + `HOST_SCROLL_PLACEHOLDER_HEIGHT`).
    val sizingModifier = if (scroll) {
        Modifier.fillMaxSize()
    } else {
        Modifier.fillMaxWidth().height(reportedHeightPx?.dp ?: HOST_SCROLL_PLACEHOLDER_HEIGHT)
    }

    @Composable
    fun WebViewSurface() {
        resolvedBaseUrl?.let { url ->
            val state = rememberWebViewState(url)
            WebView(
                state = state,
                navigator = navigator,
                webViewJsBridge = jsBridge,
                modifier = Modifier.fillMaxSize(),
            )
        }
        val currentPhase = phase
        when (currentPhase) {
            is Phase.Failed -> error(currentPhase.message)
            Phase.Rendered -> Unit
            Phase.Booting, Phase.AwaitingRender -> loading()
        }
    }

    if (pullToRefreshEnabled && scroll) {
        // Distinct from the harness's own `event {kind:"refresh"}` path (still routed to
        // `hostEventHandler` unchanged, above) — this is the gesture-driven refresh, exactly
        // as native keeps `onPtrRefresh` separate from `HostEvent.Refresh`. See the plan's
        // C-B fork (CB-2): if this gesture doesn't propagate over the WebView on-device, the
        // deterministic trigger is the harness's own overscroll-at-top `event`.
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { if (cooldownGate.tryTrigger()) onPtrRefresh() },
            modifier = modifier.then(sizingModifier),
        ) {
            Box(modifier = Modifier.fillMaxSize()) { WebViewSurface() }
        }
    } else {
        Box(modifier = modifier.then(sizingModifier)) { WebViewSurface() }
    }
}

private const val PTR_COOLDOWN_MS = 1_000L

@Composable
private fun DefaultRenderBlockWebError(message: String) {
    Text(text = message)
}

private sealed interface EventOutcome {
    data object Handled : EventOutcome
    data class ToggleTheme(val mode: ThemeId?) : EventOutcome
}

/**
 * Handles the `event` envelope. Forwards the decoded [HostEvent] to [hostEventHandler] when
 * applicable, or returns [EventOutcome.ToggleTheme] with the harness's new mode for the
 * caller to adopt before re-pushing `render` (the sentinel is SDK-internal — never forwarded
 * to the host). A fatal harness error (`kind:"error"` with `payload.fatal:true`) also invokes
 * [onFatal] so the composable surfaces an error state, in addition to (not instead of)
 * informing the host via [hostEventHandler].
 */
private fun handleEvent(
    rawParams: String,
    hostEventHandler: HostEventHandler,
    onFatal: (String) -> Unit,
): EventOutcome {
    val envelope = runCatching { Json.parseToJsonElement(rawParams).jsonObject }.getOrNull()
        ?: return EventOutcome.Handled
    val fatal = envelope["payload"]?.jsonObject?.get("fatal")?.jsonPrimitive?.boolean == true
    val message = envelope["payload"]?.jsonObject?.get("message")?.jsonPrimitive?.contentOrNull

    return when (val decoded = decodeEvent(envelope)) {
        is DecodedEvent.ForHost -> {
            hostEventHandler.onHostEvent(decoded.event)
            if (fatal) onFatal(message ?: "webblocks harness reported a fatal error")
            EventOutcome.Handled
        }
        is DecodedEvent.ToggleTheme -> EventOutcome.ToggleTheme(decoded.mode)
    }
}

/**
 * Handles the `fetchSubComponent` bridge request (gap 2): parses `{id, config}`, resolves
 * `config.componentId ?: config.flowId` through [provider], and answers via
 * `navigator.evaluateJavaScript` (main-thread-safe — never the library `callNative` callback
 * arg, per the module's threading rule). No provider / no target / a failed fetch leaves the
 * request unanswered — the harness's own promise then stays unresolved, keeping the
 * sub-component's placeholder up, exactly mirroring native's "no provider" / failure behavior.
 */
private fun handleFetchSubComponent(
    rawParams: String,
    provider: ScreenContractProvider?,
    externalCode: String?,
    mode: ThemeId,
    navigator: WebViewNavigator,
    scope: CoroutineScope,
    hostEventHandler: HostEventHandler,
) {
    val envelope = runCatching { Json.parseToJsonElement(rawParams).jsonObject }.getOrNull() ?: return
    val id = envelope["id"]?.jsonPrimitive?.contentOrNull ?: return
    val config = envelope["config"]?.jsonObject ?: JsonObject(emptyMap())
    val targetId = (config["componentId"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
        ?: config["flowId"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() })

    if (provider == null || targetId == null) return

    scope.launch {
        val embedded = runCatching { provider.getScreenContract(targetId, externalCode) }.getOrNull() ?: return@launch
        val (blockJson, unmapped) = WebBlockAdapter.toBlock(embedded.root, embedded.themeCatalog.byId(mode))
        reportUnmapped(unmapped, hostEventHandler)
        if (blockJson != null) {
            navigator.evaluateJavaScript(buildSubComponentResolution(id, blockJson.toString()))
        }
    }
}

/** Parses the shared `{heightPx}` shape both `rendered` and `height` carry. */
private fun heightPxFrom(rawParams: String): Int? =
    runCatching { Json.parseToJsonElement(rawParams).jsonObject["heightPx"]?.jsonPrimitive?.int }
        .getOrNull()

/**
 * Converts the harness's `scroll.offsetPx` — CSS px (`Math.round(scrollTop)`, the WebView
 * viewport's own coordinate space) — into the same unit [ScrollInfo.offsetPx] carries from
 * `:composeblocks`' native renderer: raw device px (`LazyListState.firstVisibleItemScrollOffset`
 * is measured in Compose's underlying pixel space, not dp). `density` is
 * `LocalDensity.current.density` (pixels per dp); rounds to the nearest px.
 */
internal fun cssPxToPhysicalPx(cssPx: Int, density: Float): Int =
    (cssPx * density).roundToInt()

private fun reportUnmapped(unmapped: List<UnmappedNode>, hostEventHandler: HostEventHandler) {
    if (unmapped.isEmpty()) return
    hostEventHandler.onHostEvent(
        HostEvent.Error(
            object : RenderBlockError(
                code = "WEBBLOCKS_UNMAPPED_NODE",
                message = "webblocks adapter could not map ${unmapped.size} node(s) to the web schema: " +
                    unmapped.joinToString { "${it.id}:${it.rawType}" },
            ) {},
        ),
    )
}

/**
 * Deliberately never invokes [IJsMessageHandler.handle]'s `callback` — the real harness
 * (`bridge.ts`: `callNative(method, paramsJson)`, no third `callback` argument at any of its
 * four call sites: `signalReady`/`signalRendered`/`signalHeight`/`emitEvent`) never registers
 * a callbackId for `ready`/`rendered`/`height`/`event`, so it never awaits or reads a reply.
 * Calling it anyway used to reply for nothing AND actively broke production: the library's
 * `WebViewJsBridge.onCallback` runs `evaluateJavaScript` from the JavaBridge thread (not
 * main), which Android's `WebView.evaluateJavascript` rejects
 * (`WebViewMethodCalledOnWrongThreadViolation`) — the thrown exception propagates back into
 * the WebView's JS engine as an uncaught, unattributable error (chromium console: "Java
 * exception was raised during method invocation"), which the harness's OWN
 * `window.addEventListener('error', ...)` genuinely (and correctly) reports as
 * `{kind:'error', payload:{fatal:true, message:"Script error."}}` — a spurious, self-inflicted
 * "fatal" on every single tap (confirmed end to end via a captured device logcat:
 * WebViewJsBridge.onCallback -> WebView.checkThread -> StrictMode violation -> chromium
 * "Java exception..." -> our own decoded fatal event). The composable's existing
 * `payload.fatal == true` filter (`handleEvent`, above) was already correct/principled; the
 * DATA feeding it was the defect. Not calling `callback` at all removes the defect at its
 * source instead of marshalling the reply to the main thread for an ACK nothing reads.
 */
private fun nativeMethodHandler(method: String, onParams: (String) -> Unit): IJsMessageHandler =
    object : IJsMessageHandler {
        override fun methodName(): String = method

        override fun handle(
            message: JsMessage,
            navigator: WebViewNavigator?,
            callback: (String) -> Unit,
        ) {
            // `callback` intentionally unused — see the doc comment above.
            onParams(message.params)
        }
    }
