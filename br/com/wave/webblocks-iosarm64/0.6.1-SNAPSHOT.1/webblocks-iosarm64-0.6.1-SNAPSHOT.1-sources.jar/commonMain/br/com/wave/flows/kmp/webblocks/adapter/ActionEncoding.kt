package br.com.wave.flows.kmp.webblocks.adapter

import br.com.wave.flows.kmp.core.contract.BackConfig
import br.com.wave.flows.kmp.core.contract.BlockAction
import br.com.wave.flows.kmp.core.contract.BlockActionTarget
import br.com.wave.flows.kmp.core.contract.DelegatedHostActionConfig
import br.com.wave.flows.kmp.core.contract.NavigateConfig
import br.com.wave.flows.kmp.core.contract.OpenUrlConfig
import br.com.wave.flows.kmp.core.contract.ShowHideConfig
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.putJsonObject

/**
 * Encodes [action] as the OUTBOUND (native -> web) web SDK `BlockAction`
 * (`common.ts:88-124`: `{type:"click", onAction, config}`, `config` shaped like
 * `BlockActionNavigate` etc. directly — no wrapper). This is the `block.action` field the
 * harness's `use-block-action.ts` reads back out (`action.config as BlockActionNavigate`,
 * flat, confirmed against that file) — do NOT confuse this with the INBOUND `navigate` event
 * the harness emits (`adapter/EventDecoding.kt`'s `decodeNavigation`), which wraps the same
 * fields one level deeper inside a `NavigationEvent` (`{type:'navigation', payload:{...}}`).
 * Conflating the two shapes was the root cause of a prior decode bug (see EventDecoding.kt).
 * `HOST_DELEGATED` emits `onAction:"hostDelegated"` with the opaque `rawJson` verbatim (web SDK
 * v1.2's one true additive change — `common.ts`'s widened `BlockAction` union +
 * `BlockActionHostDelegated`); the web `use-block-action.ts` `hostDelegated` case forwards it
 * to `onHostAction` unmodified.
 *
 * `BACK` and `OPEN_URL` have no dedicated `onAction` value in the current (non-deprecated)
 * union (`onAction: "navigate"|"show"|"hide"|"refresh"|"toggleThemeMode"` — no `"back"` or
 * `"openUrl"`); both route through `onAction:"navigate"` using the `NavigationType` members
 * that exist for exactly this (`"navigationBack"`, `"navigationExternal"`) instead of the
 * deprecated `BlockActionOld` union. `navigationExternal`'s destination has no dedicated
 * `url` field on `BlockActionNavigate` in the current union — the external URL is carried in
 * `navigationId`, the same generic string slot `NAVIGATE` uses for `destinationId`; this is
 * an inferred convention (verify against the harness once the real P1 bundle exists), not a
 * confirmed contract, and is called out in the mapping doc.
 */
internal fun encodeAction(action: BlockAction): JsonElement? =
    when (action.onAction) {
        BlockActionTarget.NAVIGATE -> {
            val config = action.config as NavigateConfig
            blockAction("navigate") {
                config.verbatim.element.forEach { (key, value) -> put(key, value) }
                val verbatimNavigationType = config.verbatim.element["navigationType"]?.jsonPrimitive?.contentOrNull
                put("navigationType", JsonPrimitive(verbatimNavigationType ?: "navigationComponent"))
                val verbatimNavigationId = config.verbatim.element["navigationId"]?.jsonPrimitive?.contentOrNull
                put("navigationId", JsonPrimitive(verbatimNavigationId ?: config.destinationId))
            }
        }

        BlockActionTarget.BACK -> {
            val config = action.config as BackConfig
            blockAction("navigate") {
                put("navigationType", JsonPrimitive("navigationBack"))
                put("referenceId", JsonPrimitive(config.referenceId))
            }
        }

        BlockActionTarget.OPEN_URL -> {
            val config = action.config as OpenUrlConfig
            blockAction("navigate") {
                put("navigationType", JsonPrimitive("navigationExternal"))
                put("navigationId", JsonPrimitive(config.externalDestinationUrl))
            }
        }

        BlockActionTarget.SHOW -> {
            val config = action.config as ShowHideConfig
            blockAction("show") { put("referenceId", JsonPrimitive(config.referenceId)) }
        }

        BlockActionTarget.HIDE -> {
            val config = action.config as ShowHideConfig
            blockAction("hide") { put("referenceId", JsonPrimitive(config.referenceId)) }
        }

        BlockActionTarget.REFRESH -> blockAction("refresh") {}

        BlockActionTarget.TOGGLE_THEME_MODE -> blockAction("toggleThemeMode") {}

        BlockActionTarget.HOST_DELEGATED -> {
            val config = action.config as DelegatedHostActionConfig
            blockAction("hostDelegated") { put("rawJson", JsonPrimitive(config.rawJson)) }
        }
    }

private fun blockAction(onAction: String, configBuilder: kotlinx.serialization.json.JsonObjectBuilder.() -> Unit) =
    buildJsonObject {
        put("type", JsonPrimitive("click"))
        put("onAction", JsonPrimitive(onAction))
        putJsonObject("config", configBuilder)
    }
