package br.com.wave.flows.kmp.webblocks

import br.com.wave.flows.kmp.runtime.RuntimeClock

/**
 * Gates repeated pull-to-refresh triggers within [windowMs] of the last accepted one.
 * Mirrors `:composeblocks`' `RenderBlockScreen` PTR cooldown intent (guard against rapid
 * re-pulls), scoped down to this module's single gesture (no per-block ledger needed —
 * a WebView screen has exactly one PTR surface, not one per action-bearing node).
 *
 * [clock] is injectable so tests can advance it deterministically instead of depending
 * on wall-clock delay.
 */
class RefreshCooldownGate(
    private val clock: RuntimeClock,
    private val windowMs: Long,
) {
    private var lastAcceptedAtMillis: Long? = null

    /** Returns `true` and records this instant if outside the cooldown window, else `false`. */
    fun tryTrigger(): Boolean {
        val now = clock.nowMillis()
        val last = lastAcceptedAtMillis
        if (last != null && now - last < windowMs) return false
        lastAcceptedAtMillis = now
        return true
    }
}
