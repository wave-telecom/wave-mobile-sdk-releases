package br.com.wave.flows.kmp.webblocks.adapter

import br.com.wave.flows.kmp.core.actions.NavigationEvent
import br.com.wave.flows.kmp.core.contract.VerbatimHostCallbackJson
import br.com.wave.flows.kmp.core.errors.RenderBlockError
import br.com.wave.flows.kmp.core.host.ActionData
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.theme.ThemeId
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Result of decoding an `event` envelope (`{v, kind, payload}`, spec §`event` envelope). */
internal sealed interface DecodedEvent {
    data class ForHost(val event: HostEvent) : DecodedEvent

    /**
     * `toggleThemeMode` is SDK-internal (mirrors `ActionResolution.ToggleThemeMode`) — the
     * composable consumes it directly (flip to [mode], re-adapt, re-push `render`), it is
     * never forwarded to [br.com.wave.flows.kmp.core.host.HostEventHandler]. [mode] is the
     * harness's OWN new mode (`renderHost.tsx`: `subscribeThemeToggle((mode) => emitEvent({
     * kind:'toggleThemeMode', payload:{mode} }))`) — the composable MUST adopt it (not just
     * re-push the old mode) or the harness's flip gets reset back by the next `render` call
     * (spec §3: harness resets its stores, including theme, on every `render`). `null` when
     * the payload is missing/malformed — the composable falls back to a local toggle.
     */
    data class ToggleTheme(val mode: ThemeId?) : DecodedEvent
}

private const val KIND_NAVIGATE = "navigate"
private const val KIND_ACTION_TRACKED = "actionTracked"
private const val KIND_ERROR = "error"
private const val KIND_REFRESH = "refresh"
private const val KIND_TOGGLE_THEME_MODE = "toggleThemeMode"
private const val KIND_HOST_DELEGATED = "hostDelegated"

private const val NAV_TYPE_BACK = "navigationBack"
private const val NAV_TYPE_EXTERNAL = "navigationExternal"
private const val NAV_TYPE_WEBVIEW = "navigationWebView"

/**
 * Decodes the `event` envelope into the SDK's [HostEvent] surface, or [DecodedEvent.ToggleTheme]
 * for the one SDK-internal kind. Unknown `kind`s are reported as a generic
 * [HostEvent.Error] rather than silently ignored — the harness contract is fixed
 * (`bridge-protocol-spec.md`), so an unrecognized kind means a spec/version mismatch, not a
 * variant the caller should shrug off.
 */
internal fun decodeEvent(envelope: JsonObject): DecodedEvent {
    val kind = envelope["kind"]?.jsonPrimitive?.contentOrNull
    val payload = envelope["payload"]?.jsonObject ?: JsonObject(emptyMap())

    return when (kind) {
        KIND_NAVIGATE -> DecodedEvent.ForHost(HostEvent.Navigation(decodeNavigation(payload)))
        KIND_ACTION_TRACKED -> DecodedEvent.ForHost(HostEvent.ActionTracked(decodeActionData(payload)))
        KIND_ERROR -> DecodedEvent.ForHost(HostEvent.Error(decodeError(payload)))
        KIND_REFRESH -> DecodedEvent.ForHost(HostEvent.Refresh)
        KIND_TOGGLE_THEME_MODE -> DecodedEvent.ToggleTheme(decodeToggleThemeMode(payload))
        KIND_HOST_DELEGATED -> DecodedEvent.ForHost(
            HostEvent.DelegatedHostAction(payload["rawJson"]?.jsonPrimitive?.contentOrNull.orEmpty()),
        )
        else -> DecodedEvent.ForHost(
            HostEvent.Error(
                object : RenderBlockError(
                    code = "WEB_HARNESS_UNKNOWN_EVENT",
                    message = "webblocks harness sent an unrecognized event kind: ${kind ?: "<missing>"}",
                ) {},
            ),
        )
    }
}

/**
 * The web `navigate` event is the `NavigationEvent` wrapper the harness's `onNavigate`
 * callback receives verbatim (`render/hooks/use-navigation.ts`: `{type:'navigation',
 * payload: NavigationPayload, extras?}`, `NavigationPayload = {navigationType, navigationId?,
 * nextScreenName?, modalReference?, navigationReference?}`) — the harness re-emits it
 * UNCHANGED as the envelope `payload` (`RenderRoot.tsx`: `onNavigate={(payload) =>
 * emitEvent({v:1, kind:'navigate', payload})}`). So `navigationEventWrapper` here is that
 * whole `{type,payload,extras?}` object; `navigationType`/`navigationId` live one level
 * deeper, under `navigationEventWrapper["payload"]` — NOT at this level (that was the
 * masked bug this function used to have: it read them flat, off the wrapper itself).
 * `navigationType` selects the [NavigationEvent] shape — `navigationBack` -> [NavigationEvent.Back],
 * `navigationExternal`/`navigationWebView` -> [NavigationEvent.External] (URL carried in
 * `navigationId`, the same inferred convention [br.com.wave.flows.kmp.webblocks.adapter.encodeAction]
 * uses when encoding outbound actions), anything else -> [NavigationEvent.Navigate].
 */
private fun decodeNavigation(navigationEventWrapper: JsonObject): NavigationEvent {
    val navigationPayload = navigationEventWrapper["payload"]?.jsonObject ?: JsonObject(emptyMap())
    val navigationType = navigationPayload["navigationType"]?.jsonPrimitive?.contentOrNull
    val navigationId = navigationPayload["navigationId"]?.jsonPrimitive?.contentOrNull.orEmpty()

    return when (navigationType) {
        NAV_TYPE_BACK -> NavigationEvent.Back
        NAV_TYPE_EXTERNAL, NAV_TYPE_WEBVIEW -> NavigationEvent.External(navigationId)
        else -> {
            // gap 3: `extras.config` (when present) IS the original BFF verbatim the outbound
            // adapter emitted (`ActionEncoding.kt`'s NAVIGATE case) — highest fidelity. Falls
            // back to the typed `navigationPayload` subset for older bundles that don't
            // forward it yet.
            val verbatimConfig = navigationEventWrapper["extras"]?.jsonObject?.get("config")?.jsonObject
            NavigationEvent.Navigate(
                nextComponentId = navigationId,
                verbatim = VerbatimHostCallbackJson(verbatimConfig ?: navigationPayload),
            )
        }
    }
}

/** `toggleThemeMode` payload is `{mode: 'light'|'dark'}` (`renderHost.tsx`: `subscribeThemeToggle
 * ((mode) => emitEvent({kind:'toggleThemeMode', payload:{mode}}))`). */
private fun decodeToggleThemeMode(payload: JsonObject): ThemeId? =
    payload["mode"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }?.let(::ThemeId)

private fun decodeActionData(payload: JsonObject): ActionData =
    ActionData(
        type = payload["type"]?.jsonPrimitive?.contentOrNull.orEmpty(),
        payload = (payload["payload"]?.jsonObject ?: JsonObject(emptyMap()))
            .mapValues { (_, v) -> (v as? JsonPrimitive)?.contentOrNull ?: v.toString() },
        timestamp = payload["timestamp"]?.jsonPrimitive?.contentOrNull.orEmpty(),
    )

private fun decodeError(payload: JsonObject): RenderBlockError {
    val code = payload["code"]?.jsonPrimitive?.contentOrNull ?: "WEB_HARNESS_ERROR"
    val message = payload["message"]?.jsonPrimitive?.contentOrNull ?: "webblocks harness reported an error"
    return object : RenderBlockError(code = code, message = message) {}
}
