package br.com.wave.flows.kmp.webblocks.adapter

import br.com.wave.flows.kmp.core.theme.FlowThemeCatalog
import br.com.wave.flows.kmp.core.theme.ThemeId
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject

/**
 * Reconstructs a web `ThemeContract` (`render-core/src/render/theme.ts:21-26`:
 * `{id, name, version, variables?: {default?, light?, dark?}}`) from [catalog] so the
 * harness's component-internal theme lookups (e.g. surface tokens) resolve the same way our
 * renderers do. Un-flattens each palette's `"group.token" -> hex` map into a nested
 * `ThemeVariableTree`. `JsonNull` when [catalog] is empty (no theme configured — matches the
 * render-time back-compat fallback to literal hex).
 *
 * `variables.default` is pinned to [mode] (the CURRENT mode of this specific `render` call),
 * not a fixed scope — safe by construction: [WebBlockAdapter.toRenderPayload] (and therefore
 * this function) is re-invoked on every `pushRender()`, including the one right after a
 * `toggleThemeMode` event adopts the harness's new mode (`RenderBlockWebScreen.kt`), so
 * `default` always re-resolves to whatever mode that render call carries — it cannot go stale
 * or fight the flipped mode.
 */
internal fun encodeThemeContract(catalog: FlowThemeCatalog, mode: ThemeId) =
    if (catalog.isEmpty()) {
        JsonNull
    } else {
        buildJsonObject {
            put("id", JsonPrimitive("catalog"))
            put("name", JsonPrimitive("wave-mobile-kmp"))
            put("version", JsonPrimitive("1"))
            putJsonObject("variables") {
                catalog.light?.let { put("light", unflattenTokens(it.tokens)) }
                catalog.dark?.let { put("dark", unflattenTokens(it.tokens)) }
                catalog.byId(mode)?.let { put("default", unflattenTokens(it.tokens)) }
            }
        }
    }

/** `{"group.token": "#fff"}` -> `{"group": {"token": "#fff"}}`. */
private fun unflattenTokens(tokens: Map<String, String>): JsonObject {
    val root = LinkedHashMap<String, Any>()

    for ((flatKey, hex) in tokens) {
        val parts = flatKey.split('.')
        var node = root
        for (part in parts.dropLast(1)) {
            @Suppress("UNCHECKED_CAST")
            node = node.getOrPut(part) { LinkedHashMap<String, Any>() } as LinkedHashMap<String, Any>
        }
        node[parts.last()] = hex
    }

    return toJsonObject(root)
}

@Suppress("UNCHECKED_CAST")
private fun toJsonObject(node: Map<String, Any>): JsonObject =
    buildJsonObject {
        for ((key, value) in node) {
            when (value) {
                is String -> put(key, JsonPrimitive(value))
                is Map<*, *> -> put(key, toJsonObject(value as Map<String, Any>))
                else -> error("Unexpected theme token node type: ${value::class}")
            }
        }
    }
