package br.com.wave.flows.kmp.webblocks.adapter

import br.com.wave.flows.kmp.core.contract.BlockType

/**
 * Total map from our [BlockType] to the web SDK's kebab-case `BlockType` string
 * (`packages/render-core/src/types/blocks/common.ts:156-178`). Returns `null` for a type
 * with no web equivalent — `TOOLBAR` (verified: absent from that union, though the web repo
 * carries an orphan `toolbar.ts`/`ToolbarBlockConfig` not wired into `BlockType`/
 * `AnyBlockConfig`) and `UNKNOWN`. Callers must record a null result as an
 * [br.com.wave.flows.kmp.webblocks.adapter.UnmappedNode] and omit the node — never invent a
 * foreign web type or silently drop it unreported.
 */
internal fun webTypeToken(type: BlockType): String? =
    when (type) {
        BlockType.TEXT -> "text"
        BlockType.RICH_TEXT -> "rich-text"
        BlockType.BUTTON -> "button"
        BlockType.CARD -> "card"
        BlockType.CONTAINER -> "container"
        BlockType.GRID -> "grid"
        BlockType.LIST -> "list"
        BlockType.DIVIDER -> "divider"
        BlockType.IMAGE -> "image"
        BlockType.RADIO_GROUP -> "radio-group"
        BlockType.SKELETON -> "skeleton"
        BlockType.SUB_COMPONENT -> "sub-component"
        BlockType.CAROUSEL -> "carousel"
        BlockType.CHART -> "chart"
        BlockType.TABS -> "tabs"
        BlockType.BOTTOM_SHEET -> "bottom-sheet"
        BlockType.ACCORDION -> "accordion"
        BlockType.SPACER -> "spacer"
        BlockType.TOOLBAR -> null
        BlockType.UNKNOWN -> null
    }
