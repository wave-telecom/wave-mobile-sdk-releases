package br.com.wave.flows.kmp.webblocks.adapter

import br.com.wave.flows.kmp.core.contract.BlockStyle
import br.com.wave.flows.kmp.core.theme.ThemePalette
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive

/**
 * Flattens [style] onto the web `BlockStyleConfig`
 * (`packages/render-core/src/types/blocks/common.ts:32-64`). Only fields with a confirmed
 * web slot are emitted — absent/native-only fields are omitted, never invented as unknown
 * keys (determinism spec: no unknown keys, no `null` keys).
 *
 * `position`/`top`/`right`/`bottom`/`left`/`zIndex`/`maxWidth`/`fullWidth` have no
 * [BlockStyle] role for most block types (they live on typed per-block-config fields on the
 * web side — e.g. `ContainerBlockConfig`/`ImageBlockConfig` — not on the shared style), so
 * they are handled per-config, not here; see the config encoders (Commit 2, step 12) and the
 * technical-debt watchlist for the subset that has no web slot at all.
 */
internal fun encodeStyle(style: BlockStyle, palette: ThemePalette?): Map<String, JsonElement> {
    val out = LinkedHashMap<String, JsonElement>()

    style.margin?.let { out["margin"] = JsonPrimitive(it) }
    style.marginTop?.let { out["marginTop"] = JsonPrimitive(it) }
    style.marginBottom?.let { out["marginBottom"] = JsonPrimitive(it) }
    style.marginLeft?.let { out["marginLeft"] = JsonPrimitive(it) }
    style.marginRight?.let { out["marginRight"] = JsonPrimitive(it) }
    style.padding?.let { out["padding"] = JsonPrimitive(it) }
    style.paddingTop?.let { out["paddingTop"] = JsonPrimitive(it) }
    style.paddingBottom?.let { out["paddingBottom"] = JsonPrimitive(it) }
    style.paddingLeft?.let { out["paddingLeft"] = JsonPrimitive(it) }
    style.paddingRight?.let { out["paddingRight"] = JsonPrimitive(it) }
    style.borderWidth?.let { out["borderWidth"] = JsonPrimitive(it) }
    style.borderStyle?.let { out["borderStyle"] = JsonPrimitive(it) }
    style.width?.let { out["width"] = JsonPrimitive(it) }
    style.height?.let { out["height"] = JsonPrimitive(it) }
    style.visibility?.let { out["visibility"] = JsonPrimitive(it) }

    style.borderRadius?.let { out["borderRadius"] = JsonPrimitive(it) }
    // Deprecated web edge names, but present in the interface with this exact spelling —
    // the only slot our per-edge radii have.
    style.borderRadiusTop?.let { out["borderRadiusTop"] = JsonPrimitive(it) }
    style.borderRadiusBottom?.let { out["borderRadiusBottom"] = JsonPrimitive(it) }
    style.borderRadiusLeft?.let { out["borderRadiusLeft"] = JsonPrimitive(it) }
    style.borderRadiusRight?.let { out["borderRadiusRight"] = JsonPrimitive(it) }

    style.borderColorHex?.let { out["borderColor"] = JsonPrimitive(resolveColor(it, palette)) }
    style.backgroundColorHex?.let { out["backgroundColor"] = JsonPrimitive(resolveColor(it, palette)) }
    style.colorHex?.let { out["color"] = JsonPrimitive(resolveColor(it, palette)) }

    return out
}

/**
 * Resolves a `@{token}` reference to its literal hex via [palette] (mirrors
 * [ThemePalette.resolveReference] semantics exactly, per the adapter's determinism
 * decision); plain hex (or an unresolved reference) passes through unchanged.
 */
internal fun resolveColor(raw: String, palette: ThemePalette?): String = palette?.resolveReference(raw) ?: raw
