package br.com.wave.flows.kmp.webblocks.adapter

import br.com.wave.flows.kmp.core.contract.BlockConfig
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.BlockStateEffect
import br.com.wave.flows.kmp.core.contract.BlockStyle
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.SubComponentBlockConfig
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.theme.ThemeId
import br.com.wave.flows.kmp.core.theme.ThemePalette
import br.com.wave.flows.kmp.webblocks.adapter.config.encodeTypeFields
import br.com.wave.flows.kmp.webblocks.adapter.config.encodeVariants
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.putJsonObject

/** A [BlockNode] the adapter could not represent in the web schema — omitted, never invented. */
data class UnmappedNode(val id: String, val rawType: String)

data class AdapterResult(val payload: JsonObject, val unmapped: List<UnmappedNode>)

/**
 * Pure `ScreenContract` -> web SDK `render` payload envelope adapter
 * (`bridge-protocol-spec.md` §`render` payload envelope). Zero Compose/WebView/ktor
 * imports — stays unit-testable and reusable by the parity battery; this separation is
 * load-bearing and must not be collapsed (see the module's SOLID notes).
 *
 * Public (not `internal`): the P4 web-vs-Compose parity battery
 * (`flowsSampleApp/src/androidInstrumentedTest`) calls [toRenderPayload] directly to feed
 * the exact production payload into a test-owned `WebView`. This is a narrow, inert
 * widening — a pure JSON mapper with no diagnostics/logging — not a debug/diagnostic
 * capability (see `plan-p4-battery.md`'s SOLID notes and the P4 change report).
 */
object WebBlockAdapter {
    fun toRenderPayload(
        contract: ScreenContract,
        mode: ThemeId,
        animationsEnabled: Boolean = false,
        visibilityOverrides: Map<String, Boolean>? = null,
        embeddedContracts: Map<String, ScreenContract> = emptyMap(),
    ): AdapterResult {
        val palette = contract.themeCatalog.byId(mode)
        val unmapped = mutableListOf<UnmappedNode>()
        val block = encodeBlock(contract.root, palette, unmapped, mode, visibilityOverrides, embeddedContracts)

        val payload = buildJsonObject {
            put("v", JsonPrimitive(1))
            put("block", block ?: JsonNull)
            putJsonObject("theme") {
                put("contract", encodeThemeContract(contract.themeCatalog, mode))
                put("mode", JsonPrimitive(mode.value))
            }
            putJsonObject("options") {
                put("externalCode", JsonNull)
                put("animationsEnabled", JsonPrimitive(animationsEnabled))
            }
        }

        return AdapterResult(payload, unmapped)
    }

    /**
     * Pure widening of [encodeBlock] for gap 2 (sub-component fetch): encodes a bare web
     * `Block` — NOT the `{v,block,theme,options}` render envelope, since the harness's
     * `fetchSubComponentBlocks` resolves to `Block<AnyBlockConfig>` directly
     * (`RenderProvider.tsx`). Zero Compose/WebView/ktor imports — same adapter purity as
     * [toRenderPayload].
     */
    fun toBlock(
        root: BlockNode,
        palette: ThemePalette?,
        mode: ThemeId? = palette?.id,
    ): Pair<JsonElement?, List<UnmappedNode>> {
        val unmapped = mutableListOf<UnmappedNode>()
        return encodeBlock(root, palette, unmapped, mode) to unmapped
    }

    /**
     * Recursively encodes [node] as the web `Block` shape
     * (`common.ts:24-30`: `{id, type, config, children?, action?}`). Returns `null` when
     * [node]'s type has no web equivalent — the caller (this function, for children; the
     * root case is handled by [toRenderPayload]) records it in [unmapped] and omits it from
     * its parent's `children` rather than emit a broken/foreign node.
     */
    private fun encodeBlock(
        node: BlockNode,
        palette: ThemePalette?,
        unmapped: MutableList<UnmappedNode>,
        mode: ThemeId? = palette?.id,
        visibilityOverrides: Map<String, Boolean>? = null,
        embeddedContracts: Map<String, ScreenContract> = emptyMap(),
    ): JsonElement? {
        // A sub-component reference whose target is embedded merges the embedded root
        // subtree in place of the reference node — the pure-adapter equivalent of
        // `ViewBlockRenderer.render`'s inline embedding, avoiding a second `render` round
        // trip. No matching embedded contract falls through to the reference's own
        // encoding (current behavior).
        //
        // Theme: the embedded subtree renders with the EMBEDDED contract's own palette
        // when its `themeCatalog` is non-empty, falling back to the outer [palette]
        // otherwise (`FlowThemeCatalog.empty()` = "no theme configured" per its own doc) —
        // an embedded contract with its own theme must not be forced into the host's.
        //
        // Id collisions: node ids are encoded verbatim from whichever contract produced
        // them, so within the embedded subtree the EMBEDDED contract's ids always win
        // (they simply replace the reference node in the tree); an id collision between
        // the embedded subtree and the OUTER tree is the embedding host's responsibility
        // to avoid (mirrors `ViewBlockRenderer.render`, which has no dedup either).
        val subComponentConfig = node.config as? SubComponentBlockConfig
        if (node.type == BlockType.SUB_COMPONENT && subComponentConfig != null) {
            val targetId = subComponentConfig.componentId?.takeIf { it.isNotBlank() }
                ?: subComponentConfig.flowId?.takeIf { it.isNotBlank() }
            val embedded = targetId?.let { embeddedContracts[it] }
            if (embedded != null) {
                val embeddedPalette = mode
                    ?.let { m -> embedded.themeCatalog.takeIf { it.isNotEmpty() }?.byId(m) }
                    ?: palette
                return encodeBlock(embedded.root, embeddedPalette, unmapped, mode, visibilityOverrides, embeddedContracts)
            }
        }

        val webType = webTypeToken(node.type)
        if (webType == null) {
            unmapped += UnmappedNode(node.id, node.type.name)
            return null
        }

        val encodedChildren = node.children.mapNotNull {
            encodeBlock(it, palette, unmapped, mode, visibilityOverrides, embeddedContracts)
        }
        val override = visibilityOverrides?.get(node.id)
        val style = styleToEncode(node.config).let { if (override != null) it.copy(visibility = override) else it }

        return buildJsonObject {
            put("id", JsonPrimitive(node.id))
            put("type", JsonPrimitive(webType))
            putJsonObject("config") {
                encodeStyle(style, palette).forEach { (k, v) -> put(k, v) }
                encodeTypeFields(node.config, palette).forEach { (k, v) -> put(k, v) }
                node.config.stateEffect?.let { put("stateEffect", encodeStateEffect(it)) }
                encodeVariants(node.config, palette)?.let { put("variants", it) }
            }
            if (encodedChildren.isNotEmpty()) put("children", JsonArray(encodedChildren))
            node.action?.let { action -> encodeAction(action)?.let { put("action", it) } }
        }
    }

    /**
     * The [BlockStyle] to feed [encodeStyle] for [config] — [BlockConfig.style] for every
     * type except `tabs`, which needs the un-split style reconstructed from [TabsBlockConfig.chipStyle].
     *
     * The native parser (`KotlinxContractDtoParser.mapTabsConfig`) relocates the BFF's flat
     * chip `backgroundColor`/`border*`/`borderRadius*`/`padding*` from `style` into `chipStyle`
     * and nulls those exact fields on `style` — a native-rendering-only transform (the bar
     * must stay transparent/borderless so it doesn't inflate the gap to the content below).
     * The web `Tabs` component has no such split: it reads those fields flat off `config`
     * (`tabs-adapter/index.tsx`: `{...config}` spread straight into the component, and
     * `TabsBlockConfig` in `types/blocks/tabs.ts` carries no separate chip-style field — only
     * a distinct `containerBorder*` set for the BAR's own border, confirming the plain
     * `border*`/`borderRadius*`/`backgroundColor`/`padding*` fields are chip-level on the web
     * side too). Un-splitting here — restoring the exact fields the parser stripped, from
     * [TabsBlockConfig.chipStyle] — is web-adapter-local; the parser itself is unchanged
     * because the split is genuinely required for the native renderers.
     *
     * `margin*`/`width`/`height`/`visibility`/`colorHex`/positioning are untouched by the
     * parser's split (present, identical, on both `style` and `chipStyle`) and are taken from
     * the bar's own `style` either way — this only restores the fields the split actually
     * zeroed, never inventing a value the contract didn't send.
     */
    private fun styleToEncode(config: BlockConfig): BlockStyle =
        if (config is TabsBlockConfig) {
            config.style.copy(
                backgroundColorHex = config.chipStyle.backgroundColorHex,
                borderColorHex = config.chipStyle.borderColorHex,
                borderWidth = config.chipStyle.borderWidth,
                borderStyle = config.chipStyle.borderStyle,
                borderRadius = config.chipStyle.borderRadius,
                borderRadiusTop = config.chipStyle.borderRadiusTop,
                borderRadiusBottom = config.chipStyle.borderRadiusBottom,
                borderRadiusLeft = config.chipStyle.borderRadiusLeft,
                borderRadiusRight = config.chipStyle.borderRadiusRight,
                padding = config.chipStyle.padding,
                paddingTop = config.chipStyle.paddingTop,
                paddingBottom = config.chipStyle.paddingBottom,
                paddingLeft = config.chipStyle.paddingLeft,
                paddingRight = config.chipStyle.paddingRight,
            )
        } else {
            config.style
        }

    private fun encodeStateEffect(effect: BlockStateEffect): JsonElement =
        buildJsonObject {
            put("type", JsonPrimitive(effect.type))
            put("referenceId", JsonPrimitive(effect.referenceId))
            put("property", JsonPrimitive(effect.property))
            effect.payloadKey?.let { put("payloadKey", JsonPrimitive(it)) }
        }
}
