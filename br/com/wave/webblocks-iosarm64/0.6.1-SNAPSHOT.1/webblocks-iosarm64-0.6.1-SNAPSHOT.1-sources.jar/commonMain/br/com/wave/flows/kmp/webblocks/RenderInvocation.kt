package br.com.wave.flows.kmp.webblocks

import kotlinx.serialization.json.JsonObject

/**
 * Builds the exact `window.waveRenderHost.render(...)` call to hand to
 * `WebViewNavigator.evaluateJavaScript`. The real harness's `render(a)` does `JSON.parse(a)`
 * internally (confirmed by reading the committed bundle) — it expects [payloadJson] as a JSON
 * **string**, not a bare object literal. Embedding the object literal directly (this
 * function's prior behavior, and the bug this fixes) makes `a` an object; `JSON.parse`
 * coerces it to the literal text `"[object Object]"` first and throws, failing every
 * production render. [payloadJson] is re-encoded as a properly escaped JS string literal so
 * `a` arrives as the string `render` actually needs.
 *
 * Public (not `internal`), for the same reason [br.com.wave.flows.kmp.webblocks.adapter.WebBlockAdapter]
 * is: the P4 web-vs-Compose parity battery's `WebCandidateHost`
 * (`flowsSampleApp/src/androidInstrumentedTest`) calls this SAME function so its render calls
 * are byte-identical to production's — one escaping path, not two that could silently drift
 * apart.
 */
fun buildRenderInvocation(payloadJson: String): String =
    "window.waveRenderHost.render(${payloadJson.toJsStringLiteral()})"

/** [buildRenderInvocation] overload for callers holding the parsed envelope, not its text. */
fun buildRenderInvocation(payload: JsonObject): String = buildRenderInvocation(payload.toString())

/**
 * Builds the `window.waveRenderHost.resolveSubComponent(id, blockJson)` call answering a
 * `fetchSubComponent` request (gap 2, bridge-protocol-spec v1.2). [id] correlates the
 * response to the request the harness made; [blockJson] is the bare web `Block` JSON
 * ([WebBlockAdapter.toBlock]'s output, stringified). The harness `JSON.parse`s its second
 * argument (same contract as `render`), so both arguments are escaped as JS string literals
 * via the SAME escaper [buildRenderInvocation] uses — one escaping path, not two.
 */
fun buildSubComponentResolution(id: String, blockJson: String): String =
    "window.waveRenderHost.resolveSubComponent(${id.toJsStringLiteral()}, ${blockJson.toJsStringLiteral()})"

/**
 * Escapes [this] into a JS double-quoted string literal. Order matters: backslash first, so
 * escaping the quote/line-separator characters afterward doesn't double-escape the backslash
 * that operation itself introduces. `U+2028`/`U+2029` (LINE/PARAGRAPH SEPARATOR) are escaped
 * because some JS engines still treat them as statement terminators even inside a string
 * literal, which would truncate the call mid-argument.
 */
private fun String.toJsStringLiteral(): String {
    val escaped = this
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace(" ", "\\u2028")
        .replace(" ", "\\u2029")
    return "\"$escaped\""
}
