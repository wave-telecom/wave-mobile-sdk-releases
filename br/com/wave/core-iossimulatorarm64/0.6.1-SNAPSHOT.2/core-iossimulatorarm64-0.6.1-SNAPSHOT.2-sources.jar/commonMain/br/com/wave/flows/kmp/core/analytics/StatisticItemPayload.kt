package br.com.wave.flows.kmp.core.analytics

import br.com.wave.flows.kmp.core.contract.AccordionBlockConfig
import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.contract.ToolbarBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

/**
 * Payload keys mirroring the client's Adobe Analytics `StatisticItem` vocabulary
 * (name/type/position/ubication/category/subcategory), so the host can fill its
 * model 1:1 without the SDK depending on any analytics vendor type.
 */
object StatisticPayloadKeys {
    const val BLOCK_ID = "blockId"
    const val NAME = "name"
    const val TYPE = "type"
    const val POSITION = "position"
    const val UBICATION = "ubication"
    const val CATEGORY = "category"
    const val SUBCATEGORY = "subcategory"
}

// Doc-stated fold set only: accented Latin vowels + ñ/Ñ, plus comma removal.
// commonMain has no java.text.Normalizer, so this is a literal lookup instead.
private val ACCENT_FOLD_MAP = mapOf(
    'á' to 'a', 'é' to 'e', 'í' to 'i', 'ó' to 'o', 'ú' to 'u',
    'Á' to 'A', 'É' to 'E', 'Í' to 'I', 'Ó' to 'O', 'Ú' to 'U',
    'ñ' to 'n', 'Ñ' to 'N',
)

fun sanitizeStatisticName(raw: String): String =
    raw
        .map { ACCENT_FOLD_MAP[it] ?: it }
        .joinToString("")
        .replace(",", "")
        .trim()

// LIST is deliberately absent: it is layout scaffolding (screen roots, sections,
// card innards), never a semantic container, so it can never surface as "Lista".
private val SEMANTIC_CONTAINER_TYPES = setOf(BlockType.CAROUSEL, BlockType.GRID)

fun mapComponentType(type: BlockType): String = when (type) {
    BlockType.CAROUSEL -> "Carrusel"
    BlockType.GRID -> "Mosaico"
    else -> "Único"
}

fun deriveComponentName(block: BlockNode): String {
    val ownName = when (val config = block.config) {
        is TextBlockConfig -> config.value
        is ButtonBlockConfig -> config.value
        is ToolbarBlockConfig -> config.title
        is AccordionBlockConfig -> config.title ?: ""
        is RichTextBlockConfig -> config.segments.joinToString(" ") { it.text }
        else -> ""
    }
    if (ownName.isNotBlank()) return ownName

    for (child in block.children) {
        val childName = deriveComponentName(child)
        if (childName.isNotBlank()) return childName
    }
    return ""
}

fun ubicationFor(topLevelIndex: Int, topLevelCount: Int): String = when {
    topLevelCount <= 1 || topLevelIndex == 0 -> "Principal"
    topLevelIndex == topLevelCount - 1 -> "Inferior"
    else -> "Medio"
}

internal data class StatisticLocation(
    val position: Int,
    val topLevelIndex: Int,
    val topLevelCount: Int,
    val containerType: BlockType? = null,
)

/**
 * Walks root->target and returns the nearest-ancestor-first chain of
 * (ancestorType, indexOfChildOnThePathWithinThatAncestor), ending with the
 * root/top-level entry. Null when [targetId] is not found under [root].
 */
private fun ancestorChain(root: ResolvedRenderNode, targetId: String): List<Pair<BlockType, Int>>? {
    fun search(node: ResolvedRenderNode): List<Pair<BlockType, Int>>? {
        node.children.forEachIndexed { index, child ->
            if (child.block.id == targetId) return listOf(node.block.type to index)
            search(child)?.let { return it + (node.block.type to index) }
        }
        return null
    }
    return search(root)
}

internal fun locateStatistic(root: ResolvedRenderNode, targetId: String): StatisticLocation? {
    val topLevelCount = root.children.size
    val chain = ancestorChain(root, targetId) ?: return null
    val topLevelIndex = chain.last().second
    val semanticAncestor = chain.firstOrNull { it.first in SEMANTIC_CONTAINER_TYPES }
    val position = semanticAncestor?.second ?: chain.first().second
    return StatisticLocation(
        position = position + 1,
        topLevelIndex = topLevelIndex,
        topLevelCount = topLevelCount,
        containerType = semanticAncestor?.first,
    )
}

fun buildStatisticItemPayload(root: ResolvedRenderNode, target: ResolvedRenderNode): Map<String, String> {
    val location = locateStatistic(root, target.block.id)
    val type = location?.containerType?.let(::mapComponentType) ?: "Único"
    return mapOf(
        StatisticPayloadKeys.BLOCK_ID to target.block.id,
        StatisticPayloadKeys.NAME to sanitizeStatisticName(deriveComponentName(target.block)),
        StatisticPayloadKeys.TYPE to type,
        StatisticPayloadKeys.POSITION to (location?.position?.toString() ?: "1"),
        StatisticPayloadKeys.UBICATION to (
            location?.let { ubicationFor(it.topLevelIndex, it.topLevelCount) } ?: "Principal"
            ),
        StatisticPayloadKeys.CATEGORY to "N/A",
        StatisticPayloadKeys.SUBCATEGORY to "N/A",
    )
}
