package br.com.wave.flows.kmp.core.visibility

import br.com.wave.flows.kmp.core.contract.BlockNode
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.contract.BlockType

/**
 * Walks the block tree and seeds an initial [VisibilityState] from each
 * block's `config.style.visibility` value when it is explicitly set.
 *
 * Blocks without an explicit visibility remain absent from the state and
 * therefore default to visible via [isBlockVisible].
 */
fun buildInitialVisibilityState(root: BlockNode): VisibilityState {
    val state = mutableMapOf<String, Boolean>()
    val tabConfigs = mutableListOf<TabsBlockConfig>()
    collectVisibility(root, state, tabConfigs)
    applyInitialTabVisibility(state, tabConfigs)
    return state
}

private fun collectVisibility(
    node: BlockNode,
    state: MutableMap<String, Boolean>,
    tabConfigs: MutableList<TabsBlockConfig>,
) {
    node.config.style.visibility?.let { state[node.id] = it }
    if (node.type == BlockType.TABS) {
        // `stateEffect`-bearing tabs (Part B) don't own content-pane visibility —
        // their `contentReferenceId`s are carousel slides, all of which must stay
        // visible. Seeding them here would prune every slide but the first.
        (node.config as? TabsBlockConfig)?.takeIf { it.stateEffect == null }?.let(tabConfigs::add)
    }
    for (child in node.children) {
        collectVisibility(child, state, tabConfigs)
    }
}

private fun applyInitialTabVisibility(
    state: MutableMap<String, Boolean>,
    tabConfigs: List<TabsBlockConfig>,
) {
    for (config in tabConfigs) {
        val activeContentId = config.options.firstOrNull()?.contentReferenceId ?: continue
        config.options.forEach { option ->
            state[option.contentReferenceId] = option.contentReferenceId == activeContentId
        }
    }
}
