package br.com.wave.flows.kmp.core.contract

sealed interface BlockConfig {
    val style: BlockStyle
    val stateEffect: BlockStateEffect? get() = null
}

/**
 * Generic cross-block sync declaration (web's `stateEffect`): on a local
 * gesture, the owning block also writes [property] on the block identified by
 * [referenceId] through the shared `RenderBlockInteractionCache` property
 * channel. [type] is only ever `"setProperty"` today (validated at parse
 * time); [payloadKey] documents which part of the source event the value
 * comes from (e.g. tapped option index) but carries no runtime behavior of
 * its own — the caller always passes the resolved `Int`.
 * Sync assumes the paired blocks declare the SAME [property] name on both
 * sides (the wire contract does); a mismatch silently yields two independent
 * slots with no sync — an unvalidated assumption, not enforced at runtime
 * (the web reference behaves the same way).
 */
data class BlockStateEffect(
    val type: String,
    val property: String,
    val referenceId: String,
    val payloadKey: String? = null,
)

data class TextBlockConfig(
    val value: String,
    override val style: BlockStyle = BlockStyle(),
    val fontSizeSp: Int? = null,
    val lineHeightSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val align: String? = null,
    val strikethrough: Boolean = false,
    val truncate: Boolean = false,
) : BlockConfig

/**
 * Mirror of the web `RichText` block — a paragraph composed of styled
 * inline segments. Block-level font props apply as defaults; each
 * segment can override them and add color / decoration. The block value
 * is the paragraph's line-height and a segment may raise it, mirroring
 * `rich-text/index.tsx`'s `<p>`/`<span>` split.
 */
data class RichTextBlockConfig(
    override val style: BlockStyle = BlockStyle(),
    val segments: List<RichTextSegment> = emptyList(),
    val fontSizeSp: Int? = null,
    val lineHeightSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val color: String? = null,
    val align: String? = null,
    val strikethrough: Boolean = false,
    val truncate: Boolean = false,
) : BlockConfig

data class RichTextSegment(
    val text: String,
    val fontSizeSp: Int? = null,
    val lineHeightSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val color: String? = null,
    val strikethrough: Boolean = false,
    val underline: Boolean = false,
)

data class ButtonBlockConfig(
    val value: String,
    override val style: BlockStyle = BlockStyle(),
    val fontSizeSp: Int? = null,
    val lineHeightSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val align: String? = null,
) : BlockConfig

data class CardBlockConfig(
    override val style: BlockStyle = BlockStyle(),
    val elevation: Int? = null,
    // Web slot: `CardBlockConfig.minHeight` (render-core/src/types/blocks/card.ts:5),
    // applied by the Card component as an inline `min-height`
    // (flows-base-components-web/src/components/card/index.tsx:76) over a flex
    // column that is `justify-content: center` (components/card/styles.module.css:4)
    // — hence min height AND centering of the leftover.
    val minHeightDp: Int? = null,
    // `variants.selected.backgroundColor` from the contract: applied only to this
    // card when it is the selected item of a radio-group, so the highlight stays on
    // the block that declares it (e.g. the icon wrapper) instead of the whole item.
    val selectedBackgroundColorHex: String? = null,
    // `variants.selected.borderRadius`: the selected pill's corner radius. The base
    // style carries no radius (the wrapper is a no-op until selected), so the rounded
    // "pill" shape only exists in the selected variant and must be applied alongside
    // `selectedBackgroundColorHex` when active.
    val selectedBorderRadius: Int? = null,
    // `variants.disabled.{color,backgroundColor}` from the contract: the colours the
    // card (and its text/icon children) take while disabled. A `refresh`-action card
    // disables itself for a cooldown window right after it is tapped, painting these.
    val disabledColorHex: String? = null,
    val disabledBackgroundColorHex: String? = null,
) : BlockConfig

data class ContainerBlockConfig(
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class GridBlockConfig(
    val columns: Int = 1,
    val gap: Int = 0,
    val maxColumnSize: Int? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ListBlockConfig(
    val spacing: Int,
    val orientation: BlockOrientation,
    val align: String? = null,
    val verticalAlign: String? = null,
    val horizontalAlign: String? = null,
    val expand: Boolean = false,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class DividerBlockConfig(
    val orientation: BlockOrientation,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ImageBlockConfig(
    val url: String,
    val altText: String? = null,
    val aspectRatio: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val align: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class RadioGroupBlockConfig(
    val orientation: BlockOrientation,
    val activeIndex: Int? = null,
    val activeColorHex: String? = null,
    val activeBackgroundColorHex: String? = null,
    val spacing: Int = 0,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class CarouselBlockConfig(
    val itemWidth: Int,
    val showIndicators: Boolean,
    val showButtons: Boolean? = null,
    val spacing: Int = 0,
    override val style: BlockStyle = BlockStyle(),
    override val stateEffect: BlockStateEffect? = null,
) : BlockConfig

data class ChartDataPoint(
    val key: String,
    val value: Int,
    val fill: String,
)

data class ChartBlockConfig(
    val type: String,
    val data: List<ChartDataPoint>,
    val size: Int,
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    val lineHeightSp: Int? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class SpacerBlockConfig(
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class ToolbarBlockConfig(
    val title: String,
    val align: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class TabOption(
    val id: String,
    val label: String,
    val contentReferenceId: String,
)

data class TabsBlockConfig(
    val options: List<TabOption>,
    val gap: Int = 0,
    val activeColorHex: String? = null,
    val activeBackgroundColorHex: String? = null,
    val inactiveColorHex: String? = null,
    val inactiveBackgroundColorHex: String? = null,
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    // Line height of the chip label. When the contract omits it the renderer
    // falls back to a default; when present it is honored like any other text.
    val lineHeightSp: Int? = null,
    // Padding/borderRadius on a `tabs` block describe each chip, not the bar.
    // They're stripped from [style] (the bar) and carried here for the chips.
    val chipStyle: BlockStyle = BlockStyle(),
    override val style: BlockStyle = BlockStyle(),
    override val stateEffect: BlockStateEffect? = null,
) : BlockConfig

data class BottomSheetBlockConfig(
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class AccordionBlockConfig(
    val title: String? = null,
    val defaultOpen: Boolean = false,
    val iconColorHex: String? = null,
    val iconUrl: String? = null,
    val iconWidth: Int? = null,
    val iconHeight: Int? = null,
    val wrapContent: Boolean? = null,
    val fullWidth: Boolean? = null,
    val fontSizeSp: Int? = null,
    val fontFamily: String? = null,
    val fontWeight: Int? = null,
    val fontStyle: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

/**
 * Embeds another component or flow inline. At render time the target's block tree is
 * fetched via [componentId] / [flowId] and rendered in place; the block's own [children]
 * are shown as the placeholder while that fetch is in flight.
 */
data class SubComponentBlockConfig(
    val componentId: String? = null,
    val flowId: String? = null,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig

data class UnknownBlockConfig(
    val rawType: String?,
    override val style: BlockStyle = BlockStyle(),
) : BlockConfig
