package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.18-SNAPSHOT"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-06-29T12:38:04.862971-03:00"
    const val GIT_SHA: String = "8ab9fc9"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.18-SNAPSHOT@2026-06-29T12:38:04.862971-03:00#8ab9fc9"
}