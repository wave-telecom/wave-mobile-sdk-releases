package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import br.com.wave.flow_wrapper_kmp.featureflags.ContractFeatureFlagProvider
import br.com.wave.flow_wrapper_kmp.featureflags.Feature
import br.com.wave.flow_wrapper_kmp.featureflags.FeatureFlags
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRouting
import br.com.wave.flow_wrapper_kmp.renderrouting.RenderRoutingSessionContext

private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"
private const val NAVBAR_FLOW_PATH = "/flows/navbar"
private const val NAVBAR_CURRENT_PAGE_QUERY_PARAM = "currentPage"
private const val NAVBAR_NEXT_COMPONENT_ID_FIELD = "nextComponentId"
private const val NAVBAR_COMPONENT_SCREEN_TOKEN = "-screen-"

internal data class RuntimeConfig(
    val msisdn: String,
    val apiKey: String,
    val environment: FlowWrapperEnvironment,
    val flowWrapperConfig: FlowWrapperConfig,
)

/** Maps the wrapper's host theme mode to the native SDK's equivalent (1:1). */
internal fun FlowThemeMode.toNativeThemeMode(): br.com.wave.flows.kmp.FlowThemeMode =
    when (this) {
        FlowThemeMode.System -> br.com.wave.flows.kmp.FlowThemeMode.System
        FlowThemeMode.Light -> br.com.wave.flows.kmp.FlowThemeMode.Light
        FlowThemeMode.Dark -> br.com.wave.flows.kmp.FlowThemeMode.Dark
    }

object FlowWrapper {
    private var runtimeConfig: RuntimeConfig? = null
    private var warmupHandle: FlowWrapperWarmupHandle? = null
    private var warmupGeneration: Long = 0
    private var navbarCurrentPage: String? = null
    private val themeModeState = mutableStateOf(FlowThemeMode.System)
    private val webViewRefreshTicks = mutableStateMapOf<String, Int>()      // requested (observable: wakes a composed block)
    private val webViewAppliedRefreshTicks = mutableMapOf<String, Int>()    // applied (plain: consuming it must NOT recompose)

    internal fun resetForTests() {
        warmupHandle?.cancel()
        warmupHandle = null
        runtimeConfig = null
        warmupGeneration = 0
        navbarCurrentPage = null
        themeModeState.value = FlowThemeMode.System
        webViewRefreshTicks.clear()
        webViewAppliedRefreshTicks.clear()
        flowWrapperWarmupLauncher = DefaultFlowWrapperWarmupLauncher
        nativeRenderBridgeDelegate = DefaultNativeRenderBridgeDelegate
        DefaultNativeRenderBridgeDelegate.reset()
        RenderRouting.resetForTests()
        FeatureFlags.resetForTests()
        br.com.wave.flows.kmp.FlowWrapper.resetThemeForTests()
    }

    fun setThemeMode(mode: FlowThemeMode) {
        if (!FeatureFlags.isEnabled(Feature.DarkMode)) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "set_theme_mode_ignored requested=$mode reason=feature_flag_disabled feature=DarkMode",
            )
            return
        }
        // WebView path: drives the themeMode URL query param.
        themeModeState.value = mode
        // Native path: forward to the kmp SDK so natively-rendered blocks follow the same
        // mode (the wrapper renders some blocks natively; both engines must agree).
        br.com.wave.flows.kmp.FlowWrapper.setThemeMode(mode.toNativeThemeMode())
    }

    internal fun currentThemeMode(): FlowThemeMode = themeModeState.value

    /**
     * Map the contract's theme token to the DarkMode feature flag + theme mode.
     * `"on"`/`"system"`/`"light"`/`"dark"` enable theming with the requested mode;
     * `"off"`/null/unknown DISABLE it and lock both engines to light — visual theming is
     * not validated yet, so a disabled contract must never render dark (even if the OS is
     * dark). Installing the provider here is what lets the backend drive theming.
     */
    internal fun applyContractTheme(themeToken: String?) {
        val normalized = themeToken?.trim()?.lowercase()
        val (darkModeEnabled, mode) = when (normalized) {
            "on", "system" -> true to FlowThemeMode.System
            "light" -> true to FlowThemeMode.Light
            "dark" -> true to FlowThemeMode.Dark
            else -> false to FlowThemeMode.Light // themes off: lock to light, never follow system
        }
        FeatureFlags.installProvider(ContractFeatureFlagProvider(darkMode = darkModeEnabled))
        themeModeState.value = mode
        // Native engine follows the same decision (off -> light). The WebView path forces
        // light too via resolveThemeQueryParam when the flag is off.
        br.com.wave.flows.kmp.FlowWrapper.setThemeMode(mode.toNativeThemeMode())
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "contract_theme_applied token=$normalized darkMode=$darkModeEnabled mode=$mode",
        )
    }

    fun start(
        apiKey: String,
        msisdn: String,
        config: FlowWrapperConfig = FlowWrapperConfig(),
        onReady: (() -> Unit)? = null,
    ) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        val decoded = ApiKeyDecoder.decode(sanitizedApiKey)

        val nextConfig =
            RuntimeConfig(
                msisdn = sanitizedMsisdn,
                apiKey = sanitizedApiKey,
                environment = decoded.environment,
                flowWrapperConfig = config,
            )

        runtimeConfig = nextConfig
        navbarCurrentPage = null

        // Resolve routing before warm-up: warm targets come from policy.nativeFlowIds().
        val policy =
            RenderRouting.resolve(
                RenderRoutingSessionContext(
                    apiKey = sanitizedApiKey,
                    msisdn = sanitizedMsisdn,
                ),
            )

        // The same contract carries the theme flag: apply it before any rendering.
        applyContractTheme(policy.themeToken)

        val warmupEntryUrl = nextConfig.warmupUrl()
        warmupHandle?.cancel()
        if (warmupHandle != null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_warmup_cancelled reason=new_start",
            )
        }
        warmupHandle = null
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "sdk_init_warmup_started timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS",
        )
        val generation = ++warmupGeneration
        var launchedHandle: FlowWrapperWarmupHandle? = null
        var warmupCompleted = false
        var webWarmReady = false
        var nativeRenderWarmReady = false

        fun maybeFinishWarmup(reason: String, callbackType: String? = null) {
            if (warmupCompleted || generation != warmupGeneration) return
            if (!webWarmReady || !nativeRenderWarmReady) return
            warmupCompleted = true
            when (reason) {
                "callback" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_ready callbackType=${callbackType ?: "UNKNOWN"} nativeRenderReady=true",
                )
                "timeout" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_timeout timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS nativeRenderReady=true action=invoke_onReady_fallback",
                )
                "unavailable" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_unavailable nativeRenderReady=true action=invoke_onReady_immediately",
                )
            }
            onReady?.invoke()
        }

        fun markWebWarmReady(reason: String, callbackType: String? = null) {
            if (webWarmReady || generation != warmupGeneration) return
            webWarmReady = true
            val handleToCancel = launchedHandle ?: warmupHandle
            if (warmupHandle === handleToCancel) {
                warmupHandle = null
            }
            handleToCancel?.cancel()
            maybeFinishWarmup(reason = reason, callbackType = callbackType)
        }

        fun markNativeRenderWarmReady() {
            if (nativeRenderWarmReady || generation != warmupGeneration) return
            nativeRenderWarmReady = true
            maybeFinishWarmup(reason = "callback")
        }

        nativeRenderBridgeDelegate.onSdkStart(
            apiKey = sanitizedApiKey,
            msisdn = sanitizedMsisdn,
            onReady = ::markNativeRenderWarmReady,
        )

        launchedHandle =
            flowWrapperWarmupLauncher.launch(
                entryUrl = warmupEntryUrl,
                onCallbackPayload = { payload ->
                    val callbackMessage = parseNativeBridgeParams(payload) ?: return@launch
                    if (!isFlowWrapperWarmupReadyCallback(callbackMessage)) {
                        platformLogDebug(
                            FLOW_WRAPPER_LOG_TAG,
                            "sdk_init_warmup_ignored_callback callbackType=${callbackMessage.type}",
                        )
                        return@launch
                    }
                    markWebWarmReady(reason = "callback", callbackType = callbackMessage.type)
                },
                onTimeout = {
                    markWebWarmReady(reason = "timeout")
                },
                timeoutMs = FLOW_WRAPPER_WARMUP_TIMEOUT_MS,
            )

        if (warmupCompleted) {
            return
        }

        if (launchedHandle == null) {
            markWebWarmReady(reason = "unavailable")
            return
        }

        warmupHandle = launchedHandle
    }

    /**
     * Forwards a host refresh callback to the native SDK so the cached contract is actually
     * invalidated. Safe in webview mode: the native [br.com.wave.flows.kmp.FlowWrapper.refresh]
     * no-ops when no contract provider is configured (no native RenderBlock mounted).
     *
     * Also arms a one-shot cache bypass for the WebView render path: the next reload of
     * [componentId] loads once with `refresh=true` in the URL, then reverts.
     */
    fun refresh(componentId: String, externalCode: String? = null) {
        br.com.wave.flows.kmp.FlowWrapper.refresh(componentId, externalCode)
        webViewRefreshTicks[componentId] = (webViewRefreshTicks[componentId] ?: 0) + 1
    }

    internal fun webViewRefreshTick(componentId: String): Int = webViewRefreshTicks[componentId] ?: 0

    internal fun webViewAppliedRefreshTick(componentId: String): Int =
        webViewAppliedRefreshTicks[componentId] ?: 0

    internal fun markWebViewRefreshApplied(componentId: String, tick: Int) {
        webViewAppliedRefreshTicks[componentId] = tick
    }

    private fun requireConfig(): RuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentConfig(): RuntimeConfig = requireConfig()

    internal fun resolveEntryPathForRendering(entryPath: String): String {
        if (entryPath != NAVBAR_FLOW_PATH) return entryPath
        val currentPage = navbarCurrentPage ?: return entryPath
        if (entryPath.containsQueryParam(NAVBAR_CURRENT_PAGE_QUERY_PARAM)) return entryPath
        return entryPath.appendQueryParameter(NAVBAR_CURRENT_PAGE_QUERY_PARAM, currentPage)
    }

    internal fun updateRuntimeStateFromCallback(
        entryPath: String,
        callbackMessage: NativeCallbackMessage,
    ) {
        if (entryPath != NAVBAR_FLOW_PATH) return

        val currentPage = callbackMessage.resolveNavbarCurrentPage() ?: return

        if (navbarCurrentPage == currentPage) return
        navbarCurrentPage = currentPage
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "navbar_state_updated currentPage=$currentPage",
        )
    }
}

private fun String.containsQueryParam(paramName: String): Boolean {
    return contains("?$paramName=") || contains("&$paramName=")
}

private fun String.appendQueryParameter(
    paramName: String,
    paramValue: String,
): String {
    val separator = if ('?' in this) '&' else '?'
    return "$this$separator$paramName=$paramValue"
}

private fun NativeCallbackMessage.resolveNavbarCurrentPage(): String? {
    extractStringFieldFromJson(
        json = payload,
        fieldName = NAVBAR_CURRENT_PAGE_QUERY_PARAM,
    )?.let { return it }

    if (!type.equals("RENDER_BLOCK_NAVIGATE", ignoreCase = true)) return null

    val nextComponentId =
        extractStringFieldFromJson(
            json = payload,
            fieldName = NAVBAR_NEXT_COMPONENT_ID_FIELD,
        ) ?: return null

    return nextComponentId.toNavbarCurrentPageOrNull()
}

private fun String.toNavbarCurrentPageOrNull(): String? {
    val screenTokenIndex = indexOf(NAVBAR_COMPONENT_SCREEN_TOKEN)
    if (screenTokenIndex <= 0) return null
    return substring(0, screenTokenIndex).takeIf { it.isNotBlank() }
}
