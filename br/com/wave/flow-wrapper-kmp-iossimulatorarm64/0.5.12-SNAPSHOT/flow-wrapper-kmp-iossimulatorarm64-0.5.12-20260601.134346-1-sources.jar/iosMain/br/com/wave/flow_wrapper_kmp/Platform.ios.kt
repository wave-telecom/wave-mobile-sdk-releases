package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator
import com.multiplatform.webview.web.defaultWebViewFactory
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.readBytes
import platform.CoreGraphics.CGRectMake
import platform.Foundation.NSData
import platform.Foundation.NSJSONSerialization
import platform.Foundation.NSURL
import platform.Foundation.NSURLRequest
import platform.WebKit.WKProcessPool
import platform.WebKit.WKScriptMessage
import platform.WebKit.WKScriptMessageHandlerProtocol
import platform.WebKit.WKUserContentController
import platform.WebKit.WKUserScript
import platform.WebKit.WKUserScriptInjectionTime
import platform.WebKit.WKWebView
import platform.WebKit.WKWebViewConfiguration
import platform.WebKit.WKWebsiteDataStore
import platform.darwin.NSObject
import platform.darwin.dispatch_async
import platform.darwin.dispatch_after
import platform.darwin.dispatch_get_main_queue
import platform.darwin.dispatch_time
import platform.darwin.DISPATCH_TIME_NOW
import platform.darwin.NSEC_PER_MSEC

// Primary handler name: matches window.webkit.messageHandlers.NativeHandler (case-sensitive)
private const val IOS_SCRIPT_MESSAGE_HANDLER_NAME = "NativeHandler"

// Legacy handler name: kept for backward compatibility during transition
private const val IOS_SCRIPT_MESSAGE_HANDLER_NAME_LEGACY = "nativeHandler"
private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"

private object IOSFlowWrapperWebViewResources {
    val websiteDataStore: WKWebsiteDataStore = WKWebsiteDataStore.defaultDataStore()
    val processPool = WKProcessPool()
}

private fun WKWebViewConfiguration.applyFlowWrapperSharedResources() {
    websiteDataStore = IOSFlowWrapperWebViewResources.websiteDataStore
    processPool = IOSFlowWrapperWebViewResources.processPool
}

@OptIn(ExperimentalForeignApi::class)
private fun NSData.toUtf8String(): String? {
    val length = this.length.toInt()
    if (length == 0) return null
    return this.bytes?.readBytes(length)?.decodeToString()
}

private class NativeHandlerScriptMessageHandler(
    private val onDataReceived: (String) -> Unit,
) : NSObject(), WKScriptMessageHandlerProtocol {

    @OptIn(ExperimentalForeignApi::class)
    override fun userContentController(
        userContentController: WKUserContentController,
        didReceiveScriptMessage: WKScriptMessage,
    ) {
        val body = didReceiveScriptMessage.body
        val payload: String? = when (body) {
            is String -> body
            else -> {
                if (body != null) {
                    val jsonData = NSJSONSerialization.dataWithJSONObject(body, options = 0u, error = null)
                    jsonData?.toUtf8String()
                } else null
            }
        }
        if (payload != null) {
            onDataReceived(payload)
        }
    }
}

@OptIn(ExperimentalForeignApi::class)
private class IOSFlowWrapperWarmupSession(
    private val entryUrl: String,
    private val url: NSURL,
    private val onCallbackPayload: (String) -> Unit,
    private val onTimeout: () -> Unit,
    private val timeoutMs: Long,
) : NSObject() {
    private val userContentController = WKUserContentController()
    private val messageHandler =
        NativeHandlerScriptMessageHandler { data ->
            if (!isClosed) {
                onCallbackPayload(data)
            }
        }
    private var webView: WKWebView? = null
    private var isClosed = false

    init {
        dispatch_after(
            dispatch_time(DISPATCH_TIME_NOW, timeoutMs * NSEC_PER_MSEC.toLong()),
            dispatch_get_main_queue(),
        ) {
            if (!isClosed) {
                onTimeout()
            }
        }
        dispatch_async(dispatch_get_main_queue()) {
            if (isClosed) return@dispatch_async

            userContentController.addScriptMessageHandler(
                scriptMessageHandler = messageHandler,
                name = IOS_SCRIPT_MESSAGE_HANDLER_NAME,
            )
            userContentController.addScriptMessageHandler(
                scriptMessageHandler = messageHandler,
                name = IOS_SCRIPT_MESSAGE_HANDLER_NAME_LEGACY,
            )

            val configuration =
                WKWebViewConfiguration().apply {
                    userContentController = this@IOSFlowWrapperWarmupSession.userContentController
                    applyFlowWrapperSharedResources()
                }

            webView =
                WKWebView(
                    frame = CGRectMake(0.0, 0.0, 0.0, 0.0),
                    configuration = configuration,
                ).apply {
                    platformLogDebug(
                        FLOW_WRAPPER_LOG_TAG,
                        "warmup_load_started entryUrl=$entryUrl",
                    )
                    loadRequest(NSURLRequest.requestWithURL(url))
                }
        }
    }

    fun close() {
        dispatch_async(dispatch_get_main_queue()) {
            if (isClosed) return@dispatch_async
            isClosed = true
            webView?.stopLoading()
            webView = null
            userContentController.removeScriptMessageHandlerForName(IOS_SCRIPT_MESSAGE_HANDLER_NAME)
            userContentController.removeScriptMessageHandlerForName(IOS_SCRIPT_MESSAGE_HANDLER_NAME_LEGACY)
        }
    }
}

actual fun platform() = "iOS"

internal actual fun platformLogDebug(tag: String, message: String) {
    println("[$tag] $message")
}

@Composable
internal actual fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
): PlatformWebViewParams? {
    navigator
    onNativeBridgeMessage
    return null
}

@Composable
internal actual fun rememberNativeHandlerWebViewFactory(
    onNativeBridgeMessage: (String) -> Unit,
): ((WebViewFactoryParam) -> NativeWebView)? {
    val currentCallback = rememberUpdatedState(onNativeBridgeMessage)
    val messageHandler = remember {
        NativeHandlerScriptMessageHandler { data -> currentCallback.value(data) }
    }
    return remember(messageHandler) {
        { param: WebViewFactoryParam ->
            val config = param.config
            config.applyFlowWrapperSharedResources()
            config.userContentController.addScriptMessageHandler(
                scriptMessageHandler = messageHandler,
                name = IOS_SCRIPT_MESSAGE_HANDLER_NAME,
            )
            // Backward compatibility: also register legacy lowercase name during transition
            config.userContentController.addScriptMessageHandler(
                scriptMessageHandler = messageHandler,
                name = IOS_SCRIPT_MESSAGE_HANDLER_NAME_LEGACY,
            )
            config.userContentController.addUserScript(
                WKUserScript(
                    source = PAGE_HEIGHT_OBSERVER_JS,
                    injectionTime = WKUserScriptInjectionTime.WKUserScriptInjectionTimeAtDocumentEnd,
                    forMainFrameOnly = true,
                ),
            )
            defaultWebViewFactory(param)
        }
    }
}

internal actual object PlatformFlowWrapperWarmupLauncher {
    actual fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle? {
        val url = NSURL.URLWithString(entryUrl) ?: return null
        val session =
            IOSFlowWrapperWarmupSession(
                entryUrl = entryUrl,
                url = url,
                onCallbackPayload = onCallbackPayload,
                onTimeout = onTimeout,
                timeoutMs = timeoutMs,
            )
        return object : FlowWrapperWarmupHandle {
            override fun cancel() {
                session.close()
            }
        }
    }
}
