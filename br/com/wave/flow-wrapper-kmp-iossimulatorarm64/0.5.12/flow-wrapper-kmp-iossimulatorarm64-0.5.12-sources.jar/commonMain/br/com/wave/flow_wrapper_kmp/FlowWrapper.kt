package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.mutableStateOf
import br.com.wave.flow_wrapper_kmp.featureflags.Feature
import br.com.wave.flow_wrapper_kmp.featureflags.FeatureFlags

private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"
private const val NAVBAR_FLOW_PATH = "/flows/navbar"
private const val NAVBAR_CURRENT_PAGE_QUERY_PARAM = "currentPage"
private const val NAVBAR_NEXT_COMPONENT_ID_FIELD = "nextComponentId"
private const val NAVBAR_COMPONENT_SCREEN_TOKEN = "-screen-"

internal data class RuntimeConfig(
    val msisdn: String,
    val apiKey: String,
    val environment: FlowWrapperEnvironment,
    val flowWrapperConfig: FlowWrapperConfig,
)

object FlowWrapper {
    private var runtimeConfig: RuntimeConfig? = null
    private var warmupHandle: FlowWrapperWarmupHandle? = null
    private var warmupGeneration: Long = 0
    private var navbarCurrentPage: String? = null
    private val themeModeState = mutableStateOf(FlowThemeMode.System)

    internal fun resetForTests() {
        warmupHandle?.cancel()
        warmupHandle = null
        runtimeConfig = null
        warmupGeneration = 0
        navbarCurrentPage = null
        themeModeState.value = FlowThemeMode.System
        flowWrapperWarmupLauncher = DefaultFlowWrapperWarmupLauncher
        nativeBottomSheetBridgeDelegate = DefaultNativeBottomSheetBridgeDelegate
        DefaultNativeBottomSheetBridgeDelegate.reset()
    }

    fun setThemeMode(mode: FlowThemeMode) {
        if (!FeatureFlags.isEnabled(Feature.DarkMode)) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "set_theme_mode_ignored requested=$mode reason=feature_flag_disabled feature=DarkMode",
            )
            return
        }
        themeModeState.value = mode
    }

    internal fun currentThemeMode(): FlowThemeMode = themeModeState.value

    fun start(
        apiKey: String,
        msisdn: String,
        config: FlowWrapperConfig = FlowWrapperConfig(),
        onReady: (() -> Unit)? = null,
    ) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        val decoded = ApiKeyDecoder.decode(sanitizedApiKey)

        val nextConfig =
            RuntimeConfig(
                msisdn = sanitizedMsisdn,
                apiKey = sanitizedApiKey,
                environment = decoded.environment,
                flowWrapperConfig = config,
            )

        runtimeConfig = nextConfig
        navbarCurrentPage = null
        val warmupEntryUrl = nextConfig.warmupUrl()
        warmupHandle?.cancel()
        if (warmupHandle != null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_warmup_cancelled reason=new_start",
            )
        }
        warmupHandle = null
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "sdk_init_warmup_started timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS",
        )
        val generation = ++warmupGeneration
        var launchedHandle: FlowWrapperWarmupHandle? = null
        var warmupCompleted = false
        var webWarmReady = false
        var nativeBottomSheetWarmReady = false

        fun maybeFinishWarmup(reason: String, callbackType: String? = null) {
            if (warmupCompleted || generation != warmupGeneration) return
            if (!webWarmReady || !nativeBottomSheetWarmReady) return
            warmupCompleted = true
            when (reason) {
                "callback" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_ready callbackType=${callbackType ?: "UNKNOWN"} nativeBottomSheetReady=true",
                )
                "timeout" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_timeout timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS nativeBottomSheetReady=true action=invoke_onReady_fallback",
                )
                "unavailable" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_unavailable nativeBottomSheetReady=true action=invoke_onReady_immediately",
                )
            }
            onReady?.invoke()
        }

        fun markWebWarmReady(reason: String, callbackType: String? = null) {
            if (webWarmReady || generation != warmupGeneration) return
            webWarmReady = true
            val handleToCancel = launchedHandle ?: warmupHandle
            if (warmupHandle === handleToCancel) {
                warmupHandle = null
            }
            handleToCancel?.cancel()
            maybeFinishWarmup(reason = reason, callbackType = callbackType)
        }

        fun markNativeBottomSheetWarmReady() {
            if (nativeBottomSheetWarmReady || generation != warmupGeneration) return
            nativeBottomSheetWarmReady = true
            maybeFinishWarmup(reason = "callback")
        }

        nativeBottomSheetBridgeDelegate.onSdkStart(
            apiKey = sanitizedApiKey,
            msisdn = sanitizedMsisdn,
            onReady = ::markNativeBottomSheetWarmReady,
        )

        launchedHandle =
            flowWrapperWarmupLauncher.launch(
                entryUrl = warmupEntryUrl,
                onCallbackPayload = { payload ->
                    val callbackMessage = parseNativeBridgeParams(payload) ?: return@launch
                    if (!isFlowWrapperWarmupReadyCallback(callbackMessage)) {
                        platformLogDebug(
                            FLOW_WRAPPER_LOG_TAG,
                            "sdk_init_warmup_ignored_callback callbackType=${callbackMessage.type}",
                        )
                        return@launch
                    }
                    markWebWarmReady(reason = "callback", callbackType = callbackMessage.type)
                },
                onTimeout = {
                    markWebWarmReady(reason = "timeout")
                },
                timeoutMs = FLOW_WRAPPER_WARMUP_TIMEOUT_MS,
            )

        if (warmupCompleted) {
            return
        }

        if (launchedHandle == null) {
            markWebWarmReady(reason = "unavailable")
            return
        }

        warmupHandle = launchedHandle
    }

    /**
     * Refresh hook for parity with the KMP-native [br.com.wave.flows.kmp.FlowWrapper.refresh].
     *
     * The WebView SDK delegates contract resolution to the embedded
     * WebView itself, so there is no host-side cache layer to invalidate
     * here — the BFF's `render_block_refresh` callback should be handled
     * inside the page. We accept the call as a no-op so sample code
     * shared with the native variant compiles unchanged.
     */
    @Suppress("UNUSED_PARAMETER")
    fun refresh(componentId: String, externalCode: String? = null) = Unit

    private fun requireConfig(): RuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentConfig(): RuntimeConfig = requireConfig()

    internal fun resolveEntryPathForRendering(entryPath: String): String {
        if (entryPath != NAVBAR_FLOW_PATH) return entryPath
        val currentPage = navbarCurrentPage ?: return entryPath
        if (entryPath.containsQueryParam(NAVBAR_CURRENT_PAGE_QUERY_PARAM)) return entryPath
        return entryPath.appendQueryParameter(NAVBAR_CURRENT_PAGE_QUERY_PARAM, currentPage)
    }

    internal fun updateRuntimeStateFromCallback(
        entryPath: String,
        callbackMessage: NativeCallbackMessage,
    ) {
        if (entryPath != NAVBAR_FLOW_PATH) return

        val currentPage = callbackMessage.resolveNavbarCurrentPage() ?: return

        if (navbarCurrentPage == currentPage) return
        navbarCurrentPage = currentPage
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "navbar_state_updated currentPage=$currentPage",
        )
    }
}

private fun String.containsQueryParam(paramName: String): Boolean {
    return contains("?$paramName=") || contains("&$paramName=")
}

private fun String.appendQueryParameter(
    paramName: String,
    paramValue: String,
): String {
    val separator = if ('?' in this) '&' else '?'
    return "$this$separator$paramName=$paramValue"
}

private fun NativeCallbackMessage.resolveNavbarCurrentPage(): String? {
    extractStringFieldFromJson(
        json = payload,
        fieldName = NAVBAR_CURRENT_PAGE_QUERY_PARAM,
    )?.let { return it }

    if (!type.equals("RENDER_BLOCK_NAVIGATE", ignoreCase = true)) return null

    val nextComponentId =
        extractStringFieldFromJson(
            json = payload,
            fieldName = NAVBAR_NEXT_COMPONENT_ID_FIELD,
        ) ?: return null

    return nextComponentId.toNavbarCurrentPageOrNull()
}

private fun String.toNavbarCurrentPageOrNull(): String? {
    val screenTokenIndex = indexOf(NAVBAR_COMPONENT_SCREEN_TOKEN)
    if (screenTokenIndex <= 0) return null
    return substring(0, screenTokenIndex).takeIf { it.isNotBlank() }
}
