package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.WarmTarget
import br.com.wave.flows.kmp.WarmTargetMode
import br.com.wave.flows.kmp.WarmTargetType

private const val NATIVE_BOTTOM_SHEET_FLOW_ID = "home-staging"
private const val NATIVE_BOTTOM_SHEET_COMPONENT_PREFIX = "bottom-sheet-"
private const val NATIVE_BOTTOM_SHEET_LOG_TAG = "FlowWrapperKmp"

// The WebView render-block-sdk stamps a per-instance UUID v4 onto the stable
// block id when it emits the navigate callback, e.g.
// `bottom-sheet-plan-details-c98f4f0e-5b53-479a-9b5e-70258d5c3705`. The native
// block index (warmed from the BFF tree) only knows the stable id
// `bottom-sheet-plan-details`, so we strip a trailing UUID to bridge the two.
private val NATIVE_BOTTOM_SHEET_INSTANCE_SUFFIX =
    Regex("-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

private fun stableNativeComponentId(componentId: String): String =
    componentId.replace(NATIVE_BOTTOM_SHEET_INSTANCE_SUFFIX, "")

internal interface NativeBottomSheetBridgeDelegate {
    fun onSdkStart(
        apiKey: String,
        msisdn: String,
        onReady: () -> Unit,
    )

    fun shouldRenderNatively(
        componentId: String?,
        flowId: String?,
        scroll: Boolean,
    ): Boolean

    @Composable
    fun RenderBlock(
        componentId: String?,
        flowId: String?,
        onEvent: ((SDKEvent) -> Unit)?,
        modifier: Modifier = Modifier,
    )
}

internal var nativeBottomSheetBridgeDelegate: NativeBottomSheetBridgeDelegate =
    DefaultNativeBottomSheetBridgeDelegate

internal object DefaultNativeBottomSheetBridgeDelegate : NativeBottomSheetBridgeDelegate {
    private var startGeneration: Long = 0
    private var homeFlowWarmReady: Boolean = false

    override fun onSdkStart(
        apiKey: String,
        msisdn: String,
        onReady: () -> Unit,
    ) {
        val generation = ++startGeneration
        homeFlowWarmReady = false

        runCatching {
            br.com.wave.flows.kmp.FlowWrapper.setMsisdn(
                apiKey = apiKey,
                msisdn = msisdn,
            )
            br.com.wave.flows.kmp.FlowWrapper.warm(
                targets = listOf(
                    WarmTarget(
                        slug = NATIVE_BOTTOM_SHEET_FLOW_ID,
                        type = WarmTargetType.FLOW,
                        mode = WarmTargetMode.FULL,
                    ),
                ),
                onReady = {
                    if (generation != startGeneration) return@warm
                    homeFlowWarmReady =
                        br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(
                            NATIVE_BOTTOM_SHEET_FLOW_ID,
                        )
                    platformLogDebug(
                        NATIVE_BOTTOM_SHEET_LOG_TAG,
                        "native_bottom_sheet_bridge_warm_finished flowId=$NATIVE_BOTTOM_SHEET_FLOW_ID ready=$homeFlowWarmReady",
                    )
                    onReady()
                },
            )
        }.onFailure { error ->
            if (generation != startGeneration) return
            homeFlowWarmReady = false
            platformLogDebug(
                NATIVE_BOTTOM_SHEET_LOG_TAG,
                "native_bottom_sheet_bridge_start_failed message=${error.message}",
            )
            onReady()
        }
    }

    override fun shouldRenderNatively(
        componentId: String?,
        flowId: String?,
        scroll: Boolean,
    ): Boolean {
        val normalizedComponentId = componentId?.trim().orEmpty()
        val normalizedFlowId = flowId?.trim().orEmpty()

        // Routing is decided ONLY by the shape of the request: a non-scrolling
        // RenderBlock for a `bottom-sheet-*` component of the home flow. Cache /
        // warm-up readiness is deliberately NOT part of the decision — a cache
        // miss must surface as empty native content, never a silent fall-through
        // to the WebView (which would hide whether native routing ever fired).
        return !scroll &&
            normalizedFlowId == NATIVE_BOTTOM_SHEET_FLOW_ID &&
            normalizedComponentId.startsWith(NATIVE_BOTTOM_SHEET_COMPONENT_PREFIX)
    }

    @Composable
    override fun RenderBlock(
        componentId: String?,
        flowId: String?,
        onEvent: ((SDKEvent) -> Unit)?,
        modifier: Modifier,
    ) {
        // Bridge the WebView's per-instance id to the stable id the native
        // block index knows. Prefer the raw id if it happens to be cached;
        // otherwise fall back to the UUID-stripped id when that one resolves.
        val requestedId = componentId?.trim().orEmpty()
        val resolvedComponentId =
            when {
                requestedId.isEmpty() -> requestedId
                br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(requestedId) -> requestedId
                else -> {
                    val stable = stableNativeComponentId(requestedId)
                    if (stable != requestedId &&
                        br.com.wave.flows.kmp.FlowWrapper.hasCachedComponent(stable)
                    ) {
                        stable
                    } else {
                        requestedId
                    }
                }
            }
        br.com.wave.flows.kmp.RenderBlock(
            componentId = resolvedComponentId,
            flowId = flowId,
            modifier = modifier,
            onEvent = onEvent?.let { handler ->
                { nativeEvent ->
                    handler(nativeEvent.toWebViewSdkEvent())
                }
            },
        )
    }

    internal fun reset() {
        startGeneration = 0
        homeFlowWarmReady = false
    }
}

private fun br.com.wave.flows.kmp.SDKEvent.toWebViewSdkEvent(): SDKEvent = when (this) {
    is br.com.wave.flows.kmp.SDKEvent.Error ->
        SDKEvent.Error(
            componentId = componentId,
            code = code,
            message = message,
        )
    is br.com.wave.flows.kmp.SDKEvent.ComponentLoaded ->
        SDKEvent.ComponentLoaded(componentId = componentId)
    is br.com.wave.flows.kmp.SDKEvent.Callback ->
        SDKEvent.Callback(
            type = type,
            payload = payload,
            origin = origin,
        )
}
