package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.18"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-01T15:19:05.543162-03:00"
    const val GIT_SHA: String = "82eaed0"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.18@2026-07-01T15:19:05.543162-03:00#82eaed0"
}