package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.3"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-03T19:34:08.61335-03:00"
    const val GIT_SHA: String = "bc332f7"
    const val GIT_BRANCH: String = "fix/core-analytics-proguard-keep"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.3@2026-07-03T19:34:08.61335-03:00#bc332f7"
}