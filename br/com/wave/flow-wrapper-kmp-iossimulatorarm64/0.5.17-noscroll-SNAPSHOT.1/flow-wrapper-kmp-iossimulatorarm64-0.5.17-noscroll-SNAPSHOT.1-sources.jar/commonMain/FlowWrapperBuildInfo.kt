package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.17-noscroll-SNAPSHOT.1"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-02T13:35:05.646629-03:00"
    const val GIT_SHA: String = "49be4a0"
    const val GIT_BRANCH: String = "chore/disable-scroll-callback-snapshot"
    const val DESCRIPTION: String = "0.5.17-noscroll-SNAPSHOT.1@2026-07-02T13:35:05.646629-03:00#49be4a0"
}