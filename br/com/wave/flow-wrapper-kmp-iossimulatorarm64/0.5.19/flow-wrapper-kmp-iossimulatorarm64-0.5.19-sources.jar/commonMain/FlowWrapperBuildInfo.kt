package br.com.wave.flow_wrapper_kmp

object FlowWrapperBuildInfo {
    const val VERSION_LABEL: String = "0.5.19"
    const val BUILD_TYPE: String = "release"
    const val IS_DEBUG_BUILD: Boolean = false
    const val COMPILED_AT_BRT: String = "2026-07-06T18:49:05.10566-03:00"
    const val GIT_SHA: String = "b1fb345"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.19@2026-07-06T18:49:05.10566-03:00#b1fb345"
}