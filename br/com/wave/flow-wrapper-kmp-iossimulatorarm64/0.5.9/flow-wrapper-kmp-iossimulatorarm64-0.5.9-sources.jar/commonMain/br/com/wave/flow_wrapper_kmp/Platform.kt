package br.com.wave.flow_wrapper_kmp

import androidx.compose.runtime.Composable
import com.multiplatform.webview.web.NativeWebView
import com.multiplatform.webview.web.PlatformWebViewParams
import com.multiplatform.webview.web.WebViewFactoryParam
import com.multiplatform.webview.web.WebViewNavigator

expect fun platform(): String

internal expect fun platformLogDebug(tag: String, message: String)

@Composable
internal expect fun rememberFlowWrapperPlatformWebViewParams(
    navigator: WebViewNavigator,
    onNativeBridgeMessage: (String) -> Unit,
): PlatformWebViewParams?

@Composable
internal expect fun rememberNativeHandlerWebViewFactory(
    onNativeBridgeMessage: (String) -> Unit,
): ((WebViewFactoryParam) -> NativeWebView)?

internal expect object PlatformFlowWrapperWarmupLauncher {
    fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle?
}
