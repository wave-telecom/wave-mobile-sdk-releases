package br.com.wave.flow_wrapper_kmp

private const val WARMUP_ENTRY_PATH = "/init"
private const val WARMUP_READY_CALLBACK_TYPE = "RENDER_BLOCK_LOADED"
private const val WARMUP_READY_CALLBACK_TYPE_LEGACY = "onLoaded"
internal const val FLOW_WRAPPER_WARMUP_TIMEOUT_MS = 10_000L

internal interface FlowWrapperWarmupHandle {
    fun cancel()
}

internal interface FlowWrapperWarmupLauncher {
    fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle?
}

internal object DefaultFlowWrapperWarmupLauncher : FlowWrapperWarmupLauncher {
    override fun launch(
        entryUrl: String,
        onCallbackPayload: (String) -> Unit,
        onTimeout: () -> Unit,
        timeoutMs: Long,
    ): FlowWrapperWarmupHandle? {
        return PlatformFlowWrapperWarmupLauncher.launch(
            entryUrl = entryUrl,
            onCallbackPayload = onCallbackPayload,
            onTimeout = onTimeout,
            timeoutMs = timeoutMs,
        )
    }
}

internal var flowWrapperWarmupLauncher: FlowWrapperWarmupLauncher = DefaultFlowWrapperWarmupLauncher

internal fun RuntimeConfig.warmupUrl(): String {
    return flowWrapperConfig.entryUrlProvider.urlFor(
        EntryUrlContext(
            msisdn = msisdn,
            environment = environment,
            path = WARMUP_ENTRY_PATH,
        ),
    )
}

internal fun isFlowWrapperWarmupReadyCallback(callbackMessage: NativeCallbackMessage): Boolean {
    return callbackMessage.type == WARMUP_READY_CALLBACK_TYPE ||
        callbackMessage.type == WARMUP_READY_CALLBACK_TYPE_LEGACY
}
