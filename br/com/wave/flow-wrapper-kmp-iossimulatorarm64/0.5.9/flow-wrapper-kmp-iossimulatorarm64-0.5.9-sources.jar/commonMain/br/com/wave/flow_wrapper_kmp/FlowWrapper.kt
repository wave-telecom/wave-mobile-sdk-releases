package br.com.wave.flow_wrapper_kmp

private const val FLOW_WRAPPER_LOG_TAG = "FlowWrapperKmp"

internal data class RuntimeConfig(
    val msisdn: String,
    val apiKey: String,
    val environment: FlowWrapperEnvironment,
    val flowWrapperConfig: FlowWrapperConfig,
)

object FlowWrapper {
    private var runtimeConfig: RuntimeConfig? = null
    private var warmupHandle: FlowWrapperWarmupHandle? = null
    private var warmupGeneration: Long = 0

    internal fun resetForTests() {
        warmupHandle?.cancel()
        warmupHandle = null
        runtimeConfig = null
        warmupGeneration = 0
        flowWrapperWarmupLauncher = DefaultFlowWrapperWarmupLauncher
    }

    fun start(
        apiKey: String,
        msisdn: String,
        config: FlowWrapperConfig = FlowWrapperConfig(),
        onReady: (() -> Unit)? = null,
    ) {
        val sanitizedApiKey = apiKey.trim()
        val sanitizedMsisdn = msisdn.trim()

        require(sanitizedApiKey.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank apiKey."
        }
        require(sanitizedMsisdn.isNotEmpty()) {
            "FlowWrapper.start requires a non-blank msisdn."
        }

        val decoded = ApiKeyDecoder.decode(sanitizedApiKey)

        val nextConfig =
            RuntimeConfig(
                msisdn = sanitizedMsisdn,
                apiKey = sanitizedApiKey,
                environment = decoded.environment,
                flowWrapperConfig = config,
            )

        runtimeConfig = nextConfig

        val warmupEntryUrl = nextConfig.warmupUrl()
        warmupHandle?.cancel()
        if (warmupHandle != null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_warmup_cancelled endpoint=$warmupEntryUrl msisdn=${nextConfig.msisdn} reason=new_start",
            )
        }
        warmupHandle = null
        platformLogDebug(
            FLOW_WRAPPER_LOG_TAG,
            "sdk_init_warmup_started endpoint=$warmupEntryUrl msisdn=${nextConfig.msisdn} timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS",
        )
        val generation = ++warmupGeneration
        var launchedHandle: FlowWrapperWarmupHandle? = null
        var warmupCompleted = false

        fun finishWarmup(reason: String, callbackType: String? = null) {
            if (warmupCompleted || generation != warmupGeneration) return
            warmupCompleted = true
            val handleToCancel = launchedHandle ?: warmupHandle
            if (warmupHandle === handleToCancel) {
                warmupHandle = null
            }
            handleToCancel?.cancel()
            when (reason) {
                "callback" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_ready endpoint=$warmupEntryUrl msisdn=${nextConfig.msisdn} callbackType=${callbackType ?: "UNKNOWN"}",
                )
                "timeout" -> platformLogDebug(
                    FLOW_WRAPPER_LOG_TAG,
                    "sdk_init_warmup_timeout endpoint=$warmupEntryUrl msisdn=${nextConfig.msisdn} timeoutMs=$FLOW_WRAPPER_WARMUP_TIMEOUT_MS action=invoke_onReady_fallback",
                )
            }
            onReady?.invoke()
        }

        launchedHandle =
            flowWrapperWarmupLauncher.launch(
                entryUrl = warmupEntryUrl,
                onCallbackPayload = { payload ->
                    val callbackMessage = parseNativeBridgeParams(payload) ?: return@launch
                    if (!isFlowWrapperWarmupReadyCallback(callbackMessage)) {
                        platformLogDebug(
                            FLOW_WRAPPER_LOG_TAG,
                            "sdk_init_warmup_ignored_callback endpoint=$warmupEntryUrl msisdn=${nextConfig.msisdn} callbackType=${callbackMessage.type}",
                        )
                        return@launch
                    }
                    finishWarmup(reason = "callback", callbackType = callbackMessage.type)
                },
                onTimeout = {
                    finishWarmup(reason = "timeout")
                },
                timeoutMs = FLOW_WRAPPER_WARMUP_TIMEOUT_MS,
            )

        if (warmupCompleted) {
            return
        }

        if (launchedHandle == null) {
            platformLogDebug(
                FLOW_WRAPPER_LOG_TAG,
                "sdk_init_warmup_unavailable endpoint=$warmupEntryUrl msisdn=${nextConfig.msisdn} action=invoke_onReady_immediately",
            )
            onReady?.invoke()
            return
        }

        warmupHandle = launchedHandle
    }

    private fun requireConfig(): RuntimeConfig {
        return checkNotNull(runtimeConfig) {
            "FlowWrapper.start(apiKey, msisdn) must be called before RenderBlock()."
        }
    }

    internal fun currentConfig(): RuntimeConfig = requireConfig()
}
