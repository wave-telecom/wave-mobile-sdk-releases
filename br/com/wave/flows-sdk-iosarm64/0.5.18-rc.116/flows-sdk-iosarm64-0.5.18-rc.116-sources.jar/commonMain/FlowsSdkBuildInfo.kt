package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.18-SNAPSHOT-29-g4257f28"
    const val COMPILED_AT_BRT: String = "2026-07-01T15:02:51.936729-03:00"
    const val GIT_SHA: String = "4257f28"
    const val GIT_BRANCH: String = "release/0.5.18"
    const val DESCRIPTION: String = "0.5.18-SNAPSHOT-29-g4257f28@2026-07-01T15:02:51.936729-03:00#4257f28"
}