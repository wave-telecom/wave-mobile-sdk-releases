package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "v0.5.9-40-g9e7ea01"
    const val COMPILED_AT_BRT: String = "2026-05-20T17:46:50.362347-03:00"
    const val GIT_SHA: String = "9e7ea01"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "v0.5.9-40-g9e7ea01@2026-05-20T17:46:50.362347-03:00#9e7ea01"
}