package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.15-SNAPSHOT.3-1-g697c652"
    const val COMPILED_AT_BRT: String = "2026-06-23T13:32:10.8845-03:00"
    const val GIT_SHA: String = "697c652"
    const val GIT_BRANCH: String = "release/0.5.15"
    const val DESCRIPTION: String = "0.5.15-SNAPSHOT.3-1-g697c652@2026-06-23T13:32:10.8845-03:00#697c652"
}