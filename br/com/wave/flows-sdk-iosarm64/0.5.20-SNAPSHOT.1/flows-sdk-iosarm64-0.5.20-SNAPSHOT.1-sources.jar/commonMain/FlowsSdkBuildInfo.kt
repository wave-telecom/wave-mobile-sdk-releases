package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT-4-g09272bf"
    const val COMPILED_AT_BRT: String = "2026-07-03T10:44:02.255842-03:00"
    const val GIT_SHA: String = "09272bf"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT-4-g09272bf@2026-07-03T10:44:02.255842-03:00#09272bf"
}