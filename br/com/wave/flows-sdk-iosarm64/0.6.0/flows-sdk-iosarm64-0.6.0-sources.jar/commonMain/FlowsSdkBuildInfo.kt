package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-rc.171-1-gc3ad5f2b"
    const val COMPILED_AT_BRT: String = "2026-08-10T11:40:34.136645-03:00"
    const val GIT_SHA: String = "c3ad5f2b"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.6.0-rc.171-1-gc3ad5f2b@2026-08-10T11:40:34.136645-03:00#c3ad5f2b"
}