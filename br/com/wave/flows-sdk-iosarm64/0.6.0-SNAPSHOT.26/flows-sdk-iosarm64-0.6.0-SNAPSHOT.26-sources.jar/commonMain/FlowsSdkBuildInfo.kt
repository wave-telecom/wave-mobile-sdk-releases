package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.25-2-gfa64c54"
    const val COMPILED_AT_BRT: String = "2026-05-25T13:42:48.648-03:00"
    const val GIT_SHA: String = "fa64c54"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.25-2-gfa64c54@2026-05-25T13:42:48.648-03:00#fa64c54"
}