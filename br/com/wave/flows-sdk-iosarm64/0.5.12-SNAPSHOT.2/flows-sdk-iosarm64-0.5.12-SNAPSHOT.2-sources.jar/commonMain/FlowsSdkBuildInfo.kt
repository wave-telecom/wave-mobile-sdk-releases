package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.12-SNAPSHOT.1-3-g9cdaa44"
    const val COMPILED_AT_BRT: String = "2026-06-02T10:00:47.912595-03:00"
    const val GIT_SHA: String = "9cdaa44"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.12-SNAPSHOT.1-3-g9cdaa44@2026-06-02T10:00:47.912595-03:00#9cdaa44"
}