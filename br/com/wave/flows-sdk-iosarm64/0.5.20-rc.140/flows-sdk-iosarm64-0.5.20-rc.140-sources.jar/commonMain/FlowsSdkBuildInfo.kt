package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-rc.139-2-g67f9be3"
    const val COMPILED_AT_BRT: String = "2026-07-07T11:48:37.760452-03:00"
    const val GIT_SHA: String = "67f9be3"
    const val GIT_BRANCH: String = "release/0.5.20"
    const val DESCRIPTION: String = "0.5.20-rc.139-2-g67f9be3@2026-07-07T11:48:37.760452-03:00#67f9be3"
}