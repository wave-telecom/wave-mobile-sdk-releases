package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "qa-gallo-v2-17-g0cc170b"
    const val COMPILED_AT_BRT: String = "2026-05-21T16:14:16.426464-03:00"
    const val GIT_SHA: String = "0cc170b"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "qa-gallo-v2-17-g0cc170b@2026-05-21T16:14:16.426464-03:00#0cc170b"
}