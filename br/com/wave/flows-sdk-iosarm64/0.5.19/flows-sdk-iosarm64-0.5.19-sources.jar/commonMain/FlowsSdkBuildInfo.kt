package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.19-rc.123-1-gcd988c9"
    const val COMPILED_AT_BRT: String = "2026-07-02T17:52:52.517282-03:00"
    const val GIT_SHA: String = "cd988c9"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.19-rc.123-1-gcd988c9@2026-07-02T17:52:52.517282-03:00#cd988c9"
}