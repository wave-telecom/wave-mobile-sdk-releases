package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.19-3-gb1fb345"
    const val COMPILED_AT_BRT: String = "2026-07-06T18:48:25.511263-03:00"
    const val GIT_SHA: String = "b1fb345"
    const val GIT_BRANCH: String = "main"
    const val DESCRIPTION: String = "0.5.19-3-gb1fb345@2026-07-06T18:48:25.511263-03:00#b1fb345"
}