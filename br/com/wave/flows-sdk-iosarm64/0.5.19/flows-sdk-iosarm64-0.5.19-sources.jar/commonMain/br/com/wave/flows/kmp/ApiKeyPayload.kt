package br.com.wave.flows.kmp

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

@Serializable
internal data class ApiKeyPayload(
    val tenantId: String,
    val baseUrl: String,
    val authVersion: Int,
)

private const val JWT_PARTS = 3
private const val JWT_PAYLOAD_INDEX = 1

private val apiKeyPayloadJson = Json { ignoreUnknownKeys = true }

// JWT segments are base64url WITHOUT '=' padding, so decode with padding optional.
private val jwtBase64 = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL)

/**
 * Decodes the payload of the API Key JWT received at SDK init. The signature is
 * NOT verified: the B2F already validated the key at origin, so the SDK only
 * reads the payload. The `msisdn` is never taken from here — it arrives as a
 * separate parameter of `start(...)`.
 */
@OptIn(ExperimentalEncodingApi::class)
internal fun decodeJwtPayload(jwt: String): ApiKeyPayload {
    val parts = jwt.split('.')
    require(parts.size == JWT_PARTS) {
        "apiKey is not a valid JWT (expected $JWT_PARTS parts, got ${parts.size})."
    }

    val payload = parts[JWT_PAYLOAD_INDEX]
    val payloadJson = runCatching { jwtBase64.decode(payload).decodeToString() }
        .getOrElse { cause ->
            throw IllegalArgumentException(
                "apiKey payload is not a valid base64url-encoded value.",
                cause,
            )
        }

    return apiKeyPayloadJson.decodeFromString(payloadJson)
}
