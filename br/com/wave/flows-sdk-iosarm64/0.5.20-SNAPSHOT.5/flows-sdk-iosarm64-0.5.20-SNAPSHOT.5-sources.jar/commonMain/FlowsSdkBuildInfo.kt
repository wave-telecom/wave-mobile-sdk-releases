package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.5.20-SNAPSHOT.4-8-gaf37d98"
    const val COMPILED_AT_BRT: String = "2026-07-07T08:55:13.906798-03:00"
    const val GIT_SHA: String = "af37d98"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.5.20-SNAPSHOT.4-8-gaf37d98@2026-07-07T08:55:13.906798-03:00#af37d98"
}