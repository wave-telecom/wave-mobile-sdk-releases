package br.com.wave.flows.kmp

import io.ktor.client.HttpClient
import io.ktor.client.plugins.UserAgent
import io.ktor.client.plugins.api.createClientPlugin
import io.ktor.client.plugins.defaultRequest
import io.ktor.http.HttpHeaders

expect fun createPlatformHttpClient(): HttpClient

fun createPlatformImageHttpClient(): HttpClient {
    return HttpClient {
        install(UserAgent) {
            agent = IMAGE_USER_AGENT
        }
        install(SameOriginReferer)

        defaultRequest {
            headers.append(HttpHeaders.AcceptLanguage, "es-MX,es;q=0.9")
            headers.append("Sec-Fetch-Site", "cross-site")
        }
    }
}

// Telcel's WAF requires a non-empty Referer; the exact value is not checked.
// We derive it from the request URL itself so we don't pin a hostname that
// could later be wrong (e.g. a Vercel dev URL) or misleading for analytics.
private val SameOriginReferer = createClientPlugin("SameOriginReferer") {
    onRequest { request, _ ->
        val host = request.url.host
        if (host.isNotBlank() && !request.headers.contains(HttpHeaders.Referrer)) {
            request.headers[HttpHeaders.Referrer] = "${request.url.protocol.name}://$host/"
        }
    }
}

private const val IMAGE_USER_AGENT =
    "Mozilla/5.0 (Linux; Android 14; sdk_gphone64_x86_64 Build/UE1A.230829.050; wv) " +
        "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.136 " +
        "Mobile Safari/537.36"
