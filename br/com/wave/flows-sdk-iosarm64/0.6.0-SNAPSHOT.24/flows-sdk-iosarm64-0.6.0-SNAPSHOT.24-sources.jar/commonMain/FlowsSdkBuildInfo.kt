package br.com.wave.flows.kmp

object FlowsSdkBuildInfo {
    const val VERSION_LABEL: String = "0.6.0-SNAPSHOT.23-4-g36cad90"
    const val COMPILED_AT_BRT: String = "2026-05-23T15:28:44.590991-03:00"
    const val GIT_SHA: String = "36cad90"
    const val GIT_BRANCH: String = "develop"
    const val DESCRIPTION: String = "0.6.0-SNAPSHOT.23-4-g36cad90@2026-05-23T15:28:44.590991-03:00#36cad90"
}