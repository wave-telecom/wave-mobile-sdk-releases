package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LocalMinimumInteractiveComponentSize
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderButtonNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as ButtonBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    val background = config.style.backgroundColorHex?.toThemedComposeColorOrNull()
    val textColor = radioGroupOverride.colorOverride
        ?: config.style.colorHex?.toThemedComposeColorOrNull()
    val isLink = background == null || background == Color.Transparent
    val contentColor = textColor ?: ButtonDefaults.buttonColors().contentColor

    if (isLink) {
        // Render as an inline text link — contracts use transparent buttons as
        // anchor-style affordances (e.g. "Mostrar detalles" on the home screen).
        BlockHorizontalAlign(config.align) {
            Row(
                modifier = modifier
                    .clickable { renderContext.dispatchNodeAction(node) }
                    .applyBlockStyle(config.style)
                    .padding(config.style.toPaddingValues()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = config.value,
                    color = textColor ?: Color.Unspecified,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(
                        fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
                        fontFamily = config.fontFamily.toComposeFontFamilyOrNull(),
                        fontWeight = config.fontWeight?.toComposeFontWeight(),
                        lineHeight = config.lineHeightSp?.sp
                            ?: (config.fontSizeSp?.sp ?: TextStyle.Default.fontSize),
                        lineHeightStyle = LineHeightStyle(
                            alignment = LineHeightStyle.Alignment.Center,
                            trim = LineHeightStyle.Trim.None,
                        ),
                    ),
                )
            }
        }
        return
    }

    // Width parity with web: the web button is `width: fit-content` by default, growing only
    // when `fullWidth` is set or a fixed `width` is given. The shared shouldFillWidth() would
    // fill a width-less button in a vertical parent, so gate filling on `fullWidth` alone;
    // applyBlockStyle still applies a fixed `width` when present, otherwise the button wraps.
    val buttonModifier = if (config.style.fullWidth == true) {
        modifier.fillMaxWidth()
    } else {
        modifier
    }.applyBlockStyle(config.style)

    // The height is NOT pinned: it emerges from the contract's box model
    // (padding + label line height), exactly like web. Padding comes straight from the
    // contract (`toPaddingValues`); when the contract sends a lineHeight it is used
    // directly — e.g. lineHeight=24 + vertical padding 8/8 → 40dp. When the contract
    // omits lineHeight the fallback is a 1em box (`lineHeight = fontSize`, CSS
    // `line-height:1`). `Trim.None` keeps the full line box equal to lineHeight (matching
    // CSS, which does not trim leading). We avoid a fixed `.height()` + inner
    // `fillMaxHeight()` on purpose: inside a height-equalizing parent (carousel card,
    // `expand` list) those let the button stretch past its box.
    BlockHorizontalAlign(config.align) {
        // Material's Surface(onClick) enforces a 48dp minimum interactive (touch-target)
        // size, which would floor the button height at 48 regardless of the contract box.
        // Disable it so the button height equals the design box (e.g. 40dp).
        CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides Dp.Unspecified) {
        Surface(
            onClick = { renderContext.dispatchNodeAction(node) },
            modifier = buttonModifier,
            shape = config.style.toRoundedCornerShape(),
            color = background ?: ButtonDefaults.buttonColors().containerColor,
            contentColor = contentColor,
        ) {
            Box(
                modifier = Modifier.padding(config.style.toPaddingValues()),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = config.value,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(
                        fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
                        fontFamily = config.fontFamily.toComposeFontFamilyOrNull(),
                        fontWeight = config.fontWeight?.toComposeFontWeight(),
                        lineHeight = config.lineHeightSp?.sp
                            ?: (config.fontSizeSp?.sp ?: TextStyle.Default.fontSize),
                        lineHeightStyle = LineHeightStyle(
                            alignment = LineHeightStyle.Alignment.Center,
                            trim = LineHeightStyle.Trim.None,
                        ),
                    ),
                )
            }
        }
        }
    }
}
