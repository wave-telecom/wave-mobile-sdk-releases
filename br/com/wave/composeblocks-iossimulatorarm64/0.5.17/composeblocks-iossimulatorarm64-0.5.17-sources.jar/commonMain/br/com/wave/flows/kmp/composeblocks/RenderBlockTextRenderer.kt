package br.com.wave.flows.kmp.composeblocks

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentWidth
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderTextNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as TextBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    val compactHorizontalItem = LocalCompactHorizontalItem.current
    val fontSizeSp = config.fontSizeSp
    val resolvedFontSize = when {
        fontSizeSp != null -> (fontSizeSp * radioGroupOverride.fontScaleOverride).sp
        else -> TextStyle.Default.fontSize
    }
    val clampLongStrongText = !compactHorizontalItem &&
        (config.fontWeight ?: 0) >= 600 &&
        config.style.width == null &&
        config.value.length > 18
    Text(
        text = config.value,
        modifier = modifier
            .applyBlockStyle(config.style)
            .then(
                if (config.align.equals("center", ignoreCase = true)) {
                    Modifier.fillMaxWidth()
                } else {
                    Modifier
                },
            )
            .then(
                if (compactHorizontalItem && config.style.width == null) {
                    Modifier.wrapContentWidth(unbounded = true)
                } else {
                    Modifier
                },
            )
            .padding(config.style.toPaddingValues()),
        textAlign = config.align.toComposeTextAlign()
            ?: if (radioGroupOverride.inGroup || compactHorizontalItem) TextAlign.Center else TextAlign.Start,
        softWrap = if (config.truncate) false else !compactHorizontalItem,
        maxLines = when {
            config.truncate -> 1
            compactHorizontalItem -> 1
            radioGroupOverride.inGroup -> 2
            clampLongStrongText -> 2
            else -> Int.MAX_VALUE
        },
        overflow = when {
            config.truncate -> TextOverflow.Ellipsis
            compactHorizontalItem -> TextOverflow.Visible
            clampLongStrongText -> TextOverflow.Ellipsis
            else -> TextOverflow.Clip
        },
        style = TextStyle(
            color = radioGroupOverride.colorOverride
                ?: config.style.colorHex?.toThemedComposeColorOrNull()
                ?: LocalContentColorOverride.current
                ?: Color.Unspecified,
            fontSize = resolvedFontSize,
            fontFamily = config.fontFamily.toComposeFontFamilyOrNull(),
            fontWeight = config.fontWeight?.toComposeFontWeight(),
            textDecoration = if (config.strikethrough) TextDecoration.LineThrough else null,
            // `lineHeight` comes from the contract; when absent, fall back to a 1em box
            // (`lineHeight = fontSize`, equivalent to CSS `line-height:1`) so the rendered
            // layout matches the WebView. Explicit contract lineHeight still wins.
            // `resolvedFontSize` is used (not raw config.fontSizeSp) so the box tracks the
            // scaled size inside a radio group. Trim.None keeps the full line box equal to
            // lineHeight, matching CSS (which does not trim leading).
            lineHeight = config.lineHeightSp?.sp ?: resolvedFontSize,
            lineHeightStyle = LineHeightStyle(
                alignment = LineHeightStyle.Alignment.Center,
                trim = LineHeightStyle.Trim.None,
            ),
        ),
    )
}
