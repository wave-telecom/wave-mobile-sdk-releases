package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.RadioGroupBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache

private fun resolveInitialSelectionId(
    children: List<ResolvedRenderNode>,
    fallbackIndex: Int?,
): String? {
    if (children.isEmpty()) return null
    val clampedIndex = (fallbackIndex ?: 0).coerceIn(0, children.lastIndex)
    return children[clampedIndex].block.id
}

@Composable
internal fun renderRadioGroupNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as RadioGroupBlockConfig
    val routeStateKey = LocalRenderRouteStateKey.current
    val initialSelectionId = resolveInitialSelectionId(node.children, config.activeIndex)
    val cachedSelectionId = remember(routeStateKey, node.block.id) {
        RenderBlockInteractionCache.getSelection(
            routeId = routeStateKey,
            blockId = node.block.id,
            slot = "radio.activeChildId",
        )
    }
    val effectiveInitialSelectionId =
        cachedSelectionId?.takeIf { saved -> node.children.any { it.block.id == saved } } ?: initialSelectionId
    var selectedChildId by remember(node.block.id, routeStateKey) {
        mutableStateOf(effectiveInitialSelectionId)
    }
    val activeBackgroundColor = config.activeBackgroundColorHex?.toThemedComposeColorOrNull()
    val activeColor = config.activeColorHex?.toThemedComposeColorOrNull()

    if (config.orientation == BlockOrientation.HORIZONTAL) {
        AdaptiveHorizontalListLayout(
            modifier = modifier
                .then(if (shouldFillWidth(config.style, parentOrientation)) Modifier.fillMaxWidth() else Modifier)
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            spacing = config.spacing,
            horizontalAlign = "space-between",
            verticalAlign = "center",
        ) {
            node.children.forEach { child ->
                val isActive = child.block.id == selectedChildId
                val shape = child.block.config.style.toRoundedCornerShape()
                CompositionLocalProvider(
                    LocalRadioGroupStyleOverride provides RadioGroupStyleOverride(
                        active = isActive,
                        colorOverride = if (isActive) activeColor else null,
                        backgroundColorOverride = if (isActive) activeBackgroundColor ?: Color.Transparent else Color.Transparent,
                        inGroup = true,
                        fontScaleOverride = 0.92f,
                    ),
                    LocalCompactHorizontalItem provides true,
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                    ) {
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = config.orientation,
                            wrapActionClick = false,
                            modifier = Modifier
                                .padding(horizontal = 2.dp)
                                .clip(shape)
                                .then(
                                    if (isActive && activeBackgroundColor != null) {
                                        Modifier.background(activeBackgroundColor, shape)
                                    } else {
                                        Modifier
                                    },
                                )
                                .clickable {
                                    selectedChildId = child.block.id
                                    if (routeStateKey.isNotBlank()) {
                                        RenderBlockInteractionCache.putSelection(
                                            routeId = routeStateKey,
                                            blockId = node.block.id,
                                            value = child.block.id,
                                            slot = "radio.activeChildId",
                                        )
                                    }
                                    renderContext.dispatchNodeAction(child)
                                },
                        )
                    }
                }
            }
        }
    } else {
        Column(
            modifier = modifier
                .then(if (shouldFillWidth(config.style, parentOrientation)) Modifier.fillMaxWidth() else Modifier)
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            verticalArrangement = Arrangement.spacedBy(config.spacing.dp),
        ) {
            node.children.forEach { child ->
                val isActive = child.block.id == selectedChildId
                val shape = child.block.config.style.toRoundedCornerShape()
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                ) {
                    CompositionLocalProvider(
                        LocalRadioGroupStyleOverride provides RadioGroupStyleOverride(
                            active = isActive,
                            colorOverride = if (isActive) activeColor else null,
                            backgroundColorOverride = if (isActive) activeBackgroundColor ?: Color.Transparent else Color.Transparent,
                            inGroup = true,
                            fontScaleOverride = 0.92f,
                        ),
                    ) {
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = config.orientation,
                            wrapActionClick = false,
                            modifier = Modifier
                                .clip(shape)
                                .then(
                                    if (isActive && activeBackgroundColor != null) {
                                        Modifier.background(activeBackgroundColor, shape)
                                    } else {
                                        Modifier
                                    },
                                )
                                .clickable {
                                    selectedChildId = child.block.id
                                    if (routeStateKey.isNotBlank()) {
                                        RenderBlockInteractionCache.putSelection(
                                            routeId = routeStateKey,
                                            blockId = node.block.id,
                                            value = child.block.id,
                                            slot = "radio.activeChildId",
                                        )
                                    }
                                    renderContext.dispatchNodeAction(child)
                                },
                        )
                    }
                }
            }
        }
    }
}
