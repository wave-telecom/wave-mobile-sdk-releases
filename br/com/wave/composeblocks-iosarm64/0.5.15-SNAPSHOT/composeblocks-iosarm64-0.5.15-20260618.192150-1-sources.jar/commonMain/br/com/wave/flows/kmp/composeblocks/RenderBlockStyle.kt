package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockStyle

// Note: these Modifier extensions are @Composable because they resolve theme
// tokens via LocalFlowTheme (through `toThemedComposeColorOrNull`). Modifier
// is non-composable, so we read the token in composable scope and capture
// the resulting Color into the modifier chain.
@Composable
internal fun Modifier.applyBlockStyle(style: BlockStyle): Modifier {
    var next = this

    style.width?.let { next = next.width(it.dp) }
    style.height?.let { next = next.height(it.dp) }
    if (style.hasMargins()) {
        next = next.padding(style.toMarginValues())
    }
    style.toBorderStroke()?.let { border ->
        next = next.border(border, style.toRoundedCornerShape())
    }
    style.zIndex?.let { next = next.zIndex(it.toFloat()) }
    val backgroundColor = style.backgroundColorHex?.toThemedComposeColorOrNull()
    if (backgroundColor != null) {
        val shape = style.toRoundedCornerShape()
        next = next
            .clip(shape)
            .background(backgroundColor, shape)
    }

    return next
}

@Composable
internal fun Modifier.applyBlockStyle(
    style: BlockStyle,
    includeBackground: Boolean,
): Modifier {
    var next = this

    style.width?.let { next = next.width(it.dp) }
    style.height?.let { next = next.height(it.dp) }
    if (style.hasMargins()) {
        next = next.padding(style.toMarginValues())
    }
    style.toBorderStroke()?.let { border ->
        next = next.border(border, style.toRoundedCornerShape())
    }
    style.zIndex?.let { next = next.zIndex(it.toFloat()) }
    val backgroundColor = style.backgroundColorHex?.toThemedComposeColorOrNull()
    if (includeBackground && backgroundColor != null) {
        val shape = style.toRoundedCornerShape()
        next = next
            .clip(shape)
            .background(backgroundColor, shape)
    }

    return next
}

internal fun shouldFillWidth(
    style: BlockStyle,
    parentOrientation: BlockOrientation?,
): Boolean {
    return style.width == null && parentOrientation != BlockOrientation.HORIZONTAL
}

internal fun BlockStyle.toRoundedCornerShape(): RoundedCornerShape {
    return RoundedCornerShape(
        topStart = (borderRadiusTop ?: borderRadius ?: 0).dp,
        topEnd = (borderRadiusRight ?: borderRadius ?: 0).dp,
        bottomStart = (borderRadiusLeft ?: borderRadius ?: 0).dp,
        bottomEnd = (borderRadiusBottom ?: borderRadius ?: 0).dp,
    )
}

@Composable
@ReadOnlyComposable
internal fun BlockStyle.toBorderStroke(): androidx.compose.foundation.BorderStroke? {
    val width = borderWidth ?: return null
    val color = borderColorHex?.toThemedComposeColorOrNull() ?: return null
    if (width <= 0) return null
    if (borderStyle?.equals("solid", ignoreCase = true) == false) return null
    return androidx.compose.foundation.BorderStroke(width.dp, color)
}

internal fun BlockStyle.toPaddingValues(defaultPadding: Int = 0): PaddingValues {
    val top = paddingTop ?: padding ?: defaultPadding
    val bottom = paddingBottom ?: padding ?: defaultPadding
    val left = paddingLeft ?: padding ?: defaultPadding
    val right = paddingRight ?: padding ?: defaultPadding
    return PaddingValues(start = left.dp, top = top.dp, end = right.dp, bottom = bottom.dp)
}

internal fun BlockStyle.toVerticalPaddingValues(defaultPadding: Int = 0): PaddingValues {
    val top = paddingTop ?: padding ?: defaultPadding
    val bottom = paddingBottom ?: padding ?: defaultPadding
    return PaddingValues(top = top.dp, bottom = bottom.dp)
}

internal fun BlockStyle.toMarginValues(): PaddingValues {
    val top = marginTop ?: margin ?: 0
    val bottom = marginBottom ?: margin ?: 0
    val left = marginLeft ?: margin ?: 0
    val right = marginRight ?: margin ?: 0
    return PaddingValues(start = left.dp, top = top.dp, end = right.dp, bottom = bottom.dp)
}

internal fun BlockStyle.hasMargins(): Boolean {
    return margin != null || marginTop != null || marginBottom != null || marginLeft != null || marginRight != null
}

internal fun Int.toComposeFontWeight(): FontWeight {
    return when {
        this >= 700 -> FontWeight.Bold
        this >= 600 -> FontWeight.SemiBold
        this >= 500 -> FontWeight.Medium
        else -> FontWeight.Normal
    }
}

internal fun String?.toComposeTextAlign(): TextAlign? {
    return when (this?.lowercase()) {
        "center" -> TextAlign.Center
        "end", "right" -> TextAlign.End
        "start", "left" -> TextAlign.Start
        else -> null
    }
}

internal fun String?.toHorizontalAlignment(): Alignment.Horizontal {
    return when (this?.lowercase()) {
        "center" -> Alignment.CenterHorizontally
        "end", "right" -> Alignment.End
        else -> Alignment.Start
    }
}

// Maps a list's `verticalAlign` to a Column arrangement. Space-* values
// distribute children along the height (so e.g. `space-between` pins the last
// child to the bottom — used by the device cards to keep "Lo quiero" at the
// foot of the card). They drop the `spacing` gap, matching CSS justify-content.
internal fun String?.toVerticalArrangement(spacing: Int): Arrangement.Vertical {
    return when (this?.lowercase()) {
        "space-between", "spacebetween" -> spaceWithMinGap(spacing.dp, SpaceMode.Between)
        "space-around", "spacearound" -> spaceWithMinGap(spacing.dp, SpaceMode.Around)
        "space-evenly", "spaceevenly" -> spaceWithMinGap(spacing.dp, SpaceMode.Evenly)
        "center" -> Arrangement.spacedBy(spacing.dp, Alignment.CenterVertically)
        "end", "bottom" -> Arrangement.spacedBy(spacing.dp, Alignment.Bottom)
        else -> Arrangement.spacedBy(spacing.dp)
    }
}

private enum class SpaceMode { Between, Around, Evenly }

/**
 * `space-between` / `space-around` / `space-evenly` that honor [minGap] as a
 * floor, mirroring CSS flexbox where `gap` is the minimum gutter and
 * `justify-content` only distributes the *remaining* free space on top of it —
 * so the inter-item gap never drops below the configured spacing.
 *
 * Compose's stock [Arrangement.SpaceBetween]/[Arrangement.SpaceAround]/
 * [Arrangement.SpaceEvenly] take no spacing, so the contract's `spacing` was
 * dropped: when a list exactly fills its height (e.g. the tallest card in a
 * height-equalized carousel) the gap collapsed to 0 and the last item glued to
 * the one above it. Here the reserved gaps hold at [minGap] and only the
 * surplus is distributed, per [mode]:
 *  - [SpaceMode.Between]: surplus split across the n-1 inner gaps, no end space.
 *  - [SpaceMode.Around]: each item gets equal surplus around it (half at ends).
 *  - [SpaceMode.Evenly]: surplus split equally across all n+1 slots.
 */
private fun spaceWithMinGap(minGap: Dp, mode: SpaceMode): Arrangement.Vertical =
    object : Arrangement.Vertical {
        override val spacing: Dp = minGap

        override fun Density.arrange(
            totalSize: Int,
            sizes: IntArray,
            outPositions: IntArray,
        ) {
            if (sizes.isEmpty()) return
            val gapPx = minGap.roundToPx()
            val n = sizes.size
            if (n == 1) {
                outPositions[0] = when (mode) {
                    SpaceMode.Between -> 0
                    SpaceMode.Around, SpaceMode.Evenly -> ((totalSize - sizes[0]) / 2).coerceAtLeast(0)
                }
                return
            }
            val content = sizes.sum()
            // Surplus once the minimum inter-item gaps are reserved. Clamped at 0
            // so a gap can only grow past minGap, never shrink below it.
            val free = (totalSize - content - gapPx * (n - 1)).coerceAtLeast(0).toFloat()
            val lead: Float
            val between: Float
            when (mode) {
                SpaceMode.Between -> { lead = 0f; between = gapPx + free / (n - 1) }
                SpaceMode.Around -> { lead = free / (2 * n); between = gapPx + free / n }
                SpaceMode.Evenly -> { lead = free / (n + 1); between = gapPx + free / (n + 1) }
            }
            var pos = lead
            for (i in sizes.indices) {
                outPositions[i] = pos.roundToInt()
                pos += sizes[i] + between
            }
        }
    }

internal fun String?.toVerticalAlignment(): Alignment.Vertical {
    return when (this?.lowercase()) {
        "center" -> Alignment.CenterVertically
        "end", "bottom" -> Alignment.Bottom
        else -> Alignment.Top
    }
}

internal fun String?.toContentScale(): ContentScale {
    return when (this?.lowercase()) {
        "fill" -> ContentScale.FillBounds
        "crop" -> ContentScale.Crop
        else -> ContentScale.Fit
    }
}

internal fun BlockStyle.isAbsolutePosition(): Boolean {
    return position?.equals("absolute", ignoreCase = true) == true
}

internal fun BlockStyle.isRelativePosition(): Boolean {
    return position?.equals("relative", ignoreCase = true) == true
}

internal fun BlockStyle.toAbsoluteAlignment(): Alignment {
    val hasTop = top != null
    val hasBottom = bottom != null
    val hasLeft = left != null
    val hasRight = right != null
    return when {
        hasTop && hasRight -> Alignment.TopEnd
        hasTop && hasLeft -> Alignment.TopStart
        hasBottom && hasRight -> Alignment.BottomEnd
        hasBottom && hasLeft -> Alignment.BottomStart
        hasRight -> Alignment.TopEnd
        hasLeft -> Alignment.TopStart
        hasBottom -> Alignment.BottomStart
        else -> Alignment.TopStart
    }
}

internal fun BlockStyle.toAbsoluteOffsetX(): androidx.compose.ui.unit.Dp {
    val leftValue = left
    val rightValue = right
    return when {
        leftValue != null -> leftValue.dp
        rightValue != null -> (-rightValue).dp
        else -> 0.dp
    }
}

internal fun BlockStyle.toAbsoluteOffsetY(): androidx.compose.ui.unit.Dp {
    val topValue = top
    val bottomValue = bottom
    return when {
        topValue != null -> topValue.dp
        bottomValue != null -> (-bottomValue).dp
        else -> 0.dp
    }
}
