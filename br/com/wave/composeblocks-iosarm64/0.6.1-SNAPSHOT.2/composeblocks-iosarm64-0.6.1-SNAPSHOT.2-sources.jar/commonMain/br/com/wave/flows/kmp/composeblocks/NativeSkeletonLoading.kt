package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.host.HostEvent
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.theme.ThemeId

/**
 * Renders a resolved skeleton [ScreenContract] through the real native render path
 * (`RenderBlockScreen`), so `BlockType.SKELETON` blocks pulse via [renderSkeletonNode],
 * over a theme-keyed opaque floor. When [skeletonContract] is null (cold cache), the floor
 * alone shows — never white.
 *
 * The root fills its bounds by default: this composable is a full-bleed shield drawn over a
 * live WebView, and a `Box` with no intrinsic size would collapse to 0x0 on a null contract,
 * bringing back the exact white frame this change exists to remove.
 */
@Composable
fun NativeSkeletonLoading(
    skeletonContract: ScreenContract?,
    themeMode: ThemeId,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize().background(skeletonFloorColor(themeMode)).testTag(TAG_FLOOR)) {
        if (skeletonContract != null) {
            RenderBlockScreen(
                contract = skeletonContract,
                hostEventHandler = NoOpHostEventHandler,
                scroll = false,
                modifier = Modifier.fillMaxSize().testTag(TAG_CONTENT),
            )
        }
    }
}

/**
 * The theme-keyed opaque floor color backing [NativeSkeletonLoading]'s never-white guarantee.
 * Public so any render path outside `:composeblocks` that must not flash white can share this
 * exact value instead of duplicating the constant.
 */
fun skeletonFloorColor(themeMode: ThemeId): Color =
    if (themeMode == ThemeId.Dark) Color(0xFF121212) else Color(0xFFF2F2F2)

private val NoOpHostEventHandler =
    object : HostEventHandler {
        override fun onHostEvent(event: HostEvent) {}
    }

internal const val TAG_FLOOR = "flowNativeSkeletonFloor"
internal const val TAG_CONTENT = "flowNativeSkeletonContent"
