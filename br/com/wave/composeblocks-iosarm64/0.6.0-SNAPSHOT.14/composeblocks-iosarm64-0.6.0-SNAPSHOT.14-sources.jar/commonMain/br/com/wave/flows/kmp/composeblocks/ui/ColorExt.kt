package br.com.wave.flows.kmp.composeblocks.ui

import androidx.compose.ui.graphics.Color

internal fun String.toComposeColorOrNull(): Color? {
    val normalized = removePrefix("#")
    val value = normalized.toLongOrNull(16) ?: return null
    val argb = if (normalized.length <= 6) {
        0xFF000000 or value
    } else {
        value
    }
    return Color(argb)
}
