package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import br.com.wave.flows.kmp.composeblocks.ui.toComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.TabOption
import br.com.wave.flows.kmp.core.contract.TabsBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.visibility.setBlockVisibility
import br.com.wave.flows.kmp.runtime.api.RenderBlockInteractionCache

private val DefaultActiveColor = Color(0xFFFFFFFF)
private val DefaultActiveBackground = Color(0xFF0071D1)
private val DefaultInactiveColor = Color(0xFF0071D1)
private val DefaultInactiveBackground = Color(0xFFFFFFFF)
private val DefaultUnderlineColor = Color(0xFF0071D1)
private val DefaultUnderlineContainerBorder = Color(0xFFD0D0D0)

@Composable
internal fun renderTabsNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as TabsBlockConfig
    val options = config.options

    val routeStateKey = LocalRenderRouteStateKey.current
    val initialTabId = options.firstOrNull()?.id
    val cachedTabId = remember(routeStateKey, node.block.id) {
        RenderBlockInteractionCache.getSelection(
            routeId = routeStateKey,
            blockId = node.block.id,
            slot = "tabs.activeTabId",
        )
    }
    val effectiveInitialTabId = cachedTabId?.takeIf { saved -> options.any { it.id == saved } } ?: initialTabId
    var activeTabId by remember(node.block.id, routeStateKey) { mutableStateOf(effectiveInitialTabId) }

    val activeColor = config.activeColorHex?.toComposeColorOrNull() ?: DefaultActiveColor
    val activeBackground = config.activeBackgroundColorHex?.toComposeColorOrNull() ?: DefaultActiveBackground
    val inactiveColor = config.inactiveColorHex?.toComposeColorOrNull() ?: DefaultInactiveColor
    val inactiveBackground = config.inactiveBackgroundColorHex?.toComposeColorOrNull() ?: DefaultInactiveBackground
    val useUnderlineStyle = config.activeBackgroundColorHex == null && config.inactiveBackgroundColorHex == null
    val fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize
    val fontFamily = config.fontFamily.toComposeFontFamilyOrNull()
    val fontWeight = config.fontWeight?.toComposeFontWeight()

    Column(
        modifier = modifier
            .then(if (config.style.width == null) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style)
            .padding(
                if (useUnderlineStyle) {
                    config.style.toVerticalPaddingValues()
                } else {
                    config.style.toPaddingValues()
                },
            ),
    ) {
        if (useUnderlineStyle) {
            UnderlineTabsRow(
                options = options,
                activeTabId = activeTabId,
                activeColor = (config.activeColorHex?.toComposeColorOrNull() ?: DefaultUnderlineColor),
                inactiveColor = (config.inactiveColorHex?.toComposeColorOrNull() ?: Color(0xFF595959)),
                underlineColor = (config.activeColorHex?.toComposeColorOrNull() ?: DefaultUnderlineColor),
                containerBorderColor = DefaultUnderlineContainerBorder,
                fontSize = fontSize,
                fontFamily = fontFamily,
                fontWeight = fontWeight,
                onTabClick = { option ->
                    activeTabId = option.id
                    if (routeStateKey.isNotBlank()) {
                        RenderBlockInteractionCache.putSelection(
                            routeId = routeStateKey,
                            blockId = node.block.id,
                            value = option.id,
                            slot = "tabs.activeTabId",
                        )
                    }
                    var state = renderContext.currentVisibility()
                    options.forEach { candidate ->
                        state = setBlockVisibility(
                            state = state,
                            blockId = candidate.contentReferenceId,
                            value = candidate.id == option.id,
                        )
                    }
                    renderContext.onVisibilityChange(state)
                },
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(config.gap.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                options.forEach { option ->
                    val isActive = option.id == activeTabId
                    TabChip(
                        option = option,
                        isActive = isActive,
                        activeColor = activeColor,
                        activeBackground = activeBackground,
                        inactiveColor = inactiveColor,
                        inactiveBackground = inactiveBackground,
                        fontSize = fontSize,
                        fontFamily = fontFamily,
                        fontWeight = fontWeight,
                        onClick = {
                            activeTabId = option.id
                            if (routeStateKey.isNotBlank()) {
                                RenderBlockInteractionCache.putSelection(
                                    routeId = routeStateKey,
                                    blockId = node.block.id,
                                    value = option.id,
                                    slot = "tabs.activeTabId",
                                )
                            }
                            var state = renderContext.currentVisibility()
                            options.forEach { candidate ->
                                state = setBlockVisibility(
                                    state = state,
                                    blockId = candidate.contentReferenceId,
                                    value = candidate.id == option.id,
                                )
                            }
                            renderContext.onVisibilityChange(state)
                        },
                    )
                }
            }
        }

        node.children.forEach { child ->
            RenderResolvedNode(
                node = child,
                renderContext = renderContext,
                parentOrientation = BlockOrientation.VERTICAL,
            )
        }
    }
}

@Composable
private fun UnderlineTabsRow(
    options: List<TabOption>,
    activeTabId: String?,
    activeColor: Color,
    inactiveColor: Color,
    underlineColor: Color,
    containerBorderColor: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    fontFamily: androidx.compose.ui.text.font.FontFamily?,
    fontWeight: FontWeight?,
    onTabClick: (TabOption) -> Unit,
) {
    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(containerBorderColor)
                .padding(vertical = 0.5.dp),
        )
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(0.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                options.forEach { option ->
                    val isActive = option.id == activeTabId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onTabClick(option) }
                            .padding(PaddingValues(horizontal = 8.dp, vertical = 8.dp)),
                    ) {
                        Text(
                            text = option.label,
                            color = if (isActive) activeColor else inactiveColor,
                            fontSize = fontSize,
                            fontFamily = fontFamily,
                            fontWeight = fontWeight ?: if (isActive) FontWeight.SemiBold else FontWeight.Medium,
                            modifier = Modifier.align(Alignment.Center),
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(0.dp),
            ) {
                options.forEach { option ->
                    val isActive = option.id == activeTabId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isActive) underlineColor else Color.Transparent)
                            .padding(vertical = 1.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun TabChip(
    option: TabOption,
    isActive: Boolean,
    activeColor: Color,
    activeBackground: Color,
    inactiveColor: Color,
    inactiveBackground: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    fontFamily: androidx.compose.ui.text.font.FontFamily?,
    fontWeight: FontWeight?,
    onClick: () -> Unit,
) {
    val background = if (isActive) activeBackground else inactiveBackground
    val textColor = if (isActive) activeColor else inactiveColor
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(background, shape)
            .clickable(onClick = onClick)
            .padding(PaddingValues(horizontal = 16.dp, vertical = 8.dp)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = option.label,
            color = textColor,
            fontSize = fontSize,
            fontFamily = fontFamily,
            fontWeight = fontWeight ?: if (isActive) FontWeight.SemiBold else FontWeight.Medium,
        )
    }
}
