package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.CarouselBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import kotlin.math.roundToInt

@Composable
internal fun renderCarouselNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as CarouselBlockConfig
    val children = node.children
    val itemWidth = if (config.itemWidth > 0) config.itemWidth else 200
    val spacing = config.spacing

    val scrollState = rememberScrollState()
    val density = LocalDensity.current

    // Equalize card heights to the tallest, mirroring the web's flexbox stretch.
    // A free-scrolling Row composes every card eagerly, so the first measure pass
    // already sees all of them: each card reports its natural height, we keep the
    // max, then pin every card to it. (IntrinsicSize.Max would be the idiomatic
    // way, but it is unstable through `horizontalScroll` and jams the parent
    // LazyColumn's scrolling — so we measure explicitly instead.)
    var maxHeightPx by remember(children) { mutableStateOf(0) }

    Column(
        modifier = modifier
            .then(if (config.style.width == null) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (children.isEmpty()) return@Column

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(spacing.dp),
        ) {
            children.forEach { child ->
                Box(
                    modifier = Modifier
                        .width(itemWidth.dp)
                        .then(
                            if (maxHeightPx > 0) {
                                Modifier.height(with(density) { maxHeightPx.toDp() })
                            } else {
                                Modifier
                            },
                        )
                        .onSizeChanged { if (it.height > maxHeightPx) maxHeightPx = it.height },
                ) {
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                        modifier = Modifier.fillMaxHeight(),
                    )
                }
            }
        }

        if (config.showIndicators && children.size > 1) {
            // No paged snapping here (free scroll), so derive the active dot from the
            // scroll offset: each card advances by itemWidth + spacing.
            val activeIndex by remember(itemWidth, spacing, children.size) {
                derivedStateOf {
                    val stridePx = with(density) { (itemWidth + spacing).dp.toPx() }
                    if (stridePx <= 0f) {
                        0
                    } else {
                        (scrollState.value / stridePx).roundToInt().coerceIn(0, children.size - 1)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            ) {
                repeat(children.size) { index ->
                    val isActive = activeIndex == index
                    Box(
                        modifier = Modifier
                            .size(if (isActive) 8.dp else 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (isActive) Color(0xFF0071D1) else Color(0xFFCBD5E1),
                                CircleShape,
                            ),
                    )
                }
            }
        }
    }
}
