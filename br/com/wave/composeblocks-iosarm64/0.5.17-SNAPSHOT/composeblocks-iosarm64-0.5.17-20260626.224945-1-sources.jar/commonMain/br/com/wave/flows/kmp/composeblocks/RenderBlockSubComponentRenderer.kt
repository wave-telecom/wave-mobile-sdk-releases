package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.composeblocks.registry.ComposeRendererRegistry
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ScreenContract
import br.com.wave.flows.kmp.core.contract.SubComponentBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.runtime.buildRenderPlan
import br.com.wave.flows.kmp.core.visibility.buildInitialVisibilityState

/**
 * Renders a `sub-component` block: fetches the target component/flow's tree via the
 * render context's [contractProvider] and renders it in place. While the fetch is in
 * flight — or when it can't run (no provider, no target, or an embed cycle) — the
 * block's own [ResolvedRenderNode.children] are shown as the placeholder, per the
 * blocks API (`sub-component` "shows `children` while loading").
 */
@Composable
internal fun renderSubComponentNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as SubComponentBlockConfig
    val targetId = config.componentId?.takeIf { it.isNotBlank() }
        ?: config.flowId?.takeIf { it.isNotBlank() }
    val provider = renderContext.contractProvider
    val embedStack = LocalSubComponentStack.current

    // No provider / no target / cycle → just paint the inline placeholder.
    if (provider == null || targetId == null || targetId in embedStack) {
        SubComponentPlaceholder(node, modifier, renderContext)
        return
    }

    val externalCode = renderContext.externalCode
    val embedded by produceState<ScreenContract?>(initialValue = null, targetId, externalCode) {
        // Publish a cached hit first (instant placeholder→content swap when warm),
        // then the freshly resolved contract. Failures keep the placeholder up.
        value = runCatching { provider.getCachedScreenContract(targetId, externalCode) }.getOrNull()
        value = runCatching { provider.getScreenContract(targetId, externalCode) }.getOrNull() ?: value
    }

    val contract = embedded
    if (contract == null) {
        SubComponentPlaceholder(node, modifier, renderContext)
        return
    }

    val plan = remember(contract.root) {
        buildRenderPlan(
            block = contract.root,
            rendererRegistry = ComposeRendererRegistry.supportedRendererTypes,
            visibility = buildInitialVisibilityState(contract.root),
        )
    }
    val rootNode = plan.node
    if (rootNode == null) {
        SubComponentPlaceholder(node, modifier, renderContext)
        return
    }

    CompositionLocalProvider(LocalSubComponentStack provides (embedStack + targetId)) {
        RenderResolvedNode(
            node = rootNode,
            renderContext = renderContext,
            parentOrientation = parentOrientation,
            modifier = modifier,
        )
    }
}

@Composable
private fun SubComponentPlaceholder(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    Column(modifier = modifier) {
        node.children.forEach { child ->
            RenderResolvedNode(
                node = child,
                renderContext = renderContext,
                parentOrientation = BlockOrientation.VERTICAL,
            )
        }
    }
}
