package br.com.wave.flows.kmp.composeblocks

import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp

internal data class AdaptiveHorizontalPlacement(
    val layoutWidth: Int,
    val positions: List<Int>,
)

internal fun calculateAdaptiveHorizontalPlacement(
    itemWidths: List<Int>,
    spacingPx: Int,
    maxWidth: Int?,
    horizontalAlign: String?,
): AdaptiveHorizontalPlacement {
    val gapCount = (itemWidths.size - 1).coerceAtLeast(0)
    val intrinsicContentWidth = itemWidths.sum() + spacingPx * gapCount
    val layoutWidth = if (maxWidth != null) {
        maxOf(maxWidth, intrinsicContentWidth)
    } else {
        intrinsicContentWidth
    }
    val extraWidth = (layoutWidth - intrinsicContentWidth).coerceAtLeast(0)
    val normalizedAlign = horizontalAlign?.lowercase()
    val leadSpace = when (normalizedAlign) {
        "center" -> extraWidth / 2
        "end", "right" -> extraWidth
        else -> 0
    }
    val distributedGap =
        if (gapCount > 0 && normalizedAlign in setOf("space-around", "space-between", "space-evenly")) {
            extraWidth / gapCount
        } else {
            0
        }
    val gapRemainder =
        if (gapCount > 0 && normalizedAlign in setOf("space-around", "space-between", "space-evenly")) {
            extraWidth % gapCount
        } else {
            0
        }

    var x = leadSpace
    val positions = buildList(itemWidths.size) {
        itemWidths.forEachIndexed { index, width ->
            add(x)
            x += width
            if (index < itemWidths.lastIndex) {
                x += spacingPx + distributedGap + if (index < gapRemainder) 1 else 0
            }
        }
    }

    return AdaptiveHorizontalPlacement(
        layoutWidth = layoutWidth,
        positions = positions,
    )
}

@Composable
internal fun AdaptiveHorizontalListLayout(
    modifier: Modifier = Modifier,
    spacing: Int,
    horizontalAlign: String?,
    verticalAlign: String?,
    expandIndexes: Set<Int> = emptySet(),
    shrinkIndexes: Set<Int> = emptySet(),
    expandLastItem: Boolean = false,
    content: @Composable () -> Unit,
) {
    Layout(
        modifier = modifier,
        content = content,
    ) { measurables, constraints ->
        if (measurables.isEmpty()) {
            return@Layout layout(constraints.minWidth, constraints.minHeight) {}
        }

        val spacingPx = spacing.dp.roundToPx()
        val boundedMaxWidth = constraints.maxWidth.takeIf { constraints.hasBoundedWidth }
        val looseConstraints = Constraints(
            minWidth = 0,
            maxWidth = Constraints.Infinity,
            minHeight = 0,
            maxHeight = constraints.maxHeight,
        )
        val placeables = MutableList<Placeable?>(measurables.size) { null }
        var occupiedWidth = 0
        var measuredCount = 0

        measurables.forEachIndexed { index, measurable ->
            val shouldDeferExpand = boundedMaxWidth != null && (index in expandIndexes)
            val shouldDeferShrink = boundedMaxWidth != null &&
                (index in shrinkIndexes) && index !in expandIndexes
            if (shouldDeferExpand || shouldDeferShrink) return@forEachIndexed

            val shouldExpandLast = expandLastItem && boundedMaxWidth != null && index == measurables.lastIndex
            val placeable = if (shouldExpandLast) {
                val maxWidth = boundedMaxWidth ?: 0
                val remainingWidth = (maxWidth - occupiedWidth - spacingPx * measuredCount).coerceAtLeast(0)
                measurable.measure(
                    Constraints(
                        minWidth = remainingWidth,
                        maxWidth = remainingWidth,
                        minHeight = 0,
                        maxHeight = constraints.maxHeight,
                    ),
                )
            } else {
                measurable.measure(looseConstraints)
            }
            placeables[index] = placeable
            occupiedWidth += placeable.width
            measuredCount += 1
        }

        // Shrink-to-fit pass: cap each shrink item at the width still available after
        // the fixed children and gaps. Measured with `minWidth = 0`, so a short item
        // keeps its natural width (one line) and a long one is clamped to the cap and
        // wraps — matching the web flexbox. Items are measured in order, subtracting
        // each consumed width so multiple shrink siblings split what is left.
        val deferredShrink = shrinkIndexes.sorted()
            .filter { it in measurables.indices && it !in expandIndexes }
        if (boundedMaxWidth != null && deferredShrink.isNotEmpty()) {
            val gapsTotal = (measurables.size - 1).coerceAtLeast(0) * spacingPx
            var consumedWidth = placeables.filterNotNull().sumOf { it.width }
            deferredShrink.forEach { measurableIndex ->
                val availableWidth = (boundedMaxWidth - consumedWidth - gapsTotal).coerceAtLeast(0)
                val placeable = measurables[measurableIndex].measure(
                    Constraints(
                        minWidth = 0,
                        maxWidth = availableWidth,
                        minHeight = 0,
                        maxHeight = constraints.maxHeight,
                    ),
                )
                placeables[measurableIndex] = placeable
                consumedWidth += placeable.width
            }
        }

        val deferredExpand = expandIndexes.sorted().filter { it in measurables.indices }
        if (boundedMaxWidth != null && deferredExpand.isNotEmpty()) {
            val gapsTotal = (measurables.size - 1).coerceAtLeast(0) * spacingPx
            val fixedWidth = placeables.filterNotNull().sumOf { it.width }
            val remainingWidth = (boundedMaxWidth - fixedWidth - gapsTotal).coerceAtLeast(0)
            val baseWidth = remainingWidth / deferredExpand.size
            val remainder = remainingWidth % deferredExpand.size

            deferredExpand.forEachIndexed { idx, measurableIndex ->
                val itemWidth = baseWidth + if (idx < remainder) 1 else 0
                placeables[measurableIndex] = measurables[measurableIndex].measure(
                    Constraints(
                        minWidth = itemWidth,
                        maxWidth = itemWidth,
                        minHeight = 0,
                        maxHeight = constraints.maxHeight,
                    ),
                )
            }
        } else {
            deferredExpand.forEach { measurableIndex ->
                placeables[measurableIndex] = measurables[measurableIndex].measure(looseConstraints)
            }
        }

        val measuredPlaceables = placeables.mapNotNull { it }
        val placement = calculateAdaptiveHorizontalPlacement(
            itemWidths = measuredPlaceables.map { it.width },
            spacingPx = spacingPx,
            maxWidth = boundedMaxWidth,
            horizontalAlign = horizontalAlign,
        )
        val layoutHeight = measuredPlaceables.maxOfOrNull { it.height } ?: constraints.minHeight
        val verticalAlignment = verticalAlign.toVerticalAlignment()

        layout(width = placement.layoutWidth, height = layoutHeight) {
            measuredPlaceables.forEachIndexed { index, placeable ->
                val y = when (verticalAlignment) {
                    Alignment.CenterVertically -> (layoutHeight - placeable.height) / 2
                    Alignment.Bottom -> layoutHeight - placeable.height
                    else -> 0
                }
                placeable.placeRelative(x = placement.positions[index], y = y)
            }
        }
    }
}
