package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

/**
 * Compose port of the web `RichText` block: a paragraph composed of styled
 * inline segments. Block-level font props apply as defaults; each segment
 * can override font, color, and decoration. The `truncate` flag caps the
 * paragraph to a single line with an ellipsis, matching the web's CSS
 * `overflow:hidden; white-space:nowrap; text-overflow:ellipsis`.
 */
@Composable
internal fun renderRichTextNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as RichTextBlockConfig

    val baseColor = config.color?.toThemedComposeColorOrNull()
        ?: config.style.colorHex?.toThemedComposeColorOrNull()
        ?: Color.Unspecified
    val baseFontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize
    val baseFontFamily = config.fontFamily.toComposeFontFamilyOrNull()
    val baseFontWeight = config.fontWeight?.toComposeFontWeight()
    val baseFontStyle = config.fontStyle.toComposeFontStyleOrNull()
    val baseDecoration = if (config.strikethrough) TextDecoration.LineThrough else null

    // Resolve per-segment font families inside the composable scope (they
    // depend on `LocalRenderBlockFontResolver`) so the annotated-string
    // builder below can run as a plain lambda.
    val segmentStyles = config.segments.map { segment ->
        buildSegmentSpanStyle(
            segment = segment,
            baseColor = baseColor,
            baseDecoration = baseDecoration,
            resolvedFamily = segment.fontFamily.toComposeFontFamilyOrNull(),
        )
    }

    val annotated = buildAnnotatedString {
        config.segments.forEachIndexed { index, segment ->
            withStyle(segmentStyles[index]) { append(segment.text) }
        }
    }

    Text(
        text = annotated,
        modifier = modifier
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        textAlign = config.align.toComposeTextAlign() ?: TextAlign.Start,
        maxLines = if (config.truncate) 1 else Int.MAX_VALUE,
        overflow = if (config.truncate) TextOverflow.Ellipsis else TextOverflow.Clip,
        softWrap = !config.truncate,
        style = TextStyle(
            color = baseColor,
            fontSize = baseFontSize,
            fontFamily = baseFontFamily,
            fontWeight = baseFontWeight,
            fontStyle = baseFontStyle,
            textDecoration = baseDecoration,
        ),
    )
}

@Composable
@ReadOnlyComposable
private fun buildSegmentSpanStyle(
    segment: br.com.wave.flows.kmp.core.contract.RichTextSegment,
    baseColor: Color,
    baseDecoration: TextDecoration?,
    resolvedFamily: FontFamily?,
): SpanStyle {
    val decorations = buildList {
        if (segment.strikethrough) add(TextDecoration.LineThrough)
        if (segment.underline) add(TextDecoration.Underline)
    }
    val segmentDecoration = when {
        decorations.isEmpty() -> null
        decorations.size == 1 -> decorations.single()
        else -> TextDecoration.combine(decorations)
    }
    return SpanStyle(
        color = segment.color?.toThemedComposeColorOrNull() ?: baseColor,
        fontSize = segment.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
        fontFamily = resolvedFamily,
        fontWeight = segment.fontWeight?.toComposeFontWeight(),
        fontStyle = segment.fontStyle.toComposeFontStyleOrNull(),
        textDecoration = segmentDecoration ?: baseDecoration,
    )
}

private fun String?.toComposeFontStyleOrNull(): FontStyle? = when (this?.lowercase()) {
    "italic", "oblique" -> FontStyle.Italic
    "normal" -> FontStyle.Normal
    else -> null
}
