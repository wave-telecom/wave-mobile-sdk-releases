package br.com.wave.flows.kmp.composeblocks

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale

typealias RenderBlockImageContent = @Composable (
    model: String,
    contentDescription: String?,
    modifier: Modifier,
    contentScale: ContentScale,
    colorFilter: ColorFilter?,
) -> Unit

val LocalRenderBlockImageContent = compositionLocalOf<RenderBlockImageContent?> { null }
