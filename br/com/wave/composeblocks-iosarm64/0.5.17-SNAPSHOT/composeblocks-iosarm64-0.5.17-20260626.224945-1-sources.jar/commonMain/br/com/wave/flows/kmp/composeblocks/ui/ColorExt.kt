package br.com.wave.flows.kmp.composeblocks.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import br.com.wave.flows.kmp.composeblocks.theme.LocalFlowTheme

/**
 * Pure hex → Color conversion. Accepts:
 *   - `"transparent"` (case-insensitive)        → [Color.Transparent]
 *   - 6-digit hex `"#RRGGBB"` / `"RRGGBB"`      → opaque colour
 *   - 8-digit hex `"#AARRGGBB"` / `"AARRGGBB"`  → with alpha
 * Returns null for anything else (including unresolved `@{token}` strings).
 *
 * Kept non-`@Composable` because it has no Compose dependency — it is the
 * leaf step both [toThemedComposeColorOrNull] and any other caller end up
 * invoking once the input is a plain hex string.
 */
internal fun String.toComposeColorOrNull(): Color? {
    if (equals("transparent", ignoreCase = true)) {
        return Color.Transparent
    }
    val normalized = removePrefix("#")
    val value = normalized.toLongOrNull(16) ?: return null
    val argb = if (normalized.length <= 6) {
        0xFF000000 or value
    } else {
        value
    }
    return Color(argb)
}

/**
 * Theme-aware colour resolution for block config strings. If [this] is a
 * `@{token}` reference, looks it up in [LocalFlowTheme] first; otherwise
 * passes through. Then runs the literal hex parser. Returns null when:
 *   - the input is not a recognised hex literal AND not a known token, or
 *   - the input is a `@{token}` but no theme is configured (legacy mode).
 *
 * Callers stay textually identical to the old `toComposeColorOrNull()` —
 * only the implicit `@Composable` receiver is new.
 */
@Composable
@ReadOnlyComposable
internal fun String.toThemedComposeColorOrNull(): Color? {
    val resolved = LocalFlowTheme.current.resolveReference(this) ?: this
    return resolved.toComposeColorOrNull()
}
