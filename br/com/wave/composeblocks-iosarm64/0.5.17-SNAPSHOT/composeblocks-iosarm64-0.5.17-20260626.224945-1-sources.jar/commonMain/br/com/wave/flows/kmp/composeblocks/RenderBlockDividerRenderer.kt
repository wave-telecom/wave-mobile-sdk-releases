package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Divider
import androidx.compose.material3.DividerDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.DividerBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderDividerNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as DividerBlockConfig
    // The contract line color lands in `style.colorHex` (`color: "@{Tools.Divider}"`).
    // Without passing it through, Material's Divider falls back to its default
    // (outlineVariant), which is darker than the design's #D0D0D0.
    val lineColor = config.style.colorHex?.toThemedComposeColorOrNull() ?: DividerDefaults.color
    if (config.orientation == BlockOrientation.HORIZONTAL) {
        Divider(color = lineColor, modifier = modifier.fillMaxWidth().applyBlockStyle(config.style))
    } else {
        Spacer(modifier = modifier.height(1.dp).applyBlockStyle(config.style))
    }
}
