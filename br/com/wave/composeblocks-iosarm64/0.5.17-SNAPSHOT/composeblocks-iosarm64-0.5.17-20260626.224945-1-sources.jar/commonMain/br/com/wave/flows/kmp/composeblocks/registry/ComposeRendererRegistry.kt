package br.com.wave.flows.kmp.composeblocks.registry

import br.com.wave.flows.kmp.core.contract.BlockType

object ComposeRendererRegistry {
    val supportedRendererTypes: Set<String> = BlockType.entries.map { it.name }.toSet()
}
