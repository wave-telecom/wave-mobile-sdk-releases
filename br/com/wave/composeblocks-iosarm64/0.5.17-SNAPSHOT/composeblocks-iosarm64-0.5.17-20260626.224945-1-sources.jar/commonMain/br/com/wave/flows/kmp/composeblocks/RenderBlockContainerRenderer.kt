package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ContainerBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderContainerNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as ContainerBlockConfig
    val containerStyle = config.style
    val normalChildren = node.children.filterNot { child -> child.block.config.style.isAbsolutePosition() }
    val absoluteChildren = node.children.filter { child -> child.block.config.style.isAbsolutePosition() }

    val rootModifier = modifier
        .then(if (shouldFillWidth(containerStyle, parentOrientation)) Modifier.fillMaxWidth() else Modifier)
        .applyBlockStyle(containerStyle)

    Box(
        modifier = rootModifier.then(
            if (containerStyle.isAbsolutePosition()) {
                Modifier.offset(
                    x = containerStyle.toAbsoluteOffsetX(),
                    y = containerStyle.toAbsoluteOffsetY(),
                )
            } else {
                Modifier
            },
        ),
    ) {
        if (normalChildren.isNotEmpty()) {
            Column(modifier = Modifier.fillMaxWidth()) {
                normalChildren.forEach { child ->
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.VERTICAL,
                    )
                }
            }
        }

        absoluteChildren.forEach { child ->
            val childStyle = child.block.config.style
            Box(
                modifier = Modifier
                    .align(childStyle.toAbsoluteAlignment())
                    .offset(
                        x = childStyle.toAbsoluteOffsetX(),
                        y = childStyle.toAbsoluteOffsetY(),
                    ),
            ) {
                RenderResolvedNode(
                    node = child,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.HORIZONTAL,
                )
            }
        }
    }
}
