package br.com.wave.flows.kmp.composeblocks

import br.com.wave.flows.kmp.composeblocks.theme.FlowThemeStore
import br.com.wave.flows.kmp.core.contract.ScreenContractProvider
import br.com.wave.flows.kmp.core.host.HostEventHandler
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.runtime.InternalSdkEffect
import br.com.wave.flows.kmp.core.runtime.dispatchBlockAction
import br.com.wave.flows.kmp.core.visibility.VisibilityState
import br.com.wave.flows.kmp.runtime.MonotonicRuntimeClock
import br.com.wave.flows.kmp.runtime.RuntimeClock
import br.com.wave.flows.kmp.runtime.SystemRuntimeClock

internal data class RenderBlockRenderContext(
    val hostEventHandler: HostEventHandler,
    val currentVisibility: () -> VisibilityState,
    val onVisibilityChange: (VisibilityState) -> Unit,
    // Wall-clock: used for the action-tracking timestamp (epoch). Keep it wall.
    val clock: RuntimeClock = SystemRuntimeClock,
    // Monotonic: drives the refresh cooldown window so a device clock change can't
    // shorten/extend/break it. Injectable so tests can advance it deterministically.
    val cooldownClock: RuntimeClock = MonotonicRuntimeClock,
    // Source used by `sub-component` blocks to fetch the embedded component/flow's
    // tree. Null when the screen was rendered without a provider (e.g. a static
    // contract passed straight to RenderBlockScreen) — sub-components then just
    // render their placeholder children.
    val contractProvider: ScreenContractProvider? = null,
    val externalCode: String? = null,
)

internal fun RenderBlockRenderContext.dispatchNodeAction(node: ResolvedRenderNode) {
    val action = node.block.action ?: return
    val result = dispatchBlockAction(
        action = action,
        blockId = node.block.id,
        visibility = currentVisibility(),
        timestamp = clock.nowMillis().toString(),
    )

    result.hostEvents.forEach(hostEventHandler::onHostEvent)
    onVisibilityChange(result.visibility)
    result.internalEffects.forEach { effect ->
        when (effect) {
            InternalSdkEffect.ToggleThemeMode -> FlowThemeStore.toggle()
        }
    }
}
