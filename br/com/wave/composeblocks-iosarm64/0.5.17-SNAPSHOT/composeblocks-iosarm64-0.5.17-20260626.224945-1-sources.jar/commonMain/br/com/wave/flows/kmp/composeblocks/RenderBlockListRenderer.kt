package br.com.wave.flows.kmp.composeblocks

import kotlin.math.abs
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.SubcomposeLayout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.registry.ComposeRendererRegistry
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.ListBlockConfig
import br.com.wave.flows.kmp.core.contract.RichTextBlockConfig
import br.com.wave.flows.kmp.core.contract.SkeletonBlockConfig
import br.com.wave.flows.kmp.core.contract.TextBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode
import br.com.wave.flows.kmp.core.renderplan.createRenderPlan

@Composable
internal fun renderListNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
    parentOrientation: BlockOrientation?,
) {
    val config = node.block.config as ListBlockConfig
    val compactHorizontalItem = LocalCompactHorizontalItem.current
    val chartOverlayContent = LocalChartOverlayContent.current
    if (config.orientation == BlockOrientation.VERTICAL) {
        val tabOrder = LocalTabContentOrder.current
        val tabContentChild = node.children.firstOrNull { it.block.id in tabOrder }
        // When this list hosts a tab's content, let a horizontal swipe anywhere
        // over it (including the chart) switch tabs. The handler is registered
        // by the sibling `tabs` block via the screen-scoped swipe registry.
        val swipeHandler = tabContentChild?.let { LocalTabSwipeRegistry.current?.handlerFor(it.block.id) }
        val swipeModifier = if (swipeHandler != null) Modifier.tabSwipeGesture(swipeHandler) else Modifier
        CompositionLocalProvider(LocalCompactHorizontalItem provides false) {
            Column(
                modifier = modifier
                    .then(
                        if (shouldFillWidth(config.style, parentOrientation) && !compactHorizontalItem) {
                            Modifier.fillMaxWidth()
                        } else {
                            Modifier
                        },
                    )
                    // `expand` lists fill the parent's height (a no-op when the
                    // parent is wrap-content), giving space-* arrangements room to
                    // distribute — e.g. pinning a card's button to the bottom.
                    // Skip it inside a horizontal row: there `expand` means "share
                    // the width", and forcing fillMaxHeight on every column makes
                    // the row collapse vertically (no child supplies an intrinsic
                    // height), which drops table rows entirely.
                    .then(
                        if ((config.expand || LocalStretchTabContentHeight.current) &&
                            parentOrientation != BlockOrientation.HORIZONTAL
                        ) {
                            Modifier.fillMaxHeight()
                        } else {
                            Modifier
                        },
                    )
                    .applyBlockStyle(config.style)
                    .padding(
                        if (compactHorizontalItem) {
                            config.style.toVerticalPaddingValues()
                        } else {
                            config.style.toPaddingValues()
                        },
                    )
                    .then(swipeModifier),
                verticalArrangement = config.verticalAlign.toVerticalArrangement(config.spacing),
                horizontalAlignment = config.horizontalAlign.toHorizontalAlignment(),
            ) {
                if (tabContentChild != null) {
                    // This list hosts a tab's content: animate a tab switch with a
                    // directional horizontal slide — right→left when moving to a
                    // later tab, left→right when going back to an earlier one.
                    val tabContent: @Composable () -> Unit = {
                        val stretch = LocalStretchTabContentHeight.current
                        val fillHeight = if (stretch) Modifier.fillMaxHeight() else Modifier
                        AnimatedContent(
                            targetState = tabContentChild,
                            modifier = fillHeight,
                            transitionSpec = {
                                val from = tabOrder[initialState.block.id] ?: 0
                                val to = tabOrder[targetState.block.id] ?: 0
                                if (to >= from) {
                                    (slideInHorizontally { w -> w } + fadeIn()) togetherWith
                                        (slideOutHorizontally { w -> -w } + fadeOut())
                                } else {
                                    (slideInHorizontally { w -> -w } + fadeIn()) togetherWith
                                        (slideOutHorizontally { w -> w } + fadeOut())
                                }
                            },
                            label = "tabContent",
                        ) { child ->
                            RenderResolvedNode(
                                node = child,
                                renderContext = renderContext,
                                parentOrientation = BlockOrientation.VERTICAL,
                                modifier = fillHeight,
                            )
                        }
                    }
                    val candidates = rememberTabHeightCandidates(node, tabOrder, renderContext)
                    if (candidates.size > 1) {
                        TabContentWithReservedHeight(
                            candidates = candidates,
                            renderContext = renderContext,
                            content = tabContent,
                        )
                    } else {
                        tabContent()
                    }
                } else {
                    node.children.forEach { child ->
                        RenderResolvedNode(
                            node = child,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.VERTICAL,
                        )
                    }
                }
            }
        }
    } else {
        val centerUnalignedChartOverlayRow = chartOverlayContent && config.horizontalAlign == null
        val expandLastItem = node.children.lastOrNull()?.containsDivider() == true
        val expandIndexes = node.children.mapIndexedNotNull { index, child ->
            val childConfig = child.block.config
            // A width-less skeleton in a horizontal row would otherwise measure with
            // unbounded width, where `fillMaxWidth()` is a no-op → a 0-width (invisible)
            // bar. Treat it as an expand item so the layout splits the remaining width
            // among such bars (matching the contract's space-between skeleton rows).
            val skeletonWantsWidth = childConfig is SkeletonBlockConfig &&
                childConfig.width.isNullOrBlank()
            val shouldExpand = (childConfig is ListBlockConfig && childConfig.expand) ||
                childConfig.style.fullWidth == true ||
                skeletonWantsWidth
            if (shouldExpand) index else null
        }.toSet()
        // Text dropped straight into a horizontal row would otherwise measure with
        // unbounded width and lay out as a single line that overflows the row (the
        // web flexbox shrinks the item to fit; Compose's row does not). Mark every
        // un-truncated, width-less text/rich-text as a "shrink" item: the layout
        // caps it at the width still available so it stays on one line when it fits
        // (labels, prices) and wraps when it doesn't (the suspension alert message).
        // `fullWidth`/`expand` items already fill the row, so they are left to that
        // path instead.
        val shrinkIndexes = node.children.mapIndexedNotNull { index, child ->
            if (index in expandIndexes) return@mapIndexedNotNull null
            val childConfig = child.block.config
            val wantsShrink = when (childConfig) {
                is TextBlockConfig -> !childConfig.truncate && childConfig.style.width == null
                is RichTextBlockConfig -> !childConfig.truncate && childConfig.style.width == null
                else -> false
            }
            if (wantsShrink) index else null
        }.toSet()
        AdaptiveHorizontalListLayout(
            modifier = modifier
                .then(
                    if (shouldFillWidth(config.style, parentOrientation) && !centerUnalignedChartOverlayRow) {
                        Modifier.fillMaxWidth()
                    } else {
                        Modifier
                    },
                )
                .applyBlockStyle(config.style)
                .padding(config.style.toPaddingValues()),
            spacing = config.spacing,
            horizontalAlign = if (centerUnalignedChartOverlayRow) "center" else config.horizontalAlign,
            verticalAlign = config.verticalAlign,
            expandIndexes = expandIndexes,
            shrinkIndexes = shrinkIndexes,
            expandLastItem = expandLastItem,
        ) {
            node.children.forEachIndexed { index, child ->
                // Shrink items are width-capped by the layout, so they must NOT opt
                // into the compact single-line path (`wrapContentWidth(unbounded)` +
                // `maxLines = 1`) that the text renderer applies to horizontal-row
                // children — that would re-measure them unbounded and defeat the cap.
                val compact = index !in shrinkIndexes
                CompositionLocalProvider(LocalCompactHorizontalItem provides compact) {
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.HORIZONTAL,
                    )
                }
            }
        }
    }
}

private fun ResolvedRenderNode.containsDivider(): Boolean {
    return block.type == BlockType.DIVIDER || children.any { it.containsDivider() }
}

@Composable
private fun rememberTabHeightCandidates(
    hostNode: ResolvedRenderNode,
    tabOrder: Map<String, Int>,
    renderContext: RenderBlockRenderContext,
): List<ResolvedRenderNode> {
    return remember(hostNode.block, tabOrder) {
        val baseVisibility = renderContext.currentVisibility()
        hostNode.block.children
            .filter { it.id in tabOrder }
            .mapNotNull { child ->
                val visibility = baseVisibility.toMutableMap().apply { put(child.id, true) }
                createRenderPlan(
                    block = child,
                    rendererRegistry = ComposeRendererRegistry.supportedRendererTypes,
                    visibility = visibility,
                ).node
            }
    }
}

@Composable
private fun TabContentWithReservedHeight(
    candidates: List<ResolvedRenderNode>,
    renderContext: RenderBlockRenderContext,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    var reservedHeightPx by remember(candidates) { mutableStateOf(0) }
    Box(modifier = Modifier.fillMaxWidth()) {
        TabHeightProbe(candidates = candidates, renderContext = renderContext) { tallest ->
            if (tallest > reservedHeightPx) reservedHeightPx = tallest
        }
        if (reservedHeightPx > 0) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(with(density) { reservedHeightPx.toDp() }),
            ) {
                CompositionLocalProvider(LocalStretchTabContentHeight provides true) {
                    content()
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxWidth()) {
                content()
            }
        }
    }
}

@Composable
private fun TabHeightProbe(
    candidates: List<ResolvedRenderNode>,
    renderContext: RenderBlockRenderContext,
    onTallest: (Int) -> Unit,
) {
    SubcomposeLayout(modifier = Modifier.fillMaxWidth()) { constraints ->
        val measureConstraints = constraints.copy(minHeight = 0)
        val tallest = subcompose(Unit) {
            CompositionLocalProvider(LocalTabHeightMeasurementPass provides true) {
                candidates.forEach { candidate ->
                    Box(modifier = Modifier.fillMaxWidth()) {
                        RenderResolvedNode(
                            node = candidate,
                            renderContext = renderContext,
                            parentOrientation = BlockOrientation.VERTICAL,
                        )
                    }
                }
            }
        }.maxOfOrNull { it.measure(measureConstraints).height } ?: 0
        onTallest(tallest)
        layout(0, 0) {}
    }
}

/**
 * Detects a horizontal swipe over a tab's content and commits a tab change on
 * release: drag left → next tab (`+1`), drag right → previous (`-1`). Only
 * horizontal-dominant drags are consumed, so the vertical scroll of the screen
 * keeps working. The threshold avoids accidental switches on small drags.
 */
private fun Modifier.tabSwipeGesture(onSwipe: (Int) -> Unit): Modifier =
    this.pointerInput(onSwipe) {
        val thresholdPx = 56.dp.toPx()
        var totalDrag = 0f
        detectHorizontalDragGestures(
            onDragStart = { totalDrag = 0f },
            onDragEnd = {
                when {
                    totalDrag <= -thresholdPx -> onSwipe(1)
                    totalDrag >= thresholdPx -> onSwipe(-1)
                }
            },
        ) { change, dragAmount ->
            totalDrag += dragAmount
            // Only claim the drag once it's a deliberate tab swipe (past the
            // threshold). Before that, leave it unconsumed so a horizontally
            // scrollable child inside the tab content (e.g. a carousel) still
            // receives it instead of being starved.
            if (abs(totalDrag) >= thresholdPx) change.consume()
        }
    }
