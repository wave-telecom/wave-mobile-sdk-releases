package br.com.wave.flows.kmp.composeblocks

/**
 * Signals to renderers that they are pinned at the top of a `RenderBlock`
 * invocation — i.e. the host explicitly asked for *this* block to be the
 * root of a render tree.
 *
 * Default: `false`. Most rendered nodes are nested children and have no
 * reason to alter their behaviour based on rooting.
 *
 * Today only `renderBottomSheetNode` reads this: when called as root via
 * the in-RAM block index (host overlay path), the renderer skips the
 * Material `ModalBottomSheet` chrome and emits content only, leaving
 * presentation to the host. When called nested inside another contract
 * (legacy `onAction: "show"` path), the renderer still produces the
 * chrome so old contracts keep working.
 */
internal val LocalIsRootBlock = androidx.compose.runtime.compositionLocalOf { false }
