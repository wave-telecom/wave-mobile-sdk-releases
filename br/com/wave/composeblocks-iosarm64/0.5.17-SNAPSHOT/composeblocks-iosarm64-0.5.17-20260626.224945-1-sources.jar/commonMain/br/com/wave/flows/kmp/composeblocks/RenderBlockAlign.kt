package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/**
 * Maps a contract `align` value to a Box content-alignment, or null for
 * `start`/absent (the default left-aligned layout — no wrapper needed).
 */
internal fun String?.toBlockBoxAlignment(): Alignment? = when (this?.lowercase()) {
    "center" -> Alignment.Center
    "end", "right" -> Alignment.CenterEnd
    else -> null
}

/**
 * Honors a block's `config.align` for blocks that don't fill their parent's
 * width on their own (image, button): wraps [content] in a full-width Box
 * aligned per [align]. For `start`/null the content is emitted unwrapped, so
 * default left layout is untouched and no extra Box is introduced.
 */
@Composable
internal fun BlockHorizontalAlign(align: String?, content: @Composable () -> Unit) {
    val alignment = align.toBlockBoxAlignment()
    if (alignment != null) {
        Box(Modifier.fillMaxWidth(), contentAlignment = alignment) { content() }
    } else {
        content()
    }
}
