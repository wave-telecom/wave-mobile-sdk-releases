package br.com.wave.flows.kmp.composeblocks

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.text.font.FontFamily

fun interface RenderBlockFontResolver {
    fun resolve(fontFamily: String?): FontFamily?
}

val LocalRenderBlockFontResolver = compositionLocalOf<RenderBlockFontResolver?> { null }

@Composable
internal fun String?.toComposeFontFamilyOrNull(): FontFamily? {
    return LocalRenderBlockFontResolver.current?.resolve(this)
}
