package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.ImageBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderImageNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as ImageBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    val altText = config.altText.orEmpty().lowercase()
    val imageModifier = modifier
        .applyBlockStyle(config.style)
        .padding(config.style.toPaddingValues())
    val icon = when {
        "volver" in altText || "back" in altText -> Icons.AutoMirrored.Outlined.ArrowBack
        "configuración" in altText || "configuracion" in altText || "settings" in altText -> Icons.Outlined.Settings
        else -> null
    }
    val isRemoteUrl = config.url.startsWith("http://", ignoreCase = true) ||
        config.url.startsWith("https://", ignoreCase = true)
    val styleWidth = config.width ?: config.style.width
    val styleHeight = config.height ?: config.style.height
    val withConfiguredSize = when {
        styleWidth != null && styleHeight != null -> Modifier.size(width = styleWidth.dp, height = styleHeight.dp)
        styleWidth != null -> Modifier.width(styleWidth.dp)
        styleHeight != null -> Modifier.height(styleHeight.dp)
        else -> Modifier
    }

    BlockHorizontalAlign(config.align) {
        when {
            isRemoteUrl -> LocalRenderBlockImageContent.current?.invoke(
                config.url,
                config.altText ?: config.url,
                imageModifier
                    .then(withConfiguredSize)
                    .then(
                        if (styleWidth == null && styleHeight == null) {
                            Modifier.size(120.dp)
                        } else {
                            Modifier
                        },
                    ),
                config.aspectRatio.toContentScale(),
                (
                    radioGroupOverride.colorOverride
                        ?: config.style.colorHex?.toThemedComposeColorOrNull()
                        ?: LocalContentColorOverride.current.takeIf {
                            config.url.endsWith(".svg", ignoreCase = true)
                        }
                )?.let(ColorFilter::tint),
            ) ?: Box(
                modifier = imageModifier
                    .then(withConfiguredSize)
                    .then(
                        if (styleWidth == null && styleHeight == null) {
                            Modifier.size(120.dp)
                        } else {
                            Modifier
                        },
                    )
                    .background(Color(0xFFE5E7EB)),
            ) {
                Text(
                    text = config.altText ?: config.url,
                    modifier = Modifier.padding(8.dp),
                    color = Color(0xFF4B5563),
                    fontSize = 12.sp,
                )
            }

            icon != null -> Box(
                modifier = imageModifier
                    .size((config.style.width ?: 24).dp)
                    .background(config.style.backgroundColorHex?.toThemedComposeColorOrNull() ?: Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = config.altText ?: config.url,
                    tint = radioGroupOverride.colorOverride
                        ?: config.style.colorHex?.toThemedComposeColorOrNull()
                        ?: LocalContentColorOverride.current
                        ?: Color.Unspecified,
                )
            }

            else -> Box(
                modifier = imageModifier
                    .background(Color(0xFFE5E7EB)),
            ) {
                Text(
                    text = config.altText ?: config.url,
                    modifier = Modifier.padding(8.dp),
                    color = Color(0xFF4B5563),
                    fontSize = 12.sp,
                )
            }
        }
    }
}
