package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.ButtonBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderButtonNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as ButtonBlockConfig
    val radioGroupOverride = LocalRadioGroupStyleOverride.current
    val background = config.style.backgroundColorHex?.toThemedComposeColorOrNull()
    val textColor = radioGroupOverride.colorOverride
        ?: config.style.colorHex?.toThemedComposeColorOrNull()
    val isLink = background == null || background == Color.Transparent
    val contentColor = textColor ?: ButtonDefaults.buttonColors().contentColor

    if (isLink) {
        // Render as an inline text link — contracts use transparent buttons as
        // anchor-style affordances (e.g. "Mostrar detalles" on the home screen).
        BlockHorizontalAlign(config.align) {
            Row(
                modifier = modifier
                    .clickable { renderContext.dispatchNodeAction(node) }
                    .applyBlockStyle(config.style)
                    .padding(config.style.toPaddingValues()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = config.value,
                    color = textColor ?: Color.Unspecified,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(
                        fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
                        fontFamily = config.fontFamily.toComposeFontFamilyOrNull(),
                        fontWeight = config.fontWeight?.toComposeFontWeight(),
                        lineHeight = config.lineHeightSp?.sp ?: TextUnit.Unspecified,
                        lineHeightStyle = if (config.lineHeightSp != null) {
                            LineHeightStyle(
                                alignment = LineHeightStyle.Alignment.Center,
                                trim = LineHeightStyle.Trim.Both,
                            )
                        } else {
                            null
                        },
                    ),
                )
            }
        }
        return
    }

    val buttonModifier = if (shouldFillWidth(config.style, parentOrientation = null)) {
        modifier.fillMaxWidth()
    } else {
        modifier
    }.applyBlockStyle(config.style)

    // The height is NOT pinned: it emerges from the contract's box model
    // (padding + label line height), exactly like web. Padding comes straight from the
    // contract (`toPaddingValues`), and the label's line height comes from the contract
    // via `lineHeight` — `LineHeightStyle(Center, Trim.Both)` strips half-leading so the
    // line box equals the CSS line-height value — so `lineHeight:24` + vertical padding
    // 8/8 lands on 40px; with no contract lineHeight the label keeps the font's own line
    // box. We avoid a fixed `.height()` + inner `fillMaxHeight()` on purpose: inside a
    // height-equalizing parent (carousel card, `expand` list) those let the button
    // stretch past its box.
    BlockHorizontalAlign(config.align) {
        Surface(
            onClick = { renderContext.dispatchNodeAction(node) },
            modifier = buttonModifier,
            shape = config.style.toRoundedCornerShape(),
            color = background ?: ButtonDefaults.buttonColors().containerColor,
            contentColor = contentColor,
        ) {
            Box(
                modifier = Modifier.padding(config.style.toPaddingValues()),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = config.value,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(
                        fontSize = config.fontSizeSp?.sp ?: TextStyle.Default.fontSize,
                        fontFamily = config.fontFamily.toComposeFontFamilyOrNull(),
                        fontWeight = config.fontWeight?.toComposeFontWeight(),
                        lineHeight = config.lineHeightSp?.sp ?: TextUnit.Unspecified,
                        lineHeightStyle = if (config.lineHeightSp != null) {
                            LineHeightStyle(
                                alignment = LineHeightStyle.Alignment.Center,
                                trim = LineHeightStyle.Trim.Both,
                            )
                        } else {
                            null
                        },
                    ),
                )
            }
        }
    }
}
