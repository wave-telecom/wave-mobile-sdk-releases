package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.GridBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

/**
 * Renders a `grid` block: children laid out in a fixed-column grid.
 *
 * config:
 *  - `columns`       number of columns (>= 1)
 *  - `gap`           spacing in dp between cells, both axes
 *  - `maxColumnSize` max width (dp) a single column is allowed to grow to
 *
 * Non-lazy on purpose: grids appear inside the screen's own scroll container,
 * so a lazy grid here would nest scrollables. Children are chunked into rows of
 * `columns`; trailing cells in the last row are filled with empty weighted
 * boxes so columns stay aligned.
 */
@Composable
internal fun renderGridNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val config = node.block.config as GridBlockConfig
    val columns = config.columns.coerceAtLeast(1)
    val gap = config.gap.dp
    Column(
        // fillMaxWidth is essential: without it the Column measures at
        // min-content (e.g. inside a min-width parent) and the weighted cells
        // below collapse to ~0, breaking text into one glyph per line.
        modifier = modifier
            .fillMaxWidth()
            .applyBlockStyle(config.style)
            .padding(config.style.toPaddingValues()),
        verticalArrangement = Arrangement.spacedBy(gap),
    ) {
        if (columns <= 1) {
            // Single column is just a vertical stack — no weighting needed.
            node.children.forEach { child ->
                RenderResolvedNode(
                    node = child,
                    renderContext = renderContext,
                    parentOrientation = BlockOrientation.VERTICAL,
                )
            }
        } else {
            node.children.chunked(columns).forEach { rowChildren ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(gap),
                ) {
                    rowChildren.forEach { child ->
                        Box(modifier = Modifier.weight(1f)) {
                            RenderResolvedNode(
                                node = child,
                                renderContext = renderContext,
                                parentOrientation = BlockOrientation.VERTICAL,
                            )
                        }
                    }
                    // Keep columns aligned when the last row is partially filled.
                    repeat(columns - rowChildren.size) {
                        Box(Modifier.weight(1f)) {}
                    }
                }
            }
        }
    }
}
