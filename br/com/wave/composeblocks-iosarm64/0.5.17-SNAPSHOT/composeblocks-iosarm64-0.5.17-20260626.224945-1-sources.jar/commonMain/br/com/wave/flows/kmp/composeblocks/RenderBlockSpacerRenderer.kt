package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.core.contract.SpacerBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderSpacerNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as SpacerBlockConfig
    Spacer(modifier = modifier.height((config.style.marginBottom ?: 12).dp))
}
