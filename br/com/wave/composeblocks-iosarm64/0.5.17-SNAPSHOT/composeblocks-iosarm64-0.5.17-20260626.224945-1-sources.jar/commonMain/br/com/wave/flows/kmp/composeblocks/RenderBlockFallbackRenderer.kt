package br.com.wave.flows.kmp.composeblocks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.wave.flows.kmp.core.contract.BlockOrientation
import br.com.wave.flows.kmp.core.contract.BlockType
import br.com.wave.flows.kmp.core.contract.UnknownBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

@Composable
internal fun renderFallbackNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
    renderContext: RenderBlockRenderContext,
) {
    val rawType = (node.block.config as? UnknownBlockConfig)?.rawType
    val title = when {
        rawType != null -> "UNSUPPORTED BLOCK: $rawType"
        else -> "UNSUPPORTED BLOCK CONFIGURATION"
    }

    Column(
        modifier = modifier
            .then(if (node.block.type != BlockType.SPACER) Modifier.fillMaxWidth() else Modifier)
            .applyBlockStyle(node.block.config.style)
            .background(Color(0xFFB00020))
            .border(width = 3.dp, color = Color(0xFFFFF176))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = title,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
        )
        Text(
            text = "id=${node.block.id}",
            color = Color.White,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
        )
        node.block.contractErrors.forEach { error ->
            Text(
                text = "${error.code}: ${error.message}",
                color = Color(0xFFFFF176),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
            )
        }
        if (node.children.isNotEmpty()) {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                node.children.forEach { child ->
                    RenderResolvedNode(
                        node = child,
                        renderContext = renderContext,
                        parentOrientation = BlockOrientation.VERTICAL,
                    )
                }
            }
        }
    }
}
