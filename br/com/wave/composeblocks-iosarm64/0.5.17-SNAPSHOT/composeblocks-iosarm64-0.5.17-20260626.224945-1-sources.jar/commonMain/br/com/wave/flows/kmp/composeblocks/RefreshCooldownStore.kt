package br.com.wave.flows.kmp.composeblocks

import androidx.compose.runtime.mutableStateMapOf

/**
 * Process-wide cooldown ledger for `refresh`-action blocks, keyed by route + block id.
 *
 * The lock lives here — NOT in the block's own composition — on purpose: triggering a
 * refresh tears down and rebuilds the very subtree that owns the button (the screen
 * reloads, and `showPreload` contracts even flash a spinner in between). A `remember`
 * inside that subtree would reset the instant the refresh it armed completes, so the
 * button would never actually stay disabled. A snapshot-backed singleton outlives the
 * rebuild and is still observed by Compose — reads recompose when [lock]/[release]
 * mutate the map.
 *
 * Deadlines are absolute monotonic-clock millis (see MonotonicRuntimeClock), so a rebuild
 * mid-cooldown recomputes the remaining time from the deadline instead of restarting the
 * window, and a device clock change can't corrupt it.
 */
internal object RefreshCooldownStore {
    private val lockedUntilMillisByKey = mutableStateMapOf<String, Long>()

    /** Absolute deadline (monotonic millis) this key is locked until, or null if free. */
    fun lockedUntilMillis(key: String): Long? = lockedUntilMillisByKey[key]

    fun lock(key: String, untilMillis: Long) {
        lockedUntilMillisByKey[key] = untilMillis
    }

    fun release(key: String) {
        lockedUntilMillisByKey.remove(key)
    }

    /**
     * Drops every cooldown. Called on SDK session reset so a locked card whose node was
     * disposed before its window elapsed (e.g. logout / navigate-away) doesn't keep its
     * key around for the life of the process. See [clearRefreshCooldowns].
     */
    fun clear() {
        lockedUntilMillisByKey.clear()
    }
}

/**
 * Public hook for the SDK layer to wipe refresh cooldowns when a session is torn down or
 * restarted (alongside the contract-cache clear), preventing cross-session leakage.
 */
fun clearRefreshCooldowns() {
    RefreshCooldownStore.clear()
}
