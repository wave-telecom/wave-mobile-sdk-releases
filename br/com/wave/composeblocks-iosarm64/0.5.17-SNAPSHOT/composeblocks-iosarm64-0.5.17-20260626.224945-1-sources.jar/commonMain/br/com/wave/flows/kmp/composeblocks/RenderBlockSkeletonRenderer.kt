package br.com.wave.flows.kmp.composeblocks

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.wave.flows.kmp.composeblocks.ui.toThemedComposeColorOrNull
import br.com.wave.flows.kmp.core.contract.SkeletonBlockConfig
import br.com.wave.flows.kmp.core.renderplan.ResolvedRenderNode

private val DefaultSkeletonColor = Color(0xFFE0E0E0)

@Composable
internal fun renderSkeletonNode(
    node: ResolvedRenderNode,
    modifier: Modifier,
) {
    val config = node.block.config as SkeletonBlockConfig
    val transition = rememberInfiniteTransition(label = "skeletonPulse")
    val alpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "skeletonAlpha",
    )

    val barModifier = config.width.toSkeletonWidthModifier()
        .then(config.height.toSkeletonHeightModifier())
        .alpha(alpha)
        .clip(config.style.toRoundedCornerShape())
        .background(config.style.backgroundColorHex?.toThemedComposeColorOrNull() ?: DefaultSkeletonColor)

    if (!config.align.isNullOrBlank()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .applyBlockStyle(config.style, includeBackground = false),
        ) {
            Box(modifier = barModifier.then(skeletonAlignmentModifier(config.align)))
        }
    } else {
        Box(
            modifier = modifier
                .applyBlockStyle(config.style, includeBackground = false)
                .then(barModifier),
        )
    }
}

private fun String?.toSkeletonWidthModifier(): Modifier {
    val raw = this?.trim().orEmpty()
    if (raw.isBlank()) return Modifier.fillMaxWidth()

    val percentage = raw.removeSuffix("%").toFloatOrNull()
    return when {
        raw.endsWith("%") && percentage != null -> Modifier.fillMaxWidth((percentage / 100f).coerceIn(0.05f, 1f))
        raw.toIntOrNull() != null -> Modifier.width(raw.toInt().dp)
        else -> Modifier.fillMaxWidth()
    }
}

private fun String?.toSkeletonHeightModifier(): Modifier {
    val raw = this?.trim().orEmpty()
    if (raw.isBlank()) return Modifier.height(24.dp)

    val percentage = raw.removeSuffix("%").toFloatOrNull()
    return when {
        raw.endsWith("%") && percentage != null -> Modifier.height((24 * (percentage / 100f)).dp)
        raw.toIntOrNull() != null -> Modifier.height(raw.toInt().dp)
        else -> Modifier.height(24.dp)
    }
}

private fun BoxScope.skeletonAlignmentModifier(align: String?): Modifier {
    return when (align?.trim()?.lowercase()) {
        "center" -> Modifier.align(Alignment.Center)
        "end", "right" -> Modifier.align(Alignment.CenterEnd)
        "start", "left" -> Modifier.align(Alignment.CenterStart)
        else -> Modifier
    }
}
