package br.com.wave.flows.kmp.webblocks

import android.webkit.RenderProcessGoneDetail
import android.webkit.WebView
import com.multiplatform.webview.web.AccompanistWebViewClient
import com.multiplatform.webview.web.PlatformWebViewParams

/**
 * `AccompanistWebViewClient` is `open` and does not override `onRenderProcessGone`, so an
 * unhandled crash propagates uncaught and kills the integrator's host process. Subclassing it
 * (rather than a bare `WebViewClient`) keeps every other override — the library still wires
 * `state`/`navigator` onto this instance exactly as it does its own default client.
 */
internal actual fun rendererDeathWebViewParams(onRendererGone: () -> Unit): PlatformWebViewParams? =
    PlatformWebViewParams(
        client = object : AccompanistWebViewClient() {
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                onRendererGone()
                // Returning true tells Android we handled the crash — the host process survives.
                return true
            }
        },
    )
